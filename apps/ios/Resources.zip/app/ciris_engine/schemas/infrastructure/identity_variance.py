"""
Schemas for identity variance monitoring operations.

These replace all Dict[str, Any] usage in logic/infrastructure/sub_services/identity_variance_monitor.py.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Union

from pydantic import BaseModel, Field

from ciris_engine.schemas.types import JSONValue


class VarianceImpact(str, Enum):
    """Impact levels for different types of changes (not used in variance calculation)."""

    CRITICAL = "critical"  # Core purpose/ethics changes
    HIGH = "high"  # Capabilities/trust changes
    MEDIUM = "medium"  # Behavioral patterns
    LOW = "low"  # Preferences/templates


class IdentityDiff(BaseModel):
    """Represents a difference between baseline and current identity."""

    node_id: str = Field(..., description="Node ID where difference found")
    diff_type: str = Field(..., description="Type of difference: added, removed, modified")
    impact: VarianceImpact = Field(..., description="Impact level of the change")
    baseline_value: Optional[str] = Field(None, description="Value in baseline (serialized)")
    current_value: Optional[str] = Field(None, description="Current value (serialized)")
    description: str = Field(..., description="Human-readable description of difference")


class VarianceReport(BaseModel):
    """Complete variance analysis report."""

    timestamp: datetime = Field(..., description="When analysis was performed")
    baseline_snapshot_id: str = Field(..., description="ID of baseline snapshot")
    current_snapshot_id: str = Field(..., description="ID of current snapshot")
    total_variance: float = Field(..., description="Total variance percentage (simple count/total)")
    differences: List[IdentityDiff] = Field(default_factory=list, description="List of differences found")
    requires_wa_review: bool = Field(..., description="Whether WA review is required")
    recommendations: List[str] = Field(default_factory=list, description="Recommended actions")


# IdentitySnapshot moved to schemas/services/nodes.py as TypedGraphNode


class VarianceAnalysis(BaseModel):
    """Detailed variance analysis between snapshots."""

    baseline_nodes: Set[str] = Field(default_factory=set, description="Node IDs in baseline")
    current_nodes: Set[str] = Field(default_factory=set, description="Node IDs in current")
    added_nodes: Set[str] = Field(default_factory=set, description="Nodes added since baseline")
    removed_nodes: Set[str] = Field(default_factory=set, description="Nodes removed since baseline")
    modified_nodes: Set[str] = Field(default_factory=set, description="Nodes modified since baseline")
    variance_scores: Dict[str, float] = Field(default_factory=dict, description="Variance score by node")
    impact_counts: Dict[VarianceImpact, int] = Field(default_factory=dict, description="Count of changes by impact")


class WAReviewRequest(BaseModel):
    """Request for WA review of identity variance."""

    request_id: str = Field(..., description="Unique request ID")
    timestamp: datetime = Field(..., description="When request was made")
    current_variance: float = Field(..., description="Current variance percentage")
    variance_report: VarianceReport = Field(..., description="Full variance report")
    critical_changes: List[IdentityDiff] = Field(default_factory=list, description="Critical changes requiring review")
    proposed_actions: List[str] = Field(default_factory=list, description="Proposed corrective actions")
    urgency: str = Field("high", description="Review urgency level")


class VarianceCheckMetadata(BaseModel):
    """Metadata for variance check operations."""

    handler_name: str = Field("identity_variance_monitor", description="Handler performing check")
    check_type: str = Field(..., description="Type of check: scheduled, forced, triggered")
    check_reason: Optional[str] = Field(None, description="Reason for check if triggered")
    previous_check: Optional[datetime] = Field(None, description="Previous check timestamp")
    baseline_established: datetime = Field(..., description="When baseline was established")


class CurrentIdentityData(BaseModel):
    """Structured representation of current identity state extracted from nodes."""

    agent_id: str = Field("unknown", description="Agent ID")
    identity_hash: str = Field("unknown", description="Identity hash")
    core_purpose: str = Field("unknown", description="Core purpose description")
    role: str = Field("unknown", description="Role description")
    permitted_actions: List[str] = Field(default_factory=list, description="List of permitted actions")
    restricted_capabilities: List[str] = Field(default_factory=list, description="List of restricted capabilities")
    ethical_boundaries: List[str] = Field(default_factory=list, description="List of ethical boundaries")
    personality_traits: List[str] = Field(default_factory=list, description="List of personality traits")
    communication_style: str = Field("standard", description="Communication style")
    learning_enabled: bool = Field(True, description="Whether learning is enabled")
    adaptation_rate: float = Field(0.1, description="Rate of adaptation")


class IdentityAmendment(BaseModel):
    """A Wise Authority-approved change to the agent's identity, with its provenance."""

    node_id: str = Field(..., description="The amendment's graph node")
    content: str = Field(..., description="The approved identity text")
    wa_id: str = Field(..., description="The Wise Authority that approved it")
    deferral_id: str = Field(..., description="The deferral whose approval this is")
    granted_at: str = Field(..., description="ISO-8601 time the approval was applied")
    response_attestation_id: Optional[str] = Field(
        None, description="The Wise Authority's signed approval row it cites (CIRISAgent#1316), if any"
    )
    amendment_attestation_id: Optional[str] = Field(
        None, description="The signed identity_amendment:v1 row for this change (CIRISAgent#1316), if any"
    )
    approved_sha256: Optional[str] = Field(
        None, description="sha256 of the exact text the Wise Authority approved, as the approval recorded it (#1366 F1)"
    )
    verified: bool = Field(
        False,
        description=(
            "True only when sha256(content) equals the digest inside the WA's signed response row AND the node's "
            "signed identity_amendment:v1 row (#1366 F1). Only verified amendments reach the governance block the "
            "input-ablated consciences read. Set by the loader, never stored."
        ),
    )
    amendment_row_prev: Optional[str] = Field(
        None,
        description=(
            "The ``refs.prev`` of this amendment's signed identity_amendment row (rc21): the row it follows in the "
            "profile chain. Read from the signed row by the loader, never from local provenance."
        ),
    )
    base: bool = Field(
        False,
        description=(
            "The profile's BASE link (rc21): its approved digest is the base template's digest, not text; it has no "
            "content and never renders in the identity block."
        ),
    )


class IdentityProfileStatus(str, Enum):
    """The rc21 whole-profile check at load (wire.md section 3)."""

    VERIFIED = "verified"  # the held profile equals the signed chain's derived digest
    CONTESTED = "contested"  # two links name one prev: neither counts; the chain before them does
    UNANCHORED = "unanchored"  # no base link: the shipped template runs, no amendment is authoritative
    MISMATCH = "mismatch"  # the held profile differs from the chain's derived digest: load refused


class IdentityProfile(BaseModel):
    """The whole-profile digest of the identity the agent holds, and its check at load.

    ``profile_digest`` is SHA-256(CDE(["CEG-profile/2", d0, d1..dn])) over the
    bytes the agent loads: d0 the held base template, d1..dn the amendments of
    the signed chain. ``expected_profile_digest`` is the same over the chain's
    signed digests. Only when they are equal (``verified``, or ``contested``
    for the chain before the contested slot) do the chain's amendments count
    as verified; otherwise none does, and the agent keeps its base identity.
    """

    profile_digest: str = Field(..., description="sha256 hex of the held profile's CDE encoding")
    expected_profile_digest: Optional[str] = Field(
        None, description="sha256 hex derived from the signed chain; None when there is no base link"
    )
    status: IdentityProfileStatus = Field(..., description="Result of the load-time check")
    reason: str = Field(..., description="The rc21 token: profile_match, profile_contested, profile_unanchored, profile_digest_mismatch")
    template: Optional[str] = Field(None, description="The shipped template the held base is, if any")
    template_verified: bool = Field(
        False, description="The shipped template's bytes are in the template manifest under a verified root-WA signature"
    )
    base_digest: str = Field(..., description="sha256 hex of the held identity base")
    base_row_id: Optional[str] = Field(None, description="The base link's identity_amendment row id")
    chain_row_ids: List[str] = Field(default_factory=list, description="The counted chain after the base, in order")
    amendment_digests: List[str] = Field(default_factory=list, description="sha256 hex of each counted amendment, in order")
    contested_row_ids: List[str] = Field(default_factory=list, description="Links that name one prev (profile_contested)")
    waiting_row_ids: List[str] = Field(default_factory=list, description="Links whose prev is not held: they wait")

    @property
    def authoritative(self) -> bool:
        return self.status in (IdentityProfileStatus.VERIFIED, IdentityProfileStatus.CONTESTED)


class IdentityData(BaseModel):
    """Identity data schema for system snapshots - sourced from local graph memory."""

    agent_id: str = Field(..., description="Agent identifier")
    description: str = Field(..., description="Agent description")
    role: str = Field(..., description="Agent role description")
    trust_level: float = Field(0.5, ge=0.0, le=1.0, description="Agent trust level")
    stewardship: Optional[Union[str, JSONValue]] = Field(
        None, description="Stewardship description or data structure if present"
    )
    approved_amendments: List[IdentityAmendment] = Field(
        default_factory=list,
        description="Wise Authority-approved identity amendments, oldest first, rendered with the core identity",
    )
    profile: Optional[IdentityProfile] = Field(
        None,
        description=(
            "The whole-profile digest and its load-time check; rides the system snapshot into the trace. None when "
            "the identity was not loaded through the profile check."
        ),
    )


class IdentitySummary(BaseModel):
    """Summarized identity data for system contexts - sourced from local graph memory."""

    identity_purpose: Optional[str] = Field(None, description="Core identity purpose")
    identity_capabilities: List[str] = Field(default_factory=list, description="Identity capabilities")
    identity_restrictions: List[str] = Field(default_factory=list, description="Identity restrictions")


class ServiceStatusMetrics(BaseModel):
    """Custom metrics for service status reporting."""

    has_baseline: float = Field(0.0, description="1.0 if baseline exists, 0.0 otherwise")
    last_variance_check: Optional[str] = Field(None, description="ISO timestamp of last variance check")
    variance_threshold: float = Field(0.20, description="Variance threshold for triggering WA review")


class JSONDict(BaseModel):
    """Generic node attributes for parsing."""

    agent_id: Optional[str] = Field(None, description="Agent ID from node")
    identity_hash: Optional[str] = Field(None, description="Identity hash from node")
    description: Optional[str] = Field(None, description="Description field")
    role_description: Optional[str] = Field(None, description="Role description")
    permitted_actions: Optional[List[str]] = Field(None, description="Permitted actions")
    restricted_capabilities: Optional[List[str]] = Field(None, description="Restricted capabilities")
    areas_of_expertise: Optional[List[str]] = Field(None, description="Areas of expertise")
    startup_instructions: Optional[str] = Field(None, description="Startup instructions")
    ethical_boundaries: Optional[List[str]] = Field(None, description="Ethical boundaries")
    node_class: Optional[str] = Field(None, description="Node class type")
