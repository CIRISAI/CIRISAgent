"""Incident Service Module."""

from .service import IncidentManagementService

__all__ = ["IncidentManagementService"]
