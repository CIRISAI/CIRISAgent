"""Terminal handlers module."""
