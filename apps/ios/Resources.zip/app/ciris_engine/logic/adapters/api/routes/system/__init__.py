"""
System routes module.

This module provides a unified router that combines all system-related endpoints
organized into logical sub-modules:

- health: System health and time endpoints
- runtime: Runtime control and cognitive state transitions
- services: Services status and resource monitoring
- shutdown: Graceful and local shutdown
- adapters: Adapter management (list, load, unload, reload)
- adapter_config: Interactive adapter configuration workflow
- tools: Available tools listing

The main router is exported for backward compatibility with existing code
that imports `from ...routes.system import router`.
"""

from fastapi import APIRouter

from . import (
    adapter_config,
    adapters,
    agent_mode,
    data_management,
    fabric,
    health,
    llm_routes,
    peers,
    runtime,
    services,
    shutdown,
    skill_builder,
    skill_import,
    tools,
)

# Create the main router with the system prefix and tags
router = APIRouter(prefix="/system", tags=["system"])

# Include all sub-routers
# Health endpoints: /system/health, /system/time
router.include_router(health.router)

# Runtime control: /system/runtime/{action}, /system/state/transition
router.include_router(runtime.router)

# Services and resources: /system/services, /system/resources
router.include_router(services.router)

# Shutdown: /system/shutdown, /system/local-shutdown
router.include_router(shutdown.router)

# Data management: /system/data/reset-account, /system/data/wipe-signing-key
router.include_router(data_management.router)

# Skill import: /system/adapters/import-skill, /system/adapters/imported-skills
# NOTE: Must be registered BEFORE adapters.router to avoid {adapter_type} wildcard matching
router.include_router(skill_import.router)

# Adapter configuration workflow: /system/adapters/{type}/configure/*, /system/adapters/configure/*
router.include_router(adapter_config.router)

# Adapter management: /system/adapters/*
# NOTE: This router has /adapters/{adapter_type} which must come AFTER static routes
router.include_router(adapters.router)

# Skill builder: /system/skills/* (HyperCard-style card builder)
router.include_router(skill_builder.router)

# Tools: /system/tools
router.include_router(tools.router)

# LLM management: /system/llm/status, /system/llm/providers, /system/llm/distribution
router.include_router(llm_routes.router)

# AgentMode: /system/agent-mode (GET observer+, PUT system_admin)
router.include_router(agent_mode.router)

# Federation peer-bootstrap: NodeCode share/add (GET observer+, POST system_admin)
router.include_router(peers.router)

# Fabric component versions: /system/fabric (Trust-page substrate versions)
router.include_router(fabric.router)

from .schemas import (
    AdapterActionRequest,
    ConfigStepInfo,
    ConfigurableAdapterInfo,
    ConfigurableAdaptersResponse,
    ConfigurationCompleteRequest,
    ConfigurationCompleteResponse,
    ConfigurationSessionResponse,
    ConfigurationStatusResponse,
    PersistedConfigsResponse,
    RemovePersistedResponse,
    ResourceUsageResponse,
    RuntimeAction,
    RuntimeControlResponse,
    ServicesStatusResponse,
    ServiceStatus,
    ShutdownRequest,
    ShutdownResponse,
    StartupStatusResponse,
    StateTransitionRequest,
    StateTransitionResponse,
    StepExecutionRequest,
    StepExecutionResponse,
    SystemHealthResponse,
    SystemTimeResponse,
    ToolInfoResponse,
)

# Re-export schemas for backward compatibility
from .skill_import import (
    ImportedSkillInfo,
    ImportedSkillsListResponse,
    SkillImportRequest,
    SkillImportResponse,
    SkillPreviewResponse,
)

__all__ = [
    # Main router
    "router",
    # Schemas (for backward compatibility)
    "AdapterActionRequest",
    "ConfigStepInfo",
    "ConfigurableAdapterInfo",
    "ConfigurableAdaptersResponse",
    "ConfigurationCompleteRequest",
    "ConfigurationCompleteResponse",
    "ConfigurationSessionResponse",
    "ConfigurationStatusResponse",
    "PersistedConfigsResponse",
    "RemovePersistedResponse",
    "ResourceUsageResponse",
    "RuntimeAction",
    "RuntimeControlResponse",
    "ServiceStatus",
    "ServicesStatusResponse",
    "ShutdownRequest",
    "ShutdownResponse",
    "StartupStatusResponse",
    "StateTransitionRequest",
    "StateTransitionResponse",
    "StepExecutionRequest",
    "StepExecutionResponse",
    "SystemHealthResponse",
    "SystemTimeResponse",
    "ToolInfoResponse",
    # Skill import schemas
    "ImportedSkillInfo",
    "ImportedSkillsListResponse",
    "SkillImportRequest",
    "SkillImportResponse",
    "SkillPreviewResponse",
]
