"""
Dynamic loader for adapters.

Discovers and loads services from the ciris_adapters directory.
"""

import importlib
import importlib.util
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, cast

from ciris_engine.protocols.services import ServiceProtocol
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.runtime.manifest import ModuleLoadResult, ServiceManifest, ServiceMetadata, ServicePriority

logger = logging.getLogger(__name__)


class AdapterLoader:
    """Loads adapters from external packages."""

    def __init__(self, services_dir: Path | None = None) -> None:
        self.services_dir = services_dir or Path("ciris_adapters")
        self.loaded_services: Dict[str, ServiceMetadata] = {}

    def discover_services(self) -> List[ServiceManifest]:
        """Discover all adapters with valid manifests."""
        services: List[ServiceManifest] = []

        if not self.services_dir.exists():
            logger.info(f"Adapters directory not found: {self.services_dir}")
            return services

        for service_dir in self.services_dir.iterdir():
            if not service_dir.is_dir() or service_dir.name.startswith("_"):
                continue

            manifest_path = service_dir / "manifest.json"
            if manifest_path.exists():
                try:
                    with open(manifest_path, encoding="utf-8") as f:
                        manifest_data = json.load(f)

                    # Parse into typed manifest
                    manifest = ServiceManifest.model_validate(manifest_data)
                    # Store path separately for loading
                    setattr(manifest, "_path", service_dir)
                    services.append(manifest)
                    # DEBUG, not INFO. A user reporting a startup failure has to scroll
                    # past 63 of these to reach the line that matters, and did. The count
                    # is logged once below; the names are a debugging detail.
                    logger.debug(f"Discovered adapter: {manifest.module.name}")
                except Exception as e:
                    logger.error(f"Failed to load manifest from {service_dir}: {e}")

        if services:
            logger.info(
                "Discovered %d adapters: %s",
                len(services),
                ", ".join(sorted(m.module.name for m in services)),
            )

        return services

    def validate_manifest(self, manifest: ServiceManifest) -> bool:
        """Validate a service manifest has required fields."""
        # Use the manifest's built-in validation
        errors = manifest.validate_manifest()
        if errors:
            for error in errors:
                logger.error(f"Manifest validation error: {error}")
            return False
        return True

    def check_dependencies(self, manifest: ServiceManifest) -> bool:
        """Check if service dependencies are available."""
        # Check legacy dependencies format if present
        if not manifest.dependencies:
            return True

        # Check protocol dependencies
        for protocol in manifest.dependencies.protocols:
            try:
                parts = protocol.split(".")
                module = importlib.import_module(".".join(parts[:-1]))
                if not hasattr(module, parts[-1]):
                    logger.error(f"Protocol not found: {protocol}")
                    return False
            except ImportError as e:
                logger.error(f"Failed to import protocol {protocol}: {e}")
                return False

        # Check schema dependencies
        for schema in manifest.dependencies.schemas:
            try:
                importlib.import_module(schema)
            except ImportError as e:
                logger.error(f"Failed to import schema {schema}: {e}")
                return False

        return True

    def load_service_class(self, manifest: ServiceManifest, class_path: str) -> Optional[type[ServiceProtocol]]:
        """Load a specific service class by class path from a manifest.

        Args:
            manifest: The service manifest
            class_path: Specific class path to load (e.g., "reddit.service.RedditCommunicationService")

        Returns:
            The loaded service class or None if loading fails
        """
        if not self.validate_manifest(manifest):
            return None

        if not self.check_dependencies(manifest):
            logger.error(f"Dependencies not satisfied for {manifest.module.name}")
            return None

        parts = class_path.split(".")
        module_path = ".".join(parts[:-1])
        class_name = parts[-1]

        # Prefer fully-qualified package import (e.g. "ciris_adapters.<name>.<module>")
        # so the module is identity-equal with any other import site — loading the
        # same adapter under multiple adapter_ids must not create sibling module
        # instances, which leaks duplicate loggers, duplicate isinstance classes,
        # and duplicated module-level state.
        services_pkg = self.services_dir.name
        candidate_paths = []
        if services_pkg and not module_path.startswith(f"{services_pkg}."):
            candidate_paths.append(f"{services_pkg}.{module_path}")
        candidate_paths.append(module_path)

        for candidate in candidate_paths:
            try:
                module = importlib.import_module(candidate)
                service_class = getattr(module, class_name)
                logger.info(
                    f"Successfully loaded service class: {class_name} from {manifest.module.name} "
                    f"(module={candidate})"
                )
                return cast(type[ServiceProtocol], service_class)
            except ModuleNotFoundError:
                continue
            except Exception as e:
                logger.error(
                    f"Failed to load service class {class_path} from {manifest.module.name} "
                    f"via {candidate}: {type(e).__name__}: {e!r}",
                    exc_info=True,
                )
                return None

        # Final fallback: sys.path-based import for non-package layouts (e.g. tests
        # pointing services_dir at a plain directory without __init__.py).
        import sys

        sys.path.insert(0, str(self.services_dir))
        try:
            module = importlib.import_module(module_path)
            service_class = getattr(module, class_name)
            logger.warning(
                f"Loaded {class_name} from {manifest.module.name} via sys.path fallback "
                f"(module={module_path}); consider making {services_pkg!r} a package to avoid "
                f"duplicate module instances"
            )
            return cast(type[ServiceProtocol], service_class)
        except Exception as e:
            logger.error(
                f"Failed to load service class {class_path} from {manifest.module.name}: "
                f"{type(e).__name__}: {e!r}",
                exc_info=True,
            )
            return None
        finally:
            sys.path.pop(0)

    def load_service(self, manifest: ServiceManifest) -> Optional[type[ServiceProtocol]]:
        """Dynamically load a service class from manifest (loads first service in manifest)."""
        if not self.validate_manifest(manifest):
            return None

        if not self.check_dependencies(manifest):
            logger.error(f"Dependencies not satisfied for {manifest.module.name}")
            return None

        _service_path = getattr(manifest, "_path", None)
        if not _service_path:
            logger.error("Manifest missing path information")
            return None
        service_name = manifest.module.name

        # Get class path from manifest
        if manifest.services:
            service_class_path = manifest.services[0].class_path
        elif manifest.exports and "service_class" in manifest.exports:
            # Legacy format support
            export_value = manifest.exports["service_class"]
            service_class_path = export_value if isinstance(export_value, str) else export_value[0]
        else:
            logger.error("No service class path found in manifest")
            return None

        # Use the new load_service_class method
        service_class = self.load_service_class(manifest, service_class_path)
        if not service_class:
            return None

        # Create service metadata
        parts = service_class_path.split(".")
        class_name = parts[-1]
        service_meta = ServiceMetadata(
            service_type=manifest.services[0].type if manifest.services else ServiceType.LLM,
            module_name=service_name,
            class_name=class_name,
            version=manifest.module.version,
            is_mock=manifest.module.is_mock,
            capabilities=manifest.capabilities or [],
            priority=manifest.services[0].priority if manifest.services else ServicePriority.NORMAL,
            health_status="loaded",
        )
        self.loaded_services[service_name] = service_meta
        logger.info(f"Successfully loaded adapter: {service_name}")

        return service_class

    def get_service_metadata(self, service_name: str) -> Optional[ServiceMetadata]:
        """Get metadata for a loaded service."""
        return self.loaded_services.get(service_name)

    def _should_skip_manifest(self, manifest: Any, config: Any) -> Optional[str]:
        """Check if manifest should be skipped. Returns skip reason or None.

        Skips adapters that:
        1. Are mock services in production mode
        2. Have auto_load=False (require explicit user enablement)
        3. Have requires_consent=True (require wizard completion)
        4. Have opt_in_required=True (require explicit opt-in)

        These adapters will be loaded later by AdapterConfigurationService
        when the user completes the setup wizard and configuration is persisted.
        """
        module_name = manifest.module.name

        # Skip mock services in production
        if not getattr(config, "mock_llm", False) and manifest.module.is_mock:
            return f"Skipping mock service in production: {module_name}"

        # Skip adapters that don't auto-load (require explicit enablement)
        if not manifest.module.auto_load:
            return f"Skipping adapter with auto_load=False: {module_name} (requires wizard setup)"

        # Skip adapters that require consent (must complete wizard first)
        if manifest.module.requires_consent:
            return f"Skipping adapter with requires_consent=True: {module_name} (requires wizard consent)"

        # Skip adapters that require explicit opt-in
        if manifest.module.opt_in_required:
            return f"Skipping adapter with opt_in_required=True: {module_name} (requires explicit opt-in)"

        return None

    def _build_service_config(self, manifest: Any) -> dict[str, Any]:
        """Build configuration dict from manifest defaults."""
        service_config = {}
        if manifest.configuration:
            for key, param in manifest.configuration.items():
                service_config[key] = param.default
        return service_config

    def _register_service_declarations(self, manifest: Any, service_instance: Any, service_registry: Any) -> None:
        """Register all service declarations from manifest."""
        for service_decl in manifest.services:
            service_registry.register_global(
                service_type=service_decl.type,
                provider=service_instance,
                priority=ServicePriority[service_decl.priority.value],
                capabilities=service_decl.capabilities or manifest.capabilities or [],
                metadata=self.loaded_services[manifest.module.name].model_dump(),
            )

    def _log_mock_llm_startup(self, manifest: Any) -> None:
        """Log mock LLM service startup if applicable."""
        if manifest.module.is_mock:
            for service_decl in manifest.services:
                if service_decl.type == ServiceType.LLM:
                    from ciris_engine.logic.runtime.startup_logging import _log_service_started

                    _log_service_started(14, "MockLLMService")

    async def _initialize_single_adapter(self, manifest: Any, service_registry: Any, result: ModuleLoadResult) -> None:
        """Initialize a single adapter from manifest."""
        service_class = self.load_service(manifest)
        if not service_class:
            return

        try:
            service_config = self._build_service_config(manifest)
            service_instance = service_class(**service_config)
            await service_instance.start()

            self._register_service_declarations(manifest, service_instance, service_registry)

            service_meta = self.loaded_services[manifest.module.name]
            service_meta.health_status = "started"
            result.services_loaded.append(service_meta)
            logger.info(f"Initialized adapter: {manifest.module.name}")

            self._log_mock_llm_startup(manifest)

        except Exception as e:
            error_msg = f"Failed to initialize {manifest.module.name}: {e}"
            logger.error(error_msg)
            result.errors.append(error_msg)
            result.success = False

    async def initialize_adapters(self, service_registry: Any, config: Any) -> ModuleLoadResult:
        """Initialize all discovered adapters."""
        result = ModuleLoadResult(module_name="adapters", success=True)
        discovered = self.discover_services()

        for manifest in discovered:
            skip_reason = self._should_skip_manifest(manifest, config)
            if skip_reason:
                logger.info(skip_reason)
                result.warnings.append(skip_reason)
                continue

            await self._initialize_single_adapter(manifest, service_registry, result)

        return result
