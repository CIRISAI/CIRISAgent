"""`/v1/auth/*` — served by the NODE, reverse-proxied from the brain's listener.

NOT MOUNTED YET. Held for ciris-server 0.5.168 — see CIRISServer#389. This is
written and verified faithful (direct-to-node and through-this-proxy return
byte-identical responses), but the node refuses the owner credential the Python
accepts, and a failed login on the node writes NOTHING to the log, so the
failing branch cannot be localized: `resolve_login` miss and hash mismatch are
the same string on the wire (correctly — not leaking account existence is the
point) and neither leaves a trace anywhere else. Mounting this today would trade
a working login for one nobody can debug. Re-mount is two lines in `app.py`.

CIRISAgent#1028 / ciris-server 0.5.165 finished the Rust port of this surface, so
the 2752 lines of `routes/auth.py` this module replaces were a second
implementation of something the node already owned. The node is authoritative for
identity — `brain_adapter._SUBSTRATE_PREFIXES` has said so, listing `/v1/auth`
with the note "node owns identity" — but the client never reached it, because the
client's front door is the brain's :8080 and the node's surface is :4243. Two
implementations, and the one users met was the copy.

Measured on a set-up instance before this change:

    :8080  /v1/auth/oauth/providers -> 401   (Python's)     <- what the client got
    :4243  /v1/auth/oauth/providers -> 200   (the node's)   <- what was authoritative

That gap is not academic. The Python's `create_oauth_user` wrote `pubkey: ""`,
which persist refuses, so OAuth users lived in an in-memory dict with no key and
did not survive a restart; and `_decode_google_jwt_locally` read a Google JWT's
claims WITHOUT verifying its signature. Both are fixed in the node's port, and
neither could be fixed by us as long as the copy kept being the one that ran.

So this forwards rather than reimplements. Nothing here should ever grow a
decision — the moment this module starts deciding something about identity, the
duplication is back.

WHY A PROXY AND NOT A PORT CHANGE: pointing the client at :4243 is the topology
the fold is heading for, but it is a client-visible move (base URL, bundled
profiles, every saved node) and this release is not the place. The prefix arrives
at :8080 and leaves for the node; when the front door moves, this module is
deleted rather than rewritten.

REDIRECTS ARE RESPONSES HERE. `/v1/auth/oauth/{provider}/login` answers 307 with a
`Location` pointing at Google. An HTTP client that follows redirects by default
would chase it, and the caller would receive Google's HTML instead of the
redirect it must hand to a browser. `follow_redirects=False` is load-bearing.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Set

import httpx
from fastapi import APIRouter, HTTPException, Request, Response, status

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Authentication"])

#: The node's substrate listener. Fixed at 4243 by the fold (``node_fold``); the
#: env var exists for tests that stand the node up elsewhere.
NODE_UPSTREAM = os.environ.get("CIRIS_NODE_HTTP_URL", "http://127.0.0.1:4243")

#: The node binds :4243 a few seconds after :8080 starts serving.
NODE_STARTING_RETRY_AFTER_SECONDS = 2

#: Hop-by-hop headers, which describe THIS connection and must not be relayed
#: onto another one (RFC 9110 §7.6.1). `host` must be recomputed for the upstream
#: and `content-length` re-derived from the body httpx actually sends — relaying
#: a stale one truncates or hangs the request.
_HOP_BY_HOP: Set[str] = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
    "host",
    "content-length",
}

_TIMEOUT = httpx.Timeout(30.0, connect=5.0)

#: A single `/v1/auth/*` sub-path. Deliberately narrow: the node's auth surface is
#: `login`, `me`, `refresh`, `logout`, `attestation`, `owner-hint`, `api-keys/{id}`,
#: `oauth/{provider}/login|callback`, `native/{google,apple}`, `device/*`.
#: Everything in that set is [a-z0-9], `-`, `_`, `.` and `/`.
_SAFE_SUBPATH = re.compile(r"^[A-Za-z0-9._~/-]*$")


def _safe_subpath(path: str) -> str:
    """Validate the caller-supplied sub-path before it becomes an upstream URL.

    This handler forwards `/v1/auth/{path:path}`, so `path` is user-controlled and
    is concatenated into the node's URL. Without this, `..` segments escape the
    `/v1/auth/` prefix — httpx normalises them — and the proxy becomes a way to
    reach ANY node endpoint through a route that authenticates nothing. The node
    would answer as if we had asked. (Sonar S7044.)

    An allowlist, not a denylist: `..` alone is not enough, because encodings and
    backslashes reach the same place by other spellings. Anything outside the
    character set the node's own auth paths use is refused.
    """
    if not _SAFE_SUBPATH.match(path) or ".." in path or path.startswith("/"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid auth path")
    return path


def _log_agent_side_cert_inventory() -> None:
    """On a refused login, log the certs THIS side can see in the same store.

    Staged QA produced `login failed: no cert resolved for identifier
    identifier=jeff certs_scanned=5` while the agent had just written a WA named
    `jeff` to the same database, one second before the node composed. The node
    counts what it scanned but does not name it, and we log what we wrote but not
    what is still there at login time — so neither side's logs could answer the
    only question that matters: is the row absent, or present under a name the
    node does not match on?

    `certs_scanned=5` is consistent with BOTH. This closes that gap from our end.
    Diagnostic only — it never affects the response, and any failure to read is
    swallowed, because a logging aid must not be able to break a login.

    IT ALSO LOGS NO CALLER INPUT. It used to interpolate the request `path`
    (Sonar S5145), which was safe only because `_safe_subpath` had validated it
    upstream — the exact "depends on a check elsewhere staying correct" that the
    other log statement in this file carries a comment against. The value added
    nothing anyway: this only fires for a refused login, so the path is always
    `login`.

    Names are already logged verbatim by CIRIS_USER_CREATE at setup, so this adds
    no disclosure that the same log file does not already carry.
    """
    try:
        from ciris_engine.logic.persistence.stores import authentication_store

        certs = authentication_store.list_wa_certificates(active_only=False)
        summary = ", ".join(
            f"{getattr(c, 'name', '?')!r}/{getattr(c, 'wa_id', '?')[-6:]}"
            f"{'' if getattr(c, 'active', True) else ' INACTIVE'}"
            for c in (certs or [])[:12]
        )
        logger.warning(
            "auth proxy: the node REFUSED a login. Agent-side store holds %d cert(s): %s. "
            "Compare against the node's certs_scanned=. A DIFFERENT count is the "
            "signal: this side lists only rows passing _is_brain_wa_row (classic "
            "wa_id shape); anything else is skipped as a substrate-owned federation "
            "identity. If the two halves partition the same table differently, a "
            "brain-written cert can be invisible to the node's scan.",
            len(certs or []),
            summary or "(none)",
        )
    except Exception as exc:  # noqa: BLE001 — diagnostics must never break auth
        logger.debug("auth proxy: could not enumerate agent-side certs: %s", exc)


@router.get("/system/verify-status", include_in_schema=False)
async def proxy_verify_status_to_node(request: Request) -> Response:
    """Relay `GET /v1/system/verify-status` to the node.

    THE BUG THIS CLOSES. The client asks for CIRISVerify status every 30s. In
    node mode it calls `GET /v1/system/verify-status`; in AGENT mode it calls
    `GET /v1/auth/attestation`, which the Python router used to serve with a GET
    handler. 2.9.14 deleted that router and proxied `/v1/auth/*` to the node —
    whose attestation route is POST-only. So the agent-mode GET became a 405,
    38 times in one session on a live install, and verify never loaded:

        :8080 /v1/auth/attestation      GET=405   <- what the client calls
        :4243 /v1/auth/attestation      GET=405   <- node: POST-only (the cause)
        :4243 /v1/system/verify-status  GET=200   <- where the data actually is
        :8080 /v1/system/verify-status  GET=404   <- but we exposed no route to it

    The data was one hop away the whole time. Verify is substrate-owned now, so
    the answer is to expose the node's read-only route through the agent's front
    door rather than reinstate a Python attestation handler — which would be the
    duplication #1028 exists to remove.

    Deliberately NOT proxying `/v1/system/*` wholesale: that prefix is the
    brain's (agent, telemetry, runtime control), and a catch-all here would
    shadow those routes. One exact path, because exactly one moved.
    """
    url = f"{NODE_UPSTREAM}/v1/system/verify-status"
    headers = {k: v for k, v in request.headers.items() if k.lower() not in _HOP_BY_HOP}

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, follow_redirects=False) as client:
            upstream = await client.get(url, params=request.query_params, headers=headers)
    except httpx.RequestError:
        # Same reasoning as the auth proxy: name the UPSTREAM, never the caller's
        # path, and answer 502 — the node being unreachable is infrastructure,
        # not a verdict about this request.
        logger.exception("verify-status proxy could not reach the node at %s", NODE_UPSTREAM)
        return Response(
            content=b'{"detail":"verification service unavailable"}',
            status_code=502,
            media_type="application/json",
        )

    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        headers={k: v for k, v in upstream.headers.items() if k.lower() not in _HOP_BY_HOP},
    )


@router.api_route(
    "/auth/{path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    include_in_schema=False,
)
async def proxy_auth_to_node(path: str, request: Request) -> Response:
    """Relay one `/v1/auth/*` call to the node and return what it says.

    Deliberately opaque: no status interpretation, no body parsing, no schema.
    Whatever the node decides about identity is what the caller sees, including
    its errors — a proxy that "helpfully" rewrites an upstream failure is how the
    two implementations diverge again.
    """
    url = f"{NODE_UPSTREAM}/v1/auth/{_safe_subpath(path)}"
    headers = {k: v for k, v in request.headers.items() if k.lower() not in _HOP_BY_HOP}

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT, follow_redirects=False) as client:
            upstream = await client.request(
                request.method,
                url,
                params=request.query_params,
                headers=headers,
                content=await request.body(),
            )
    except httpx.RequestError as exc:
        from ciris_engine.logic.runtime.node_fold import node_booting

        if node_booting():
            # The boot window: :8080 serves before the node binds :4243. Not an
            # outage, and not an auth decision -- the identity service is still
            # starting. 503 + Retry-After tells the caller to come back; WARNING,
            # not ERROR, because nothing has failed. A miss once the node is
            # listening still logs ERROR below (CIRISAgent#1262 staged QA).
            logger.warning(
                "auth proxy: the node is still starting (not yet listening at %s); answered 503, retry in %ss",
                NODE_UPSTREAM,
                NODE_STARTING_RETRY_AFTER_SECONDS,
            )
            return Response(
                content=b'{"detail":"identity service starting"}',
                status_code=503,
                headers={"Retry-After": str(NODE_STARTING_RETRY_AFTER_SECONDS)},
                media_type="application/json",
            )
        # The node not being reachable is an infrastructure failure, not an auth
        # decision. 502 says so; 401 would tell the caller their credentials were
        # rejected by something that never saw them.
        # Log the UPSTREAM, never the caller's path — it is user-controlled, and a
        # CRLF in it forges log lines (Sonar S5145). The path is already validated
        # above, but a log statement should not depend on a check elsewhere staying
        # correct. The exception text is the diagnostic value here anyway.
        logger.exception("auth proxy could not reach the node at %s", NODE_UPSTREAM)
        return Response(
            content=b'{"detail":"identity service unavailable"}',
            status_code=502,
            media_type="application/json",
        )

    # A refused LOGIN is the one 401 worth explaining, because it is the only one
    # where both halves have an opinion about the same rows.
    if upstream.status_code == 401 and path.rstrip("/").endswith("login"):
        _log_agent_side_cert_inventory()

    return Response(
        content=upstream.content,
        status_code=upstream.status_code,
        headers={k: v for k, v in upstream.headers.items() if k.lower() not in _HOP_BY_HOP},
    )
