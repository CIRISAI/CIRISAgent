"""Context building utilities for Action Selection PDMA."""

import logging
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Union

if TYPE_CHECKING:
    from ciris_engine.logic.dma.prompt_loader import DMAPromptLoader

from ciris_engine.logic.formatters import format_system_snapshot, format_user_profiles
from ciris_engine.schemas.dma.faculty import ConscienceFailureContext, EnhancedDMAInputs
from ciris_engine.schemas.dma.prompts import PromptCollection
from ciris_engine.schemas.dma.results import CSDMAResult, DSDMAResult, EthicalDMAResult, IDMAResult
from ciris_engine.schemas.runtime.enums import HandlerActionType
from ciris_engine.schemas.runtime.models import Task, Thought
from ciris_engine.schemas.types import JSONDict

logger = logging.getLogger(__name__)


class ActionSelectionContextBuilder:
    """Builds context for action selection evaluation."""

    def __init__(
        self,
        prompts: Union[Dict[str, str], PromptCollection],
        service_registry: Optional[Any] = None,
        bus_manager: Optional[Any] = None,
    ):
        self.prompts = prompts
        self.service_registry = service_registry
        self.bus_manager = bus_manager
        self._instruction_generator: Optional[Any] = None
        self._tools_cached: bool = False
        self._cached_task: Optional[Task] = None
        self._cached_installable_tools: Optional[str] = None

    async def pre_cache_context(self, thought: Thought) -> int:
        """Pre-cache tools and task context before building prompt.

        MUST be called before build_main_user_content().
        Returns the number of tools cached.
        """
        # Ensure instruction generator is initialized
        if self._instruction_generator is None:
            from ciris_engine.logic.dma.action_selection.action_instruction_generator import ActionInstructionGenerator

            self._instruction_generator = ActionInstructionGenerator(self.service_registry, self.bus_manager)

        # Pre-cache tools asynchronously
        tool_count: int = await self._instruction_generator.pre_cache_tools()
        self._tools_cached = True
        logger.info(f"[CONTEXT] Pre-cached {tool_count} tools for action selection")

        # Pre-cache the original task for this thought (sync operation)
        self._cache_original_task(thought)

        # Pre-cache installable tools (async)
        await self._cache_installable_tools()

        return tool_count

    async def _cache_installable_tools(self) -> None:
        """Pre-cache the installable tools string asynchronously."""
        try:
            from ciris_engine.logic.services.tool.discovery_service import AdapterDiscoveryService

            discovery = AdapterDiscoveryService()
            report = await discovery.get_discovery_report()

            if not report.ineligible:
                self._cached_installable_tools = ""
                return

            # Filter to only installable adapters (those with install hints)
            installable = [a for a in report.ineligible if a.can_install and a.install_hints]

            if not installable:
                self._cached_installable_tools = ""
                return

            lines = [
                "\n\n## Tools Available for Installation",
                "The following tools are NOT currently available but CAN be installed.",
                "If you need one of these tools, use SPEAK to ask the user to install it.",
                "",
            ]

            for adapter in installable[:10]:  # Limit to 10 to avoid prompt bloat
                # Get tool names from the adapter
                tool_names = [t.name for t in adapter.tools] if adapter.tools else [adapter.name]
                tools_str = ", ".join(tool_names[:3])  # Show up to 3 tool names
                if len(tool_names) > 3:
                    tools_str += f" (+{len(tool_names) - 3} more)"

                # Get missing dependencies
                missing = []
                if adapter.missing_binaries:
                    missing.append(f"binaries: {', '.join(adapter.missing_binaries[:3])}")
                if adapter.missing_env_vars:
                    missing.append(f"env vars: {', '.join(adapter.missing_env_vars[:2])}")
                missing_str = "; ".join(missing) if missing else "dependencies"

                # Get install method hints
                install_methods = list({h.kind for h in adapter.install_hints[:3]})
                methods_str = ", ".join(install_methods)

                lines.append(f"- **{adapter.name}** (tools: {tools_str})")
                lines.append(f"  Missing: {missing_str}")
                lines.append(f"  Install via: {methods_str}")

            lines.append("")
            lines.append(
                "💡 If the user's request would benefit from one of these tools, "
                'use SPEAK to tell them: "I could help better with [tool] but it needs to be installed. '
                'Would you like me to guide you through installing it?"'
            )

            self._cached_installable_tools = "\n".join(lines)
            logger.info(f"[CONTEXT] Pre-cached {len(installable)} installable tools")

        except Exception as e:
            logger.debug(f"[CONTEXT] Could not cache installable tools: {e}")
            self._cached_installable_tools = ""

    async def pre_cache_tools(self) -> int:
        """Legacy method - prefer pre_cache_context() which also caches task."""
        if self._instruction_generator is None:
            from ciris_engine.logic.dma.action_selection.action_instruction_generator import ActionInstructionGenerator

            self._instruction_generator = ActionInstructionGenerator(self.service_registry, self.bus_manager)

        tool_count: int = await self._instruction_generator.pre_cache_tools()
        self._tools_cached = True
        logger.info(f"[CONTEXT] Pre-cached {tool_count} tools for action selection")
        return tool_count

    def _cache_original_task(self, thought: Thought) -> None:
        """Cache the original task that spawned this thought chain."""
        from ciris_engine.logic import persistence

        try:
            source_task_id = thought.source_task_id
            agent_occurrence_id = thought.agent_occurrence_id

            logger.info(f"[CONTEXT] Fetching original task {source_task_id} for thought {thought.thought_id}")

            task = persistence.get_task_by_id(source_task_id, agent_occurrence_id)
            if task:
                self._cached_task = task
                logger.info(
                    f"[CONTEXT] ✓ Cached original task: '{task.description[:80]}...' (depth={thought.thought_depth})"
                )

                # If there's a parent task, log it for context
                if task.context and task.context.parent_task_id:
                    parent_task = persistence.get_task_by_id(task.context.parent_task_id, agent_occurrence_id)
                    if parent_task:
                        logger.info(f"[CONTEXT]   Parent task: '{parent_task.description[:80]}...'")
            else:
                logger.warning(f"[CONTEXT] Task {source_task_id} not found in persistence")
                self._cached_task = None

        except Exception as e:
            logger.error(f"[CONTEXT] Failed to cache original task: {e}")
            self._cached_task = None

    def build_main_user_content(self, triaged_inputs: EnhancedDMAInputs, agent_name: Optional[str] = None) -> str:
        """Build the main user content for LLM evaluation."""

        logger.info("[CONTEXT] Building main user content for action selection")

        # Extract core components from typed input
        original_thought = triaged_inputs.original_thought
        ethical_pdma_result = triaged_inputs.ethical_pdma_result
        csdma_result = triaged_inputs.csdma_result
        dsdma_result = triaged_inputs.dsdma_result
        idma_result = getattr(triaged_inputs, "idma_result", None)
        current_thought_depth = triaged_inputs.current_thought_depth
        max_rounds = triaged_inputs.max_rounds

        # Build context sections
        permitted_actions = self._get_permitted_actions(triaged_inputs)
        _action_options_str = ", ".join([a.value for a in permitted_actions])

        _available_tools_str = self._get_available_tools_str(permitted_actions)
        _installable_tools_str = self._get_installable_tools_str()

        # Build DMA summaries
        _ethical_summary = self._build_ethical_summary(ethical_pdma_result)
        _csdma_summary = self._build_csdma_summary(csdma_result)
        _dsdma_summary_str = self._build_dsdma_summary(dsdma_result)
        _idma_summary_str = self._build_idma_summary(idma_result)

        # Build ponder context
        _ponder_notes_str = self._build_ponder_context(original_thought, current_thought_depth)

        # Build final attempt advisory
        _final_ponder_advisory = self._build_final_attempt_advisory(current_thought_depth, max_rounds, agent_name)

        # Build guidance sections
        _guidance_sections = self._build_guidance_sections(agent_name, permitted_actions)

        # Build system context
        processing_context = triaged_inputs.processing_context
        user_profile_context_str, system_snapshot_context_str = self._build_system_context(processing_context)

        # Log context size details
        if user_profile_context_str:
            logger.info(f"[CONTEXT] User profile context: {len(user_profile_context_str)} chars")
        if system_snapshot_context_str:
            logger.info(f"[CONTEXT] System snapshot context: {len(system_snapshot_context_str)} chars")

        # Build startup guidance
        _startup_guidance = self._build_startup_guidance(original_thought)

        # Build conscience feedback guidance if available
        conscience_feedback = getattr(triaged_inputs, "conscience_feedback", None)
        _conscience_guidance = self._build_conscience_guidance(conscience_feedback)

        # If a DMA bounce ran AND any DMA exhausted without finding a passing
        # alternative, fold its difficulty rationale into the conscience-guidance
        # slot so ASPDMA sees it without a new template variable. Resolved
        # bounces are invisible — the higher-rated DMA result already replaced
        # the original on csdma_result / dsdma_result.
        bounce_summary = getattr(triaged_inputs, "bounce_summary", None)
        if bounce_summary and getattr(bounce_summary, "any_exhausted", False):
            from ciris_engine.logic.utils.localization import get_preferred_language, get_string

            rationale = getattr(bounce_summary, "difficulty_rationale", None) or "(no rationale)"
            advisory = get_string(
                get_preferred_language(),
                "prompts.dma.bounce_advisory_aspdma",
                rationale=rationale,
            )
            _conscience_guidance = f"{_conscience_guidance}{advisory}" if _conscience_guidance else advisory

        # Get reject thought guidance
        _reject_thought_guidance = self._get_reject_thought_guidance()

        # Extract all guidance sections for template formatting
        _action_parameter_schemas = _guidance_sections.get("action_parameter_schemas", "")
        _action_parameters_speak_csdma_guidance = _guidance_sections.get("action_parameters_speak_csdma_guidance", "")
        _action_parameters_ponder_guidance = _guidance_sections.get("action_parameters_ponder_guidance", "")
        _action_parameters_observe_guidance = _guidance_sections.get("action_parameters_observe_guidance", "")
        _reasoning_csdma_guidance = _guidance_sections.get("reasoning_csdma_guidance", "")

        # Build original task context
        _original_task_str = self._build_original_task_context(original_thought)

        # Render the routed user-message template (#974 step 1, FSD
        # RESEARCH_PROMPT_OVERRIDES §11.1). The ~90-line action doctrine that
        # used to live here as a Python literal is now the context_integration
        # field of prompts/action_selection_pdma.yml, rendered through
        # DMAPromptLoader.get_user_message so localized templates and the
        # research-override dma_prompt namespace both intercept it
        # (key: action_selection_pdma.context_integration). The {slot}
        # structure is structural; only the values are supplied here.
        loader, template_data = self._load_user_template()
        _slots: Dict[str, Any] = {
            "action_options_str": _action_options_str,
            "available_tools_str": _available_tools_str,
            "installable_tools_str": _installable_tools_str,
            "startup_guidance": _startup_guidance,
            "conscience_guidance": _conscience_guidance,
            "reject_thought_guidance": _reject_thought_guidance,
            "action_parameter_schemas": _action_parameter_schemas,
            "action_parameters_speak_csdma_guidance": _action_parameters_speak_csdma_guidance,
            "action_parameters_ponder_guidance": _action_parameters_ponder_guidance,
            "action_parameters_observe_guidance": _action_parameters_observe_guidance,
            "reasoning_csdma_guidance": _reasoning_csdma_guidance,
            "final_ponder_advisory": _final_ponder_advisory,
            "original_thought_content": original_thought.content,
            "original_task_str": _original_task_str,
            "thought_depth": original_thought.thought_depth,
            "ponder_notes_str": _ponder_notes_str,
            "user_profile_context_str": user_profile_context_str,
            "system_snapshot_context_str": system_snapshot_context_str,
            "ethical_summary": _ethical_summary,
            "csdma_summary": _csdma_summary,
            "dsdma_summary_str": _dsdma_summary_str,
            "idma_summary_str": _idma_summary_str,
        }
        formatted_content = loader.get_user_message(template_data, **_slots)

        # Three localized blocks the template has no {slot} for — #993, and the
        # #990 pair. Every slot in `context_integration` is filled and every
        # value supplied has a slot; these keys sit outside that closed set, so
        # they were loaded, localized into 29 languages, and discarded.
        #
        # `tool_selection_guidance` is the tool-hallucination guard: "Use the
        # EXACT tool name from the 'Available tools' list. Do NOT invent or
        # modify tool names", plus the TSASPDMA division of labour ("you do NOT
        # provide tool parameters"). It has never been sent to a model.
        #
        # APPENDED rather than slotted, deliberately. A new {slot} in
        # `context_integration` would have to be added to all 29 localized
        # copies of the template to render for anyone but English speakers —
        # and a slot that exists in the base and not in a translation is how
        # you get a block that silently serves some users and not others. The
        # text itself is already per-locale, so appending it reaches every
        # language on the first commit.
        #
        # Rendered through safe_format with the same slot values: these blocks
        # carry `{{...}}` escapes (the alignment example is a literal JSON
        # snippet) which only resolve under a format pass.
        from ciris_engine.logic.dma.prompt_loader import safe_format

        for _key in (
            "csdma_ambiguity_guidance",
            "csdma_ambiguity_alignment_example",
            "tool_selection_guidance",
        ):
            _text = self._get_agent_specific_prompt(_key, agent_name)
            if _text:
                formatted_content += "\n\n" + safe_format(
                    _text, source=f"action_selection_pdma.{_key}[{loader.language}]", **_slots
                )

        return formatted_content.strip()

    def _load_user_template(self) -> "tuple[DMAPromptLoader, PromptCollection]":
        """Resolve the ASPDMA user-message template (#974 step 1).

        Returns ``(loader, collection)`` where ``collection.context_integration``
        is guaranteed non-empty. Loaded through :func:`get_prompt_loader` so the
        research-override ``dma_prompt`` namespace intercepts the field. A
        localized template that predates the key serves the base-locale
        doctrine — exactly what the inline English literal did for every locale
        before the routing, so composed bytes are unchanged.
        """
        from ciris_engine.logic.dma.prompt_loader import DEFAULT_LANGUAGE, get_prompt_loader

        loader = get_prompt_loader()
        template_data = loader.load_prompt_template("action_selection_pdma")
        if not template_data.context_integration and loader.language != DEFAULT_LANGUAGE:
            loader = get_prompt_loader(DEFAULT_LANGUAGE)
            template_data = loader.load_prompt_template("action_selection_pdma")
        if not template_data.context_integration:
            raise ValueError(
                "action_selection_pdma.yml no longer defines context_integration — "
                "the ASPDMA user-message template has no source. #974 routed it out "
                "of Python; it must live in the YAML."
            )
        return loader, template_data

    def _get_permitted_actions(self, triaged_inputs: EnhancedDMAInputs) -> List[HandlerActionType]:
        """Get permitted actions from triaged inputs."""
        default_permitted_actions = [
            HandlerActionType.SPEAK,
            HandlerActionType.PONDER,
            HandlerActionType.REJECT,
            HandlerActionType.DEFER,
            HandlerActionType.MEMORIZE,
            HandlerActionType.RECALL,
            HandlerActionType.FORGET,
            HandlerActionType.OBSERVE,
            HandlerActionType.TOOL,
            HandlerActionType.TASK_COMPLETE,
        ]

        original_thought = triaged_inputs.original_thought

        # CRITICAL: Use 'is not None' check, NOT truthiness check!
        # An empty list [] should not fall back to defaults - it means NO actions permitted.
        # Only fall back if the value is actually None (not provided).
        if triaged_inputs.permitted_actions is not None:
            permitted_actions = triaged_inputs.permitted_actions
            logger.info(
                f"ActionSelectionPDMA: Using template-defined permitted_actions for thought {original_thought.thought_id}: {[a.value for a in permitted_actions]}"
            )
        else:
            permitted_actions = default_permitted_actions
            logger.warning(
                f"ActionSelectionPDMA: 'permitted_actions' is None for thought {original_thought.thought_id}. Using default permitted actions: {[a.value for a in permitted_actions]}"
            )

        if not permitted_actions:
            logger.error(
                f"ActionSelectionPDMA: 'permitted_actions' is EMPTY for thought {original_thought.thought_id}. This should never happen - check template configuration."
            )

        # Return the permitted actions - they MUST be HandlerActionType enums
        return list(permitted_actions)

    def _get_tool_summary(self, tool_key: str, tool_info: Any) -> Optional[str]:
        """Extract a concise summary for a single tool."""
        if not isinstance(tool_info, dict):
            return None

        tool_name = tool_info.get("name", tool_key)
        when_to_use = tool_info.get("when_to_use", "")

        if not when_to_use:
            desc = tool_info.get("description", "")
            when_to_use = f"{desc[:100]}..." if len(desc) > 100 else desc

        return f"- **{tool_name}**: {when_to_use}" if when_to_use else None

    def _get_cached_tools(self) -> Optional[Dict[str, Any]]:
        """Get cached tools from instruction generator if available."""
        if self._instruction_generator is None:
            return None
        if not hasattr(self._instruction_generator, "_cached_tools"):
            return None
        return getattr(self._instruction_generator, "_cached_tools", None)

    def _get_available_tools_str(self, permitted_actions: List[HandlerActionType]) -> str:
        """Get concise tool summaries if TOOL action is permitted.

        Returns quick guidance on WHEN to use each tool (not full parameters).
        Full parameter schemas are provided separately in action_parameter_schemas.
        """
        if HandlerActionType.TOOL not in permitted_actions:
            logger.info("[CONTEXT] TOOL action not in permitted_actions, skipping tool summaries")
            return ""

        cached_tools = self._get_cached_tools()
        if not cached_tools:
            logger.warning(
                "[CONTEXT] No cached tools available for tool summaries - tools may not have been pre-cached!"
            )
            return ""

        logger.info(f"[CONTEXT] Building tool summaries for {len(cached_tools)} cached tools")
        logger.info(f"[CONTEXT] Cached tool names: {list(cached_tools.keys())}")

        # Build concise summaries using when_to_use (not full parameters)
        summaries = ["\n\n## Quick Tool Guide (when to use each tool):"]
        for tool_key, tool_info in cached_tools.items():
            summary = self._get_tool_summary(tool_key, tool_info)
            if summary:
                summaries.append(summary)
                logger.debug(f"[CONTEXT] Tool summary: {summary[:80]}...")

        result = "\n".join(summaries) if len(summaries) > 1 else ""
        logger.info(f"[CONTEXT] Tool summaries section: {len(result)} chars, {len(summaries)-1} tools")
        return result

    def _get_installable_tools_str(self) -> str:
        """Get list of tools that are available for installation but not currently usable.

        Returns the pre-cached installable tools string. Must call pre_cache_context() first.
        """
        if self._cached_installable_tools is not None:
            return self._cached_installable_tools

        logger.debug("[CONTEXT] Installable tools not cached - call pre_cache_context() first")
        return ""

    def _build_ethical_summary(self, ethical_pdma_result: EthicalDMAResult) -> str:
        """Build ethical DMA summary.

        v3.1 reshape: PDMA emits {action, rationale, weight_alignment_score,
        ethical_alignment_score}. Two scores: weight_alignment is how
        aligned the response is with training-weights' natural pull;
        ethical_alignment is how aligned with the cross-tradition framework.
        Their delta is the torque magnitude. Bounce gate reads
        ethical_alignment_score; weight is diagnostic. Summary surfaces both
        plus the action recommendation and rationale paragraph.
        """
        # Truncate rationale for context-builder summary; full rationale
        # remains available downstream via the result object.
        rationale_summary = (
            ethical_pdma_result.rationale[:300] + "..."
            if len(ethical_pdma_result.rationale) > 300
            else ethical_pdma_result.rationale
        )
        torque = ethical_pdma_result.weight_alignment_score - ethical_pdma_result.ethical_alignment_score
        return (
            f"Ethical PDMA Recommendation: action={ethical_pdma_result.action.value}, "
            f"weight_alignment={ethical_pdma_result.weight_alignment_score:.2f}, "
            f"ethical_alignment={ethical_pdma_result.ethical_alignment_score:.2f}, "
            f"torque={torque:+.2f}. "
            f"Rationale: {rationale_summary}"
        )

    def _build_csdma_summary(self, csdma_result: CSDMAResult) -> str:
        """Build CSDMA summary."""
        return f"CSDMA Output: Plausibility {csdma_result.plausibility_score:.2f}, Flags: {', '.join(csdma_result.flags) if csdma_result.flags else 'None'}. Reasoning: {csdma_result.reasoning}"

    def _build_dsdma_summary(self, dsdma_result: Optional[DSDMAResult]) -> str:
        """Build DSDMA summary."""
        if not dsdma_result:
            return "DSDMA did not apply or did not run for this thought."

        return (
            f"DSDMA ({dsdma_result.domain}) Output: Domain Alignment {dsdma_result.domain_alignment:.2f}, "
            f"Flags: {', '.join(dsdma_result.flags) if dsdma_result.flags else 'None'}. "
            f"Reasoning: {dsdma_result.reasoning}"
        )

    def _build_idma_summary(self, idma_result: Optional[IDMAResult]) -> str:
        """Build IDMA (Intuition DMA / Coherence Collapse Analysis) summary.

        Field labels and prose flow through the localization layer
        (`handlers.idma_*` keys) so non-English prompt paths receive the
        guidance in the agent's preferred language. Numeric values, JSON
        keys (`k_eff`, `rho`), and component identifiers stay code-stable.
        """
        if not idma_result:
            return ""

        from ciris_engine.logic.utils.localization import get_preferred_language, get_string

        lang = get_preferred_language()

        def L(key: str, default: str, **params: Any) -> str:
            return get_string(lang, f"handlers.{key}", default=default, **params)

        fragility_warning = ""
        if idma_result.fragility_flag:
            fragility_warning = "⚠️ " + L(
                "idma_fragility_warning",
                "FRAGILITY DETECTED - reasoning may be relying on too few or too-overlapping sources. "
                "Options: (1) Use web_search tool if available to get independent information, "
                "(2) Use other tools to gather additional data, "
                "(3) Ask the user for more information or clarification, "
                "(4) Consider alternative points of view, "
                "(5) Acknowledge uncertainty in your response.",
            ) + " "

        # IDMAResult was trimmed from 43 → 8 fields (see schema comment for why
        # the removed fields were causing LLM JSON-validation cascades). The
        # fields referenced below that are no longer on the schema — k_raw,
        # phase_confidence, collapse_margin, common_cause_flags,
        # source_type_counts, top_correlation_factors — are fetched with
        # getattr-default-None so this code still runs against a lean
        # IDMAResult and continues to render any extras if a provider still
        # emits them.
        k_raw = getattr(idma_result, "k_raw", None)
        phase_confidence = getattr(idma_result, "phase_confidence", None)
        collapse_margin = getattr(idma_result, "collapse_margin", None)
        common_cause_flags = getattr(idma_result, "common_cause_flags", None) or []
        source_type_counts = getattr(idma_result, "source_type_counts", None) or []
        top_correlation_factors = getattr(idma_result, "top_correlation_factors", None) or []

        source_count = k_raw if k_raw is not None else len(idma_result.sources_identified)
        plain_language_bits = [
            f"{L('idma_label_effective_source_count', 'effective source count')}={idma_result.k_eff:.2f}",
            f"{L('idma_label_source_overlap', 'source overlap')}={idma_result.correlation_risk:.2f}",
            f"{L('idma_label_reasoning_state', 'reasoning state')}={idma_result.phase}",
        ]
        if phase_confidence is not None:
            plain_language_bits.append(
                f"{L('idma_label_state_confidence', 'state confidence')}={phase_confidence:.2f}"
            )
        if collapse_margin is not None:
            plain_language_bits.append(
                f"{L('idma_label_safety_margin', 'safety margin')}={collapse_margin:.2f}"
            )
        if source_count:
            plain_language_bits.append(f"{L('idma_label_raw_source_count', 'raw source count')}={source_count}")
        if common_cause_flags:
            plain_language_bits.append(
                f"{L('idma_label_shared_bottlenecks', 'shared bottlenecks')}={', '.join(common_cause_flags[:3])}"
            )
        if idma_result.intervention_recommendation:
            plain_language_bits.append(
                f"{L('idma_label_recommended_recovery', 'recommended recovery')}={idma_result.intervention_recommendation}"
            )

        none_label = L("idma_label_none", "None")
        unknown_label = L("idma_label_unknown", "Unknown")
        sources_str = ", ".join(idma_result.sources_identified[:3]) if idma_result.sources_identified else none_label
        source_types_str = (
            ", ".join(source_type_counts[:3]) if source_type_counts else unknown_label
        )
        if top_correlation_factors:
            top_drivers = ", ".join(top_correlation_factors[:3])
        elif idma_result.correlation_factors:
            top_drivers = ", ".join(idma_result.correlation_factors[:3])
        else:
            top_drivers = none_label

        return (
            f"{L('idma_summary_header', 'IDMA (Intuition/CCA) Output')}: "
            f"{'; '.join(plain_language_bits)}. "
            f"({L('idma_scientific_mapping', 'Scientific mapping')}: k_eff={idma_result.k_eff:.2f}, rho={idma_result.correlation_risk:.2f}). "
            f"{fragility_warning}"
            f"{L('idma_label_sources', 'Sources')}: {sources_str}. "
            f"{L('idma_label_source_types', 'Source types')}: {source_types_str}. "
            f"{L('idma_label_top_overlap_drivers', 'Top overlap drivers')}: {top_drivers}. "
            f"Reasoning: {idma_result.reasoning[:150]}..."
        )

    def _build_ponder_context(self, original_thought: Thought, current_thought_depth: int) -> str:
        """Build ponder context string."""
        notes_list = original_thought.ponder_notes if original_thought.ponder_notes else []

        if notes_list:
            ponder_notes_str = "\n\nIMPORTANT CONTEXT FROM PREVIOUS ACTION ROUNDS:\n"
            ponder_notes_str += (
                f"This thought has been pondered {current_thought_depth} time(s). PLEASE TRY AND ACT (SPEAK) NOW\n"
            )
            ponder_notes_str += "The following key questions were previously identified:\n"
            for i, q_note in enumerate(notes_list):
                ponder_notes_str += f"{i+1}. {q_note}\n"
            ponder_notes_str += (
                "Please consider these questions and the original thought in your current evaluation. "
                "If you choose to 'Ponder' again, ensure your new 'questions' are DIFFERENT "
                "from the ones listed above and aim to address any REMAINING ambiguities or guide towards a solution.\n"
            )
            return ponder_notes_str
        elif current_thought_depth > 0:
            return f"\n\nThis thought has been pondered {current_thought_depth} time(s) previously. If choosing 'Ponder' again, formulate new, insightful questions.\n"

        return ""

    def _build_final_attempt_advisory(
        self, current_thought_depth: int, max_rounds: int, agent_name: Optional[str]
    ) -> str:
        """Build final attempt advisory."""
        is_final_attempt_round = current_thought_depth >= max_rounds - 1

        if not is_final_attempt_round:
            return ""

        final_ponder_advisory_template = self._get_agent_specific_prompt("final_ponder_advisory", agent_name)
        try:
            return final_ponder_advisory_template.format(
                current_thought_depth_plus_1=current_thought_depth + 1,
                max_rounds=max_rounds,
            )
        except KeyError as e:
            logger.error(
                f"KeyError formatting final_ponder_advisory_template: {e}. Template: '{final_ponder_advisory_template}'"
            )
            return "\nIMPORTANT FINAL ATTEMPT: Attempt to provide a terminal action."

    def _build_guidance_sections(
        self, agent_name: Optional[str], permitted_actions: List[HandlerActionType]
    ) -> Dict[str, str]:
        """Build all guidance sections.

        RESOLVED (#990/#993): ``action_alignment_csdma_guidance`` and
        ``action_alignment_example`` are built here from
        ``csdma_ambiguity_guidance`` / ``csdma_ambiguity_alignment_example``,
        and used to be dropped on the floor — :meth:`build_main_user_content`
        reads only keys with a matching ``{slot}`` in
        ``action_selection_pdma.yml``'s ``context_integration``, and those two
        have none. They are now appended after the template render, together
        with ``tool_selection_guidance``, so all three reach the model in every
        locale. See the comment at that append site for why appending beats
        adding a slot.
        """
        return {
            "action_alignment_csdma_guidance": self._get_agent_specific_prompt("csdma_ambiguity_guidance", agent_name),
            "action_alignment_example": self._get_agent_specific_prompt(
                "csdma_ambiguity_alignment_example", agent_name
            ),
            "action_parameters_speak_csdma_guidance": self._get_agent_specific_prompt(
                "action_params_speak_csdma_guidance", agent_name
            ),
            "action_parameters_ponder_guidance": self._get_agent_specific_prompt(
                "action_params_ponder_guidance", agent_name
            ),
            "action_parameters_observe_guidance": self._get_agent_specific_prompt(
                "action_params_observe_guidance", agent_name
            ),
            "reasoning_csdma_guidance": self._get_agent_specific_prompt("reasoning_csdma_guidance", agent_name),
            "action_parameter_schemas": self._composed_action_parameter_schemas(permitted_actions),
        }

    def _composed_action_parameter_schemas(self, permitted_actions: List[HandlerActionType]) -> str:
        """The action schemas as COMPOSED — manifest first, generation second (#990).

        This slot is the one place in the ASPDMA composer where a runtime value
        shadows a template field: ``_get_dynamic_action_schemas`` derives the
        per-action FLAT field list from the live permitted-action set and the
        handler param models, so ``action_selection_pdma.action_parameter_schemas``
        in the YAML is only ever a fallback. Applying the research override at
        the YAML load point therefore did nothing — the manifest value was set
        on the ``PromptCollection`` and then passed over, while the override
        layer logged a successful replacement. That is the #989 failure shape in
        a different place, and it made the key invisible to the ablation gate.

        The override is applied HERE, at the composition boundary, so a manifest
        value is what actually reaches the model. Gate closed (no manifest) this
        is byte-identical to calling the generator directly — ``override_dma_prompt``
        returns ``None`` without both ``CIRIS_RESEARCH_PROMPT_OVERRIDES`` and
        ``CIRIS_TESTING_MODE``, which is what the #972 goldens prove.

        A replacement inconsistent with the live action enum can produce output
        the ASPDMA parser rejects. That is a legitimate research condition — a
        campaign may want exactly that degradation — so it is permitted and made
        LEGIBLE (the warning below names the risk and the key) rather than
        prevented. Research mode is the correct place for it.
        """
        from ciris_engine.logic.utils.research_overrides import override_dma_prompt

        replacement = override_dma_prompt("action_selection_pdma", "action_parameter_schemas")
        if replacement is not None:
            logger.warning(
                "[RESEARCH-OVERRIDE] action_selection_pdma.action_parameter_schemas replaced at the "
                "composition boundary: the generated per-action schemas were DISCARDED in favour of "
                "the manifest value. If it does not match the permitted action set %s, the model's "
                "response may not parse — that is a property of this arm, not a bug.",
                [a.value for a in permitted_actions],
            )
            return replacement
        return self._get_dynamic_action_schemas(permitted_actions)

    def _build_system_context(self, processing_context_data: Any) -> tuple[str, str]:
        """Build user profile and system snapshot context."""
        user_profile_context_str = ""
        system_snapshot_context_str = ""

        if processing_context_data:
            if hasattr(processing_context_data, "system_snapshot") and processing_context_data.system_snapshot:
                user_profiles_data = getattr(processing_context_data.system_snapshot, "user_profiles", None)
                user_profile_context_str = format_user_profiles(user_profiles_data)
                system_snapshot_context_str = format_system_snapshot(processing_context_data.system_snapshot)

        return user_profile_context_str, system_snapshot_context_str

    def _build_startup_guidance(self, original_thought: Thought) -> str:
        """Build startup guidance if applicable."""
        if original_thought.thought_type == "startup_meta":
            return (
                "\nCRITICAL STARTUP DIRECTIVE: When handling 'startup_meta' thoughts, "
                "select SPEAK to confirm status or PONDER only if additional internal checks are required. "
                "Avoid MEMORIZE, ACT, REJECT, or DEFER during startup."
            )
        return ""

    def _build_conscience_guidance(
        self, conscience_feedback: Optional[Union[JSONDict, ConscienceFailureContext]]
    ) -> str:
        """Build conscience guidance from feedback if available.

        The `retry_guidance` payload is already pre-formatted in the agent's
        locale (header + structured shard detail + materially-different rule)
        by `_build_retry_guidance` in thought_processor.main, so we just emit
        it with surrounding whitespace.
        """
        if not conscience_feedback:
            return ""

        if isinstance(conscience_feedback, ConscienceFailureContext):
            return f"\n\n{conscience_feedback.retry_guidance}\n"
        elif isinstance(conscience_feedback, dict) and "retry_guidance" in conscience_feedback:
            return f"\n\n{conscience_feedback['retry_guidance']}\n"

        return ""

    def _get_reject_thought_guidance(self) -> str:
        """Get reject thought guidance."""
        return "\nNote on 'Reject Thought': Use this action sparingly, primarily if the original thought is nonsensical, impossible to act upon even with clarification, or fundamentally misaligned with the agent's purpose. Prefer 'Ponder' or 'Speak' for clarification if possible."

    def _get_agent_specific_prompt(self, base_key: str, agent_name: Optional[str]) -> str:
        """Get agent-specific prompt variation, falling back to base key."""
        # Handle both dict and PromptCollection
        if isinstance(self.prompts, PromptCollection):
            prompt = self.prompts.get_prompt(base_key, agent_name)
            if prompt:
                return prompt
        else:
            # Original dict logic
            if agent_name:
                agent_key = f"{agent_name.lower()}_mode_{base_key}"
                if agent_key in self.prompts:
                    return self.prompts[agent_key]

            if base_key in self.prompts:
                return self.prompts[base_key]

        logger.warning(f"Prompt key for '{base_key}' (agent: {agent_name}) not found. Using empty string.")
        return ""

    def _get_dynamic_action_schemas(self, permitted_actions: List[HandlerActionType]) -> str:
        """Get dynamically generated action schemas or fall back to static prompts."""
        try:
            # Lazy initialize the instruction generator
            if self._instruction_generator is None:
                from ciris_engine.logic.dma.action_selection.action_instruction_generator import (
                    ActionInstructionGenerator,
                )

                self._instruction_generator = ActionInstructionGenerator(self.service_registry, self.bus_manager)

            # Generate dynamic instructions
            dynamic_schemas: str = self._instruction_generator.generate_action_instructions(permitted_actions)

            if dynamic_schemas:
                logger.debug("Using dynamically generated action schemas")
                return dynamic_schemas

        except Exception as e:
            logger.warning(f"Failed to generate dynamic action schemas: {e}")

        # Fall back to static schemas from prompts
        if isinstance(self.prompts, PromptCollection):
            return self.prompts.action_parameter_schemas or ""
        else:
            return self.prompts.get("action_parameter_schemas", "")

    def _build_original_task_context(self, original_thought: Thought) -> str:
        """Build the original task context string for the prompt.

        This provides the LLM with the original user request so it can
        properly follow through on multi-step operations.
        """
        if not self._cached_task:
            # Fallback: if task wasn't cached, return minimal info
            logger.warning(
                f"[CONTEXT] Original task not cached for thought {original_thought.thought_id}. "
                "The LLM may not have full context about the user's original request."
            )
            return f"(Task ID: {original_thought.source_task_id} - description not available)"

        task = self._cached_task
        parts = []

        # Primary task description - this is what the user originally asked for
        parts.append(f'Task: "{task.description}"')
        parts.append(f"Task ID: {task.task_id}")

        # Include task status for context
        if hasattr(task, "status") and task.status:
            parts.append(f"Status: {task.status}")

        # Include parent task context if available (for subtasks)
        if task.context:
            if task.context.parent_task_id:
                parts.append(f"Parent Task ID: {task.context.parent_task_id}")
            if task.context.correlation_id:
                parts.append(f"Correlation ID: {task.context.correlation_id}")

        # Include any priority information
        if hasattr(task, "priority") and task.priority:
            parts.append(f"Priority: {task.priority}")

        # Add guidance about following through
        if original_thought.thought_depth > 0:
            parts.append("")
            parts.append(
                "⚠️ FOLLOW-THROUGH REQUIRED: This is a follow-up thought (depth > 0). "
                "You have already started working on this task. Review what actions "
                "have been taken and determine what remains to COMPLETE the original task."
            )

        return "\n".join(parts)
