"""
ciris_engine/runtime/ciris_runtime.py

New simplified runtime that properly orchestrates all components.

This file has been refactored to use extracted helper modules for better
separation of concerns and reduced complexity:
- service_property_mixin.py: Service property accessors
- initialization_steps.py: Initialization step handlers
- config_migration.py: Configuration migration utilities
- billing_helpers.py: Billing provider helpers
- resume_helpers.py: Resume from first-run helpers
- shutdown_continuity.py: Shutdown continuity helpers
- bootstrap_helpers.py: Bootstrap configuration helpers
- ciris_runtime_helpers.py: Runtime execution helpers (existing)
"""

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional

from ciris_engine.schemas.types import JSONDict

if TYPE_CHECKING:
    from ciris_engine.schemas.runtime.bootstrap import RuntimeBootstrapConfig

from ciris_engine.logic.infrastructure.handlers.action_dispatcher import ActionDispatcher
from ciris_engine.logic.infrastructure.handlers.handler_registry import build_action_dispatcher
from ciris_engine.logic.processors import AgentProcessor
from ciris_engine.logic.utils.constants import DEFAULT_NUM_ROUNDS
from ciris_engine.logic.utils.shutdown_manager import (
    get_shutdown_manager,
    is_global_shutdown_requested,
    wait_for_global_shutdown_async,
)
from ciris_engine.protocols.runtime.base import BaseAdapterProtocol
from ciris_engine.schemas.adapters import AdapterServiceRegistration
from ciris_engine.schemas.config.essential import EssentialConfig
from ciris_engine.schemas.processors.states import AgentState
from ciris_engine.schemas.runtime.adapter_management import AdapterConfig
from ciris_engine.schemas.runtime.core import AgentIdentityRoot
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.services.attestation import AttestationGateOutcome

from .billing_helpers import (
    CIRIS_PROXY_DOMAINS,
    create_billing_provider,
    create_billing_token_handler,
    create_llm_token_handler,
    get_resource_monitor_for_billing,
    is_using_ciris_proxy,
    reinitialize_billing_provider,
    update_llm_services_token,
    update_service_token_if_ciris_proxy,
)
from .bootstrap_helpers import (
    check_mock_llm,
    create_bootstrap_from_legacy,
    load_adapters_from_bootstrap,
    parse_bootstrap_config,
)
from .component_builder import ComponentBuilder
from .config_migration import migrate_adapter_configs_to_graph, migrate_tickets_config_to_graph
from .identity_manager import IdentityManager
from .resume_helpers import (
    auto_enable_android_adapters_for_resume,
    auto_enable_environment_adapters_for_resume,
    initialize_core_services_for_resume,
    initialize_identity_for_resume,
    initialize_llm_for_resume,
    migrate_cognitive_behaviors_for_resume,
    reinject_adapters_for_resume,
    reload_environment_for_resume,
    set_service_runtime_references,
)
from .service_initializer import ServiceInitializer
from .service_property_mixin import ServicePropertyMixin
from .shutdown_continuity import (
    build_shutdown_node_attributes,
    create_startup_node,
    determine_shutdown_consent_status,
    preserve_shutdown_continuity,
    update_identity_with_shutdown_reference,
)

logger = logging.getLogger(__name__)

# Keep single domain for backwards compatibility (tests)
CIRIS_PROXY_DOMAIN = "ciris.ai"


class CIRISRuntime(ServicePropertyMixin):
    """
    Main runtime orchestrator for CIRIS Agent.
    Handles initialization of all components and services.
    Implements the RuntimeInterface protocol.
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "CIRISRuntime":
        """Custom __new__ to handle CI environment issues."""
        instance = object.__new__(cls)
        return instance

    def __init__(
        self,
        adapter_types: List[str],
        essential_config: Optional[EssentialConfig] = None,
        bootstrap: Optional["RuntimeBootstrapConfig"] = None,
        startup_channel_id: Optional[str] = None,
        adapter_configs: Optional[Dict[str, AdapterConfig]] = None,
        **kwargs: Any,
    ) -> None:
        # CRITICAL: Prevent runtime creation during module imports
        import os

        if os.environ.get("CIRIS_IMPORT_MODE", "").lower() == "true":
            logger.error("CRITICAL: Attempted to create CIRISRuntime during import mode!")
            raise RuntimeError(
                "Cannot create CIRISRuntime during module imports. "
                "This prevents side effects and unwanted process creation. "
                "Call prevent_sideeffects.allow_runtime_creation() before creating runtime."
            )

        # Declare attributes that will be set in parse_bootstrap_config
        self.essential_config: EssentialConfig
        self.startup_channel_id: str
        self.adapter_configs: Dict[str, AdapterConfig]
        self.modules_to_load: List[str]
        self.debug: bool
        self._preload_tasks: List[Any]

        # Import RuntimeBootstrapConfig here to avoid circular imports
        from ciris_engine.schemas.runtime.bootstrap import RuntimeBootstrapConfig

        self.bootstrap: RuntimeBootstrapConfig

        # Use bootstrap helpers to parse configuration
        parse_bootstrap_config(
            self, bootstrap, essential_config, startup_channel_id, adapter_types, adapter_configs, kwargs
        )

        self.adapters: List[BaseAdapterProtocol] = []

        # CRITICAL: Check for mock LLM environment variable
        check_mock_llm(self)

        # Initialize managers
        self.identity_manager: Optional[IdentityManager] = None
        self.service_initializer = ServiceInitializer(essential_config=essential_config)
        self.component_builder: Optional[ComponentBuilder] = None
        self.agent_processor: Optional["AgentProcessor"] = None
        self._adapter_tasks: List[asyncio.Task[Any]] = []

        # Load adapters from bootstrap config
        load_adapters_from_bootstrap(self)

        if not self.adapters:
            raise RuntimeError("No valid adapters specified, shutting down")

        # Runtime state
        self._initialized = False
        self._shutdown_manager = get_shutdown_manager()
        self._shutdown_event: Optional[asyncio.Event] = None
        self._shutdown_reason: Optional[str] = None
        self._agent_task: Optional[asyncio.Task[Any]] = None
        self._shutdown_complete = False
        self._shutdown_in_progress = False
        self._safe_mode = False
        self._safe_mode_reason: Optional[str] = None
        self._background_tasks: set[asyncio.Task[Any]] = set()

        # Resume protection
        self._resume_in_progress = False
        self._resume_started_at: Optional[float] = None
        self._startup_time: float = time.time()

        # Identity - will be loaded during initialization
        self.agent_identity: Optional[AgentIdentityRoot] = None

    # Profile property - converts agent identity to profile format
    @property
    def profile(self) -> Optional[Any]:
        """Convert agent identity to profile format for compatibility."""
        if not self.agent_identity:
            return None

        from ciris_engine.schemas.config.agent import AgentTemplate, DSDMAConfiguration

        dsdma_config = None
        if (
            self.agent_identity.core_profile.domain_specific_knowledge
            or self.agent_identity.core_profile.dsdma_prompt_template
        ):
            dsdma_config = DSDMAConfiguration(
                domain_specific_knowledge=self.agent_identity.core_profile.domain_specific_knowledge,
                prompt_template=self.agent_identity.core_profile.dsdma_prompt_template,
            )

        return AgentTemplate(
            name=self.agent_identity.agent_id,
            description=self.agent_identity.core_profile.description,
            role_description=self.agent_identity.core_profile.role_description,
            permitted_actions=self.agent_identity.permitted_actions,
            dsdma_kwargs=dsdma_config,
            csdma_overrides=self.agent_identity.core_profile.csdma_overrides,
            action_selection_pdma_overrides=self.agent_identity.core_profile.action_selection_pdma_overrides,
        )

    @property
    def agent_template(self) -> Optional[Any]:
        """Access to full agent template - includes tickets config and all template data."""
        return self.identity_manager.agent_template if self.identity_manager else None

    def _ensure_shutdown_event(self) -> None:
        """Ensure shutdown event is created when needed in async context."""
        if self._shutdown_event is None:
            try:
                self._shutdown_event = asyncio.Event()
            except RuntimeError:
                logger.warning("Cannot create shutdown event outside of async context")

    def _ensure_config(self) -> EssentialConfig:
        """Ensure essential_config is available, raise if not."""
        if not self.essential_config:
            raise RuntimeError("Essential config not initialized")
        return self.essential_config

    def request_shutdown(self, reason: str = "Shutdown requested") -> None:
        """Request a graceful shutdown of the runtime."""
        self._ensure_shutdown_event()

        if self._shutdown_event and self._shutdown_event.is_set():
            logger.debug(f"Shutdown already requested, ignoring duplicate request: {reason}")
            return

        logger.critical(f"RUNTIME SHUTDOWN REQUESTED: {reason}")
        self._shutdown_reason = reason

        if self._shutdown_event:
            self._shutdown_event.set()

        from ciris_engine.logic.utils.shutdown_manager import request_global_shutdown

        request_global_shutdown(f"Runtime: {reason}")

    def _request_shutdown(self, reason: str = "Shutdown requested") -> None:
        """Wrapper used during initialization failures."""
        self.request_shutdown(reason)

    def enter_safe_mode(self, reason: str) -> bool:
        """
        Enter safe mode - reduces agent to minimal functionality.

        In safe mode, the agent:
        - Can still respond to messages
        - Cannot execute autonomous tool actions
        - Cannot make memory modifications
        - Logs all attempted actions for review

        Args:
            reason: Human-readable reason for entering safe mode

        Returns:
            True if safe mode was activated successfully, False if already in safe mode
        """
        if self._safe_mode:
            logger.warning(f"Already in safe mode (reason: {self._safe_mode_reason})")
            return False  # Already in safe mode - no state change

        logger.critical(f"ENTERING SAFE MODE: {reason}")
        self._safe_mode = True
        self._safe_mode_reason = reason

        # Log to audit if available
        if hasattr(self, "service_initializer") and self.service_initializer:
            audit_service = getattr(self.service_initializer, "audit_service", None)
            if audit_service:
                try:
                    # Fire and forget - save task to prevent GC
                    import asyncio

                    task = asyncio.create_task(
                        audit_service.log_event(
                            event_type="accord_safe_mode",
                            event_data={"reason": reason, "activated": True},
                        )
                    )
                    # Store task reference to prevent premature garbage collection
                    self._background_tasks.add(task)
                    task.add_done_callback(self._background_tasks.discard)
                except Exception as e:
                    logger.error(f"Failed to log safe mode to audit: {e}")

        return True

    def exit_safe_mode(self, authorized_by: str) -> bool:
        """
        Exit safe mode - requires explicit authorization.

        Args:
            authorized_by: Identifier of who authorized exit from safe mode

        Returns:
            True if safe mode was exited successfully, False if not in safe mode
        """
        if not self._safe_mode:
            logger.warning("Not in safe mode, nothing to exit")
            return False  # Not in safe mode - no state change

        logger.critical(f"EXITING SAFE MODE: Authorized by {authorized_by}")
        self._safe_mode = False
        previous_reason = self._safe_mode_reason
        self._safe_mode_reason = None

        # Log to audit if available
        if hasattr(self, "service_initializer") and self.service_initializer:
            audit_service = getattr(self.service_initializer, "audit_service", None)
            if audit_service:
                try:
                    import asyncio

                    task = asyncio.create_task(
                        audit_service.log_event(
                            event_type="accord_safe_mode",
                            event_data={
                                "reason": previous_reason,
                                "activated": False,
                                "authorized_by": authorized_by,
                            },
                        )
                    )
                    # Store task reference to prevent premature garbage collection
                    self._background_tasks.add(task)
                    task.add_done_callback(self._background_tasks.discard)
                except Exception as e:
                    logger.error(f"Failed to log safe mode exit to audit: {e}")

        return True

    @property
    def is_safe_mode(self) -> bool:
        """Check if runtime is in safe mode."""
        return self._safe_mode

    @property
    def safe_mode_reason(self) -> Optional[str]:
        """Get the reason for safe mode, if active."""
        return self._safe_mode_reason if self._safe_mode else None

    def set_preload_tasks(self, tasks: List[str]) -> None:
        """Set tasks to be loaded after successful WORK state transition."""
        self._preload_tasks = tasks.copy()

    async def request_state_transition(self, target_state: str, reason: str) -> bool:
        """Request a cognitive state transition."""
        if not self.agent_processor:
            logger.error("Cannot transition state: agent processor not initialized")
            return False

        try:
            target = AgentState(target_state.lower())
        except ValueError:
            logger.error(f"Invalid target state: {target_state}")
            return False

        current_state = self.agent_processor.state_manager.get_state()
        logger.info(f"State transition requested: {current_state.value} -> {target.value} (reason: {reason})")

        success = await self.agent_processor.state_manager.transition_to(target)

        if success:
            logger.info(f"State transition successful: {current_state.value} -> {target.value}")
        else:
            logger.warning(f"State transition failed: {current_state.value} -> {target.value}")

        return success

    def get_preload_tasks(self) -> List[str]:
        """Get the list of preload tasks."""
        return self._preload_tasks.copy()

    async def initialize(self) -> None:
        """Initialize all components and services."""
        # An in-process RESTART (mobile resume) reuses the module-level shutdown
        # service from the run that just ended; shed it if it belongs to a dead
        # loop, or the new runtime exits at birth / wedges on its Event (#1122).
        from ciris_engine.logic.utils.shutdown_manager import reset_global_shutdown_service_if_stale

        reset_global_shutdown_service_if_stale()
        if self._initialized:
            return

        logger.info("Initializing CIRIS Runtime...")

        try:
            # CRITICAL: Ensure all directories exist with correct permissions
            from ciris_engine.logic.utils.directory_setup import (
                DirectorySetupError,
                setup_application_directories,
                validate_directories,
            )

            try:
                import os

                is_production = os.environ.get("CIRIS_ENV", "dev").lower() == "prod"

                if is_production:
                    logger.info("Production environment detected - validating directories...")
                    validate_directories()
                else:
                    logger.info("Development environment - setting up directories...")
                    setup_application_directories(essential_config=self.essential_config)

            except DirectorySetupError as e:
                logger.critical(f"DIRECTORY SETUP FAILED: {e}")
                raise RuntimeError(f"Cannot start: Directory setup failed - {e}")

            # Initialize infrastructure services first
            logger.info("[initialize] Initializing infrastructure services...")
            await self.service_initializer.initialize_infrastructure_services()
            logger.info("[initialize] Infrastructure services initialized")

            # Get the initialization service
            init_manager = self.service_initializer.initialization_service
            if not init_manager:
                raise RuntimeError("InitializationService not available from ServiceInitializer")
            logger.info(f"[initialize] Got initialization service: {init_manager}")

            # Register all initialization steps
            logger.info("[initialize] Registering initialization steps...")
            self._register_initialization_steps(init_manager)
            logger.info("[initialize] Steps registered")

            # Run the initialization sequence
            logger.info("[initialize] Running initialization sequence...")
            init_result = await init_manager.initialize()
            logger.info(f"[initialize] Initialization sequence result: {init_result}")

            if not init_result:
                raise RuntimeError("Initialization sequence failed - check logs for details")

            self._initialized = True
            agent_name = self.agent_identity.agent_id if self.agent_identity else "NO_IDENTITY"
            logger.info(f"CIRIS Runtime initialized successfully with identity '{agent_name}'")

        except asyncio.TimeoutError as e:
            logger.critical(f"Runtime initialization TIMED OUT: {e}", exc_info=True)
            self._initialized = False
            raise
        except Exception as e:
            logger.critical(f"Runtime initialization failed: {e}", exc_info=True)
            if "maintenance" in str(e).lower():
                logger.critical("Database maintenance failure during initialization - system cannot start safely")
            self._initialized = False
            raise

    async def _initialize_identity(self) -> None:
        """Initialize agent identity.

        If --identity-update flag is set, refresh identity from template after normal init.
        """
        from ciris_engine.logic.setup.first_run import is_first_run

        config = self._ensure_config()
        if not self.time_service:
            raise RuntimeError("TimeService not available for IdentityManager")
        self.identity_manager = IdentityManager(config, self.time_service)

        if is_first_run():
            logger.info("First-run mode: Skipping identity seeding (will seed after setup wizard)")
            return

        self.agent_identity = await self.identity_manager.initialize_identity()

        # Handle --identity-update flag for admin template refresh
        identity_update = getattr(self, "_identity_update", False)
        template_name_raw = getattr(self, "_template_name", None) or getattr(config, "default_template", "default")
        template_name: str = str(template_name_raw) if template_name_raw else "default"
        logger.info(
            f"[IDENTITY_UPDATE] Checking flag: _identity_update={identity_update}, template_name={template_name}"
        )

        if identity_update:
            logger.info(f"Identity update requested - refreshing from template '{template_name}'")
            success = await self.identity_manager.refresh_identity_from_template(
                template_name=template_name,
                updated_by="admin",
            )
            if success:
                self.agent_identity = self.identity_manager.agent_identity
                logger.info("Identity successfully updated from template")
            else:
                logger.error("Failed to update identity from template")
                raise RuntimeError("Identity update failed - cannot proceed")

        await self._create_startup_node()

    def _register_initialization_steps(self, init_manager: Any) -> None:
        """Register all initialization steps with the initialization manager."""
        from ciris_engine.schemas.services.operations import InitializationPhase

        # Phase 0: INFRASTRUCTURE
        init_manager.register_step(
            phase=InitializationPhase.INFRASTRUCTURE,
            name="Initialize Infrastructure Services",
            handler=self._initialize_infrastructure,
            verifier=self._verify_infrastructure,
            critical=True,
        )

        # Phase 1: DATABASE
        init_manager.register_step(
            phase=InitializationPhase.DATABASE,
            name="Initialize Database",
            handler=self._init_database,
            verifier=self._verify_database_integrity,
            critical=True,
        )

        # Phase 1 (post-database): CIRISEdge federation runtime.
        # Consumes the persist Engine from the previous step (CIRISEdge#16
        # cohabitation). A failure here is a boot failure: session auth cannot
        # run without it (#1101). When Edge is DISABLED by env the step is a no-op;
        # `GET /v1/system/federation` then returns `{available: false}`.
        init_manager.register_step(
            phase=InitializationPhase.DATABASE,
            name="Initialize Edge Runtime",
            handler=self._init_edge_runtime,
            verifier=self._verify_edge_runtime,
            # CRITICAL (CIRISAgent#1101): every `sess:` bearer is judged by the
            # in-process substrate. With Edge down the API answered 503 to every
            # session while health stayed green. The step is skipped cleanly when
            # Edge is disabled by env (pytest / CIRIS_EDGE_DISABLED), and the
            # PyO3-cohabitation branch still degrades rather than raising.
            critical=True,
        )

        # Phase 2: MEMORY
        init_manager.register_step(
            phase=InitializationPhase.MEMORY,
            name="Memory Service",
            handler=self._initialize_memory_service,
            verifier=self._verify_memory_service,
            critical=True,
        )

        # Phase 3: IDENTITY
        init_manager.register_step(
            phase=InitializationPhase.IDENTITY,
            name="Agent Identity",
            handler=self._initialize_identity,
            verifier=self._verify_identity_integrity,
            critical=True,
        )

        # Phase 4: SECURITY
        init_manager.register_step(
            phase=InitializationPhase.SECURITY,
            name="Security Services",
            handler=self._initialize_security_services,
            verifier=self._verify_security_services,
            critical=True,
        )

        # Phase 5: SERVICES
        # Use longer timeout on mobile platforms (90s) as they can be slower
        from ciris_engine.logic.utils.path_resolution import is_android, is_ios

        core_services_timeout = 90.0 if (is_android() or is_ios()) else 30.0
        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Core Services",
            handler=self._initialize_services,
            verifier=self._verify_core_services,
            critical=True,
            timeout=core_services_timeout,
        )

        # Adapter start includes the node fold (compose + bind 4243), which
        # takes 15-40s on-device under emulator arm64 translation.
        adapter_start_timeout = 120.0 if (is_android() or is_ios()) else 30.0
        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Start Adapters",
            handler=self._start_adapters,
            critical=True,
            timeout=adapter_start_timeout,
        )

        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Register Adapter Services",
            handler=self._register_adapter_services,
            critical=True,
        )

        # Adapter loading can be slow on mobile due to graph DB queries
        adapter_load_timeout = 60.0 if (is_android() or is_ios()) else 30.0
        # Enrichment tools are network/IO bound (200-400ms each) and slower on mobile
        enrichment_cache_timeout = 60.0 if (is_android() or is_ios()) else 30.0
        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Load Saved Adapters",
            handler=self._load_saved_adapters,
            critical=False,  # Non-critical - system can run without saved adapters
            timeout=adapter_load_timeout,
        )

        # Warm the context-enrichment cache before the first thought needs it.
        # Shipped in 2.4.2 (#669) but only ever registered by the dead duplicate
        # registrar in initialization_steps.py, so it never ran at boot: every
        # first thought paid the full 200-400ms per enrichment tool.
        # Non-critical by construction — the handler is first-run aware and
        # swallows its own failures; enrichment then runs lazily as before.
        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Populate Context Enrichment Cache",
            handler=self._populate_context_enrichment_cache,
            critical=False,  # Non-critical - context enrichment can run on-demand
            timeout=enrichment_cache_timeout,
        )

        init_manager.register_step(
            phase=InitializationPhase.SERVICES,
            name="Initialize Maintenance Service",
            handler=self._initialize_maintenance_service,
            critical=True,
        )

        # Phase 6: COMPONENTS
        init_manager.register_step(
            phase=InitializationPhase.COMPONENTS,
            name="Build Components",
            handler=self._build_components,
            critical=True,
        )

        init_manager.register_step(
            phase=InitializationPhase.COMPONENTS,
            name="Start Adapter Connections",
            handler=self._start_adapter_connections,
            critical=True,
            timeout=45.0,
        )

        # Phase 7: VERIFICATION
        init_manager.register_step(
            phase=InitializationPhase.VERIFICATION,
            name="Final System Verification",
            handler=self._final_verification,
            critical=True,
        )

    async def _initialize_infrastructure(self) -> None:
        """Initialize infrastructure services."""
        import os

        if not os.environ.get("PYTEST_CURRENT_TEST"):
            from ciris_engine.logic.utils.logging_config import setup_basic_logging

            time_service = self.service_initializer.time_service
            if not time_service:
                raise RuntimeError("CRITICAL: TimeService not available - CANNOT INITIALIZE FILE LOGGING")

            try:
                setup_basic_logging(
                    level=logging.DEBUG if self.debug else logging.INFO,
                    log_to_file=True,
                    console_output=False,
                    enable_incident_capture=True,
                    time_service=time_service,
                )
                logger.info("[_initialize_infrastructure] File logging initialized successfully")
            except Exception as e:
                raise RuntimeError(f"CRITICAL: Failed to setup file logging: {e}")

    async def _verify_infrastructure(self) -> bool:
        """Verify infrastructure services are operational."""
        if not self.service_initializer.time_service:
            logger.error("TimeService not initialized")
            return False
        if not self.service_initializer.shutdown_service:
            logger.error("ShutdownService not initialized")
            return False
        if not self.service_initializer.initialization_service:
            logger.error("InitializationService not initialized")
            return False
        return True

    async def _init_database(self) -> None:
        """Initialize database and run migrations."""
        from ciris_engine.logic import persistence
        from ciris_engine.logic.config.db_paths import get_sqlite_db_full_path

        # One canonical DB-path resolver — honors config.database.database_url
        # (Postgres, including the CIRIS_DB_URL env var) and otherwise returns
        # the SQLite main_db path. Every consumer (memory service, auth, etc.)
        # resolves the same way; diverging here would construct the process
        # persist Engine with a different DSN and trip EngineConfigMismatch.
        db_path = get_sqlite_db_full_path(self.essential_config)
        if db_path.startswith(("postgresql://", "postgres://")):
            logger.info("Using PostgreSQL database")
        else:
            logger.info(f"Using SQLite database: {db_path}")

        # initialize_database bootstraps persist's Engine end-to-end (schema
        # via persist's own sqlx migrations + A0a legacy graph migration).
        persistence.initialize_database(db_path)

        if not self.essential_config:
            self.essential_config = EssentialConfig()
            self.essential_config.load_env_vars()
            logger.warning("No config provided, using defaults")

    async def _verify_database_integrity(self) -> bool:
        """Verify database integrity before proceeding.

        Post-A1 absorption (CIRISAgent#763): persist owns the schema. If the
        Engine is wired and a cheap probe succeeds, the schema is intact.
        """
        try:
            import json

            from ciris_engine.logic.persistence.models.graph import get_persist_engine

            engine = get_persist_engine()
            if engine is None:
                raise RuntimeError("persist engine not wired — initialize_database must run first")

            # Cheap sanity probe.
            engine.task_list("{}", json.dumps({"version": "v1", "last_ts": "9999-12-31T23:59:59Z", "last_id": ""}), 1)

            logger.info("Database integrity verified (persist engine healthy)")
            return True
        except Exception as e:
            logger.error(f"Database integrity check failed: {e}")
            return False

    async def _init_edge_runtime(self) -> None:
        """Initialize CIRISEdge federation runtime (foundation dep, post-database).

        Currently best-effort due to Edge v0.9.1's PyO3 cross-crate PyClass
        identity bug — the cohabitation handoff of persist's Engine fails
        with `TypeError: argument 'engine': 'Engine' object is not an
        instance of 'Engine'`. The edge_runtime module catches this
        specific failure and logs a warning, leaving the Edge singleton
        unset. When the Edge team ships v0.9.2+ with the fix (tracked at
        CIRISEdge#22 issuecomment-4560383149), flip the register_step
        above to critical=True.

        Before invoking ``initialize_edge_runtime``, seed the
        ``AgentModeBroker`` from ``EssentialConfig.agent_mode``. The broker
        defaults to ``AgentMode.PROXY`` at module import; without this seed
        the ``AGENT_MODE`` env var (parsed into EssentialConfig.agent_mode
        by ``load_env_vars``) would be ignored by Edge, which reads the
        mode through ``get_agent_mode_broker().current_mode()``. Use the
        sync setter because ConfigService is not yet wired at this phase.
        """
        from ciris_engine.logic.runtime import edge_runtime
        from ciris_engine.logic.utils.agent_mode_broker import get_agent_mode_broker
        from ciris_engine.logic.utils.path_resolution import get_data_dir

        config = self._ensure_config()
        get_agent_mode_broker().set_mode_sync(config.agent_mode)

        # CIRISAgent#1244: a mock LLM named only in the module list must be
        # known before any federation path starts (modules may be mutated
        # after construction, so re-check immediately before edge init).
        from ciris_engine.logic.utils.mock_llm_guard import latch_if_mock_llm_module

        latch_if_mock_llm_module(getattr(self, "modules_to_load", None) or [], "pre-edge")
        identity_dir = get_data_dir() / "edge"
        edge_runtime.initialize_edge_runtime(identity_dir)

    async def _verify_edge_runtime(self) -> bool:
        """Verify Edge runtime status — passes regardless of degraded state."""
        from ciris_engine.logic.runtime import edge_runtime

        if edge_runtime.is_available():
            addr = edge_runtime.get_federation_address()
            logger.info("Edge runtime verified: federation_address=%s", addr)
        elif edge_runtime._edge_disabled():
            logger.info("Edge runtime disabled via env — skipping verification")
        else:
            logger.warning(
                "Edge runtime not available (degraded). GET /v1/system/federation will report available=false."
            )
        return True  # Non-critical: always pass.

    async def _initialize_memory_service(self) -> None:
        """Initialize memory service early for identity storage."""
        config = self._ensure_config()
        await self.service_initializer.initialize_memory_service(config)

    async def _verify_memory_service(self) -> bool:
        """Verify memory service is operational."""
        return await self.service_initializer.verify_memory_service()

    async def _verify_identity_integrity(self) -> bool:
        """Verify identity was properly established."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if not self.identity_manager:
            logger.error("Identity manager not initialized")
            return False

        if is_first_run():
            logger.info("First-run mode: Identity manager created (identity will be seeded after setup)")
            return True

        return await self.identity_manager.verify_identity_integrity()

    async def _initialize_security_services(self) -> None:
        """Initialize security-critical services first."""
        config = self._ensure_config()
        await self.service_initializer.initialize_security_services(config, self.essential_config)

    async def _verify_security_services(self) -> bool:
        """Verify security services are operational."""
        return await self.service_initializer.verify_security_services()

    async def _initialize_services(self) -> None:
        """Initialize all remaining core services."""
        from ciris_engine.logic.setup.first_run import is_first_run

        config = self._ensure_config()

        if is_first_run():
            logger.info("First-run mode: Skipping core service initialization (setup wizard only)")
            return

        if not self.agent_identity:
            raise RuntimeError("CRITICAL: Cannot initialize services without agent identity")

        await self.service_initializer.initialize_all_services(
            config,
            self.essential_config,
            self.agent_identity.agent_id,
            self.startup_channel_id,
            self.modules_to_load,
        )

        if self.modules_to_load:
            logger.info(f"Loading {len(self.modules_to_load)} external modules: {self.modules_to_load}")
            await self.service_initializer.load_modules(self.modules_to_load)

        # Set runtime references on services
        set_service_runtime_references(self)

    async def _verify_core_services(self) -> bool:
        """Verify all core services are operational."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if is_first_run():
            logger.info("First-run mode: Core services verification skipped")
            return True

        return self.service_initializer.verify_core_services()

    async def _initialize_maintenance_service(self) -> None:
        """Initialize the maintenance service and perform startup cleanup."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if is_first_run():
            logger.info("First-run mode: Skipping maintenance service initialization")
            return

        if not self.maintenance_service:
            raise RuntimeError("Maintenance service was not initialized properly")
        logger.info("Maintenance service verified available")

        await self._perform_startup_maintenance()

    async def _start_single_adapter(self, adapter: Any) -> None:
        """Start one adapter with timing + explicit failure logging."""
        adapter_name = adapter.__class__.__name__
        start_time = time.perf_counter()
        logger.info("[_start_adapters] Starting %s", adapter_name)
        try:
            await adapter.start()
            elapsed = time.perf_counter() - start_time
            logger.info("[_start_adapters] %s started in %.2fs", adapter_name, elapsed)
        except Exception:
            elapsed = time.perf_counter() - start_time
            logger.exception("[_start_adapters] %s failed after %.2fs", adapter_name, elapsed)
            raise

    def _log_background_adapter_start_failure(self, t: "asyncio.Task[Any]") -> None:
        """Surface background-start failures explicitly.

        Without this the re-raise in _start_single_adapter becomes an
        unretrieved task exception and a REQUIRED adapter (e.g.
        accord_metrics) can silently not run during the first-run wizard
        session.
        """
        self._background_tasks.discard(t)
        if t.cancelled():
            return
        exc = t.exception()
        if exc is not None:
            logger.error(
                "[_start_adapters] BACKGROUND adapter start FAILED (%s): %s — "
                "the adapter is NOT running for this first-run session and "
                "will block boot on the next (non-first-run) start",
                t.get_name(),
                exc,
            )

    async def _start_adapters_first_run(self) -> None:
        """First-run start order: wizard-critical adapters block, the rest
        start in the background so the setup wizard is reachable fast."""
        blocking_adapter_names = {"CIRISVerifyAdapter", "ApiPlatform"}
        blocking_adapters = [a for a in self.adapters if a.__class__.__name__ in blocking_adapter_names]
        background_adapters = [a for a in self.adapters if a.__class__.__name__ not in blocking_adapter_names]

        logger.info(
            "[_start_adapters] First-run mode: blocking adapters=%s background adapters=%s",
            [adapter.__class__.__name__ for adapter in blocking_adapters],
            [adapter.__class__.__name__ for adapter in background_adapters],
        )

        if blocking_adapters:
            await asyncio.gather(*(self._start_single_adapter(adapter) for adapter in blocking_adapters))

        for adapter in background_adapters:
            task = asyncio.create_task(
                self._start_single_adapter(adapter),
                name=f"AdapterStart::{adapter.__class__.__name__}",
            )
            self._background_tasks.add(task)
            task.add_done_callback(self._log_background_adapter_start_failure)

        logger.info(
            "[_start_adapters] First-run blocking adapters started; %d background adapter starts scheduled",
            len(background_adapters),
        )

    async def _start_adapters(self) -> None:
        """Start all adapters."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if is_first_run():
            await self._start_adapters_first_run()
        else:
            await asyncio.gather(*(self._start_single_adapter(adapter) for adapter in self.adapters))

        logger.info(f"All {len(self.adapters)} adapters started")
        await self._migrate_adapter_configs_to_graph()

    async def _wait_for_critical_services(self, timeout: float) -> None:
        """Wait for services required for agent operation."""
        start_time = asyncio.get_event_loop().time()
        last_report_time = start_time

        required_services = [
            (ServiceType.COMMUNICATION, ["send_message"], "Communication (Discord/API/CLI)"),
        ]

        while (asyncio.get_event_loop().time() - start_time) < timeout:
            all_ready = True
            missing_services = []

            for service_type, capabilities, name in required_services:
                if self.service_registry:
                    service = await self.service_registry.get_service(
                        handler="SpeakHandler",
                        service_type=service_type,
                        required_capabilities=capabilities,
                    )
                    if not service:
                        all_ready = False
                        missing_services.append(name)
                    else:
                        if hasattr(service, "is_healthy"):
                            is_healthy = await service.is_healthy()
                            if not is_healthy:
                                all_ready = False
                                missing_services.append(f"{name} (registered but not connected)")
                            else:
                                service_name = service.__class__.__name__ if service else "Unknown"
                                if "Discord" in service_name and not hasattr(self, "_discord_connected_reported"):
                                    if (
                                        hasattr(service, "client")
                                        and service.client
                                        and hasattr(service.client, "user")
                                    ):
                                        user = service.client.user
                                        guilds = service.client.guilds if hasattr(service.client, "guilds") else []
                                        logger.info(f"    Discord connected as {user} to {len(guilds)} guild(s)")
                                        for guild in guilds[:3]:
                                            logger.info(f"      - {guild.name} (ID: {guild.id})")
                                        if len(guilds) > 3:
                                            logger.info(f"      ... and {len(guilds) - 3} more guild(s)")
                                        self._discord_connected_reported = True

            if all_ready:
                return

            current_time = asyncio.get_event_loop().time()
            if current_time - last_report_time >= 3.0:
                elapsed = current_time - start_time
                logger.info(f"    Still waiting for: {', '.join(missing_services)} ({elapsed:.1f}s elapsed)")
                last_report_time = current_time

            await asyncio.sleep(0.5)

        raise TimeoutError(f"Critical services not available after {timeout}s. Missing: {', '.join(missing_services)}")

    async def _migrate_adapter_configs_to_graph(self) -> None:
        """Migrate adapter configurations to graph config service."""
        await migrate_adapter_configs_to_graph(self)

    async def _migrate_tickets_config_to_graph(self) -> None:
        """Migrate tickets config to graph."""
        await migrate_tickets_config_to_graph(self)

    async def _final_verification(self) -> None:
        """Perform final system verification."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if is_first_run():
            logger.info("First-run mode: Skipping final verification (waiting for setup wizard)")
            logger.info("=" * 60)
            logger.info("CIRIS Agent First-Run Mode Active")
            logger.info("Setup wizard is ready at http://127.0.0.1:8080/setup")
            logger.info("=" * 60)
            return

        if not self.agent_identity:
            raise RuntimeError("No agent identity established")

        logger.info("=" * 60)
        logger.info("CIRIS Agent Pre-Wakeup Verification Complete")
        logger.info(f"Identity: {self.agent_identity.agent_id}")
        logger.info(f"Purpose: {self.agent_identity.core_profile.description}")
        logger.info(f"Capabilities: {len(self.agent_identity.permitted_actions)} allowed")

        service_count = 0
        if self.service_registry:
            registry_info = self.service_registry.get_provider_info()
            for service_list in registry_info.get("services", {}).values():
                service_count += len(service_list)

        logger.info(f"Services: {service_count} registered")
        logger.info("=" * 60)

    async def _perform_startup_maintenance(self) -> None:
        """Perform database cleanup at startup."""
        if self.maintenance_service:
            try:
                logger.info("Starting critical database maintenance...")
                await self.maintenance_service.perform_startup_cleanup()
                logger.info("Database maintenance completed successfully")
            except Exception as e:
                logger.critical(f"CRITICAL ERROR: Database maintenance failed during startup: {e}")
                logger.critical("Database integrity cannot be guaranteed - initiating graceful shutdown")
                self._request_shutdown(f"Critical database maintenance failure: {e}")
                raise RuntimeError(f"Database maintenance failure: {e}") from e
        else:
            logger.critical("CRITICAL ERROR: No maintenance service available during startup")
            logger.critical("Database integrity cannot be guaranteed - initiating graceful shutdown")
            self._request_shutdown("No maintenance service available")
            raise RuntimeError("No maintenance service available")

    async def _clean_runtime_configs(self) -> None:
        """Clean up runtime-specific configuration from previous runs."""
        if not self.config_service:
            logger.warning("Config service not available - skipping runtime config cleanup")
            return

        try:
            logger.info("Cleaning up runtime-specific configurations...")
            all_configs = await self.config_service.list_configs()

            runtime_config_patterns = ["adapter.", "runtime.", "session.", "temp."]
            deleted_count = 0

            for key, value in all_configs.items():
                is_runtime_config = any(key.startswith(pattern) for pattern in runtime_config_patterns)

                if is_runtime_config:
                    config_node = await self.config_service.get_config(key)
                    if config_node:
                        if config_node.updated_by == "system_bootstrap":
                            logger.debug(f"Preserving bootstrap config: {key}")
                            continue

                        graph_node = config_node.to_graph_node()
                        await self.config_service.graph.forget(graph_node)  # type: ignore[attr-defined]
                        deleted_count += 1
                        logger.debug(f"Deleted runtime config node: {key}")

            if deleted_count > 0:
                logger.info(f"Cleaned up {deleted_count} runtime-specific configuration entries from previous runs")
            else:
                logger.info("No runtime-specific configuration entries to clean up")

        except Exception as e:
            logger.error(f"Failed to clean up runtime config: {e}", exc_info=True)

    async def _register_adapter_services(self) -> None:
        """Register services provided by the loaded adapters."""
        from ciris_engine.logic.setup.first_run import is_first_run

        if is_first_run():
            logger.info("First-run mode: Skipping adapter service registration")
            return

        if not self.service_registry:
            logger.error("ServiceRegistry not initialized. Cannot register adapter services.")
            return

        for adapter in self.adapters:
            try:
                adapter_type = adapter.__class__.__name__.lower().replace("adapter", "")
                adapter_info = self._build_adapter_info(adapter)
                await self._create_adapter_auth_token(adapter, adapter_type, adapter_info)

                registrations = adapter.get_services_to_register()
                for reg in registrations:
                    self._register_adapter_service(reg, adapter)
            except Exception as e:
                logger.error(f"Error registering services for adapter {adapter.__class__.__name__}: {e}", exc_info=True)

    def _build_adapter_info(self, adapter: Any) -> JSONDict:
        """Build adapter info dictionary for authentication token creation."""
        # Use stable adapter_id if available, otherwise use "default"
        # IMPORTANT: Do NOT use id(adapter) as it changes on every restart,
        # causing duplicate observer certificates to be created.
        instance_id = "default"
        if hasattr(adapter, "adapter_id") and adapter.adapter_id:
            instance_id = str(adapter.adapter_id)

        adapter_info: JSONDict = {
            "instance_id": instance_id,
            "startup_time": (
                self.time_service.now().isoformat() if self.time_service else datetime.now(timezone.utc).isoformat()
            ),
        }
        if hasattr(adapter, "get_channel_info"):
            adapter_info.update(adapter.get_channel_info())
        return adapter_info

    async def _create_adapter_auth_token(
        self, adapter: Any, adapter_type: str, adapter_info: JSONDict
    ) -> Optional[str]:
        """Create and set authentication token for an adapter."""
        auth_service = self.service_initializer.auth_service if self.service_initializer else None
        if not auth_service:
            return None

        # auth_service is `Any` (see service_initializer.py), so the call
        # returns Any — annotate locally so the function honours its
        # declared `Optional[str]` return type.
        auth_token: Optional[str] = await auth_service._create_channel_token_for_adapter(adapter_type, adapter_info)

        if hasattr(adapter, "set_auth_token") and auth_token:
            adapter.set_auth_token(auth_token)

        if auth_token:
            logger.info(f"Generated authentication token for {adapter_type} adapter")

        return auth_token

    def _register_adapter_service(self, reg: AdapterServiceRegistration, adapter: Any) -> bool:
        """Register a single adapter service. Returns True if successful."""
        if not isinstance(reg, AdapterServiceRegistration):
            logger.error(
                f"Adapter {adapter.__class__.__name__} provided an invalid AdapterServiceRegistration object: {reg}"
            )
            return False

        if self.service_registry is None:
            logger.error("Cannot register adapter service: service_registry is None")
            return False

        self.service_registry.register_service(
            service_type=reg.service_type,
            provider=reg.provider,
            priority=reg.priority,
            capabilities=reg.capabilities,
        )
        logger.info(f"Registered {reg.service_type.value} from {adapter.__class__.__name__}")
        return True

    async def _register_adapter_services_for_resume(self) -> None:
        """Register adapter services during resume_from_first_run."""
        if not self.service_registry:
            logger.error("ServiceRegistry not initialized. Cannot register adapter services.")
            return

        for adapter in self.adapters:
            try:
                adapter_type = adapter.__class__.__name__.lower().replace("adapter", "")
                adapter_info = self._build_adapter_info(adapter)
                await self._create_adapter_auth_token(adapter, adapter_type, adapter_info)

                for reg in adapter.get_services_to_register():
                    self._register_adapter_service(reg, adapter)
            except Exception as e:
                logger.error(f"Error registering services for adapter {adapter.__class__.__name__}: {e}", exc_info=True)

    async def _load_saved_adapters(self) -> None:
        """Load adapters that were saved to the graph config service.

        This restores dynamically loaded adapters (added via API) after restart.
        """
        from ciris_engine.logic.runtime.initialization_steps import load_saved_adapters_from_graph

        await load_saved_adapters_from_graph(self)

    async def _populate_context_enrichment_cache(self) -> None:
        """Pre-run context-enrichment tools so the first thought does not pay for them.

        Delegates to the step handler in initialization_steps, which is
        first-run aware and swallows its own failures (enrichment falls back to
        running lazily on the first thought).
        """
        from ciris_engine.logic.runtime.initialization_steps import populate_context_enrichment_cache

        await populate_context_enrichment_cache(self)

    async def _build_components(self) -> None:
        """Build all processing components.

        Idempotent: if `self.agent_processor` is already built, this is a
        no-op. The init manager registers a "Build Components" step at
        Phase 6 (`ciris_runtime.py:601`) AND the post-setup RESUME flow
        calls `_build_components` directly (`ciris_runtime.py:1387`).
        Without idempotency the second call replaces `self.agent_processor`
        with a fresh AgentProcessor whose state_manager never transitions
        to WORK — the first agent_processor's task is still running but
        `self.agent_processor` no longer points to it, so /v1/agent/status
        reads SHUTDOWN from the orphaned reference and the qa_runner
        timeout fires (observed: accord_metrics qa module hung 600s
        despite the agent actually being in WORK).
        """
        if self.agent_processor is not None:
            logger.debug(
                "[_build_components] agent_processor already built; skipping duplicate "
                "build (idempotent guard against double-registration on Phase 6)."
            )
            return

        logger.info("[_build_components] Starting component building...")
        logger.info(f"[_build_components] llm_service: {self.llm_service}")
        logger.info(f"[_build_components] service_registry: {self.service_registry}")
        logger.info(f"[_build_components] service_initializer: {self.service_initializer}")

        if self.service_initializer:
            logger.info(f"[_build_components] service_initializer.llm_service: {self.service_initializer.llm_service}")
            logger.info(
                f"[_build_components] service_initializer.service_registry: {self.service_initializer.service_registry}"
            )

        if not self.llm_service:
            from ciris_engine.logic.setup.first_run import is_first_run

            if is_first_run():
                logger.info("[_build_components] First-run setup mode - LLM not yet configured")
                logger.info("[_build_components] Setup wizard will guide LLM configuration")
            else:
                logger.error("[_build_components] LLM service not available but setup was completed!")
                logger.error("[_build_components] Check your LLM configuration")
            return

        try:
            self.component_builder = ComponentBuilder(self)
            logger.info("[_build_components] ComponentBuilder created successfully")

            self.agent_processor = await self.component_builder.build_all_components()
            logger.info(f"[_build_components] agent_processor created: {self.agent_processor}")

            if self.runtime_control_service:
                self.runtime_control_service.setup_thought_tracking()  # type: ignore[attr-defined]
                logger.debug("Thought tracking callback set up after agent_processor creation")

        except Exception as e:
            logger.error(f"[_build_components] Failed to build components: {e}", exc_info=True)
            raise

        self._register_core_services()
        logger.info("[_build_components] Component building completed")

    async def _start_adapter_connections(self) -> None:
        """Start adapter connections and wait for them to be ready."""
        from ciris_engine.logic.setup.first_run import is_first_run

        from .ciris_runtime_helpers import (
            create_adapter_lifecycle_tasks,
            log_adapter_configuration_details,
            verify_adapter_service_registration,
            wait_for_adapter_readiness,
        )

        log_adapter_configuration_details(self.adapters)

        first_run = is_first_run()
        if first_run:
            logger.info("")
            logger.info("=" * 70)
            logger.info("FIRST RUN DETECTED - Setup Wizard Mode")
            logger.info("=" * 70)
            logger.info("")
            logger.info("The agent processor will NOT start in first-run mode.")
            logger.info("Only the API server is running to provide the setup wizard.")
            logger.info("")
            logger.info("Next Steps:")
            logger.info("  1. Open your browser to: http://localhost:8080")
            logger.info("  2. Complete the setup wizard")
            logger.info("  3. Restart the agent with: ciris-agent")
            logger.info("")
            logger.info("After restart, the full agent will start normally.")
            logger.info("=" * 70)
            logger.info("")

            adapters_ready = await wait_for_adapter_readiness(self.adapters)
            if not adapters_ready:
                raise RuntimeError("Adapters failed to become ready within timeout")

            self._adapter_tasks = create_adapter_lifecycle_tasks(self.adapters, agent_task=None)

            logger.info("Setup wizard ready at http://localhost:8080")
            logger.info("Waiting for setup completion... (Press CTRL+C to exit)")
            return

        agent_task = asyncio.create_task(self._create_agent_processor_when_ready(), name="AgentProcessorTask")
        self._adapter_tasks = create_adapter_lifecycle_tasks(self.adapters, agent_task)

        adapters_ready = await wait_for_adapter_readiness(self.adapters)
        if not adapters_ready:
            raise RuntimeError("Adapters failed to become ready within timeout")

        services_available = await verify_adapter_service_registration(self)
        if not services_available:
            raise RuntimeError("Failed to establish adapter connections within timeout")

        await self._wait_for_critical_services(timeout=5.0)

    def _is_using_ciris_proxy(self) -> bool:
        """Check if runtime is configured to use CIRIS proxy."""
        return is_using_ciris_proxy()

    def _create_billing_token_handler(self, credit_provider: Any) -> Any:
        """Create handler for billing token refresh signals."""
        return create_billing_token_handler(credit_provider)

    def _create_llm_token_handler(self) -> Any:
        """Create handler for LLM service token refresh signals."""
        return create_llm_token_handler(self)

    def _update_llm_services_token(self, new_token: str) -> None:
        """Update all LLM services that use CIRIS proxy with new token."""
        update_llm_services_token(self, new_token)

    def _update_service_token_if_ciris_proxy(self, service: Any, new_token: str, is_primary: bool = False) -> None:
        """Update a service's API key if it uses CIRIS proxy."""
        update_service_token_if_ciris_proxy(service, new_token, is_primary)

    async def _reinitialize_billing_provider(self) -> None:
        """Reinitialize billing provider after setup completes."""
        await reinitialize_billing_provider(self)

    def _get_resource_monitor_for_billing(self) -> Any:
        """Get resource monitor service for billing initialization."""
        return get_resource_monitor_for_billing(self)

    def _create_billing_provider(self, google_id_token: str) -> Any:
        """Create and configure the CIRIS billing provider."""
        return create_billing_provider(google_id_token)

    def _resume_reload_environment(self, log_step: Any, total_steps: int) -> "EssentialConfig":
        """Reload environment and config during resume from first-run."""
        return reload_environment_for_resume(self, log_step, total_steps)

    async def _resume_initialize_identity(self, config: "EssentialConfig", log_step: Any, total_steps: int) -> None:
        """Initialize identity with user-selected template during resume."""
        await initialize_identity_for_resume(self, config, log_step, total_steps)

    async def _resume_migrate_cognitive_behaviors(self, log_step: Any, total_steps: int) -> None:
        """Migrate cognitive state behaviors from template during resume."""
        await migrate_cognitive_behaviors_for_resume(self, log_step, total_steps)

    def _set_service_runtime_references(self) -> None:
        """Set runtime references on services that need them."""
        set_service_runtime_references(self)

    async def _resume_initialize_core_services(
        self, config: "EssentialConfig", log_step: Any, total_steps: int
    ) -> None:
        """Initialize core services during resume."""
        await initialize_core_services_for_resume(self, config, log_step, total_steps)

    async def _resume_initialize_llm(self, log_step: Any, total_steps: int) -> None:
        """Initialize LLM service during resume."""
        await initialize_llm_for_resume(self, log_step, total_steps)

    def _resume_reinject_adapters(self, log_step: Any, total_steps: int) -> None:
        """Re-inject services into running adapters during resume."""
        reinject_adapters_for_resume(self, log_step, total_steps)

    async def _resume_load_post_setup_adapters(self, log_step: Any, total_steps: int) -> None:
        """Load adapters configured during setup wizard (explicit loading only).

        This replaces auto-enable - all adapter loading must be explicit via
        CIRIS_ADAPTER env var set during setup.
        """
        from ciris_engine.logic.runtime.resume_helpers import load_post_setup_adapters_for_resume

        await load_post_setup_adapters_for_resume(self, log_step, total_steps)

    async def _resume_auto_enable_environment_adapters(self) -> None:
        """Auto-enable adapters based on detected runtime environment.

        This enables adapters that can be automatically configured based on
        the environment, such as:
        - home_assistant: When SUPERVISOR_TOKEN present (HA addon mode)
        - ciris_hosted_tools: When on Android with Google auth

        Called after post-setup adapters are loaded.
        """
        await auto_enable_environment_adapters_for_resume(self)

    async def resume_from_first_run(self) -> None:
        """Resume initialization after setup wizard completes."""
        self._resume_in_progress = True
        self._resume_started_at = time.time()
        logger.info(f"[RESUME] Started at {self._resume_started_at:.3f}, _resume_in_progress=True")

        start_time = time.time()
        total_steps = 14

        def log_step(step_num: int, total: int, msg: str) -> None:
            elapsed = time.time() - start_time
            logger.warning(f"[RESUME {step_num}/{total}] [{elapsed:.2f}s] {msg}")

        logger.warning("")
        logger.warning("=" * 70)
        logger.warning("RESUMING FROM FIRST-RUN MODE")
        logger.warning("=" * 70)
        logger.warning("")
        log_step(1, total_steps, "Starting resume from first-run...")

        # Steps 2-3: Reload environment and config
        config = self._resume_reload_environment(log_step, total_steps)

        # Step 4: Initialize identity
        await self._resume_initialize_identity(config, log_step, total_steps)

        # Step 5: Migrate cognitive behaviors
        await self._resume_migrate_cognitive_behaviors(log_step, total_steps)

        # Step 6: Initialize core services
        await self._resume_initialize_core_services(config, log_step, total_steps)

        # Step 7: Register adapter services
        log_step(7, total_steps, "Registering adapter services...")
        await self._register_adapter_services_for_resume()
        log_step(7, total_steps, "Adapter services registered")

        # Step 8: Initialize maintenance service
        log_step(
            8, total_steps, f"Initializing maintenance... maintenance_service={self.maintenance_service is not None}"
        )
        if self.maintenance_service:
            await self._perform_startup_maintenance()
            log_step(8, total_steps, "Maintenance service initialized")
        else:
            log_step(8, total_steps, "Skipped maintenance - no maintenance_service")

        # Step 9: Reinitialize billing provider
        log_step(9, total_steps, "Reinitializing billing provider...")
        await self._reinitialize_billing_provider()
        log_step(9, total_steps, "Billing provider reinitialized")

        # Step 10: Initialize LLM service
        await self._resume_initialize_llm(log_step, total_steps)

        # Step 11: Re-inject services into adapters
        self._resume_reinject_adapters(log_step, total_steps)

        # Step 12: Load post-setup adapters and auto-enable environment adapters
        # This loads adapters configured during setup (e.g., cirisnode after Portal registration)
        # Then auto-enables environment-specific adapters (e.g., home_assistant when running as HA addon)
        log_step(12, total_steps, "Loading post-setup adapters...")
        await self._resume_load_post_setup_adapters(log_step, total_steps)
        log_step(12, total_steps, "Auto-enabling environment adapters...")
        await self._resume_auto_enable_environment_adapters()
        log_step(12, total_steps, "Post-setup adapters loaded")

        # Step 13: Build cognitive components
        log_step(13, total_steps, "Building cognitive components...")
        await self._build_components()
        log_step(13, total_steps, "Cognitive components built")

        # Step 14: Create agent processor task
        log_step(14, total_steps, "Creating agent processor task...")
        self._agent_task = asyncio.create_task(self._create_agent_processor_when_ready(), name="AgentProcessorTask")
        log_step(14, total_steps, "Waiting for critical services (timeout=10s)...")
        await self._wait_for_critical_services(timeout=10.0)

        elapsed = time.time() - start_time
        logger.warning("")
        logger.warning(f"RESUME COMPLETE in {elapsed:.2f}s - Agent processor started!")
        logger.warning("=" * 70)
        logger.warning("")

        self._resume_in_progress = False
        self._resume_started_at = None
        logger.info(f"[RESUME] Completed in {elapsed:.2f}s, _resume_in_progress=False")

        # Log "agent_configured" audit event - this is the definitive first-run completion record
        # It captures whether portal key was provisioned, identity template used, etc.
        await self._log_agent_configured_event()

    async def _log_agent_configured_event(self) -> None:
        """Log audit event for first-run configuration completion.

        This creates a tamper-evident record of the agent's initial configuration.
        This event is logged AFTER resume_from_first_run completes, when the audit service
        is fully initialized. Attestation may still be pending at this point.
        """
        if not self.audit_service:
            logger.warning("[AUDIT] Cannot log agent_configured - audit_service not available")
            return

        try:
            from ciris_engine.logic.persistence.models.graph import get_persist_engine
            from ciris_engine.schemas.audit import EventPayload

            # Get signing key info — the engine's local signer (2.9.7: the
            # ONE signer identity). Be defensive: engine may not be wired yet.
            key_id = "unknown"
            try:
                engine = get_persist_engine()
                key_id = str(engine.local_derived_key_id()) if engine is not None else "pending"
            except Exception:
                pass  # Key not available yet, that's fine

            # Get identity info if available
            identity_template = None
            agent_id = None
            if self.identity_manager:
                if self.identity_manager.agent_template:
                    identity_template = getattr(self.identity_manager.agent_template, "name", None)
                if self.identity_manager.agent_identity:
                    agent_id = getattr(self.identity_manager.agent_identity, "agent_id", None)

            # Use EventPayload as expected by AuditServiceProtocol.log_event
            # result should be normalized outcome, config details go in action
            config_details = (
                f"key_id={key_id}, template={identity_template or 'unknown'}, agent={agent_id or 'unknown'}"
            )
            audit_event = EventPayload(
                action=f"agent_configured: {config_details}",
                result="success",
                service_name="resume_from_first_run",
            )
            await self.audit_service.log_event("agent_configured", audit_event)
            logger.info(f"[AUDIT] agent_configured event logged (key_id={key_id})")
        except Exception as e:
            logger.warning(f"[AUDIT] Failed to log agent_configured event: {e}")

    async def _create_agent_processor_when_ready(self) -> None:
        """Create and start agent processor once all services are ready."""
        logger.info("Waiting for services to be ready before starting agent processor...")

        await self._wait_for_critical_services(timeout=30.0)

        if not self.agent_processor:
            from ciris_engine.logic.setup.first_run import is_first_run

            if is_first_run():
                logger.info("Agent processor not started - first-run setup mode active")
            else:
                logger.error("Agent processor not initialized but setup was completed!")
                logger.error("This indicates a configuration error - check LLM settings")
            return

        if self.bus_manager:
            _sink_task = asyncio.create_task(self.bus_manager.start())
            logger.info("Started multi-service sink as background task")

        # Hard gate: nothing — not WAKEUP, not WORK, not a single thought —
        # runs until startup attestation has finished. ciris_verify is a
        # mandatory runtime dependency, and per-thought batch_context already
        # blocks on await_attestation_ready(). Without this gate the *first*
        # thought after startup absorbs the full attestation latency and
        # downstream timing assertions (SSE snapshot waits, /v1/agent/interact
        # response window) blow their budgets. Gating here ensures the
        # processor only starts once the attestation cache is populated and
        # every subsequent thought sees a no-op await.
        #
        # Auth service enforces an end-to-end latency budget. If blown, the
        # gate dumps verifier-debugging receipts and starts the processor
        # DEGRADED rather than aborting — see _await_attestation_ready. The
        # breach is never silent (that would mask a verifier regression), but
        # it is also never fatal: a slow disk must not brick the install.
        await self._await_attestation_ready()

        effective_num_rounds = DEFAULT_NUM_ROUNDS
        logger.info(
            f"Starting agent processor (num_rounds={effective_num_rounds if effective_num_rounds != -1 else 'infinite'})..."
        )

        await self.agent_processor.start_processing(effective_num_rounds)

    async def _await_attestation_ready(self) -> None:
        """Block on the AuthenticationService's attestation budget.

        Non-fatal by design: a budget breach is a latency regression, not a
        correctness failure, so it degrades to a warning and lets the
        processor start. Enforcement lives in batch_context, which refuses
        to build a thought without an attestation result.

        Looks up the service by capability (await_attestation_ready) rather
        than registry type, mirroring batch_context's lookup so the two gate
        sites stay aligned. The budget is enforced by the auth service
        itself; a breach is reported here and startup continues degraded.

        On budget breach we dump receipts (per-stage timings, cache state,
        baseline_attestation, the active verifier mode) at ERROR level so
        the failure becomes a fileable ciris_verify issue rather than a
        flake-of-the-week.
        """
        auth_service = self.service_initializer.auth_service if self.service_initializer else None
        if auth_service is None or not hasattr(auth_service, "await_attestation_ready"):
            logger.warning(
                "AuthenticationService unavailable for attestation gate — "
                "processor will start without a startup attestation barrier. "
                "Per-thought batch_context will still block on attestation, "
                "so first-thought latency may be elevated until cache fills."
            )
            return

        logger.info("Awaiting startup attestation (15s budget) before processor start...")
        try:
            outcome = await auth_service.await_attestation_ready()
            if isinstance(outcome, AttestationGateOutcome) and outcome.is_breach():
                # The gate no longer raises on a latency breach, so the receipts
                # have to be driven off the returned outcome instead. Without
                # this the wedged-verifier case — the one this whole path exists
                # for — would log "complete" and dump nothing.
                self._log_attestation_failure_receipts(
                    auth_service,
                    RuntimeError(f"Startup attestation SLO breach: {outcome.value}"),
                )
                logger.warning(
                    "Startup attestation breached its latency budget (%s) — starting the "
                    "processor anyway (DEGRADED). batch_context still refuses to build a "
                    "thought without an attestation result, so nothing runs unattested. "
                    "Receipts above are a fileable ciris_verify issue.",
                    outcome.value,
                )
                return
            logger.info("Startup attestation complete — processor cleared to start.")
        except Exception as e:
            # Receipts first: this stays a fileable ciris_verify issue.
            self._log_attestation_failure_receipts(auth_service, e)
            # Then DEGRADE rather than abort. This gate is a latency pre-warm,
            # not the enforcement point — per-thought batch_context blocks on
            # the same await_attestation_ready() and refuses to build a thought
            # without an attestation result, so starting the processor here
            # cannot produce an unattested thought.
            #
            # Aborting instead cost a Windows user the whole app: 2.9.37 on
            # py3.14 spent >18s inside one ciris_verify_tree() call, blew the
            # 20s budget, and the runtime shut down 22s after boot — no UI, no
            # setup wizard, no way in. A slow disk should degrade first-thought
            # latency, not brick the install.
            logger.warning(
                "Startup attestation did not complete within budget — starting the "
                "processor anyway (DEGRADED). First-thought latency will absorb the "
                "remaining attestation time, and batch_context still refuses to build "
                "a thought without an attestation result, so nothing runs unattested. "
                "Receipts above are a fileable ciris_verify issue: %s",
                e,
            )

    def _log_attestation_failure_receipts(self, auth_service: Any, exc: BaseException) -> None:
        """Dump everything an upstream ciris_verify maintainer would need to
        reproduce a budget breach: per-stage timings, cache state, baseline,
        active mode, and the exception chain. Called from the gate's except
        branch so the receipts land in incidents_latest.log adjacent to the
        failure, alongside the raised RuntimeError."""
        import platform
        import sys
        import traceback

        def _safe(getter: Callable[[], Any]) -> Any:
            try:
                return getter()
            except Exception as e:  # pragma: no cover — defensive
                return f"<error reading: {e}>"

        receipts = {
            "exception_type": type(exc).__name__,
            "exception_message": str(exc),
            "attestation_started_at": _safe(lambda: getattr(auth_service, "_attestation_started_at", None)),
            "attestation_task_done": _safe(
                lambda: bool(getattr(auth_service, "_attestation_task", None) and auth_service._attestation_task.done())
            ),
            "attestation_cache_populated": _safe(lambda: getattr(auth_service, "_attestation_cache", None) is not None),
            "baseline_attestation_populated": _safe(
                lambda: getattr(auth_service, "_baseline_attestation", None) is not None
            ),
            "attestation_in_progress": _safe(lambda: bool(getattr(auth_service, "_attestation_in_progress", False))),
            "stage_timings_seconds": _safe(lambda: getattr(auth_service, "_attestation_stage_timings", None)),
            "platform": f"{platform.system()} {platform.release()}",
            "python": sys.version.split()[0],
            "running_tasks_count": _safe(lambda: len(asyncio.all_tasks())),
        }

        logger.error("=" * 70)
        logger.error("ATTESTATION GATE BUDGET BREACH — receipts for ciris_verify issue:")
        for key, value in receipts.items():
            logger.error("  %s: %s", key, value)
        logger.error("Exception chain:")
        for line in traceback.format_exception(type(exc), exc, exc.__traceback__):
            for sub_line in line.rstrip("\n").splitlines():
                logger.error("  %s", sub_line)
        logger.error("=" * 70)
        logger.error("File this at https://github.com/CIRISAI/CIRISVerify/issues with the block above.")

    def _register_core_services(self) -> None:
        """Register core services in the service registry."""
        self.service_initializer.register_core_services()

    def _build_action_dispatcher(self, dependencies: Any) -> ActionDispatcher:
        """Build action dispatcher. Override in subclasses for custom sinks."""
        config = self._ensure_config()
        from ciris_engine.logic.buses import BusManager

        if not self.service_registry:
            raise RuntimeError("Service registry not initialized")
        logger.debug(f"[AUDIT self.service_initializer exists: {self.service_initializer is not None}")
        if self.service_initializer:
            logger.debug(f"[AUDIT service_initializer.audit_service: {self.service_initializer.audit_service}")
        logger.debug(f"[AUDIT Creating BusManager with audit_service={self.audit_service}")
        logger.debug(f"[AUDIT self.audit_service type: {type(self.audit_service)}")
        logger.debug(f"[AUDIT self.audit_service is None: {self.audit_service is None}")

        assert self.service_registry is not None
        if self.time_service is None:
            raise RuntimeError("TimeService must be initialized before creating BusManager")

        bus_manager = BusManager(
            self.service_registry,
            time_service=self.time_service,
            telemetry_service=self.telemetry_service,
            audit_service=self.audit_service,
            resource_monitor=self.resource_monitor,
        )

        return build_action_dispatcher(
            bus_manager=bus_manager,
            time_service=self.time_service,
            shutdown_callback=dependencies.shutdown_callback,
            max_rounds=config.workflow.max_rounds,
            telemetry_service=self.telemetry_service,
            secrets_service=self.secrets_service,
        )

    def _should_exit_runtime_loop(
        self, agent_task: Optional[asyncio.Task[Any]], shutdown_logged: bool
    ) -> tuple[bool, bool]:
        """Check if runtime loop should exit."""
        if agent_task and agent_task.done():
            return True, shutdown_logged
        if (self._shutdown_event and self._shutdown_event.is_set()) or is_global_shutdown_requested():
            return True, True
        return False, shutdown_logged

    def _handle_completed_runtime_tasks(
        self,
        done: set[asyncio.Task[Any]],
        agent_task: Optional[asyncio.Task[Any]],
        adapter_tasks: List[asyncio.Task[Any]],
        all_tasks: list[asyncio.Task[Any]],
    ) -> tuple[bool, bool]:
        """Handle completed runtime tasks."""
        from .ciris_runtime_helpers import handle_runtime_agent_task_completion, handle_runtime_task_failures

        if (self._shutdown_event and self._shutdown_event.is_set()) or is_global_shutdown_requested():
            return True, True

        if agent_task and agent_task in done:
            handle_runtime_agent_task_completion(self, agent_task, adapter_tasks)
            return True, False

        excluded_tasks = {t for t in all_tasks if t.get_name() in ["ShutdownEventWait", "GlobalShutdownWait"]}
        handle_runtime_task_failures(self, done, excluded_tasks)
        return False, False

    async def run(self, _: Optional[int] = None) -> None:
        """Run the agent processing loop with shutdown monitoring."""
        from .ciris_runtime_helpers import (
            finalize_runtime_execution,
            monitor_runtime_shutdown_signals,
            setup_runtime_monitoring_tasks,
        )

        if not self._initialized:
            await self.initialize()

        try:
            agent_task, adapter_tasks, all_tasks = setup_runtime_monitoring_tasks(self)
            if not all_tasks:
                logger.error("No tasks to monitor - exiting")
                return

            shutdown_logged = False
            while True:
                should_exit, shutdown_logged = self._should_exit_runtime_loop(agent_task, shutdown_logged)
                if should_exit:
                    break

                done, pending = await asyncio.wait(all_tasks, return_when=asyncio.FIRST_COMPLETED, timeout=1.0)
                all_tasks = [t for t in all_tasks if t not in done]

                shutdown_logged = monitor_runtime_shutdown_signals(self, shutdown_logged)

                should_break, _ = self._handle_completed_runtime_tasks(done, agent_task, adapter_tasks, all_tasks)
                if should_break:
                    break

            await finalize_runtime_execution(self, set(pending) if "pending" in locals() else set())

        except KeyboardInterrupt:
            logger.info("Received interrupt signal. Requesting shutdown.")
            self.request_shutdown("KeyboardInterrupt")
        except Exception as e:
            logger.error(f"Runtime error: {e}", exc_info=True)
        finally:
            logger.debug("Runtime.run() entering finally block")
            await self.shutdown()
            logger.debug("Runtime.run() exiting finally block")

    async def shutdown(self) -> None:
        """Gracefully shutdown all services with continuity awareness."""
        from .ciris_runtime_helpers import (
            cleanup_runtime_resources,
            execute_final_maintenance_tasks,
            execute_service_shutdown_sequence,
            finalize_shutdown_logging,
            handle_adapter_shutdown_cleanup,
            handle_agent_processor_shutdown,
            prepare_shutdown_maintenance_tasks,
            preserve_critical_system_state,
            validate_shutdown_completion,
            validate_shutdown_preconditions,
        )

        if not validate_shutdown_preconditions(self):
            return

        logger.info("Shutting down CIRIS Runtime...")

        await prepare_shutdown_maintenance_tasks(self)
        await execute_final_maintenance_tasks(self)
        await preserve_critical_system_state(self)

        logger.info("Initiating shutdown sequence for CIRIS Runtime...")
        self._ensure_shutdown_event()
        if self._shutdown_event:
            self._shutdown_event.set()

        await handle_agent_processor_shutdown(self)
        await handle_adapter_shutdown_cleanup(self)

        logger.debug("Stopping core services...")
        await execute_service_shutdown_sequence(self)
        await self._release_substrate()

        await finalize_shutdown_logging(self)
        await cleanup_runtime_resources(self)
        validate_shutdown_completion(self)
        logger.debug("Shutdown method returning")

    async def _release_substrate(self) -> None:
        """Stop the node fold and close the Edge transport before Python exits (#1102).

        Order matters: the node (4243) serves on the edge (4242), so the node
        goes first. Both calls block with the GIL released and are bounded; a
        timeout is logged, never raised -- the process must still exit, and the
        next boot's Edge init now names a held port in its own words (#1101).
        """
        from ciris_engine.logic.runtime import edge_runtime, node_fold

        for label, fn, budget in (
            ("node fold", lambda: node_fold.stop_node_fold(timeout_secs=30.0), 35.0),
            ("edge runtime", lambda: edge_runtime.close_edge_runtime(), 15.0),
        ):
            try:
                result = await asyncio.wait_for(asyncio.to_thread(fn), timeout=budget)
                logger.info("Substrate release: %s -> %s", label, result)
            except asyncio.TimeoutError:
                logger.warning(
                    "Substrate release: %s did not finish within %.0fs; ports may stay bound (#1102)", label, budget
                )
            except Exception as exc:  # noqa: BLE001 -- shutdown must finish
                logger.warning("Substrate release: %s raised (continuing): %s", label, exc)

    async def _create_startup_node(self) -> None:
        """Create startup node for continuity tracking."""
        await create_startup_node(self)

    def _determine_shutdown_consent_status(self) -> str:
        """Determine if shutdown was consensual based on agent processor result."""
        return determine_shutdown_consent_status(self)

    def _build_shutdown_node_attributes(self, reason: str, consent_status: str) -> JSONDict:
        """Build attributes dict for shutdown memory node."""
        return build_shutdown_node_attributes(self, reason, consent_status)

    async def _update_identity_with_shutdown_reference(self, shutdown_node_id: str) -> None:
        """Update agent identity with shutdown memory reference."""
        await update_identity_with_shutdown_reference(self, shutdown_node_id)

    async def _preserve_shutdown_continuity(self) -> None:
        """Preserve agent state for future reactivation."""
        await preserve_shutdown_continuity(self)

    def _parse_bootstrap_config(
        self,
        bootstrap: Optional["RuntimeBootstrapConfig"],
        essential_config: Optional[EssentialConfig],
        startup_channel_id: Optional[str],
        adapter_types: List[str],
        adapter_configs: Optional[Dict[str, AdapterConfig]],
        kwargs: JSONDict,
    ) -> None:
        """Parse bootstrap configuration or create from legacy parameters."""
        parse_bootstrap_config(
            self, bootstrap, essential_config, startup_channel_id, adapter_types, adapter_configs, kwargs
        )

    def _create_bootstrap_from_legacy(
        self,
        essential_config: Optional[EssentialConfig],
        startup_channel_id: Optional[str],
        adapter_types: List[str],
        adapter_configs: Optional[Dict[str, AdapterConfig]],
        kwargs: JSONDict,
    ) -> None:
        """Create bootstrap config from legacy parameters."""
        create_bootstrap_from_legacy(self, essential_config, startup_channel_id, adapter_types, adapter_configs, kwargs)

    def _check_mock_llm(self) -> None:
        """Check for mock LLM environment variable and add to modules if needed."""
        check_mock_llm(self)

    def _load_adapters_from_bootstrap(self) -> None:
        """Load adapters from bootstrap configuration."""
        load_adapters_from_bootstrap(self)
