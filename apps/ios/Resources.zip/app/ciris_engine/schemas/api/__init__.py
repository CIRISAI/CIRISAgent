"""API schemas module."""
