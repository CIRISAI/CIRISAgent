from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Generic, List, Optional, Tuple, TypeVar, Union

import yaml
from pydantic import BaseModel

from ciris_engine.logic.registries.base import ServiceRegistry
from ciris_engine.protocols.services import LLMService
from ciris_engine.schemas.dma.prompts import PromptCollection
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.runtime.models import ImageContent, Task
from ciris_engine.schemas.services.llm import ContentBlock, ImageContentBlock, ImageURLDetail, TextContentBlock
from ciris_engine.schemas.types import JSONDict

if TYPE_CHECKING:
    from ciris_engine.protocols.faculties import EpistemicFaculty

logger = logging.getLogger(__name__)

InputT = TypeVar("InputT")
DMAResultT = TypeVar("DMAResultT", bound=BaseModel)


class BaseDMA(ABC, Generic[InputT, DMAResultT]):
    """Concrete base class for Decision Making Algorithms.

    This class provides the implementation of the BaseDMAInterface
    with backward compatibility for existing DMAs.
    """

    def _get_prompt_value(self, key: str) -> Optional[str]:
        """Read a prompt block from PromptCollection or dict overrides.

        Lives HERE, not on individual evaluators. It was defined on DSASPDMA
        alone, so MSASPDMA — written against the same `prompt_template_data`
        contract, using the same blocks — type-checked clean locally and failed
        CI with six "has no attribute" errors. Prompt access is a BaseDMA
        concern: every evaluator with a template needs it, and the next one
        should inherit it rather than rediscover the omission.
        """
        # getattr, not attribute access: `prompt_template_data` is supplied by
        # subclasses that HAVE a template, and not every DMA does. Declaring it
        # on the base would assert a property this class cannot provide.
        template = getattr(self, "prompt_template_data", None)
        if isinstance(template, PromptCollection):
            return template.get_prompt(key)
        if isinstance(template, dict):
            value = template.get(key)
            return str(value) if isinstance(value, str) else None
        return None

    def _require_prompt_value(self, key: str) -> str:
        """Read a required prompt block, or fail loudly during construction.

        Names the evaluator class in the error so a missing key points at the
        template that lacks it, rather than at whichever base method read it.
        """
        value = self._get_prompt_value(key)
        if value is None:
            raise ValueError(f"{type(self).__name__} prompt template missing required key: {key}")
        return value

    def __init__(
        self,
        service_registry: ServiceRegistry,
        model_name: Optional[str] = None,
        max_retries: int = 3,
        prompt_overrides: Optional[Union[Dict[str, str], PromptCollection]] = None,
        faculties: Optional[Dict[str, "EpistemicFaculty"]] = None,
        sink: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        self.service_registry = service_registry
        self.model_name = model_name
        self.max_retries = max_retries
        self.faculties = faculties or {}
        self.sink = sink

        self.kwargs = kwargs

        self.prompts: Union[Dict[str, str], PromptCollection] = {}
        self._load_prompts(prompt_overrides)

    def _load_prompts(self, overrides: Optional[Union[Dict[str, str], PromptCollection]] = None) -> None:
        """Load prompts from YAML file or use defaults.

        First checks for PROMPT_FILE class attribute, then falls back to
        prompts/<class_name>.yml file in the same directory as the DMA.
        Finally falls back to DEFAULT_PROMPT or DEFAULT_PROMPT_TEMPLATE if defined.
        """
        prompt_file = None
        if hasattr(self.__class__, "PROMPT_FILE"):
            prompt_file = getattr(self.__class__, "PROMPT_FILE")
        else:
            dma_file = Path(self.__class__.__module__.replace(".", "/"))
            prompt_file = dma_file.parent / "prompts" / f"{self.__class__.__name__.lower()}.yml"

        if prompt_file and Path(prompt_file).exists():
            try:
                # If overrides is already a PromptCollection, use it directly
                if isinstance(overrides, PromptCollection):
                    self.prompts = overrides
                    return

                # encoding="utf-8" is REQUIRED, not tidiness. Without it Python
                # uses the locale default, which on Windows is cp1252, and the
                # prompt YAML failed to load entirely:
                #
                #   Failed to load prompts from ...\action_selection_pdma.yml:
                #   'charmap' codec can't decode byte 0x8f in position 7288
                #
                # It is caught and logged as a WARNING below, so the agent then
                # reasoned with fallback prompts and kept running -- a silent
                # behavioural change on one platform, not a crash anyone chases.
                with open(prompt_file, "r", encoding="utf-8") as f:
                    file_prompts = yaml.safe_load(f) or {}

                # Research-override application (#989). This path reads the YAML
                # directly and keeps a plain dict, so it never passed through
                # DMAPromptLoader — which meant thirteen dma_prompt keys were
                # silently unapplied while the loader logged successful
                # replacements for their siblings. A manifest that reports a
                # swap it did not perform is worse than one that cannot swap:
                # the campaign reads a success line and runs the original value.
                #
                # No-op when the research gate is closed (the helper returns the
                # mapping unchanged), so production composition is unaffected —
                # the #972 golden bytes prove it.
                from ciris_engine.logic.dma.prompt_loader import apply_research_overrides_to_mapping

                template_name = Path(prompt_file).stem
                file_prompts = apply_research_overrides_to_mapping(template_name, file_prompts)

                # Support both dict and PromptCollection. Caller-supplied
                # overrides still win over the manifest: they are explicit
                # construction arguments, not experiment configuration.
                if isinstance(overrides, dict):
                    self.prompts = {**file_prompts, **overrides}
                else:
                    self.prompts = file_prompts
                return
            except Exception as e:
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(f"Failed to load prompts from {prompt_file}: {e}")

        # Handle overrides as PromptCollection
        if isinstance(overrides, PromptCollection):
            self.prompts = overrides
            return

        defaults = {}
        if hasattr(self, "DEFAULT_PROMPT"):
            defaults = getattr(self, "DEFAULT_PROMPT")
        elif hasattr(self, "DEFAULT_PROMPT_TEMPLATE"):
            defaults = getattr(self, "DEFAULT_PROMPT_TEMPLATE")

        if isinstance(overrides, dict):
            self.prompts = {**defaults, **overrides}
        else:
            self.prompts = defaults

    def get_accord_mode(self) -> str:
        """Get the accord mode from prompts configuration.

        Returns:
            'full' (default), 'compressed', or 'none'
        """
        if isinstance(self.prompts, PromptCollection):
            return getattr(self.prompts, "accord_mode", "full")
        elif isinstance(self.prompts, dict):
            # Check for accord_header key (legacy) or accord_mode
            accord_value = self.prompts.get("accord_header", self.prompts.get("accord_mode", "full"))
            if isinstance(accord_value, bool):
                # Legacy boolean - True means 'full', False means 'none'
                return "full" if accord_value else "none"
            return str(accord_value) if accord_value else "full"
        return "full"

    async def get_llm_service(self) -> Optional[LLMService]:
        """Return the LLM service for this DMA from the service registry."""
        service = await self.service_registry.get_service(
            handler=self.__class__.__name__,
            service_type=ServiceType.LLM,
        )
        return service

    async def call_llm_structured(
        self,
        messages: List[JSONDict],
        response_model: type,
        max_tokens: int = 1024,
        temperature: float = 0.0,
        thought_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> Tuple[Any, ...]:
        """Call LLM via sink for centralized failover, round-robin, and circuit breaker protection.

        Args:
            messages: List of message dictionaries
            response_model: Pydantic model for response
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            thought_id: Optional thought_id for resource tracking
            task_id: Optional task_id for ciris.ai billing (all calls with same task_id share 1 credit)

        Returns:
            Tuple[BaseModel, ResourceUsage]
        """
        if not self.sink:
            # Critical system failure - DMAs cannot function without the multi-service sink
            import logging

            logger = logging.getLogger(__name__)
            logger.critical(
                f"FATAL: No multi-service sink available for {self.__class__.__name__}. System cannot continue."
            )
            raise RuntimeError(
                f"FATAL: No multi-service sink available for {self.__class__.__name__}. DMAs require the sink for all LLM calls. System must shutdown."
            )

        # Use LLM bus for centralized failover, round-robin, and circuit breaker protection
        result = await self.sink.llm.call_llm_structured(
            messages=messages,
            response_model=response_model,
            handler_name=self.__class__.__name__,
            max_tokens=max_tokens,
            temperature=temperature,
            thought_id=thought_id,
            task_id=task_id,
        )

        # The sink returns Optional[tuple] which we need to ensure is a valid tuple
        if result is None:
            raise RuntimeError(f"Multi-service sink returned None for structured LLM call in {self.__class__.__name__}")

        # Ensure result is a tuple (it should be from the type annotation)
        if not isinstance(result, tuple):
            raise RuntimeError(f"Multi-service sink returned non-tuple: {type(result)}")

        return result

    async def apply_faculties(self, content: str, context: Optional[JSONDict] = None) -> Dict[str, BaseModel]:
        """Apply available epistemic faculties to content.

        Args:
            content: The content to analyze
            context: Optional context for analysis (FacultyContext or dict to convert)

        Returns:
            Dictionary mapping faculty name to evaluation result
        """
        from ciris_engine.schemas.dma.faculty import FacultyContext

        # Use Dict[str, BaseModel] to match return type
        results: Dict[str, BaseModel] = {}

        if not self.faculties:
            return results

        # Convert dict to FacultyContext if needed
        faculty_context: Optional[FacultyContext] = None
        if context is not None:
            if isinstance(context, dict):
                faculty_context = FacultyContext(**context)
            else:
                faculty_context = context

        for name, faculty in self.faculties.items():
            try:
                result = await faculty.analyze(content, faculty_context)
                results[name] = result
            except Exception as e:
                # Log error but don't fail the entire evaluation
                import logging

                logger = logging.getLogger(__name__)
                logger.warning(f"Faculty {name} failed to evaluate: {e}")
                continue

        return results

    def get_algorithm_type(self) -> str:
        """Get the type of decision making algorithm."""
        # Return class name by default
        return self.__class__.__name__

    async def fetch_original_task(self, source_task_id: str, agent_occurrence_id: str = "default") -> Optional[Task]:
        """Fetch the original task from persistence.

        Args:
            source_task_id: The task ID to fetch
            agent_occurrence_id: The occurrence ID for the task

        Returns:
            Task object if found, None otherwise
        """
        try:
            from ciris_engine.logic import persistence

            task = persistence.get_task_by_id(source_task_id, agent_occurrence_id)
            if task:
                logger.debug(f"[DMA] Fetched original task: {source_task_id}")
            else:
                logger.warning(f"[DMA] Task {source_task_id} not found in persistence")
            return task
        except Exception as e:
            logger.error(f"[DMA] Failed to fetch task {source_task_id}: {e}")
            return None

    def format_task_context(self, task: Optional[Task], thought_depth: int = 0) -> str:
        """Format task context for inclusion in DMA prompts.

        Args:
            task: The original Task object (or None if not found)
            thought_depth: Current thought depth (0=initial, >0=follow-up)

        Returns:
            Formatted string with task context for the prompt
        """
        if not task:
            return "(Original task not available)"

        parts = []
        parts.append(f'Task: "{task.description}"')
        parts.append(f"Task ID: {task.task_id}")

        if hasattr(task, "status") and task.status:
            parts.append(f"Status: {task.status}")

        # Include parent task context if available (for subtasks)
        if task.context and task.context.parent_task_id:
            parts.append(f"Parent Task ID: {task.context.parent_task_id}")

        # Add follow-through guidance for non-initial thoughts
        if thought_depth > 0:
            parts.append("")
            parts.append(
                "⚠️ FOLLOW-THROUGH REQUIRED: This is thought depth {depth}. "
                "Previous actions have been taken. Evaluate whether the current "
                "thought properly continues toward completing the original task.".format(depth=thought_depth)
            )

        return "\n".join(parts)

    @staticmethod
    def build_multimodal_content(
        text: str,
        images: List[ImageContent],
    ) -> Union[str, List[Dict[str, Any]]]:
        """
        Build content for an LLM message, supporting both text-only and multimodal.

        If no images are provided, returns the text string directly.
        If images are provided, returns a list of serialized content block dicts.

        Args:
            text: Text content of the message
            images: List of ImageContent objects (can be empty)

        Returns:
            Either a string (text-only) or List[Dict] (multimodal content blocks)
        """
        if not images:
            return text

        # Build content blocks for multimodal message and serialize to dicts
        # This ensures JSON serialization works when sent to LLM APIs
        content: List[Dict[str, Any]] = [TextContentBlock(text=text).model_dump()]

        for img in images:
            image_block = ImageContentBlock(image_url=ImageURLDetail(url=img.to_data_url()))
            content.append(image_block.model_dump())

        return content

    def build_user_message(
        self,
        text: str,
        images: Optional[List[ImageContent]] = None,
    ) -> JSONDict:
        """
        Build a user message dict for LLM calls, with optional multimodal support.

        Args:
            text: Text content of the message
            images: Optional list of ImageContent objects

        Returns:
            Message dict with role and content (text or multimodal)
        """
        content = self.build_multimodal_content(text, images or [])
        return {"role": "user", "content": content}

    @abstractmethod
    async def evaluate(self, *args: Any, **kwargs: Any) -> BaseModel:
        """Execute DMA evaluation and return a pydantic model.

        Note: This maintains the old signature for backward compatibility.
        New DMAs should use the typed interface methods.
        """
        raise NotImplementedError
