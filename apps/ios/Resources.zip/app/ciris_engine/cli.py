"""
CIRIS Agent CLI - Desktop-first launcher with server fallback.

Usage after 'pip install ciris-agent':
    ciris-agent                          # Start server + launch desktop app
    ciris-agent --server                 # Start API server only (headless)
    ciris-agent --adapter api            # Same as --server
    ciris-agent --adapter discord        # Discord bot mode
    ciris-agent upgrade                  # Close CIRIS, upgrade it, start it again
"""

import os
import subprocess
import sys
import threading
from pathlib import Path

# Skip early FFI verification to avoid tokio runtime hang during Python import lock
# Binary self-verification still runs when get_license_status() is called
os.environ["CIRIS_SKIP_EARLY_VERIFY"] = "1"

from ciris_engine.logic.utils import win_console as _win_console  # noqa: E402

_win_console.setup()

#: Set to 0 to keep ciris-agent.exe in the foreground on Windows.
HANDOFF_ENV = "CIRIS_LAUNCHER_HANDOFF"


def main() -> None:
    """
    Entry point for the ciris-agent CLI command.

    By default, starts the API server and launches the desktop app.
    Use --server or --adapter for headless/server modes.
    """
    # Stops CIRIS first: pip can't replace a running install on Windows.
    if sys.argv[1:2] == ["upgrade"]:
        from ciris_engine.upgrade import run_upgrade

        sys.exit(run_upgrade(sys.argv[2:]))

    _hand_off_from_launcher()

    # Check if user wants server/headless mode
    server_mode = False
    for arg in sys.argv[1:]:
        if arg in ("--server", "--headless", "--adapter", "-a"):
            server_mode = True
            break
        if arg in ("--help", "-h", "--version"):
            # Let main.py handle these
            server_mode = True
            break

    # The node this process starts must know what device it is on (server
    # 0.5.220 / persist v53: SELF and FAMILY content does not replicate to a
    # server-class node). The bare `ciris-agent` is a person's desktop install;
    # the flags above are headless. Set before anything spawns the node.
    from ciris_engine.logic.runtime.device_class import HostDeviceClass, declare_device_class

    declare_device_class(HostDeviceClass.SERVER if server_mode else HostDeviceClass.LAPTOP)

    # "Run without AI" (CIRISAgent#1149): the owner chose a node with no brain.
    # Asked before anything from the engine is imported; if set, the process
    # is ciris-server and the client and nothing else.
    from ciris_engine import node_only

    wants_help = any(arg in ("--help", "-h", "--version") for arg in sys.argv[1:])
    cfg = None if wants_help else node_only.node_only_config()
    if cfg is not None:
        if server_mode:
            node_only.run_headless(cfg)
        sys.exit(node_only.run_desktop(cfg))

    if server_mode:
        _normalize_server_flags()
        # Delegate to main.py for server/adapter modes
        _run_server_mode()
    else:
        # Start server then launch desktop app
        _run_desktop_mode()



def _started_from_exe_launcher() -> bool:
    """True under the Scripts\\ciris-agent.exe pip generated.

    Not sys.argv[0]: pip's launcher script strips ".exe" from it. The script runs
    from inside the exe, so __main__ is "...\\ciris-agent.exe\\__main__.py".
    """
    main_file = getattr(sys.modules.get("__main__"), "__file__", None) or ""
    return ".exe" in str(main_file).lower()


def _hand_off_from_launcher() -> None:
    """On Windows, keep running without ciris-agent.exe.

    The launcher stays alive as long as what it started, and pip can't replace a
    running launcher, so `pip install -U` under a running CIRIS failed (WinError 32)
    after it had already replaced the client and the server, and left an agent
    that couldn't import. Stopping when pip starts doesn't help: pip reaches the
    launcher within seconds (8 s in run 41856049056), faster than a clean stop.
    So nothing waits on the launcher: this restarts under the plain interpreter,
    on the same console, and lets the launcher exit.

    CIRIS_LAUNCHER_HANDOFF=0 keeps it in the foreground, for a service wrapper
    that watches the process it started.
    """
    if sys.platform != "win32" or os.environ.get(HANDOFF_ENV, "1").strip() == "0":
        return
    if not _started_from_exe_launcher() or any(a in ("--help", "-h", "--version") for a in sys.argv[1:]):
        return
    env = _win_console.subprocess_env()
    env[HANDOFF_ENV] = "0"
    child = subprocess.Popen([sys.executable, "-m", "ciris_engine.cli", *sys.argv[1:]], env=env)
    print(f"CIRIS is running (pid {child.pid}). This window shows its output; close it or press Ctrl+C to stop.")
    sys.exit(0)


def _normalize_server_flags() -> None:
    """Turn ``--server`` / ``--headless`` into what main.py's click interface takes.

    They selected server mode here and were then passed through, so the documented
    ``ciris-agent --server`` died with "No such option '--server'" on every version.
    """
    args = [a for a in sys.argv[1:] if a not in ("--server", "--headless")]
    if len(args) != len(sys.argv) - 1 and "--adapter" not in args and "-a" not in args:
        args = ["--adapter", "api", *args]
    sys.argv[1:] = args


def _explain_server_death(exit_code: int, port: int) -> None:
    """Say WHY the server died, using the logs it just wrote.

    2.9.23 promised that a failure would explain itself, and then a user on
    Windows got exactly one line for a server that died after all 22 services
    had started:

        ERROR: Server process exited with code 1

    That line is OURS, not the server's. The server logs to a file and to its
    own incidents log; the launcher knew both paths and printed neither, so the
    person best placed to act had the least information. Nobody greps a path
    they were never shown.

    Reads the tail of whatever it can find. Never raises: this runs on a path
    that is already failing, and a diagnostic that throws replaces the real
    problem with its own.
    """
    import os
    from pathlib import Path

    print(f"\n{'=' * 72}", file=sys.stderr)
    print(f"CIRIS server exited with code {exit_code}", file=sys.stderr)
    print(f"{'=' * 72}", file=sys.stderr)

    try:
        home = Path(os.environ.get("CIRIS_HOME") or (Path.home() / "ciris"))
        logs = home / "logs"
        # incidents first: it is WARNING+ only, so the cause is usually the tail.
        # ciris-server.log carries the substrate's own (non-Python) output, which
        # never reaches the incidents log — the startup banner says so.
        candidates = [
            ("incidents", logs / "incidents_latest.log"),
            ("agent log", logs / "latest.log"),
            ("substrate", logs / "ciris-server.log"),
        ]
        shown = False
        for label, path in candidates:
            try:
                if not path.exists() or path.stat().st_size == 0:
                    continue
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
                tail = [ln for ln in lines[-40:] if ln.strip()][-12:]
                if not tail:
                    continue
                print(f"\n--- last {len(tail)} lines of {label}: {path}", file=sys.stderr)
                for ln in tail:
                    print(f"    {ln}", file=sys.stderr)
                shown = True
            except OSError:
                continue

        if not shown:
            print(f"\nNo log content found under {logs}", file=sys.stderr)
            print("If that directory is empty the server died before logging started —", file=sys.stderr)
            print("run `ciris-server` directly to see its output on this console.", file=sys.stderr)
        else:
            print(f"\nFull logs: {logs}", file=sys.stderr)
    except Exception as exc:  # pragma: no cover - diagnostics must not throw
        print(f"(could not read logs: {type(exc).__name__}: {exc})", file=sys.stderr)

    print(f"\nIf the cause is not above, these are the usual ones:", file=sys.stderr)
    print(f"  - port {port} already in use   (Windows: netstat -ano | findstr :{port})", file=sys.stderr)
    print("  - a second process holding the same CIRIS_HOME (one engine per home)", file=sys.stderr)
    print("  - a stale .env pointing at paths that no longer exist", file=sys.stderr)
    print(f"{'=' * 72}\n", file=sys.stderr)


def _wait_for_server_health(
    server_url: str, server_proc: "subprocess.Popen[bytes]", timeout: float = 60.0
) -> bool:
    """Wait for server to be healthy (responding to startup-status).

    Uses /v1/system/startup-status which is available during boot before
    authentication is ready, and is more lightweight than /health.

    Args:
        server_url: Base URL of the server
        server_proc: The server subprocess to monitor for early exit
        timeout: Maximum seconds to wait

    Returns:
        True if server became healthy, False if timed out or process died
    """
    import json
    import time
    import urllib.error
    import urllib.request

    # Use startup-status endpoint - available during boot, unauthenticated
    status_url = f"{server_url}/v1/system/startup-status"
    start = time.time()
    attempt = 0
    last_services = 0

    while time.time() - start < timeout:
        # Check if server process died
        if server_proc.poll() is not None:
            return False

        attempt += 1
        try:
            with urllib.request.urlopen(status_url, timeout=3) as resp:
                if resp.status == 200:
                    body = resp.read().decode("utf-8")
                    data = json.loads(body).get("data", {})
                    services_online = data.get("services_online", 0)
                    services_total = data.get("services_total", 22)
                    phase = data.get("phase", "unknown")
                    api_status = data.get("api_status", "")

                    # Print progress when services change
                    if services_online != last_services:
                        print(f"Server starting: {services_online}/{services_total} services ({phase})")
                        last_services = services_online

                    # Ready when api_status is "server_ready" (works for both
                    # normal mode with all 22 services and first-run mode with
                    # only 10 minimal services)
                    if api_status == "server_ready":
                        elapsed = time.time() - start
                        print(f"Server ready: {services_online}/{services_total} services ({elapsed:.1f}s)")
                        return True
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, json.JSONDecodeError):
            pass

        # Print progress every 10 attempts if no service updates
        if attempt % 10 == 0:
            print(f"Waiting for server... (attempt {attempt})")

        time.sleep(0.5)

    return False


def _run_desktop_mode() -> None:
    """Start API server and launch desktop application."""
    import time

    port = 8080
    server_url = f"http://localhost:{port}"

    # Find main.py
    parent_dir = Path(__file__).parent.parent
    main_py = parent_dir / "main.py"

    if not main_py.exists():
        print(f"ERROR: main.py not found at {main_py}", file=sys.stderr)
        print("Falling back to server-only mode...", file=sys.stderr)
        _run_server_mode()
        return

    print("Starting CIRIS API server...")

    # Start server in background (show output for debugging). Propagate the
    # UTF-8 stdio intent so the child main.py doesn't crash on cp1252 consoles.
    server_proc = subprocess.Popen(
        [sys.executable, str(main_py), "--adapter", "api", "--port", str(port)],
        cwd=str(parent_dir),
        env=_win_console.subprocess_env(),
    )

    # Wait briefly and check if server crashed during startup
    time.sleep(2.0)
    exit_code = server_proc.poll()
    if exit_code is not None:
        # Server process exited - it crashed during startup
        print(f"\n{'=' * 60}", file=sys.stderr)
        print("ERROR: CIRIS server failed to start!", file=sys.stderr)
        print(f"{'=' * 60}", file=sys.stderr)
        if exit_code != 0:
            print(f"Server exited with code: {exit_code}", file=sys.stderr)
        print("\nCommon causes:", file=sys.stderr)
        print(f"  - Port {port} is already in use by another process", file=sys.stderr)
        print("  - Missing configuration or dependencies", file=sys.stderr)
        print("\nTo check if port is in use:", file=sys.stderr)
        print(f"  lsof -i :{port}  (Linux/macOS)", file=sys.stderr)
        print(f"  netstat -ano | findstr :{port}  (Windows)", file=sys.stderr)
        print("\nTo kill processes using the port:", file=sys.stderr)
        print(f"  fuser -k {port}/tcp  (Linux)", file=sys.stderr)
        print(f"{'=' * 60}\n", file=sys.stderr)
        sys.exit(exit_code if exit_code != 0 else 1)

    from ciris_engine.logic.utils.path_resolution import get_ciris_home
    from ciris_engine.upgrade import STOP_DEADLINE_SECS, register_running, start_watch

    home = get_ciris_home()
    register_running(home, [sys.executable, "-m", "ciris_engine.cli", *sys.argv[1:]])
    stopping_for_upgrade = threading.Event()

    def _close_for_upgrade(reason: str) -> None:
        # The server child has its own watcher and stops itself; close the UI so
        # this launcher can exit and release ciris-agent.exe.
        print(f"\nCIRIS is closing for an upgrade: {reason}. Start it again when the upgrade finishes.", file=sys.stderr)
        stopping_for_upgrade.set()
        from ciris_engine.desktop_launcher import stop_desktop_app

        stop_desktop_app()

    start_watch(_close_for_upgrade, home)

    try:
        # Wait for server to be actually healthy before launching desktop
        # This prevents the desktop app from trying to start its own server
        print("Waiting for server to be ready...")
        if not _wait_for_server_health(server_url, server_proc, timeout=60.0):
            # Check if process crashed while we were waiting
            exit_code = server_proc.poll()
            if exit_code is not None:
                _explain_server_death(exit_code, port)
                sys.exit(exit_code if exit_code != 0 else 1)
            print("WARNING: Server not responding to health checks yet, launching desktop anyway...")
            print("         The desktop app will retry connecting to the server.")

        # Launch bundled desktop app (it has its own server detection logic)
        try:
            from ciris_engine.desktop_launcher import launch_desktop_app

            print("\nLaunching CIRIS Desktop...")
            exit_code = launch_desktop_app(server_url=server_url)

        except ImportError as e:
            print(f"Desktop launcher not available: {e}", file=sys.stderr)
            print(f"\nServer running at: {server_url}")
            print("Press Ctrl+C to stop...")
            exit_code = 0
            # Keep running until interrupted
            try:
                server_proc.wait()
            except KeyboardInterrupt:
                pass
        except Exception as e:
            print(f"ERROR: Failed to launch desktop app: {e}", file=sys.stderr)
            print(f"\nServer still running at: {server_url}")
            print("Press Ctrl+C to stop...")
            exit_code = 1
            try:
                server_proc.wait()
            except KeyboardInterrupt:
                pass

    finally:
        # Shutdown server
        print("\nShutting down server...")
        if stopping_for_upgrade.is_set():
            try:
                server_proc.wait(timeout=STOP_DEADLINE_SECS)
            except subprocess.TimeoutExpired:
                pass
        server_proc.terminate()
        try:
            server_proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server_proc.kill()

    sys.exit(exit_code)


def _run_server_mode() -> None:
    """Run in server/adapter mode via main.py."""
    # Ensure parent directory is in path so we can import main
    parent_dir = Path(__file__).parent.parent
    if str(parent_dir) not in sys.path:
        sys.path.insert(0, str(parent_dir))

    # So `ciris-agent upgrade` can find and restart this process.
    from ciris_engine.logic.utils.path_resolution import get_ciris_home
    from ciris_engine.upgrade import register_running

    register_running(get_ciris_home(), [sys.executable, "-m", "ciris_engine.cli", *sys.argv[1:]])

    # Import and run the existing main() function from main.py
    try:
        import main as ciris_main

        ciris_main.main()
    except ImportError as e:
        print(f"ERROR: Failed to import main module: {e}", file=sys.stderr)
        print("This should not happen in a properly installed package.", file=sys.stderr)
        sys.exit(1)


def server() -> None:
    """Entry point for ciris-server command (headless API server)."""
    from ciris_engine import node_only
    from ciris_engine.logic.runtime.device_class import HostDeviceClass, declare_device_class

    declare_device_class(HostDeviceClass.SERVER)

    cfg = node_only.node_only_config()
    if cfg is not None:
        node_only.run_headless(cfg)
    # Insert --adapter api if not specified
    if "--adapter" not in sys.argv and "-a" not in sys.argv:
        sys.argv.insert(1, "--adapter")
        sys.argv.insert(2, "api")
    _run_server_mode()


def desktop() -> None:
    """Entry point for ciris-desktop command."""
    from ciris_engine import node_only

    cfg = node_only.node_only_config()
    if cfg is not None:
        # UI only, against a node assumed running (the wheel's `ciris-desktop` contract).
        from ciris_server.desktop_launcher import launch_desktop_app  # type: ignore[import-not-found, import-untyped, unused-ignore]

        sys.exit(int(launch_desktop_app(server_url=cfg.server_url)))
    from ciris_engine.desktop_launcher import main as desktop_main

    desktop_main()


if __name__ == "__main__":
    main()
