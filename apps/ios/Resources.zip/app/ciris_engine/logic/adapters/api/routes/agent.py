"""
Agent interaction endpoints for CIRIS API v3.0 (Simplified).

Core endpoints for natural agent interaction.
"""

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Tuple, Union

from fastapi import APIRouter, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from ciris_engine.logic.adapters.base_observer import BillingServiceError, CreditCheckFailed, CreditDenied
from ciris_engine.schemas.api.agent import AgentLineage, MessageContext, ServiceAvailability
from ciris_engine.schemas.api.auth import ROLE_PERMISSIONS, AuthContext, Permission, UserRole
from ciris_engine.schemas.api.responses import SuccessResponse
from ciris_engine.schemas.runtime.accord_halt import AccordHaltState, AccordRowForward
from ciris_engine.schemas.runtime.messages import IncomingMessage
from ciris_engine.schemas.services.credit_gate import CreditAccount, CreditContext
from ciris_engine.schemas.types import JSONDict

from ..constants import (
    DESC_CURRENT_COGNITIVE_STATE,
    ERROR_MEMORY_SERVICE_NOT_AVAILABLE,
    ERROR_MESSAGE_HANDLER_NOT_CONFIGURED,
)
from ._common import RESPONSES_402_403_503, RESPONSES_500, RESPONSES_503, AuthObserverDep, derive_credit_account

logger = logging.getLogger(__name__)

# Minimum uptime in seconds before defaulting task count
MIN_UPTIME_FOR_DEFAULT_TASKS = 60

# Tracks which CREDIT_ATTACH miss reasons we have already logged during this
# server lifetime. The message handler runs CREDIT_ATTACH on every inbound
# message, so a missing provider would otherwise produce one log line per
# message (e.g. 1000 entries during a memory benchmark). We only care about
# the first occurrence per reason — subsequent ones are redundant.
_credit_attach_miss_logged: set[str] = set()

router = APIRouter(prefix="/agent", tags=["agent"])

# Request/Response schemas


class MessageRejectionReason(str, Enum):
    """Reasons why a message submission was rejected or not processed."""

    AGENT_OWN_MESSAGE = "AGENT_OWN_MESSAGE"  # Message from agent itself
    FILTERED_OUT = "FILTERED_OUT"  # Filtered by adaptive filter
    CREDIT_DENIED = "CREDIT_DENIED"  # Insufficient credits
    CREDIT_CHECK_FAILED = "CREDIT_CHECK_FAILED"  # Credit provider error
    PROCESSOR_PAUSED = "PROCESSOR_PAUSED"  # Agent processor paused
    RATE_LIMITED = "RATE_LIMITED"  # Rate limit exceeded
    CHANNEL_RESTRICTED = "CHANNEL_RESTRICTED"  # Channel access denied
    RESOURCE_SHED = "RESOURCE_SHED"  # Runtime self-protection: admission closed under resource pressure
    ACCORD_HALT = "ACCORD_HALT"  # CC 4.2.1.1 constitutional halt: agent acts paused, no new work admitted
    ACCORD_ROW_FORWARDED = "ACCORD_ROW_FORWARDED"  # An accord row, handed to the node; not work for the agent
    NODE_UNCLAIMED = "NODE_UNCLAIMED"  # The node has no owner: an agent does not run on an unowned node


class ImagePayload(BaseModel):
    """Image payload for multimodal requests."""

    data: str = Field(..., description="Base64-encoded image data or URL")
    media_type: str = Field(default="image/jpeg", description="MIME type (image/jpeg, image/png, etc)")
    filename: Optional[str] = Field(default=None, description="Optional filename")


class DocumentPayload(BaseModel):
    """Document payload for text extraction from files."""

    data: str = Field(..., description="Base64-encoded document data or URL")
    media_type: str = Field(
        default="application/pdf",
        description="MIME type (application/pdf, application/vnd.openxmlformats-officedocument.wordprocessingml.document)",
    )
    filename: Optional[str] = Field(default=None, description="Optional filename (helps determine document type)")


class InteractRequest(BaseModel):
    """Request to interact with the agent."""

    message: str = Field(..., description="Message to send to the agent")
    context: Optional[MessageContext] = Field(None, description="Optional context")
    images: Optional[List[ImagePayload]] = Field(default=None, description="Optional images for multimodal interaction")
    documents: Optional[List[DocumentPayload]] = Field(
        default=None, description="Optional documents (PDF, DOCX) for text extraction"
    )


class InteractOutcome(str, Enum):
    """How an interact() call ended (#1059).

    The HTTP status is 200 for all three and `response` always carries text,
    so a caller that only reads `response` keeps working. A caller that needs
    to know whether that text is the agent's answer reads this instead of
    matching the placeholder — which is localized, so string matching breaks
    for every agent not running in English.
    """

    #: `response` is the agent's reply.
    COMPLETE = "complete"
    #: The deadline passed first. `response` is the localized still-processing
    #: placeholder; the task keeps running and its reply lands in history.
    TIMEOUT = "timeout"
    #: The processor is paused; the message is queued, `response` says so.
    PAUSED = "paused"
    #: The task failed before it could answer (#1264): its last live thought
    #: raised, e.g. a DMA that exhausted its LLM retries. `response` is the
    #: localized error notice, not a reply; the task is FAILED and will not answer.
    FAILED = "failed"
    #: The message was a v2 accord row; it went to the node, not to the agent.
    ACCORD_ROW_FORWARDED = "accord_row_forwarded"


class InteractResponse(BaseModel):
    """Response from agent interaction."""

    message_id: str = Field(..., description="Unique message ID")
    response: str = Field(..., description="Agent's response")
    state: str = Field(..., description="Agent's cognitive state after processing")
    processing_time_ms: int = Field(..., description="Time taken to process")
    #: The task this interaction produced, when it can be resolved (#1011).
    #:
    #: The safety battery writes this into every capture row as
    #: `agent_task_id` and has done since it was written — but the field was
    #: never on this model, so it read `None` in every row of every run. The
    #: consequence only surfaced during a French regression hunt: the traces
    #: teed into the capture bundle key on `task_id`/`thought_id`, the verdicts
    #: key on `question_id`, and with this empty there is NO join between them.
    #: A failing question could not be traced to the reasoning that produced it,
    #: which is the entire purpose of teeing the traces.
    #:
    #: Optional because the correlation is best-effort: a paused or timed-out
    #: interaction has no task to name, and None there is honest.
    task_id: Optional[str] = Field(None, description="Task ID this interaction produced, if resolvable")
    outcome: InteractOutcome = Field(
        InteractOutcome.COMPLETE,
        description="complete: response is the agent's reply; timeout: deadline passed, the task is still "
        "running and its reply will appear in history; paused: processor paused, message queued; "
        "failed: the task failed before answering and response is the error notice; "
        "accord_row_forwarded: the message was an accord row, handed to the node",
    )
    accord_forward: Optional[AccordRowForward] = Field(
        None, description="The node's verdict, when the message was an accord row (outcome accord_row_forwarded)"
    )


class MessageRequest(BaseModel):
    """Request to send a message to the agent (async pattern)."""

    message: str = Field(..., description="Message to send to the agent")
    context: Optional[MessageContext] = Field(None, description="Optional context")


class MessageSubmissionResponse(BaseModel):
    """Response from message submission (returns immediately with task ID or rejection reason)."""

    message_id: str = Field(..., description="Unique message ID for tracking")
    task_id: Optional[str] = Field(None, description="Task ID created (if accepted)")
    channel_id: str = Field(..., description="Channel where message was sent")
    submitted_at: str = Field(..., description="ISO timestamp of submission")
    accepted: bool = Field(..., description="Whether message was accepted for processing")
    rejection_reason: Optional[MessageRejectionReason] = Field(None, description="Reason if rejected")
    rejection_detail: Optional[str] = Field(None, description="Additional detail about rejection")
    accord_forward: Optional[AccordRowForward] = Field(
        None, description="The node's verdict, when the message was an accord row (reason ACCORD_ROW_FORWARDED)"
    )


class ConversationMessage(BaseModel):
    """Message in conversation history."""

    id: str = Field(..., description="Message ID")
    author: str = Field(..., description="Message author")
    content: str = Field(..., description="Message content")
    timestamp: datetime = Field(..., description="When sent")
    is_agent: bool = Field(..., description="Whether this was from the agent")
    message_type: Literal["user", "agent", "system", "error"] = Field(
        "user", description="Type of message (user, agent, system, error)"
    )


class ConversationHistory(BaseModel):
    """Conversation history."""

    messages: List[ConversationMessage] = Field(..., description="Message history")
    total_count: int = Field(..., description="Total messages")
    has_more: bool = Field(..., description="Whether more messages exist")


class AgentStatus(BaseModel):
    """Agent status and cognitive state."""

    # Core identity
    agent_id: str = Field(..., description="Agent identifier")
    name: str = Field(..., description="Agent name")

    # Version information
    version: str = Field(..., description="CIRIS version (e.g., 1.0.4-beta)")
    codename: str = Field(..., description="Release codename")
    code_hash: Optional[str] = Field(None, description="Code hash for exact version")

    # State information
    cognitive_state: str = Field(..., description=DESC_CURRENT_COGNITIVE_STATE)
    uptime_seconds: float = Field(..., description="Time since startup")

    # Activity metrics
    messages_processed: int = Field(..., description="Total messages processed")
    last_activity: Optional[datetime] = Field(None, description="Last activity timestamp")
    current_task: Optional[str] = Field(None, description="Current task description")

    # System state
    services_active: int = Field(..., description="Number of active services")
    memory_usage_mb: float = Field(..., description="Current memory usage in MB")
    multi_provider_services: Optional[JSONDict] = Field(None, description="Services with provider counts")
    accord_halt: Optional[AccordHaltState] = Field(
        None, description="The constitutional-halt latch as the agent's act gate last read it (CC 4.2.1.1)"
    )


class AgentIdentity(BaseModel):
    """Agent identity and capabilities."""

    # Identity
    agent_id: str = Field(..., description="Unique agent identifier")
    name: str = Field(..., description="Agent name")
    purpose: str = Field(..., description="Agent's purpose")
    created_at: datetime = Field(..., description="When agent was created")
    lineage: AgentLineage = Field(..., description="Agent lineage information")
    variance_threshold: float = Field(..., description="Identity variance threshold")

    # Capabilities
    tools: List[str] = Field(..., description="Available tools")
    handlers: List[str] = Field(..., description="Active handlers")
    services: ServiceAvailability = Field(..., description="Service availability")
    permissions: List[str] = Field(..., description="Agent permissions")


class ChannelInfo(BaseModel):
    """Information about a communication channel."""

    channel_id: str = Field(..., description="Unique channel identifier")
    channel_type: str = Field(..., description="Type of channel (discord, api, cli)")
    display_name: str = Field(..., description="Human-readable channel name")
    is_active: bool = Field(..., description="Whether channel is currently active")
    created_at: Optional[datetime] = Field(None, description="When channel was created")
    last_activity: Optional[datetime] = Field(None, description="Last message in channel")
    message_count: int = Field(0, description="Total messages in channel")


class ChannelList(BaseModel):
    """List of active channels."""

    channels: List[ChannelInfo] = Field(..., description="List of channels")
    total_count: int = Field(..., description="Total number of channels")


# Message tracking for interact functionality
_message_responses: dict[str, str] = {}
_response_events: dict[str, asyncio.Event] = {}
#: The task whose SPEAK answered a waiting interact(), keyed by message_id.
#: Written by the delivery path, which knows the speaking task; read once by
#: interact() so it can name the task without a persistence scan.
_message_task_ids: dict[str, str] = {}


async def store_message_response(message_id: str, response: str, task_id: Optional[str] = None) -> None:
    """Store a response and notify waiting request."""
    import os

    occurrence_id = os.environ.get("AGENT_OCCURRENCE_ID", "default")
    logger.info(
        f"[STORE_RESPONSE] occurrence={occurrence_id}, message_id={message_id}, response_len={len(response)}, current_keys={list(_message_responses.keys())}"
    )
    _message_responses[message_id] = response
    event = _response_events.get(message_id)
    if event:
        logger.info(f"[STORE_RESPONSE] Event found for {message_id}, setting it")
        if task_id:
            _message_task_ids[message_id] = task_id
        event.set()
    else:
        # No waiter for this message_id. This is EXPECTED for async
        # submit_message() responses (the client polls history — no event is
        # ever registered) and for a sync interact() that already timed out
        # and cleaned up. So this stays WARNING, not ERROR — the unambiguous
        # failure signal is the interact() timeout itself ([INTERACT_TIMEOUT],
        # logged at ERROR), not this line.
        logger.warning(
            f"[STORE_RESPONSE] No event found for {message_id} (async submission or already-timed-out interact)"
        )


# Endpoints


def _check_send_messages_permission(auth: AuthContext, request: Request) -> None:
    """Check if user has SEND_MESSAGES permission and handle OAuth auto-request."""
    if auth.has_permission(Permission.SEND_MESSAGES):
        return

    # Get auth service to check permission request status
    auth_service = request.app.state.auth_service if hasattr(request.app.state, "auth_service") else None
    user = auth_service.get_user(auth.user_id) if auth_service else None

    # If user is an OAuth user without a permission request, automatically create one
    if user and user.auth_type == "oauth" and user.permission_requested_at is None:
        # Set permission request timestamp
        user.permission_requested_at = datetime.now(timezone.utc)
        # Store the updated user
        if auth_service is not None and hasattr(auth_service, "_users"):
            auth_service._users[user.wa_id] = user  # Access private attribute for permission tracking

        # Don't log potentially sensitive email addresses
        logger.info(f"Auto-created permission request for OAuth user ID: {user.wa_id}")

    # Build detailed error response
    error_detail = {
        "error": "insufficient_permissions",
        "message": "You do not have permission to send messages to this agent.",
        "discord_invite": "https://discord.gg/A3HVPMWd",
        "can_request_permissions": user.permission_requested_at is None if user else True,
        "permission_requested": user.permission_requested_at is not None if user else False,
        "requested_at": user.permission_requested_at.isoformat() if user and user.permission_requested_at else None,
    }

    raise HTTPException(status_code=403, detail=error_detail)


def _process_request_images(body: InteractRequest | MessageRequest) -> List[Any]:
    """Process images from InteractRequest if present."""
    if not isinstance(body, InteractRequest) or not body.images:
        return []

    from ciris_engine.logic.adapters.api.api_vision import get_api_vision_helper

    vision_helper = get_api_vision_helper()
    images = []
    for img_payload in body.images:
        image_content = vision_helper.process_image_payload(
            img_payload.data,
            img_payload.media_type,
            img_payload.filename,
        )
        if image_content:
            images.append(image_content)
    if images:
        logger.info(f"Processed {len(images)} images for multimodal interaction")
    return images


async def _process_request_documents(body: InteractRequest | MessageRequest) -> str:
    """Process documents from InteractRequest if present, return additional content string."""
    if not isinstance(body, InteractRequest) or not body.documents:
        return ""

    from ciris_engine.logic.adapters.api.api_document import get_api_document_helper

    document_helper = get_api_document_helper()
    if not document_helper.is_available():
        logger.warning("Document processing requested but not available (missing libraries)")
        return ""

    doc_payloads = [
        {"data": doc.data, "media_type": doc.media_type, "filename": doc.filename} for doc in body.documents
    ]
    document_text = await document_helper.process_document_list(doc_payloads)
    if document_text:
        logger.info(f"Processed {len(body.documents)} documents for interaction")
        return "\n\n[Document Analysis]\n" + document_text
    return ""


async def _create_interaction_message(
    auth: AuthContext, body: InteractRequest | MessageRequest, request: Request
) -> Tuple[str, str, IncomingMessage]:
    """Create message ID, channel ID, and IncomingMessage for interaction."""
    message_id = str(uuid.uuid4())
    # Use custom channel_id from context if provided, otherwise user-specific channel
    # This allows benchmarks and A2A adapters to use unique channels per message
    if body.context and body.context.channel_id:
        channel_id = body.context.channel_id
    else:
        channel_id = f"api_{auth.user_id}"  # User-specific channel

    images = _process_request_images(body)
    additional_content = await _process_request_documents(body)
    final_content = body.message + additional_content

    # Look up user's display name for author_name. Priority:
    #   1. user_preferred_name (set via PUT /v1/users/me/settings — explicit display preference)
    #   2. oauth_name (from OAuth provider)
    #   3. name (auth username, e.g. "jeff" for QA admin)
    #   4. user_id (final fallback)
    #
    # Why user_preferred_name beats name: the auth username is an opaque
    # identifier (often ASCII-only, often hardcoded for QA), while
    # user_preferred_name is the user's chosen display name (Unicode-safe,
    # culturally appropriate). For multilingual / multi-locale agents,
    # using the username instead of the display name causes the agent to
    # address users by an inappropriate identifier — e.g. addressing a
    # Yoruba user as "jeff" instead of "Tèmítọ́pẹ́".
    author_name = auth.user_id
    auth_service = getattr(request.app.state, "auth_service", None)
    memory_service = getattr(request.app.state, "memory_service", None)

    # Tier 1: user_preferred_name from the user's graph node (best-effort).
    if memory_service:
        try:
            from ciris_engine.schemas.services.graph_core import GraphScope, NodeType
            from ciris_engine.schemas.services.operations import MemoryQuery

            user_results = await memory_service.recall(
                MemoryQuery(
                    node_id=f"user/{auth.user_id}",
                    scope=GraphScope.LOCAL,
                    type=NodeType.USER,
                    include_edges=False,
                    depth=1,
                )
            )
            if user_results:
                attrs = user_results[0].attributes if isinstance(user_results[0].attributes, dict) else {}
                preferred = attrs.get("user_preferred_name")
                if isinstance(preferred, str) and preferred.strip():
                    author_name = preferred.strip()
        except Exception:
            pass  # Fall through to auth-service lookup

    # Tier 2-4: oauth_name → name → user_id (only if user_preferred_name didn't resolve).
    if author_name == auth.user_id and auth_service and hasattr(auth_service, "get_user"):
        try:
            user = auth_service.get_user(auth.user_id)
            if user:
                author_name = getattr(user, "oauth_name", None) or getattr(user, "name", None) or auth.user_id
        except Exception:
            pass  # Keep default author_name on lookup failure

    # Surface caller-declared locale (e.g. from qa_runner channel metadata)
    # so it lands on the task at creation time. This is the top of the
    # localization chain — task/thought beats user/system/env defaults.
    preferred_language: Optional[str] = None
    if body.context and body.context.metadata:
        meta_lang = body.context.metadata.get("language") or body.context.metadata.get("preferred_language")
        if isinstance(meta_lang, str) and meta_lang.strip():
            preferred_language = meta_lang.strip()

    msg = IncomingMessage(
        message_id=message_id,
        author_id=auth.user_id,
        author_name=author_name,
        content=final_content,
        channel_id=channel_id,
        timestamp=datetime.now(timezone.utc).isoformat(),
        images=images,
        preferred_language=preferred_language,
    )

    return message_id, channel_id, msg


async def _handle_consent_for_user(auth: AuthContext, channel_id: str, request: Request) -> str:
    """Handle consent checking and creation for user, return consent notice if applicable."""
    try:
        from ciris_engine.logic.services.governance.consent import ConsentNotFoundError, ConsentService
        from ciris_engine.schemas.consent.core import ConsentRequest, ConsentStream

        # Get consent manager
        if hasattr(request.app.state, "consent_manager") and request.app.state.consent_manager:
            consent_manager = request.app.state.consent_manager
        else:
            from ciris_engine.logic.services.lifecycle.time import TimeService

            time_service = TimeService()
            consent_manager = ConsentService(time_service=time_service)
            request.app.state.consent_manager = consent_manager

        # Check if user has consent
        try:
            await consent_manager.get_consent(auth.user_id)
            return ""  # User already has consent
        except ConsentNotFoundError:
            # First interaction - create default TEMPORARY consent
            consent_req = ConsentRequest(
                user_id=auth.user_id,
                stream=ConsentStream.TEMPORARY,
                categories=[],
                reason="Default TEMPORARY consent on first interaction",
            )
            await consent_manager.grant_consent(consent_req, channel_id=channel_id)

            # Return notice to add to response
            return "\n\n📝 Privacy Notice: We forget about you in 14 days unless you say otherwise. Visit /v1/consent to manage your data preferences."

    except Exception as e:
        logger.warning(f"Could not check consent for user {auth.user_id}: {e}")
        return ""


async def _track_air_interaction(
    auth: AuthContext, channel_id: str, message_content: str, request: Request
) -> Optional[str]:
    """
    Track interaction for AIR (Artificial Interaction Reminder) parasocial prevention.

    This monitors 1:1 API interactions for:
    - Time-based triggers (30 min continuous)
    - Message-based triggers (20+ messages in 30 min window)

    Returns reminder message if threshold exceeded, None otherwise.
    """
    try:
        # Get consent manager which hosts the AIR manager
        consent_manager = getattr(request.app.state, "consent_manager", None)
        if not consent_manager:
            return None

        # Track interaction and get potential reminder
        reminder: Optional[str] = await consent_manager.track_interaction(
            user_id=auth.user_id,
            channel_id=channel_id,
            channel_type="api",
            message_content=message_content,
        )

        if reminder:
            logger.info(f"[AIR] Reminder triggered for user {auth.user_id}")

        return reminder

    except Exception as e:
        logger.debug(f"AIR tracking error (non-fatal): {e}")
        return None


# Credit account utilities moved to _common.py to break cyclic dependency with billing.py
# Use derive_credit_account imported from ._common


def _attach_credit_metadata(
    msg: IncomingMessage,
    request: Request,
    auth: AuthContext,
    channel_id: str,
) -> IncomingMessage:
    """Attach credit envelope data to the message for downstream processing."""

    logger.debug(f"[CREDIT_ATTACH] Called for message {msg.message_id}")

    resource_monitor = getattr(request.app.state, "resource_monitor", None)
    logger.debug(f"[CREDIT_ATTACH] resource_monitor exists: {resource_monitor is not None}")

    if not resource_monitor:
        if "no_resource_monitor" not in _credit_attach_miss_logged:
            _credit_attach_miss_logged.add("no_resource_monitor")
            logger.warning(
                "[CREDIT_ATTACH] No resource monitor available - credit metadata will not be attached to any message. "
                "This is expected for mock-mode/benchmark runs without a billing backend."
            )
        return msg

    credit_provider = getattr(resource_monitor, "credit_provider", None)
    logger.debug(
        f"[CREDIT_ATTACH] credit_provider exists: {credit_provider is not None}, type={type(credit_provider).__name__ if credit_provider else 'None'}"
    )

    if not credit_provider:
        # Try lazy initialization - token may have been written after server start
        from ciris_engine.logic.adapters.api.routes.billing import _try_lazy_init_billing_provider

        credit_provider = _try_lazy_init_billing_provider(request, resource_monitor)
        if not credit_provider:
            if "no_credit_provider" not in _credit_attach_miss_logged:
                _credit_attach_miss_logged.add("no_credit_provider")
                logger.warning(
                    "[CREDIT_ATTACH] No credit provider configured - credit metadata will not be attached to any message. "
                    "This is expected for mock-mode/benchmark runs without a billing backend."
                )
            return msg
        logger.info(f"[CREDIT_ATTACH] Lazily initialized billing provider for {msg.message_id}")

    try:
        account, _ = derive_credit_account(auth, request)
        logger.debug(f"[CREDIT_ATTACH] Derived credit account: {account.cache_key()}")

        runtime = getattr(request.app.state, "runtime", None)
        agent_identity = getattr(runtime, "agent_identity", None) if runtime else None
        agent_id = getattr(agent_identity, "agent_id", None)

        # Determine billing mode: Android uses "informational" (check only, billing via LLM usage)
        # Hosted sites use "transactional" (check+spend per interaction)
        from ciris_engine.logic.utils.path_resolution import is_android

        billing_mode = "informational" if is_android() else "transactional"

        logger.debug(
            f"[CREDIT_ATTACH] Creating CreditContext with agent_id={agent_id}, channel_id={channel_id}, user_role={auth.role.value}, billing_mode={billing_mode}"
        )

        credit_context = CreditContext(
            agent_id=agent_id,
            channel_id=channel_id,
            request_id=msg.message_id,
            user_role=auth.role.value,
            billing_mode=billing_mode,
        )

        logger.debug("[CREDIT_ATTACH] CreditContext created successfully")
        logger.debug(
            f"[CREDIT_ATTACH] Attaching credit metadata to message {msg.message_id}: account={account.cache_key()}"
        )

        updated_msg = msg.model_copy(
            update={
                "credit_account": account.model_dump(),
                "credit_context": credit_context.model_dump(),
            }
        )

        logger.debug(f"[CREDIT_ATTACH] Credit metadata SUCCESSFULLY attached to message {msg.message_id}")

        # CRITICAL: Also attach resource_monitor to message for observer access
        # The observer may be initialized before resource_monitor exists on runtime,
        # so we attach it per-message to ensure credit enforcement works
        updated_msg._resource_monitor = resource_monitor  # type: ignore[attr-defined]
        logger.debug(f"[CREDIT_ATTACH] resource_monitor attached to message {msg.message_id}")

        return updated_msg

    except Exception as e:
        logger.critical(
            f"[CREDIT_ATTACH] EXCEPTION for message {msg.message_id}: {type(e).__name__}: {e}", exc_info=True
        )
        # Return original message without metadata on error
        return msg


def _get_runtime_processor(request: Request) -> Any:
    """Get runtime processor if available and valid."""
    runtime = getattr(request.app.state, "runtime", None)
    if not (runtime and hasattr(runtime, "agent_processor") and runtime.agent_processor):
        return None
    return runtime.agent_processor


def _is_processor_paused(processor: Any) -> bool:
    """Check if processor is in paused state."""
    return hasattr(processor, "_is_paused") and processor._is_paused


async def _handle_paused_message(request: Request, msg: IncomingMessage) -> None:
    """Route message to queue when processor is paused."""
    if hasattr(request.app.state, "on_message"):
        await request.app.state.on_message(msg)
    else:
        raise HTTPException(status_code=503, detail=ERROR_MESSAGE_HANDLER_NOT_CONFIGURED)


def _get_processor_cognitive_state(processor: Any) -> str:
    """Get current cognitive state from processor with fallback."""
    try:
        if hasattr(processor, "get_current_state"):
            state = processor.get_current_state()
            return str(state) if state is not None else "WORK"
    except Exception:
        pass
    return "WORK"  # Default


def _system_reply(key: str, default: str, language: Optional[str] = None) -> str:
    """A system-authored reply, in the caller's language (#1012).

    The interact endpoint returns two strings the AGENT never wrote — the
    timeout notice and the paused-processor notice. Both were English literals,
    and both reach the user in exactly the situations where the agent has no
    voice of its own.

    An Amharic safety-battery run graded one of them: q06 came back as "Still
    processing. Check back later." and the deterministic script check scored
    script_ratio=0.000, correctly, because there was no Ethiopic in it. The
    battery captured a system string and marked it a response — the user, in
    that moment, got English.

    `default` keeps the English wording as the fallback so a locale missing the
    key degrades to today's behaviour rather than to an empty reply.
    """
    from ciris_engine.logic.utils.localization import get_preferred_language, get_string

    return get_string(language or get_preferred_language(), key, default=default)


def _resolve_task_id_for_message(message_id: str) -> Optional[str]:
    """The task this interaction produced, resolved via correlation_id (#1011).

    `base_observer` stamps `correlation_id=msg.message_id` on every task it
    creates, so the link exists in persistence — it was simply never surfaced
    on the wire. Best-effort by design: a paused or timed-out interaction has
    no task to name, and returning None there is the honest answer rather than
    a fabricated id.

    Never raises. A capture bundle that cannot name its task is worse than one
    that says so, but neither is worth failing a live interaction over.
    """
    try:
        from ciris_engine.logic import persistence

        for task in persistence.get_all_tasks():
            ctx = getattr(task, "context", None)
            if ctx is not None and getattr(ctx, "correlation_id", None) == message_id:
                return str(task.task_id)
    except Exception as exc:  # noqa: BLE001
        logger.debug("[INTERACT] task_id correlation lookup failed for %s: %s", message_id, exc)
    return None


def _task_id_for_interaction(message_id: str, request: Optional[Request] = None) -> Optional[str]:
    """The task that owns this interaction, cheapest source first.

    1. The task whose SPEAK was delivered to this message (delivery knows it).
    2. The adapter's message_id -> task_id map, written when the observer
       returns — the only source that is right under task-append, where the
       message was folded into an existing task whose correlation_id is a
       different message.
    3. The persistence scan by correlation_id (#1011).

    Call before `_cleanup_interaction_tracking`, which drops 1 and 2.
    """
    delivered = _message_task_ids.get(message_id)
    if delivered:
        return delivered
    if request is not None:
        task_map = getattr(request.app.state, "message_task_map", None)
        if isinstance(task_map, dict):
            mapped = task_map.get(message_id)
            if isinstance(mapped, str) and mapped:
                return mapped
    return _resolve_task_id_for_message(message_id)


def _outcome_for_answered_task(task_id: Optional[str]) -> InteractOutcome:
    """COMPLETE, unless the task that answered is FAILED (its answer is the failure notice)."""
    if not task_id:
        return InteractOutcome.COMPLETE
    try:
        import os

        from ciris_engine.logic import persistence
        from ciris_engine.schemas.runtime.enums import TaskStatus

        task = persistence.get_task_by_id(task_id, os.environ.get("AGENT_OCCURRENCE_ID", "default"))
    except Exception as e:  # noqa: BLE001 - the outcome is best-effort; the reply is already in hand
        logger.debug("Could not read status of task %s for interact outcome: %s", task_id, e)
        return InteractOutcome.COMPLETE
    if task is not None and task.status == TaskStatus.FAILED:
        return InteractOutcome.FAILED
    return InteractOutcome.COMPLETE


def _create_paused_response(
    message_id: str, cognitive_state: str, processing_time: int
) -> SuccessResponse[InteractResponse]:
    """Create response for paused processor state."""
    return SuccessResponse(
        data=InteractResponse(
            message_id=message_id,
            response=_system_reply(
                "agent.processor_paused",
                "Processor paused - task added to queue. Resume processing to continue.",
            ),
            state=cognitive_state,
            processing_time_ms=processing_time,
            outcome=InteractOutcome.PAUSED,
        )
    )


async def _check_processor_pause_status(
    request: Request, msg: IncomingMessage, message_id: str, start_time: datetime
) -> Optional[SuccessResponse[InteractResponse]]:
    """Check if processor is paused and handle accordingly. Returns response if paused, None if not paused."""
    try:
        processor = _get_runtime_processor(request)
        if not processor or not _is_processor_paused(processor):
            return None

        # Processor is paused - route message and prepare response
        await _handle_paused_message(request, msg)

        # Clean up response tracking since we're returning immediately —
        # full cleanup (incl. the channel FIFO queue) so a paused-path return
        # doesn't leave a stale queue entry that drifts FIFO correlation.
        _cleanup_interaction_tracking(message_id, request)

        # Calculate processing time and get state
        processing_time = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
        cognitive_state = _get_processor_cognitive_state(processor)

        return _create_paused_response(message_id, cognitive_state, processing_time)

    except HTTPException:
        # Re-raise HTTP exceptions (like 503 for missing message handler)
        raise
    except Exception as e:
        logger.debug(f"Could not check pause state: {e}")

    return None


def _get_interaction_timeout(request: Request) -> float:
    """How long interact() waits for the agent's reply before answering TIMEOUT.

    Resolution order (highest priority first):
      1. `CIRIS_API_INTERACTION_TIMEOUT` env var — operator override that
         wins even when a stored `APIAdapterConfig` is in use. The adapter's
         `_load_config` flow can discard the env-loaded config when it is
         handed an `APIAdapterConfig` object (adapter.py:_apply_adapter_config),
         so the env var is re-checked here on every call.
      2. `request.app.state.api_config.interaction_timeout` — only when it
         was explicitly configured (a positive number). None means "not set".
      3. `active_budget().interact_deadline_s` (#1186) — the deadline for the
         primary LLM provider: 195s for a hosted model, 900s for one running
         on the user's own hardware. The budget is sized so a reply that
         needs a PONDER round still lands inside it; a fixed 110s was a coin
         flip for local models (#1013).
    """
    import os

    env_timeout = os.environ.get("CIRIS_API_INTERACTION_TIMEOUT")
    if env_timeout:
        try:
            value = float(env_timeout)
            if value > 0:
                return value
        except ValueError:
            pass  # malformed env var — fall through to config / budget

    api_config = getattr(request.app.state, "api_config", None)
    configured = getattr(api_config, "interaction_timeout", None) if api_config is not None else None
    # bool is an int subclass; a stray True must not become a 1s deadline.
    if isinstance(configured, (int, float)) and not isinstance(configured, bool) and configured > 0:
        return float(configured)

    from ciris_engine.logic.config.llm_budget import active_budget

    return float(active_budget().interact_deadline_s)


def _get_current_cognitive_state(request: Request) -> str:
    """Get current cognitive state from request runtime."""
    runtime = getattr(request.app.state, "runtime", None)
    return _get_cognitive_state(runtime)


def _raise_if_shed(result: Any, message_id: str, request: Request) -> None:
    """503 + Retry-After when the observer refused the message under SHED.

    SHED is runtime self-protection (a resource is under CRITICAL pressure),
    not an agent decision, so it is answered as a retryable service condition
    rather than as a rejected or deferred message.
    """
    from ciris_engine.logic.services.infrastructure.resource_monitor.pressure import SHED_RETRY_AFTER_SECONDS
    from ciris_engine.schemas.runtime.messages import MessageHandlingStatus

    if getattr(result, "status", None) != MessageHandlingStatus.RESOURCE_SHED:
        return
    _cleanup_interaction_tracking(message_id, request)
    raise HTTPException(
        status_code=503,
        headers={"Retry-After": str(SHED_RETRY_AFTER_SECONDS)},
        detail={
            "error": "resource_shed",
            "reason": MessageRejectionReason.RESOURCE_SHED.value,
            "message": "The agent is not admitting new work while a resource is under pressure. Retry later.",
            "resources": list(getattr(result, "shed_resources", []) or []),
            "retry_after_seconds": SHED_RETRY_AFTER_SECONDS,
        },
    )


async def _forward_if_accord_row(text: str) -> Optional[AccordRowForward]:
    """A v2 accord row sent to the agent goes to the node instead (CC 4.2.1.1).

    Checked before the halt refusal: a row is delivery to the node, not work for
    the agent, and a resumption row must get through while the halt stands.
    The node verifies and latches; the agent does no crypto.
    """
    from ciris_engine.logic.accord.ingress import extract_accord_row, forward_accord_row

    row = extract_accord_row(text)
    return await forward_accord_row(row) if row is not None else None


def _accord_forward_detail(forward: AccordRowForward) -> str:
    if not forward.delivered:
        return f"Accord row could not be delivered to the node: {forward.error}"
    return (
        f"Accord row handed to the node (HTTP {forward.status_code}, {forward.invocation_kind or 'unknown kind'} "
        f"{forward.invocation_id or ''}): halted={forward.halted}, confirmed={forward.confirmed}, "
        f"released={forward.released}{f', refusal={forward.refusal}' if forward.refusal else ''}"
        f"{f', error={forward.error}' if forward.error else ''}"
    )


async def _raise_if_accord_halted() -> None:
    """423 when a constitutional halt stands (CC 4.2.1.1, CIRISAgent#1231).

    Checked FIRST, before SHED: a halted agent answers with its halt, not with a
    resource condition. No Retry-After — the halt is not a resource condition,
    and `lapses_at`, when the node reports one, is the honest bound. The error
    token is the node's own, so a client sees one name for one fact.
    """
    from ciris_engine.logic.utils.halt_latch import read_halt_latch

    # Fresh: admitting a message is a decision, not a poll. A cached "no halt"
    # admitted CSD-129 run 4's interact 0.9 s after the node latched, and it
    # then waited out its timeout on a thought the halt held.
    halt = await read_halt_latch(fresh=True)
    if not halt.halted:
        return
    raise _accord_halt_refusal(halt)


def _accord_halt_refusal(halt: Any, held_task_id: Optional[str] = None, admitted: bool = False) -> HTTPException:
    """The 423 a halt answers with. `admitted`: the message got in just before the halt and is held."""
    from ciris_engine.schemas.runtime.accord_halt import ACCORD_HALT_REFUSAL

    if not admitted:
        message = (
            "The agent's acts are paused under a constitutional halt. Nothing was admitted; "
            "the halt ends when the holders release it or its fuse lapses."
        )
    else:
        message = (
            "The agent's acts are paused under a constitutional halt. This message was admitted just "
            "before it; its task is held, not dropped, and no reply can come until the halt ends."
        )
    detail: Dict[str, Any] = {
        "error": ACCORD_HALT_REFUSAL,
        "reason": MessageRejectionReason.ACCORD_HALT.value,
        "message": message,
        "halt": halt.model_dump(mode="json"),
    }
    if held_task_id is not None:
        detail["held_task_id"] = held_task_id
    return HTTPException(status_code=423, detail=detail)


#: How often a waiting interact looks for a halt that landed after admission.
INTERACT_HALT_POLL_SECONDS = 0.5


async def _wait_for_reply_or_halt(event: asyncio.Event, timeout: float) -> Optional[Any]:
    """Wait for the agent's reply; the halt that lands meanwhile, if one does.

    A message admitted just before a halt has its thought held: no reply can
    come, so the caller is told now (423) instead of after the whole timeout.
    Raises asyncio.TimeoutError like `wait_for` when neither happens.
    """
    from ciris_engine.logic.utils.halt_latch import read_halt_latch

    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while True:
        remaining = deadline - loop.time()
        if remaining <= 0:
            raise asyncio.TimeoutError
        try:
            await asyncio.wait_for(event.wait(), timeout=min(INTERACT_HALT_POLL_SECONDS, remaining))
            return None
        except asyncio.TimeoutError:
            pass
        halt = await read_halt_latch()
        if halt.halted:
            return halt


async def _raise_if_node_unclaimed() -> None:
    """423 when the node has no owner: EVERY NODE IS ALWAYS CLAIMED.

    Checked after the halt (a halted agent answers with its halt) and before
    anything is created. The body names both ways to claim the node and where
    the deployer finds the claim PIN, never the PIN itself.
    """
    from ciris_engine.logic.utils.node_ownership import node_owned
    from ciris_engine.schemas.runtime.node_ownership import NODE_UNCLAIMED_ERROR

    ownership = await node_owned()
    if not ownership.unclaimed:
        return
    raise HTTPException(
        status_code=423,
        detail={
            "error": NODE_UNCLAIMED_ERROR,
            "reason": MessageRejectionReason.NODE_UNCLAIMED.value,
            "message": ownership.unclaimed_message(),
            "claim_pin_file": ownership.claim_pin_file,
            "claim_route": ownership.claim_route,
            "upgrade_claim_routes": ownership.upgrade_claim_routes,
            "reading": ownership.reading.value,
        },
    )


def _cleanup_interaction_tracking(message_id: str, request: Optional[Request] = None) -> None:
    """Clean up interaction tracking for given message ID.

    Also purges message_id from its channel's FIFO pending-response queue:
    a timed-out interact() (no SPEAK arriving) must not leave a stale entry,
    or FIFO correlation drifts by one for every later request on the channel.
    """
    _response_events.pop(message_id, None)
    _message_responses.pop(message_id, None)
    _message_task_ids.pop(message_id, None)
    if request is not None:
        task_map = getattr(request.app.state, "message_task_map", None)
        if isinstance(task_map, dict):
            task_map.pop(message_id, None)
        chan_map = getattr(request.app.state, "message_channel_map", {})
        if isinstance(chan_map, dict):
            for queue in chan_map.values():
                if isinstance(queue, list):
                    try:
                        queue.remove(message_id)
                    except ValueError:
                        # message_id isn't in this channel's queue — expected,
                        # since we sweep every channel but it lives in one.
                        pass


async def _inject_error_to_channel(request: Request, channel_id: str, content: str) -> None:
    """Inject an error message into channel history for user visibility."""
    try:
        comm_service = getattr(request.app.state, "communication_service", None)
        if comm_service and hasattr(comm_service, "send_system_message"):
            await comm_service.send_system_message(
                channel_id=channel_id,
                content=content,
                message_type="error",
            )
    except Exception as e:
        logger.warning(f"Could not inject error message to channel: {e}")


@router.post("/message", response_model=None, responses=RESPONSES_402_403_503)
async def submit_message(
    request: Request, body: MessageRequest, auth: AuthObserverDep
) -> SuccessResponse[MessageSubmissionResponse]:
    """
    Submit a message to the agent (async pattern - returns immediately).

    This endpoint returns immediately with a task_id for tracking or rejection reason.
    Use GET /agent/history to poll for the agent's response.

    This is the recommended way to interact with the agent via API,
    as it doesn't block waiting for processing to complete.

    Requires: SEND_MESSAGES permission (ADMIN+ by default, or OBSERVER with explicit grant)
    """
    from ciris_engine.schemas.runtime.messages import MessageHandlingStatus

    # Check permissions
    _check_send_messages_permission(auth, request)

    # An accord row goes to the node; then a standing halt refuses intake
    # before anything is created.
    forward = await _forward_if_accord_row(body.message)
    if forward is not None:
        return SuccessResponse(
            data=MessageSubmissionResponse(
                message_id=str(uuid.uuid4()),
                task_id=None,
                channel_id=f"api_{auth.user_id}",
                submitted_at=datetime.now(timezone.utc).isoformat(),
                accepted=False,
                rejection_reason=MessageRejectionReason.ACCORD_ROW_FORWARDED,
                rejection_detail=_accord_forward_detail(forward),
                accord_forward=forward,
            )
        )
    await _raise_if_accord_halted()
    await _raise_if_node_unclaimed()

    # Create message and tracking
    message_id, channel_id, msg = await _create_interaction_message(auth, body, request)
    msg = _attach_credit_metadata(msg, request, auth, channel_id)

    # Handle consent for user
    await _handle_consent_for_user(auth, channel_id, request)

    # Track interaction for AIR (parasocial attachment prevention)
    # Note: For async pattern, reminder is logged but not returned (user polls for response)
    await _track_air_interaction(auth, channel_id, body.message, request)

    # Track submission time
    submitted_at = datetime.now(timezone.utc)

    # Check if processor is paused
    pause_response = await _check_processor_pause_status(request, msg, message_id, submitted_at)
    if pause_response:
        # Return rejection for paused processor
        response = MessageSubmissionResponse(
            message_id=message_id,
            task_id=None,
            channel_id=channel_id,
            submitted_at=submitted_at.isoformat(),
            accepted=False,
            rejection_reason=MessageRejectionReason.PROCESSOR_PAUSED,
            rejection_detail="Agent processor is paused",
        )
        return SuccessResponse(data=response)

    # Submit message and get result (with credit enforcement)
    try:
        if hasattr(request.app.state, "on_message"):
            result = await request.app.state.on_message(msg)
        else:
            raise HTTPException(status_code=503, detail=ERROR_MESSAGE_HANDLER_NOT_CONFIGURED)
    except CreditDenied as exc:
        await _inject_error_to_channel(request, channel_id, f"Message blocked: {exc.reason}")
        response = MessageSubmissionResponse(
            message_id=message_id,
            task_id=None,
            channel_id=channel_id,
            submitted_at=submitted_at.isoformat(),
            accepted=False,
            rejection_reason=MessageRejectionReason.CREDIT_DENIED,
            rejection_detail=exc.reason,
        )
        return SuccessResponse(data=response)
    except CreditCheckFailed as exc:
        await _inject_error_to_channel(
            request, channel_id, "Message blocked: Credit service temporarily unavailable. Please try again later."
        )
        response = MessageSubmissionResponse(
            message_id=message_id,
            task_id=None,
            channel_id=channel_id,
            submitted_at=submitted_at.isoformat(),
            accepted=False,
            rejection_reason=MessageRejectionReason.CREDIT_CHECK_FAILED,
            rejection_detail=str(exc),
        )
        return SuccessResponse(data=response)

    _raise_if_shed(result, message_id, request)

    # Map MessageHandlingResult to MessageSubmissionResponse
    accepted = result.status in [MessageHandlingStatus.TASK_CREATED, MessageHandlingStatus.UPDATED_EXISTING_TASK]
    rejection_reason = None
    rejection_detail = None

    if not accepted:
        # Map status to rejection reason
        status_to_reason = {
            MessageHandlingStatus.AGENT_OWN_MESSAGE: MessageRejectionReason.AGENT_OWN_MESSAGE,
            MessageHandlingStatus.FILTERED_OUT: MessageRejectionReason.FILTERED_OUT,
            MessageHandlingStatus.CHANNEL_RESTRICTED: MessageRejectionReason.CHANNEL_RESTRICTED,
            MessageHandlingStatus.RATE_LIMITED: MessageRejectionReason.RATE_LIMITED,
        }
        rejection_reason = status_to_reason.get(result.status)
        rejection_detail = result.filter_reasoning if result.filtered else None
    elif result.status == MessageHandlingStatus.UPDATED_EXISTING_TASK:
        # Add detail that existing task was updated
        rejection_detail = "Existing task updated with new information"

    # Return result
    response = MessageSubmissionResponse(
        message_id=message_id,
        task_id=result.task_id,
        channel_id=channel_id,
        submitted_at=submitted_at.isoformat(),
        accepted=accepted,
        rejection_reason=rejection_reason,
        rejection_detail=rejection_detail,
    )

    return SuccessResponse(data=response)


@router.post("/interact", response_model=None, responses=RESPONSES_402_403_503)
async def interact(request: Request, body: InteractRequest, auth: AuthObserverDep) -> SuccessResponse[InteractResponse]:
    """
    Send message and get response.

    This endpoint combines the old send/ask functionality into a single interaction.
    It sends the message and waits for the agent's response (with a reasonable timeout).

    Requires: SEND_MESSAGES permission (ADMIN+ by default, or OBSERVER with explicit grant)
    """
    # Check permissions
    _check_send_messages_permission(auth, request)

    # An accord row goes to the node, not the agent. Then a standing halt: no
    # reply can come, so say so up front.
    forward = await _forward_if_accord_row(body.message)
    if forward is not None:
        return SuccessResponse(
            data=InteractResponse(
                message_id=str(uuid.uuid4()),
                response=_accord_forward_detail(forward),
                state=_get_current_cognitive_state(request),
                processing_time_ms=0,
                outcome=InteractOutcome.ACCORD_ROW_FORWARDED,
                accord_forward=forward,
            )
        )
    await _raise_if_accord_halted()
    await _raise_if_node_unclaimed()

    # Create message and tracking
    message_id, channel_id, msg = await _create_interaction_message(auth, body, request)
    msg = _attach_credit_metadata(msg, request, auth, channel_id)

    event = asyncio.Event()
    _response_events[message_id] = event

    # Handle consent for user
    consent_notice = await _handle_consent_for_user(auth, channel_id, request)

    # Track interaction for AIR (parasocial attachment prevention)
    air_reminder = await _track_air_interaction(auth, channel_id, body.message, request)

    # Track timing
    start_time = datetime.now(timezone.utc)

    # Check if processor is paused
    pause_response = await _check_processor_pause_status(request, msg, message_id, start_time)
    if pause_response:
        return pause_response

    try:
        if hasattr(request.app.state, "on_message"):
            interact_result = await request.app.state.on_message(msg)
        else:
            raise HTTPException(status_code=503, detail=ERROR_MESSAGE_HANDLER_NOT_CONFIGURED)
    except CreditDenied as exc:
        await _inject_error_to_channel(request, channel_id, f"Message blocked: {exc.reason}")
        _cleanup_interaction_tracking(message_id, request)
        raise HTTPException(
            status_code=402,
            detail={
                "error": "insufficient_credit",
                "message": "Interaction blocked by credit policy.",
                "reason": exc.reason,
            },
        ) from exc
    except CreditCheckFailed as exc:
        await _inject_error_to_channel(
            request, channel_id, "Message blocked: Credit service temporarily unavailable. Please try again later."
        )
        _cleanup_interaction_tracking(message_id, request)
        raise HTTPException(status_code=503, detail="Credit provider unavailable") from exc
    except BillingServiceError as exc:
        await _inject_error_to_channel(request, channel_id, f"Service error: {exc.message}")
        _cleanup_interaction_tracking(message_id, request)
        raise HTTPException(
            status_code=402,
            detail={
                "error": "billing_error",
                "message": "LLM billing service error. Please check your account or try again later.",
                "reason": exc.message,
            },
        ) from exc

    _raise_if_shed(interact_result, message_id, request)

    # Get timeout and wait for response
    timeout = _get_interaction_timeout(request)

    try:
        halt = await _wait_for_reply_or_halt(event, timeout)
        if halt is not None:
            try:
                held_task_id = _task_id_for_interaction(message_id, request)
            except Exception:  # noqa: BLE001 - naming the held task is a courtesy; the 423 is the answer
                held_task_id = None
            _cleanup_interaction_tracking(message_id, request)
            raise _accord_halt_refusal(halt, held_task_id, admitted=True)

        # Get response
        import os

        occurrence_id = os.environ.get("AGENT_OCCURRENCE_ID", "default")
        logger.info(
            f"[RETRIEVE_RESPONSE] occurrence={occurrence_id}, message_id={message_id}, available_keys={list(_message_responses.keys())}"
        )
        response_content = _message_responses.get(message_id, "I'm processing your request. Please check back shortly.")
        logger.info(
            f"[RETRIEVE_RESPONSE] Retrieved content_len={len(response_content)}, content_preview={response_content[:100] if response_content else 'EMPTY'}"
        )

        # Add consent notice if this is first interaction
        if consent_notice:
            response_content += consent_notice

        # Add AIR reminder if triggered (parasocial attachment prevention)
        if air_reminder:
            response_content += "\n\n---\n" + air_reminder

        # Clean up and calculate timing
        task_id = _task_id_for_interaction(message_id, request)
        _cleanup_interaction_tracking(message_id, request)
        processing_time_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)

        # Build response
        response = InteractResponse(
            message_id=message_id,
            response=response_content,
            state=_get_current_cognitive_state(request),
            processing_time_ms=processing_time_ms,
            task_id=task_id,
            outcome=_outcome_for_answered_task(task_id),
        )

        return SuccessResponse(data=response)

    except asyncio.TimeoutError:
        import os

        # The task exists and keeps running; name it so the caller can follow
        # it in history. Resolve before cleanup, which drops the map entry.
        timed_out_task_id = _task_id_for_interaction(message_id, request)

        # Clean up. Removing message_id from the channel queue is what keeps
        # the task's late SPEAK from being delivered to the NEXT request on
        # this channel: delivery matches by task, and this message no longer
        # has a waiter (api_communication._handle_api_interaction_response).
        _cleanup_interaction_tracking(message_id, request)

        # A timeout is a real degradation — the agent did not deliver a
        # response within the window. Under mock LLM (QA) this should never
        # happen, so log at ERROR: QA incident detection must surface a
        # systemic interact() stall instead of it masking as a benign 200.
        mock_llm = bool(os.environ.get("CIRIS_MOCK_LLM"))
        logger.error(
            "[INTERACT_TIMEOUT] message_id=%s timed out after %.0fs without an agent response%s",
            message_id,
            timeout,
            " (mock LLM active — this indicates a processing stall, not slow inference)" if mock_llm else "",
        )

        # Return a timeout response rather than error
        response = InteractResponse(
            message_id=message_id,
            response=_system_reply(
                "agent.still_processing",
                "Still processing. Check back later. Agent response is not guaranteed.",
            ),
            state="WORK",
            processing_time_ms=int(timeout * 1000),  # Use actual timeout value
            task_id=timed_out_task_id,
            outcome=InteractOutcome.TIMEOUT,
        )

        return SuccessResponse(data=response)


@router.get("/history", response_model=None, responses=RESPONSES_500)
async def get_history(
    request: Request,
    auth: AuthObserverDep,
    limit: int = Query(50, ge=1, le=200, description="Maximum messages to return"),
    before: Optional[datetime] = Query(None, description="Get messages before this time"),
) -> SuccessResponse[ConversationHistory]:
    """
    Conversation history.

    Get the conversation history for the current user.
    """
    # Build channels to query based on user role
    channels_to_query = _build_channels_to_query(auth, request)
    channel_id = f"api_{auth.user_id}"

    logger.debug(f"History query for user {auth.user_id} with role {auth.role}, channels: {channels_to_query}")

    # Check for mock message history first
    message_history = getattr(request.app.state, "message_history", None)
    if message_history is not None:
        history = await _get_history_from_mock(message_history, channels_to_query, limit)
        return SuccessResponse(data=history)

    # Get communication service
    comm_service = getattr(request.app.state, "communication_service", None)
    if not comm_service:
        # Fallback: query from memory
        memory_service = getattr(request.app.state, "memory_service", None)
        if memory_service:
            history = await _get_history_from_memory(memory_service, channel_id, limit)
            return SuccessResponse(data=history)

    try:
        history = await _get_history_from_communication_service(comm_service, channels_to_query, limit, before)
        return SuccessResponse(data=history)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _get_cognitive_state(runtime: Any) -> str:
    """Get the agent's cognitive state with proper None checking."""
    if runtime is None:
        logger.warning("Runtime is None")
        return "UNKNOWN"

    # State manager is on the agent processor, not directly on runtime
    if hasattr(runtime, "agent_processor") and runtime.agent_processor:
        if hasattr(runtime.agent_processor, "state_manager") and runtime.agent_processor.state_manager:
            if hasattr(runtime.agent_processor.state_manager, "current_state"):
                state = runtime.agent_processor.state_manager.current_state
                # Convert AgentState enum to string if necessary
                return str(state)
            else:
                logger.warning("Agent processor state_manager exists but has no current_state attribute")
        else:
            logger.warning("Agent processor has no state_manager or state_manager is None")
    else:
        logger.warning("Runtime has no agent_processor or agent_processor is None")
    return "UNKNOWN"  # Don't default to WORK - be explicit about unknown state


def _calculate_uptime(time_service: Any) -> float:
    """Calculate the agent's uptime in seconds."""
    if not time_service:
        return 0.0

    # Try to get uptime from time service status
    if hasattr(time_service, "get_status"):
        time_status = time_service.get_status()
        if hasattr(time_status, "uptime_seconds"):
            uptime = time_status.uptime_seconds
            return float(uptime) if uptime is not None else 0.0

    # Calculate uptime manually
    if hasattr(time_service, "_start_time") and hasattr(time_service, "now"):
        delta = time_service.now() - time_service._start_time
        return float(delta.total_seconds())

    return 0.0


def _count_wakeup_tasks(uptime: float) -> int:
    """Count completed WAKEUP tasks."""
    try:
        from ciris_engine.logic import persistence
        from ciris_engine.schemas.runtime.enums import TaskStatus

        completed_tasks = persistence.get_tasks_by_status(TaskStatus.COMPLETED)

        wakeup_prefixes = [
            "VERIFY_IDENTITY",
            "VALIDATE_INTEGRITY",
            "EVALUATE_RESILIENCE",
            "ACCEPT_INCOMPLETENESS",
            "EXPRESS_GRATITUDE",
        ]

        count = sum(1 for task in completed_tasks if any(task.task_id.startswith(prefix) for prefix in wakeup_prefixes))

        # If no wakeup tasks found but system has been running, assume standard cycle
        if count == 0 and uptime > MIN_UPTIME_FOR_DEFAULT_TASKS:
            return 5  # Standard wakeup cycle completes 5 tasks

        return count
    except Exception as e:
        logger.warning(f"Failed to count completed tasks: {e}")
        return 0


def _count_active_services(service_registry: Any) -> Tuple[int, JSONDict]:
    """Count active services and get multi-provider service details."""
    multi_provider_count = 0
    multi_provider_services: JSONDict = {}

    if service_registry:
        from ciris_engine.schemas.runtime.enums import ServiceType

        for service_type in list(ServiceType):
            providers = service_registry.get_services_by_type(service_type)
            count = len(providers)
            if count > 0:
                multi_provider_count += count
                multi_provider_services[service_type.value] = {"providers": count, "type": "multi-provider"}

    # CIRIS has AT LEAST 19 service types:
    # Multi-provider services can have multiple instances + 12 singleton services
    services_active = multi_provider_count + 12

    return services_active, multi_provider_services


def _get_admin_channels(auth: AuthContext, request: Request) -> List[str]:
    """Get additional admin channels for privileged users."""
    channels = []
    if auth.role in ["ADMIN", "AUTHORITY", "SYSTEM_ADMIN"]:
        # Get default API channel from config
        api_host = getattr(request.app.state, "api_host", "127.0.0.1")
        api_port = getattr(request.app.state, "api_port", "8080")
        default_channel = f"api_{api_host}_{api_port}"
        channels.append(default_channel)

        # Add common variations of the API channel
        channels.extend(
            [
                f"api_0.0.0.0_{api_port}",  # Bind address
                f"api_127.0.0.1_{api_port}",  # Localhost
                f"api_localhost_{api_port}",  # Hostname variant
            ]
        )
    return channels


def _is_admin_role(auth: AuthContext) -> bool:
    """Check if auth context has an admin-level role."""
    from ciris_engine.schemas.api.auth import UserRole

    admin_roles = {UserRole.ADMIN, UserRole.SYSTEM_ADMIN, UserRole.AUTHORITY}
    return auth.role in admin_roles


def _build_channels_to_query(auth: AuthContext, request: Request) -> List[str]:
    """Build list of channels to query for conversation history."""
    channel_id = f"api_{auth.user_id}"
    channels_to_query = [channel_id]
    channels_to_query.extend(_get_admin_channels(auth, request))
    # Only include "system" channel for admin users (system/error messages)
    if _is_admin_role(auth):
        channels_to_query.append("system")
    # Remove duplicates while preserving order
    seen = set()
    deduped = []
    for channel in channels_to_query:
        if channel not in seen:
            seen.add(channel)
            deduped.append(channel)
    return deduped


def _convert_timestamp(timestamp: Any) -> datetime:
    """Convert timestamp string or datetime to datetime object."""
    if isinstance(timestamp, str):
        try:
            return datetime.fromisoformat(timestamp)
        except (ValueError, TypeError):
            return datetime.now(timezone.utc)
    elif isinstance(timestamp, datetime):
        return timestamp
    else:
        return datetime.now(timezone.utc)


def _create_conversation_message_from_mock(msg: JSONDict, is_response: bool = False) -> ConversationMessage:
    """Create ConversationMessage from mock message data."""
    if is_response:
        return ConversationMessage(
            id=f"{msg['message_id']}_response",
            author="Scout",
            content=msg["response"],
            timestamp=_convert_timestamp(msg["timestamp"]),
            is_agent=True,
        )
    else:
        return ConversationMessage(
            id=msg["message_id"],
            author=msg["author_id"],
            content=msg["content"],
            timestamp=_convert_timestamp(msg["timestamp"]),
            is_agent=False,
        )


def _expand_mock_messages(user_messages: List[JSONDict]) -> List[ConversationMessage]:
    """Expand mock messages into user message + response pairs."""
    all_messages = []
    for msg in user_messages:
        # Add user message
        all_messages.append(_create_conversation_message_from_mock(msg))
        # Add agent response if exists
        if msg.get("response"):
            all_messages.append(_create_conversation_message_from_mock(msg, is_response=True))
    return all_messages


def _apply_message_limit(messages: List[ConversationMessage], limit: int) -> List[ConversationMessage]:
    """Apply message limit, taking the last N messages."""
    if len(messages) > limit:
        return messages[-limit:]
    return messages


async def _get_history_from_mock(
    message_history: List[JSONDict], channels_to_query: List[str], limit: int
) -> ConversationHistory:
    """Process conversation history from mock data."""
    # Filter messages for requested channels
    user_messages = [m for m in message_history if m.get("channel_id") in channels_to_query]

    # Expand all messages (user + response pairs)
    all_messages = _expand_mock_messages(user_messages)

    # Apply limit
    limited_messages = _apply_message_limit(all_messages, limit)

    return ConversationHistory(
        messages=limited_messages,
        total_count=len(user_messages),
        has_more=len(user_messages) > len(limited_messages),
    )


async def _get_history_from_memory(memory_service: Any, channel_id: str, limit: int) -> ConversationHistory:
    """Query conversation history from memory service."""
    from ciris_engine.schemas.services.graph_core import GraphScope, NodeType
    from ciris_engine.schemas.services.operations import MemoryQuery

    query = MemoryQuery(
        node_id=f"conversation_{channel_id}",
        scope=GraphScope.LOCAL,
        type=NodeType.CONVERSATION_SUMMARY,
        include_edges=True,
        depth=1,
    )

    nodes = await memory_service.recall(query)

    # Convert to conversation messages
    messages = []
    for node in nodes:
        attrs = node.attributes
        messages.append(
            ConversationMessage(
                id=attrs.get("message_id", node.id),
                author=attrs.get("author", "unknown"),
                content=attrs.get("content", ""),
                timestamp=datetime.fromisoformat(attrs.get("timestamp", node.created_at)),
                is_agent=attrs.get("is_agent", False),
            )
        )

    return ConversationHistory(messages=messages, total_count=len(messages), has_more=len(messages) == limit)


def _safe_convert_message_timestamp(msg: Any) -> datetime:
    """Safely convert message timestamp with fallback."""
    timestamp_val = msg.timestamp
    if isinstance(timestamp_val, datetime):
        return timestamp_val
    if timestamp_val:
        try:
            return datetime.fromisoformat(str(timestamp_val))
        except (ValueError, TypeError):
            pass
    return datetime.now(timezone.utc)


def _determine_message_type(msg: Any, is_agent: bool) -> Literal["user", "agent", "system", "error"]:
    """Determine the message type from message attributes."""
    # Check for explicit message_type attribute first
    if hasattr(msg, "message_type"):
        explicit_type = str(msg.message_type).lower()
        if explicit_type in ("user", "agent", "system", "error"):
            return explicit_type  # type: ignore[return-value]

    # Infer from is_agent flag
    if is_agent:
        return "agent"

    # Check if author indicates system message
    author = str(msg.author_name or msg.author_id or "").lower()
    if author == "error":
        return "error"
    if author in ("system", "ciris_system"):
        return "system"

    return "user"


def _convert_service_message_to_conversation(msg: Any) -> ConversationMessage:
    """Convert communication service message to ConversationMessage."""
    is_agent = bool(getattr(msg, "is_agent_message", False) or getattr(msg, "is_bot", False))
    message_type = _determine_message_type(msg, is_agent)

    # System and error messages should have is_agent=True to prevent observation
    # (agent should not re-observe system notifications)
    if message_type in ("system", "error"):
        is_agent = True

    return ConversationMessage(
        id=str(msg.message_id or ""),
        author=str(msg.author_name or msg.author_id or ""),
        content=str(msg.content or ""),
        timestamp=_safe_convert_message_timestamp(msg),
        is_agent=is_agent,
        message_type=message_type,
    )


async def _fetch_messages_from_channels(comm_service: Any, channels_to_query: List[str], fetch_limit: int) -> List[Any]:
    """Fetch messages from all specified channels."""
    fetched_messages = []
    for channel in channels_to_query:
        try:
            logger.debug(f"Fetching messages from channel: {channel}")
            if comm_service is None:
                logger.warning("Communication service is not available")
                continue
            channel_messages = await comm_service.fetch_messages(channel, limit=fetch_limit)
            logger.debug(f"Retrieved {len(channel_messages)} messages from {channel}")
            fetched_messages.extend(channel_messages)
        except Exception as e:
            logger.warning(f"Failed to fetch from channel {channel}: {e}")
            continue
    return fetched_messages


def _sort_and_filter_messages(fetched_messages: List[Any], before: Optional[datetime]) -> List[Any]:
    """Sort messages by timestamp and apply time filter."""
    # Sort messages by timestamp (newest first)
    sorted_messages = sorted(
        fetched_messages,
        key=lambda m: _safe_convert_message_timestamp(m),
        reverse=True,
    )

    # Filter by time if specified
    if before:
        return [m for m in sorted_messages if _safe_convert_message_timestamp(m) < before]
    return sorted_messages


async def _get_history_from_communication_service(
    comm_service: Any, channels_to_query: List[str], limit: int, before: Optional[datetime]
) -> ConversationHistory:
    """Get conversation history from communication service."""
    # Fetch more messages to allow filtering
    fetch_limit = limit * 2 if before else limit

    # Fetch messages from all relevant channels
    fetched_messages = await _fetch_messages_from_channels(comm_service, channels_to_query, fetch_limit)

    # Sort and filter messages
    filtered_messages = _sort_and_filter_messages(fetched_messages, before)

    # Convert to conversation messages and apply final limit
    conv_messages = [_convert_service_message_to_conversation(msg) for msg in filtered_messages[:limit]]

    return ConversationHistory(
        messages=conv_messages,
        total_count=len(filtered_messages),
        has_more=len(filtered_messages) > limit,
    )


def _get_current_task_info(request: Request) -> Optional[str]:
    """Get current task information from task scheduler."""
    import inspect

    task_scheduler = getattr(request.app.state, "task_scheduler", None)
    if task_scheduler and hasattr(task_scheduler, "get_current_task"):
        task = task_scheduler.get_current_task()
        # If the result is a coroutine (from AsyncMock in tests), close it and ignore
        # since the real TaskSchedulerService doesn't have this method
        if inspect.iscoroutine(task):
            task.close()  # Properly close the coroutine to avoid warning
            return None
        return str(task) if task is not None else None
    return None


def _get_memory_usage(request: Request) -> float:
    """Get current memory usage from resource monitor."""
    resource_monitor = getattr(request.app.state, "resource_monitor", None)
    if resource_monitor and hasattr(resource_monitor, "snapshot"):
        return float(resource_monitor.snapshot.memory_mb)
    return 0.0


def _get_version_info() -> Tuple[str, str, Optional[str]]:
    """Get version information including codename and code hash."""
    from ciris_engine.constants import CIRIS_CODENAME, CIRIS_VERSION

    try:
        from version import __version__ as code_hash_val

        code_hash: Optional[str] = code_hash_val
    except ImportError:
        code_hash = None

    return CIRIS_VERSION, CIRIS_CODENAME, code_hash


async def _build_agent_status(
    request: Request, cognitive_state: str, uptime: float, messages_processed: int, runtime: Any
) -> AgentStatus:
    """Build AgentStatus object with all required information."""
    # Get current task (synchronous call, not awaitable)
    current_task = _get_current_task_info(request)

    # Get resource usage
    memory_usage_mb = _get_memory_usage(request)

    # Count services
    service_registry = getattr(request.app.state, "service_registry", None)
    services_active, multi_provider_services = _count_active_services(service_registry)

    # Get identity
    agent_id, agent_name = _get_agent_identity_info(runtime)

    # Get version information
    version, codename, code_hash = _get_version_info()

    from ciris_engine.logic.utils.halt_latch import read_halt_latch

    return AgentStatus(
        agent_id=agent_id,
        name=agent_name,
        version=version,
        codename=codename,
        code_hash=code_hash,
        cognitive_state=cognitive_state,
        uptime_seconds=uptime,
        messages_processed=messages_processed,
        last_activity=datetime.now(timezone.utc),
        current_task=current_task,
        services_active=services_active,
        memory_usage_mb=memory_usage_mb,
        multi_provider_services=multi_provider_services,
        accord_halt=await read_halt_latch(),
    )


def _get_agent_identity_info(runtime: Any) -> Tuple[str, str]:
    """Get agent ID and name."""
    agent_id = "ciris_agent"
    agent_name = "CIRIS"

    if hasattr(runtime, "agent_identity") and runtime.agent_identity:
        agent_id = runtime.agent_identity.agent_id
        # Try to get name from various sources
        if hasattr(runtime.agent_identity, "name"):
            agent_name = runtime.agent_identity.name
        elif hasattr(runtime.agent_identity, "core_profile"):
            # Use first part of description or role as name
            agent_name = runtime.agent_identity.core_profile.description.split(".")[0]

    return agent_id, agent_name


@router.get("/status", response_model=None, responses={**RESPONSES_500, **RESPONSES_503})
async def get_status(request: Request, auth: AuthObserverDep) -> SuccessResponse[AgentStatus]:
    """
    Agent status and cognitive state.

    Get comprehensive agent status including state, metrics, and current activity.
    """
    runtime = getattr(request.app.state, "runtime", None)
    if not runtime:
        raise HTTPException(status_code=503, detail="Runtime not available")

    try:
        # Get basic state information
        cognitive_state = _get_cognitive_state(runtime)
        time_service = getattr(request.app.state, "time_service", None)
        uptime = _calculate_uptime(time_service)
        messages_processed = _count_wakeup_tasks(uptime)

        # Build comprehensive status
        status = await _build_agent_status(request, cognitive_state, uptime, messages_processed, runtime)
        return SuccessResponse(data=status)

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _get_identity_data_from_runtime(runtime: Any) -> Dict[str, Any]:
    """Build identity data dict from runtime agent_identity."""
    identity = runtime.agent_identity
    return {
        "agent_id": identity.agent_id,
        "name": getattr(identity, "name", identity.core_profile.description.split(".")[0]),
        "purpose": getattr(identity, "purpose", identity.core_profile.description),
        "created_at": identity.identity_metadata.created_at.isoformat(),
        "lineage": {
            "model": identity.identity_metadata.model,
            "version": identity.identity_metadata.version,
            "parent_id": getattr(identity.identity_metadata, "parent_id", None),
            "creation_context": getattr(identity.identity_metadata, "creation_context", "default"),
            "adaptations": getattr(identity.identity_metadata, "adaptations", []),
        },
        "variance_threshold": 0.2,
    }


def _categorize_service_type(service_type_value: str) -> str:
    """Return the category for a service type value."""
    if "graph" in service_type_value.lower() or service_type_value == "MEMORY":
        return "graph"
    if service_type_value in ["LLM", "SECRETS"]:
        return "core"
    if service_type_value in [
        "TIME",
        "SHUTDOWN",
        "INITIALIZATION",
        "VISIBILITY",
        "AUTHENTICATION",
        "RESOURCE_MONITOR",
        "RUNTIME_CONTROL",
    ]:
        return "infrastructure"
    if service_type_value == "WISE_AUTHORITY":
        return "governance"
    return "special"


def _build_service_availability(service_registry: Any) -> ServiceAvailability:
    """Build ServiceAvailability from service registry."""
    from ciris_engine.schemas.runtime.enums import ServiceType

    services = ServiceAvailability()
    for service_type in ServiceType:
        providers = service_registry.get_services_by_type(service_type)
        count = len(providers)
        category = _categorize_service_type(service_type.value)
        if category == "graph":
            services.graph += count
        elif category == "core":
            services.core += count
        elif category == "infrastructure":
            services.infrastructure += count
        elif category == "governance":
            services.governance += count
        else:
            services.special += count
    return services


@router.get("/identity", response_model=None, responses={**RESPONSES_500, **RESPONSES_503})
async def get_identity(request: Request, auth: AuthObserverDep) -> SuccessResponse[AgentIdentity]:
    """
    Agent identity and capabilities.

    Get comprehensive agent identity including capabilities, tools, and permissions.
    """
    memory_service = getattr(request.app.state, "memory_service", None)
    if not memory_service:
        raise HTTPException(status_code=503, detail=ERROR_MEMORY_SERVICE_NOT_AVAILABLE)

    try:
        from ciris_engine.schemas.services.graph_core import GraphScope
        from ciris_engine.schemas.services.operations import MemoryQuery

        query = MemoryQuery(node_id="agent/identity", scope=GraphScope.IDENTITY, include_edges=False)
        nodes = await memory_service.recall(query)

        # Get identity data from graph or runtime fallback
        identity_data: Dict[str, Any] = {}
        if nodes:
            identity_data = nodes[0].attributes
        else:
            runtime = getattr(request.app.state, "runtime", None)
            if runtime and hasattr(runtime, "agent_identity"):
                identity_data = _get_identity_data_from_runtime(runtime)

        # Get available tools
        tool_service = getattr(request.app.state, "tool_service", None)
        tools = await tool_service.list_tools() if tool_service else []

        # Core action handlers
        handlers = [
            "observe",
            "speak",
            "tool",
            "reject",
            "ponder",
            "defer",
            "memorize",
            "recall",
            "forget",
            "task_complete",
        ]

        # Build service availability
        service_registry = getattr(request.app.state, "service_registry", None)
        services = _build_service_availability(service_registry) if service_registry else ServiceAvailability()

        # Agent's core capabilities
        permissions = ["communicate", "use_tools", "access_memory", "observe_environment", "learn", "adapt"]

        # Build response
        lineage_data = identity_data.get("lineage", {})
        lineage = AgentLineage(
            model=lineage_data.get("model", "unknown"),
            version=lineage_data.get("version", "1.0"),
            parent_id=lineage_data.get("parent_id"),
            creation_context=lineage_data.get("creation_context", "default"),
            adaptations=lineage_data.get("adaptations", []),
        )

        response = AgentIdentity(
            agent_id=identity_data.get("agent_id", "ciris_agent"),
            name=identity_data.get("name", "CIRIS"),
            purpose=identity_data.get("purpose", "Autonomous AI agent"),
            created_at=datetime.fromisoformat(identity_data.get("created_at", datetime.now(timezone.utc).isoformat())),
            lineage=lineage,
            variance_threshold=identity_data.get("variance_threshold", 0.2),
            tools=tools,
            handlers=handlers,
            services=services,
            permissions=permissions,
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _convert_to_channel_info(ch: Any, adapter_type: str) -> ChannelInfo:
    """Convert adapter channel data to ChannelInfo format."""
    if hasattr(ch, "channel_id"):
        # Pydantic model format
        return ChannelInfo(
            channel_id=ch.channel_id,
            channel_type=getattr(ch, "channel_type", adapter_type),
            display_name=getattr(ch, "display_name", ch.channel_id),
            is_active=getattr(ch, "is_active", True),
            created_at=getattr(ch, "created_at", None),
            last_activity=getattr(ch, "last_activity", None),
            message_count=getattr(ch, "message_count", 0),
        )
    else:
        # Dict format (legacy)
        return ChannelInfo(
            channel_id=ch.get("channel_id", ""),
            channel_type=ch.get("channel_type", adapter_type),
            display_name=ch.get("display_name", ch.get("channel_id", "")),
            is_active=ch.get("is_active", True),
            created_at=ch.get("created_at"),
            last_activity=ch.get("last_activity"),
            message_count=ch.get("message_count", 0),
        )


async def _get_channels_from_adapter(adapter: Any, adapter_type: str) -> List[ChannelInfo]:
    """Get channels from a single adapter."""
    channels = []
    if hasattr(adapter, "get_active_channels"):
        try:
            adapter_channels = await adapter.get_active_channels()
            for ch in adapter_channels:
                channels.append(_convert_to_channel_info(ch, adapter_type))
        except Exception as e:
            logger.error(f"Error getting channels from adapter {adapter_type}: {e}")
    return channels


async def _get_channels_from_bootstrap_adapters(runtime: Any) -> List[ChannelInfo]:
    """Get channels from bootstrap adapters."""
    channels = []
    if runtime and hasattr(runtime, "adapters"):
        logger.info(f"Checking {len(runtime.adapters)} bootstrap adapters for channels")
        for adapter in runtime.adapters:
            adapter_type = adapter.__class__.__name__.lower().replace("platform", "")
            channels.extend(await _get_channels_from_adapter(adapter, adapter_type))
    return channels


def _get_control_service(runtime: Any, request: Request) -> Any:
    """Get the runtime control service from app state or registry."""
    # Try app state first
    control_service = getattr(request.app.state, "main_runtime_control_service", None)
    if control_service:
        return control_service

    # Fallback to service registry
    if not runtime or not hasattr(runtime, "service_registry") or not runtime.service_registry:
        return None

    from ciris_engine.schemas.runtime.enums import ServiceType

    providers = runtime.service_registry.get_services_by_type(ServiceType.RUNTIME_CONTROL)
    return providers[0] if providers else None


def _get_adapter_manager(control_service: Any) -> Any:
    """Get adapter manager from control service."""
    if not control_service:
        return None
    if not hasattr(control_service, "adapter_manager"):
        return None
    return control_service.adapter_manager


async def _collect_unique_channels(adapter_manager: Any) -> List[ChannelInfo]:
    """Collect unique channels from loaded adapters."""
    if not adapter_manager or not hasattr(adapter_manager, "loaded_adapters"):
        return []

    channels = []
    seen_channel_ids = set()

    for adapter_id, instance in adapter_manager.loaded_adapters.items():
        adapter_channels = await _get_channels_from_adapter(instance.adapter, instance.adapter_type)

        # Add only unique channels
        for ch in adapter_channels:
            if ch.channel_id not in seen_channel_ids:
                channels.append(ch)
                seen_channel_ids.add(ch.channel_id)

    return channels


async def _get_channels_from_dynamic_adapters(runtime: Any, request: Request) -> List[ChannelInfo]:
    """Get channels from dynamically loaded adapters."""
    control_service = _get_control_service(runtime, request)
    adapter_manager = _get_adapter_manager(control_service)
    return await _collect_unique_channels(adapter_manager)


def _add_default_api_channels(channels: List[ChannelInfo], request: Request, auth: AuthContext) -> None:
    """Add default API channels if not already present."""
    # Default API channel
    api_host = getattr(request.app.state, "api_host", "127.0.0.1")
    api_port = getattr(request.app.state, "api_port", "8080")
    api_channel_id = f"api_{api_host}_{api_port}"

    if not any(ch.channel_id == api_channel_id for ch in channels):
        channels.append(
            ChannelInfo(
                channel_id=api_channel_id,
                channel_type="api",
                display_name=f"API Channel ({api_host}:{api_port})",
                is_active=True,
                created_at=None,
                last_activity=datetime.now(timezone.utc),
                message_count=0,
            )
        )

    # User-specific API channel
    user_channel_id = f"api_{auth.user_id}"
    if not any(ch.channel_id == user_channel_id for ch in channels):
        channels.append(
            ChannelInfo(
                channel_id=user_channel_id,
                channel_type="api",
                display_name=f"API Channel ({auth.user_id})",
                is_active=True,
                created_at=None,
                last_activity=None,
                message_count=0,
            )
        )


@router.get("/channels", response_model=None, responses=RESPONSES_500)
async def get_channels(request: Request, auth: AuthObserverDep) -> SuccessResponse[ChannelList]:
    """
    List active communication channels.

    Get all channels where the agent is currently active or has been active.
    """
    try:
        channels = []
        runtime = getattr(request.app.state, "runtime", None)

        # Get channels from bootstrap adapters
        channels.extend(await _get_channels_from_bootstrap_adapters(runtime))

        # Get channels from dynamically loaded adapters
        dynamic_channels = await _get_channels_from_dynamic_adapters(runtime, request)
        channels.extend(dynamic_channels)

        # Add default API channels
        _add_default_api_channels(channels, request, auth)

        # Sort channels by type and then by id
        channels.sort(key=lambda x: (x.channel_type, x.channel_id))

        channel_list = ChannelList(channels=channels, total_count=len(channels))
        return SuccessResponse(data=channel_list)

    except Exception as e:
        logger.error(f"Failed to get channels: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# Helper function to notify interact responses
async def notify_interact_response(message_id: str, content: str) -> None:
    """Notify waiting interact requests of responses."""
    if message_id in _response_events:
        _message_responses[message_id] = content
        _response_events[message_id].set()


def _validate_websocket_authorization(websocket: WebSocket) -> Optional[str]:
    """Validate websocket authorization header and return API key."""
    authorization = websocket.headers.get("authorization")
    if not authorization:
        return None
    if not authorization.startswith("Bearer "):
        return None
    return authorization[7:]  # Remove "Bearer " prefix


async def _authenticate_websocket_user(websocket: WebSocket, api_key: str) -> Optional[AuthContext]:
    """Authenticate websocket user and return auth context."""
    auth_service = getattr(websocket.app.state, "auth_service", None)
    if not auth_service:
        return None

    key_info = auth_service.validate_api_key(api_key)
    if not key_info:
        return None

    return AuthContext(
        user_id=key_info.user_id,
        role=key_info.role,
        permissions=ROLE_PERMISSIONS.get(key_info.role, set()),
        api_key_id=auth_service._get_key_id(api_key),
        authenticated_at=datetime.now(timezone.utc),
    )


async def _handle_websocket_subscription_action(
    websocket: WebSocket, data: JSONDict, subscribed_channels: set[str]
) -> None:
    """Handle websocket subscribe/unsubscribe actions."""
    action = data.get("action")
    channels_raw = data.get("channels", [])
    # Type narrow to list for set operations
    channels = channels_raw if isinstance(channels_raw, list) else []

    if action == "subscribe":
        subscribed_channels.update(channels)
    elif action == "unsubscribe":
        subscribed_channels.difference_update(channels)
    elif action == "ping":
        await websocket.send_json({"type": "pong", "timestamp": datetime.now(timezone.utc).isoformat()})
        return

    # Send subscription update for subscribe/unsubscribe
    if action in ["subscribe", "unsubscribe"]:
        await websocket.send_json(
            {
                "type": "subscription_update",
                "channels": list(subscribed_channels),
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )


def _register_websocket_client(websocket: WebSocket, client_id: str) -> None:
    """Register websocket client with communication service."""
    comm_service = getattr(websocket.app.state, "communication_service", None)
    if comm_service and hasattr(comm_service, "register_websocket"):
        comm_service.register_websocket(client_id, websocket)


def _unregister_websocket_client(websocket: WebSocket, client_id: str) -> None:
    """Unregister websocket client from communication service."""
    comm_service = getattr(websocket.app.state, "communication_service", None)
    if comm_service and hasattr(comm_service, "unregister_websocket"):
        comm_service.unregister_websocket(client_id)


# WebSocket endpoint for streaming


@router.websocket("/stream")
async def websocket_stream(
    websocket: WebSocket,
) -> None:
    """
    WebSocket endpoint for real-time updates.

    Clients can subscribe to different channels:
    - messages: Agent messages and responses
    - telemetry: Real-time metrics
    - reasoning: Reasoning traces
    - logs: System logs
    """
    # Validate authorization
    api_key = _validate_websocket_authorization(websocket)
    if not api_key:
        await websocket.close(code=1008, reason="Missing or invalid authorization header")
        return

    # Authenticate user
    auth_context = await _authenticate_websocket_user(websocket, api_key)
    if not auth_context:
        await websocket.close(code=1008, reason="Authentication failed")
        return

    # Check minimum role requirement (OBSERVER)
    if not auth_context.role.has_permission(UserRole.OBSERVER):
        await websocket.close(code=1008, reason="Insufficient permissions")
        return

    await websocket.accept()
    client_id = f"ws_{id(websocket)}"

    # Register websocket client
    _register_websocket_client(websocket, client_id)

    subscribed_channels = {"messages"}  # Default subscription

    try:
        while True:
            # Receive and process client messages
            data = await websocket.receive_json()
            await _handle_websocket_subscription_action(websocket, data, subscribed_channels)

    except WebSocketDisconnect:
        # Clean up on disconnect
        _unregister_websocket_client(websocket, client_id)
        logger.info(f"WebSocket client {client_id} disconnected")
