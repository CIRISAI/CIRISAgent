"""Attestation schemas for CIRISVerify integration.

These schemas define the structure for agent attestation and code integrity verification.
CIRISVerify is REQUIRED for CIRIS 2.0+ agents.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AttestationGateOutcome(str, Enum):
    """How the startup-attestation gate resolved.

    The gate is a latency pre-warm, not the enforcement point — batch_context
    blocks on the same call and refuses to build a thought without an
    attestation result — so a latency-SLO breach is reported rather than
    raised. The caller still has to KNOW a breach happened, though, or the
    receipts that make it a fileable ciris_verify issue never get dumped.
    That is what this outcome carries.
    """

    READY = "ready"
    """Attestation completed within the gate deadline."""

    SLO_BREACH_COMPLETED = "slo_breach_completed"
    """Attestation succeeded but overran the budget. The result is VALID — a
    slow filesystem does not make the tree hash wrong — so this is a latency
    regression, not a correctness failure."""

    SLO_BREACH_PENDING = "slo_breach_pending"
    """Still running past deadline + grace, so verifier_runner's own bounded
    degrade did not land either. That is a verifier bug, and the gate degrades
    rather than aborting the runtime."""

    def is_breach(self) -> bool:
        """True when receipts should be dumped for a ciris_verify issue."""
        return self is not AttestationGateOutcome.READY


class TrustRootSource(BaseModel):
    """One trust-root host's result in an attestation (CIRISVerify 21+, CC 5.3.4)."""

    endpoint: str = Field(..., description="The host's base URL")
    reachable: bool = Field(default=False, description="Did the host answer?")
    verified: bool = Field(default=False, description="Did it serve a GenesisBundle that verifies?")
    bundle_fingerprint: Optional[str] = Field(default=None, description="sha256:<hex> of the verified bundle")
    error: Optional[str] = Field(default=None, description="Failure message, if any")


class AttestationResult(BaseModel):
    """Result of a full attestation check.

    This is the cached result stored in AuthenticationService.
    """

    # Core status
    loaded: bool = Field(..., description="Whether CIRISVerify library is loaded")
    version: Optional[str] = Field(None, description="CIRISVerify version if loaded")
    agent_version: Optional[str] = Field(None, description="CIRIS Agent version")
    hardware_type: Optional[str] = Field(None, description="Hardware security type (TPM_2_0, SOFTWARE_ONLY, etc.)")
    key_status: str = Field(..., description="Key status: 'none', 'ephemeral', 'portal_pending', 'portal_active'")
    key_id: Optional[str] = Field(None, description="Portal-issued key ID if activated")
    attestation_status: str = Field(..., description="Attestation: 'not_attempted', 'pending', 'verified', 'failed'")
    error: Optional[str] = Field(None, description="Error message if verify failed to load")
    diagnostic_info: Optional[str] = Field(None, description="Detailed diagnostic info for troubleshooting")

    # Attestation level checks
    dns_us_ok: bool = Field(default=False, description="CIRIS DNS connectivity (US)")
    dns_eu_ok: bool = Field(default=False, description="CIRIS DNS connectivity (EU)")
    https_us_ok: bool = Field(default=False, description="CIRIS HTTPS connectivity (US)")
    https_eu_ok: bool = Field(default=False, description="CIRIS HTTPS connectivity (EU)")
    binary_ok: bool = Field(default=False, description="CIRISVerify binary loaded and functional")
    file_integrity_ok: bool = Field(default=False, description="File integrity verified (Tripwire-style)")
    registry_ok: bool = Field(default=False, description="Signing key registered with Portal/Registry")
    audit_ok: bool = Field(default=False, description="Audit trail intact")
    env_ok: bool = Field(default=False, description="Environment (.env) properly configured")
    play_integrity_ok: bool = Field(default=False, description="Google Play Integrity verification passed")
    play_integrity_verdict: Optional[str] = Field(
        default=None, description="Play Integrity verdict (MEETS_STRONG_INTEGRITY, etc.)"
    )
    max_level: int = Field(default=0, description="Maximum attestation level achieved (0-5)")

    # Two-phase attestation support (mobile device attestation)
    level_pending: bool = Field(
        default=False,
        description="True if waiting for device attestation (Play Integrity/App Attest). "
        "Agent should request device token and re-run attestation.",
    )
    device_attestation: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Device attestation result from Play Integrity or App Attest. "
        "Contains: platform, verified, summary, error (if failed).",
    )

    # Attestation mode
    attestation_mode: str = Field(default="partial", description="Attestation mode: 'full' or 'partial'")

    # Detailed attestation info (for expanded view)
    checks: Optional[Dict[str, Any]] = Field(default=None, description="Per-check details with ok/label/level")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Full attestation details from CIRISVerify")

    # Platform info from attestation
    platform_os: Optional[str] = Field(default=None, description="Platform OS from attestation")
    platform_arch: Optional[str] = Field(default=None, description="Platform architecture")

    # Integrity details
    total_files: Optional[int] = Field(default=None, description="Total files in registry manifest")
    files_checked: Optional[int] = Field(default=None, description="Number of files checked for integrity")
    files_passed: Optional[int] = Field(default=None, description="Number of files that passed integrity")
    files_failed: Optional[int] = Field(default=None, description="Number of files that failed integrity")
    integrity_failure_reason: Optional[str] = Field(default=None, description="Reason for integrity failure if any")

    # v0.6.0: Function integrity verification (constructor-based)
    function_integrity: Optional[str] = Field(
        default=None,
        description="Function integrity: verified, tampered, unavailable:{reason}, signature_invalid, not_found, pending",
    )

    # v0.6.0: Per-source error details for network validation
    source_errors: Optional[Dict[str, Dict[str, str]]] = Field(
        default=None, description="Per-source error details: {source: {category: str, details: str}}"
    )

    # #862: registry reachability — distinguishes "couldn't verify (network)" from
    # "verified bad (tamper)". CIRISVerify reports `reachable` separately from `valid`
    # per source, plus a top-level multi-source classifier. Defaults assume reachable
    # so an older lib that omits these never suppresses a genuine tamper-shutdown.
    registry_reachable: bool = Field(
        default=True,
        description="True if at least one registry source (DNS US/EU or HTTPS) was reachable this attestation",
    )
    source_validation_status: Optional[str] = Field(
        default=None,
        description="CIRISVerify multi-source classifier: AllSourcesAgree | PartialAgreement | "
        "SourcesDisagree | NoSourcesReachable | ValidationError",
    )

    # v0.7.0: Enhanced verification details
    ed25519_fingerprint: Optional[str] = Field(default=None, description="Ed25519 public key fingerprint (SHA-256 hex)")
    key_storage_mode: Optional[str] = Field(
        default=None, description="Key storage mode: SOFTWARE, HARDWARE_BACKED, or specific provider"
    )
    hardware_backed: bool = Field(default=False, description="Whether the key is hardware-backed")
    target_triple: Optional[str] = Field(
        default=None, description="Target triple being checked against registry (e.g., aarch64-linux-android)"
    )
    binary_self_check: Optional[str] = Field(
        default=None, description="Binary self-check status: verified, mismatch, not_found, unavailable:{reason}"
    )
    binary_hash: Optional[str] = Field(default=None, description="Binary hash computed locally")
    expected_binary_hash: Optional[str] = Field(default=None, description="Expected binary hash from registry")
    function_self_check: Optional[str] = Field(
        default=None, description="Function self-check status: verified, mismatch, not_found, unavailable:{reason}"
    )
    functions_checked: Optional[int] = Field(default=None, description="Number of functions verified")
    functions_passed: Optional[int] = Field(default=None, description="Number of functions that passed verification")
    registry_key_status: Optional[str] = Field(default=None, description="Registry key verification status")

    # v0.8.1: Python integrity for mobile
    python_integrity_ok: bool = Field(default=False, description="Python module integrity verified")
    python_modules_checked: Optional[int] = Field(default=None, description="Number of Python modules checked")
    python_modules_passed: Optional[int] = Field(default=None, description="Number of Python modules that passed")
    python_modules_failed: Optional[int] = Field(default=None, description="Number of Python modules that failed")
    python_total_hash: Optional[str] = Field(default=None, description="Total hash of all Python modules")
    python_hash_valid: bool = Field(default=False, description="Whether Python total hash matches expected")
    python_failed_modules: Optional[Dict[str, str]] = Field(
        default=None, description="Map of failed module paths to error messages"
    )

    # v0.9.7: Unified module integrity (cross-validation of disk/agent/registry)
    module_integrity_ok: bool = Field(default=False, description="Unified module integrity verified")
    module_integrity_summary: Optional[Dict[str, int]] = Field(
        default=None, description="Summary counts: total_manifest, verified, failed, missing, excluded, cross_validated"
    )
    cross_validated_files: Optional[List[str]] = Field(
        default=None, description="Files where disk == agent == registry (strongest verification)"
    )
    filesystem_verified_files: Optional[List[str]] = Field(
        default=None, description="Files where disk == registry (no agent hash)"
    )
    agent_verified_files: Optional[List[str]] = Field(
        default=None, description="Files where agent == registry (not on disk, e.g., Chaquopy)"
    )
    disk_agent_mismatch: Optional[Dict[str, Dict[str, Optional[str]]]] = Field(
        default=None, description="RED FLAG: Files with disk != agent hash (tampering indicator)"
    )
    registry_mismatch_files: Optional[Dict[str, Dict[str, Optional[str]]]] = Field(
        default=None, description="Files that don't match registry (some hash fields may be None)"
    )

    # v0.8.4: Enhanced detail lists for UI
    files_missing_count: Optional[int] = Field(default=None, description="Number of manifest files not on device")
    files_missing_list: Optional[List[str]] = Field(default=None, description="List of missing files (max 50)")
    files_failed_list: Optional[List[str]] = Field(
        default=None, description="List of files that failed hash check (max 50)"
    )
    files_unexpected_list: Optional[List[str]] = Field(default=None, description="List of unexpected files (max 50)")
    functions_failed_list: Optional[List[str]] = Field(
        default=None, description="List of functions that failed verification (max 50)"
    )

    # v0.8.6: Mobile exclusion tracking for correct denominator
    mobile_excluded_count: Optional[int] = Field(
        default=None, description="Files excluded from mobile (discord, reddit, cli, etc.)"
    )
    mobile_excluded_list: Optional[List[str]] = Field(
        default=None, description="List of mobile-excluded files (max 50)"
    )

    # v0.8.5: Registry sources agreement and attestation proof
    sources_agreeing: int = Field(default=0, description="Trust-root hosts that verified the selected root")
    sources: List[TrustRootSource] = Field(
        default_factory=list, description="Every trust-root host checked; empty before CIRISVerify 21"
    )
    attestation_proof: Optional[Dict[str, Any]] = Field(
        default=None, description="Full attestation proof from CIRISVerify"
    )

    # v0.8.6: Per-file results for deconflicted integrity display
    per_file_results: Optional[Dict[str, str]] = Field(
        default=None, description="Per-file status map (path -> passed/failed/missing/unreadable)"
    )

    # Cache metadata
    cached_at: Optional[datetime] = Field(default=None, description="When this result was cached")
    cache_ttl_seconds: int = Field(default=3600, description="Cache TTL in seconds (default 1 hour)")

    # =========================================================================
    # CIRISVerify 1.2.x: Hardware Trust Detection
    # =========================================================================
    # Detects SoC-level vulnerabilities that compromise TEE trust (e.g., CVE-2026-20435)

    # Hardware trust status (THE KEY FLAG for wallet operations)
    hardware_trust_degraded: bool = Field(
        default=False,
        description="True if hardware security is compromised (vulnerable SoC, rooted, emulator). "
        "When true, wallet operations should be receive-only.",
    )
    trust_degradation_reason: Optional[str] = Field(
        default=None,
        description="Human-readable reason for trust degradation (e.g., 'Vulnerable MediaTek SoC detected')",
    )

    # Hardware info
    soc_manufacturer: Optional[str] = Field(default=None, description="SoC manufacturer (mediatek, qualcomm, etc.)")
    soc_model: Optional[str] = Field(default=None, description="SoC model identifier (mt6893, sm8550, etc.)")
    security_patch_level: Optional[str] = Field(
        default=None, description="Android security patch level (YYYY-MM-DD format)"
    )
    is_emulator: bool = Field(default=False, description="Device is an emulator")
    is_suspicious_emulator: bool = Field(
        default=False, description="Device shows signs of sophisticated emulator (hiding detection)"
    )
    bootloader_unlocked: Optional[bool] = Field(default=None, description="Bootloader is unlocked (if detectable)")
    tee_implementation: Optional[str] = Field(
        default=None, description="TEE implementation (TrustZone, StrongBox, Keymaster, etc.)"
    )
    is_rooted: bool = Field(default=False, description="Device shows signs of root access")

    # Hardware limitations (why trust is degraded)
    hardware_limitations: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="List of HardwareLimitation objects explaining trust degradation. "
        "Each contains: limitation_type, manufacturer, advisory (CVE details), reason, current_patch, minimum_patch",
    )

    # Security advisories (CVE details for UI display)
    security_advisories: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="List of SecurityAdvisory objects for vulnerable hardware. "
        "Each contains: cve, title, impact, software_patchable, min_patch_level",
    )


class AttestationCacheStatus(BaseModel):
    """Status of the attestation cache."""

    has_cached_result: bool = Field(..., description="Whether a cached result exists")
    cached_at: Optional[datetime] = Field(None, description="When the result was cached")
    cache_age_seconds: Optional[float] = Field(None, description="Age of cache in seconds")
    cache_expired: bool = Field(default=False, description="Whether cache has expired")
    attestation_in_progress: bool = Field(default=False, description="Whether attestation is currently running")
    max_level: Optional[int] = Field(None, description="Cached max attestation level (0-5)")
    # Stale-while-revalidate fields
    has_stale_result: bool = Field(default=False, description="Whether stale data is available during refresh")
    stale_level: Optional[int] = Field(None, description="Last known level from stale cache (0-5)")


class AttestationRequest(BaseModel):
    """Request to run attestation."""

    mode: str = Field(default="partial", description="Attestation mode: 'full' or 'partial'")
    play_integrity_token: Optional[str] = Field(None, description="Google Play Integrity token")
    play_integrity_nonce: Optional[str] = Field(None, description="Nonce used for Play Integrity request")
    force_refresh: bool = Field(default=False, description="Force refresh even if cache is valid")


class VerifyAttestationContext(BaseModel):
    """Unified CIRISVerify attestation and disclosure context.

    This schema provides a consistent view of attestation state, mandatory disclosure,
    and key signature/storage info for use in:
    1. Agent LLM context (SystemSnapshot)
    2. Accord traces (CIRISLens)
    3. API responses

    The same text format is used everywhere for consistency.
    """

    # Attestation level and status
    attestation_level: int = Field(0, description="Attestation level achieved (0-5)")
    attestation_status: str = Field("not_attempted", description="Status: not_attempted, pending, verified, failed")
    attestation_mode: str = Field("partial", description="Mode: full or partial")

    # Summary string (human-readable)
    attestation_summary: str = Field(
        "", description="Human-readable summary (e.g., 'Level 3/5 | ✓Binary ✓Environment ✓Registry')"
    )

    # Mandatory disclosure (MUST be shown to users per FSD-001)
    disclosure_text: str = Field(
        "", description="Mandatory disclosure text from CIRISVerify (MUST be visible in all contexts)"
    )
    disclosure_severity: str = Field("info", description="Disclosure severity: info, warning, critical")

    # Key signature info
    key_status: str = Field("none", description="Key status: none, ephemeral, portal_pending, portal_active")
    key_id: Optional[str] = Field(None, description="Portal-issued key ID if activated")
    ed25519_fingerprint: Optional[str] = Field(None, description="Ed25519 public key SHA-256 fingerprint")

    # Key storage info
    key_storage_mode: Optional[str] = Field(
        None, description="Key storage: SOFTWARE, HARDWARE_BACKED, or specific provider"
    )
    hardware_backed: bool = Field(False, description="Whether the signing key is hardware-backed")
    hardware_type: Optional[str] = Field(None, description="Hardware security type (TPM_2_0, TEE, SOFTWARE_ONLY)")

    # Check results (boolean flags)
    binary_ok: bool = Field(False, description="CIRISVerify binary loaded and functional")
    env_ok: bool = Field(False, description="Environment properly configured")
    registry_ok: bool = Field(False, description="Signing key registered with Portal/Registry")
    file_integrity_ok: bool = Field(False, description="File integrity verified")
    audit_ok: bool = Field(False, description="Audit trail intact")
    play_integrity_ok: bool = Field(False, description="Google Play Integrity passed (mobile only)")

    # Version info
    verify_version: Optional[str] = Field(None, description="CIRISVerify library version")
    agent_version: Optional[str] = Field(None, description="Agent version being attested")

    # Timestamp
    attested_at: Optional[datetime] = Field(None, description="When this attestation was performed")

    @classmethod
    def from_attestation_result(
        cls,
        result: "AttestationResult",
        disclosure_text: str = "",
        disclosure_severity: str = "info",
        agent_version: Optional[str] = None,
    ) -> "VerifyAttestationContext":
        """Create context from an AttestationResult.

        Args:
            result: AttestationResult from authentication service
            disclosure_text: Mandatory disclosure text
            disclosure_severity: Disclosure severity level
            agent_version: Agent version string

        Returns:
            VerifyAttestationContext with all fields populated
        """
        # Build summary string
        checks = []
        if result.binary_ok:
            checks.append("✓Binary")
        else:
            checks.append("✗Binary")
        if result.env_ok:
            checks.append("✓Environment")
        else:
            checks.append("✗Environment")
        if result.registry_ok:
            checks.append("✓Registry")
        else:
            checks.append("✗Registry")
        if result.file_integrity_ok:
            checks.append("✓FileIntegrity")
        else:
            checks.append("✗FileIntegrity")
        if result.audit_ok:
            checks.append("✓Audit")
        else:
            checks.append("○Audit")

        summary = f"Level {result.max_level}/5 | {' '.join(checks)}"

        return cls(
            attestation_level=result.max_level,
            attestation_status=result.attestation_status,
            attestation_mode=result.attestation_mode,
            attestation_summary=summary,
            disclosure_text=disclosure_text,
            disclosure_severity=disclosure_severity,
            key_status=result.key_status,
            key_id=result.key_id,
            ed25519_fingerprint=result.ed25519_fingerprint,
            key_storage_mode=result.key_storage_mode,
            hardware_backed=result.hardware_backed,
            hardware_type=result.hardware_type,
            binary_ok=result.binary_ok,
            env_ok=result.env_ok,
            registry_ok=result.registry_ok,
            file_integrity_ok=result.file_integrity_ok,
            audit_ok=result.audit_ok,
            play_integrity_ok=result.play_integrity_ok,
            verify_version=result.version,
            agent_version=agent_version,
            attested_at=result.cached_at,
        )

    def to_context_string(self) -> str:
        """Generate the context string for LLM/traces.

        This is the exact same text used everywhere for consistency.
        """
        lines = [
            f"CIRIS VERIFY ATTESTATION: {self.attestation_summary}",
            f"Status: {self.attestation_status} | Mode: {self.attestation_mode}",
        ]

        if self.key_status != "none":
            key_info = f"Key: {self.key_status}"
            if self.ed25519_fingerprint:
                key_info += f" (fingerprint: {self.ed25519_fingerprint[:16]}...)"
            if self.hardware_backed:
                key_info += f" [HARDWARE-BACKED: {self.hardware_type or 'unknown'}]"
            else:
                key_info += f" [SOFTWARE: {self.key_storage_mode or 'default'}]"
            lines.append(key_info)

        if self.disclosure_text:
            severity_prefix = {
                "critical": "⚠️ CRITICAL",
                "warning": "⚠️ WARNING",
                "info": "ℹ️ NOTICE",
            }.get(self.disclosure_severity.lower(), "ℹ️ NOTICE")
            lines.append(f"{severity_prefix}: {self.disclosure_text}")

        return "\n".join(lines)
