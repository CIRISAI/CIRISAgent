"""
Service initialization for CIRIS Agent runtime.

Handles the initialization of all core services.
"""

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

import aiofiles

from ciris_engine.config.ciris_services import get_billing_url
from ciris_engine.logic.buses import BusManager
from ciris_engine.logic.config.config_accessor import ConfigAccessor
from ciris_engine.logic.config.llm_budget import classify_provider, primary_provider_declaration, resolve_budget
from ciris_engine.logic.persistence import get_sqlite_db_full_path
from ciris_engine.logic.registries.base import Priority, ServiceRegistry

# Removed AuditSinkManager - audit is consolidated, no sink needed
from ciris_engine.logic.runtime.startup_logging import (
    FIRST_RUN_SERVICES,
    RESUME_SERVICES,
    SERVICE_NAMES,
    TOTAL_CORE_SERVICES,
    _log_service_started,
    _set_service_phase,
)

# CoreToolService removed - SELF_HELP moved to memory per user request
# BasicTelemetryCollector removed - using GraphTelemetryService instead
from ciris_engine.logic.secrets.service import SecretsService
from ciris_engine.logic.services.governance.adaptive_filter import AdaptiveFilterService
from ciris_engine.logic.services.governance.wise_authority import WiseAuthorityService
from ciris_engine.logic.services.graph.audit_service import GraphAuditService as AuditService
from ciris_engine.logic.services.graph.memory_service import LocalGraphMemoryService
from ciris_engine.logic.services.infrastructure.database_maintenance import DatabaseMaintenanceService
from ciris_engine.logic.services.lifecycle.initialization import InitializationService
from ciris_engine.logic.services.lifecycle.shutdown import ShutdownService

# Import new infrastructure services
from ciris_engine.logic.services.lifecycle.time import TimeService
from ciris_engine.logic.services.runtime.llm_service import OpenAICompatibleClient
from ciris_engine.logic.utils.path_resolution import get_data_dir
from ciris_engine.protocols.services import LLMService, TelemetryService
from ciris_engine.schemas.config.essential import EssentialConfig
from ciris_engine.schemas.config.llm_budget import ProviderClass
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.runtime.manifest import ServiceManifest
from ciris_engine.schemas.services.capabilities import LLMCapabilities

logger = logging.getLogger(__name__)


def _is_loopback_or_lan(url: str, provider_id: Optional[str] = None) -> bool:
    """Does this provider run on hardware the user controls (loopback, LAN, overlay)?

    A TOPOLOGY question, and only that. It decides whether a provider is
    "local_primary"; it must never be used to decide WHO a provider is — that
    conflation is CIRISAgent#1063.

    Delegates to the one provider classifier (``classify_provider``,
    ciris_engine/logic/config/llm_budget.py, #1186), so the service name, the
    ``is_local`` metadata and the time budget cannot disagree. That classifier
    parses the host rather than substring-matching the URL (``"10."`` once
    matched a version segment) and covers all of 172.16/12, link-local, CGNAT
    overlays and ``.local`` names.
    """
    if not url and not provider_id:
        return False
    return classify_provider(provider_id, url) is ProviderClass.LOCAL


class ServiceInitializer:
    """Manages initialization of all core services."""

    def __init__(self, essential_config: Optional[EssentialConfig] = None) -> None:
        self.service_registry: Optional[ServiceRegistry] = None
        self.bus_manager: Optional[Any] = None  # Will be BusManager
        self.essential_config = essential_config or EssentialConfig()
        self.config_accessor: Optional[ConfigAccessor] = None

        # Infrastructure services (initialized first)
        self.time_service: Optional[TimeService] = None
        self.shutdown_service: Optional[ShutdownService] = None
        self.initialization_service: Optional[InitializationService] = None

        # Create initial config accessor without graph (bootstrap only)
        self.config_accessor = ConfigAccessor(None, self.essential_config)

        # Core services
        self.memory_service: Optional[LocalGraphMemoryService] = None
        self.secrets_service: Optional[SecretsService] = None
        self.wa_auth_system: Optional[WiseAuthorityService] = None
        # AuthenticationService is created in initialize_security_services and
        # ALSO registered under WISE_AUTHORITY in initialize_all_services so the
        # batch_context strict attestation gate can find it via the registry.
        # Default to None at construction time so register-only paths (or tests
        # that mock-skip the security init phase) can read self.auth_service
        # without AttributeError. Use Any (not Optional[AuthenticationService])
        # to keep this consistent with how the field was treated implicitly
        # before this annotation was added — the alternative would force a
        # forward-reference import and an `assert is not None` at every
        # downstream callsite, which the security init phase guarantees.
        self.auth_service: Any = None
        self.telemetry_service: Optional[TelemetryService] = None
        self.llm_service: Optional[LLMService] = None
        self.audit_service: Optional[AuditService] = None
        # Removed audit_sink_manager - audit is consolidated
        self.adaptive_filter_service: Optional[AdaptiveFilterService] = None
        self.secrets_tool_service: Optional[Any] = None  # SecretsToolService
        self.maintenance_service: Optional[DatabaseMaintenanceService] = None
        self.incident_management_service: Optional[Any] = None  # Will be IncidentManagementService
        self.tsdb_consolidation_service: Optional[Any] = None  # Will be TSDBConsolidationService
        self.resource_monitor_service: Optional[Any] = None  # Will be ResourceMonitorService
        self.config_service: Optional[Any] = None  # Will be GraphConfigService
        self.self_observation_service: Optional[Any] = None  # Will be SelfObservationService
        self.visibility_service: Optional[Any] = None  # Will be VisibilityService
        self.consent_service: Optional[Any] = None  # Will be ConsentService
        self.runtime_control_service: Optional[Any] = None  # Will be RuntimeControlService

        # Module management
        self.module_loader: Optional[Any] = None  # Will be ModuleLoader
        self.loaded_modules: List[str] = []
        self._skip_llm_init: bool = False  # Set to True if MOCK LLM module detected

        # Metrics tracking for v1.4.3
        self._services_started_count: int = 0
        self._initialization_errors: int = 0
        self._dependencies_resolved: int = 0
        self._startup_start_time: Optional[float] = None
        self._startup_end_time: Optional[float] = None

    def _is_first_run_mode(self) -> bool:
        """Check if we're in first-run mode."""
        from ciris_engine.logic.setup.first_run import is_first_run

        return is_first_run()

    async def initialize_infrastructure_services(self) -> None:
        """Initialize infrastructure services that all other services depend on."""
        # Track startup time
        import time

        if self._startup_start_time is None:
            self._startup_start_time = time.time()

        # Set phase for logging - this is the first phase of initialization
        _set_service_phase("FIRST-RUN" if self._is_first_run_mode() else "FULL-STARTUP")

        # Initialize TimeService first - everyone needs time
        try:
            self.time_service = TimeService()
            await self.time_service.start()
            self._services_started_count += 1
            _log_service_started(1, "TimeService")
        except Exception as e:
            self._initialization_errors += 1
            _log_service_started(1, "TimeService", success=False)
            logger.error(f"Failed to initialize TimeService: {e}")
            raise
        assert self.time_service is not None  # For type checker

        # Note: TimeService will be registered in ServiceRegistry later
        # when the registry is created in initialize_all_services()

        # Initialize ShutdownService
        self.shutdown_service = ShutdownService()
        await self.shutdown_service.start()
        self._services_started_count += 1
        _log_service_started(2, "ShutdownService")

        # Initialize InitializationService with TimeService
        self.initialization_service = InitializationService(self.time_service)
        await self.initialization_service.start()
        self._services_started_count += 1
        _log_service_started(3, "InitializationService")

        # Initialize ResourceMonitorService
        # Device-sized default budget (phones: 1 GB memory; laptop/server: 4 GB).
        # The monitor's budget is the one source: /v1/system/resources and the
        # telemetry resource view both report it, so published and acting
        # numbers cannot drift.
        from ciris_engine.logic.runtime.device_class import resolve_device_class
        from ciris_engine.logic.services.infrastructure.resource_monitor import ResourceMonitorService
        from ciris_engine.schemas.services.resources_core import ResourceBudget

        budget = ResourceBudget.for_device_class(resolve_device_class())
        logger.info(
            "Resource budget: device class %s, memory %s/%s/%s MB (elevated/high/critical)",
            budget.device_class.value,
            budget.memory_mb.warning,
            budget.memory_mb.critical,
            budget.memory_mb.limit,
        )

        # Credit provider: Controls billing for CIRIS LLM proxy usage
        # - Server: CIRIS_BILLING_API_KEY set → API key auth
        # - Android: Using CIRIS proxy + Google ID token → JWT auth
        # - Not using CIRIS proxy → No billing (credit_provider = None)
        from typing import Optional

        from ciris_engine.protocols.services.infrastructure.credit_gate import CreditGateProtocol

        credit_provider: Optional[CreditGateProtocol] = None
        is_android = "ANDROID_DATA" in os.environ

        # Check if using CIRIS LLM proxy (Android only - billing required for proxy)
        # Matches both legacy ciris.ai and new ciris-services infrastructure
        llm_base_url = os.getenv("OPENAI_API_BASE", "")
        using_ciris_proxy = "ciris.ai" in llm_base_url or "ciris-services" in llm_base_url

        # Server: Simple API key check
        api_key = os.getenv("CIRIS_BILLING_API_KEY", "")
        # Mobile: OAuth ID token for JWT auth with CIRIS proxy (Google on Android, Apple on iOS)
        from ciris_engine.logic.utils.token_handshake import read_proxy_token

        google_id_token, _tok_var = read_proxy_token()

        if api_key and not is_android:
            # Server with API key - use API key auth
            from ciris_engine.logic.services.infrastructure.resource_monitor import CIRISBillingProvider

            base_url = get_billing_url()
            timeout = float(os.getenv("CIRIS_BILLING_TIMEOUT_SECONDS", "5.0"))
            cache_ttl = int(os.getenv("CIRIS_BILLING_CACHE_TTL_SECONDS", "15"))
            fail_open = os.getenv("CIRIS_BILLING_FAIL_OPEN", "false").lower() == "true"

            credit_provider = CIRISBillingProvider(
                api_key=api_key,
                base_url=base_url,
                timeout_seconds=timeout,
                cache_ttl_seconds=cache_ttl,
                fail_open=fail_open,
            )
            logger.info("Using CIRISBillingProvider with API key auth")

        elif is_android and using_ciris_proxy:
            # Android using CIRIS LLM proxy - requires billing
            if google_id_token:
                # Have Google ID token - use JWT auth
                from ciris_engine.logic.services.infrastructure.resource_monitor import CIRISBillingProvider

                base_url = get_billing_url()
                timeout = float(os.getenv("CIRIS_BILLING_TIMEOUT_SECONDS", "5.0"))
                cache_ttl = int(os.getenv("CIRIS_BILLING_CACHE_TTL_SECONDS", "15"))
                fail_open = os.getenv("CIRIS_BILLING_FAIL_OPEN", "false").lower() == "true"

                credit_provider = CIRISBillingProvider(
                    google_id_token=google_id_token,
                    base_url=base_url,
                    timeout_seconds=timeout,
                    cache_ttl_seconds=cache_ttl,
                    fail_open=fail_open,
                )
                logger.info("Using CIRISBillingProvider with JWT auth (CIRIS LLM proxy)")
            else:
                # No token yet - user needs to sign in with Google
                logger.warning(
                    "Android using CIRIS LLM proxy without Google ID token - "
                    "user needs to sign in with Google to use LLM features"
                )
                # credit_provider stays None - LLM calls will fail until signed in

        elif is_android and not using_ciris_proxy:
            # Android but not using CIRIS proxy - no billing needed
            logger.info("Android not using CIRIS proxy - no billing required")
            # credit_provider stays None

        else:
            # Server without API key - no billing
            logger.info("No billing configured (CIRIS_BILLING_API_KEY not set)")

        self.resource_monitor_service = ResourceMonitorService(
            budget=budget,
            db_path=get_sqlite_db_full_path(self.essential_config),
            time_service=self.time_service,
            credit_provider=credit_provider,
            agent_occurrence_id=getattr(self.essential_config, "agent_occurrence_id", "default"),
        )
        await self.resource_monitor_service.start()
        self._services_started_count += 1
        _log_service_started(4, "ResourceMonitor")

    async def initialize_memory_service(self, config: Any) -> None:
        """Initialize the memory service."""
        # Initialize secrets service first (memory service depends on it)
        import os
        from pathlib import Path

        # Use configurable secrets key path from essential config
        keys_dir = Path(self.essential_config.security.secrets_key_path)
        keys_dir.mkdir(parents=True, exist_ok=True)

        # Load or generate master key. Atomic write (.tmp + fsync + os.replace)
        # protects against asyncio cancellation mid-write — see RCA-secrets-
        # master-key-zero-byte for the incident this guards against.
        # TODO(phase-split): pull master-key bootstrap into an earlier phase
        # (INFRASTRUCTURE) so it doesn't share a timeout boundary with DB
        # connect at all. Atomic write makes the file safe even under
        # cancellation; phase split would prevent the cancellation entirely.
        # Note: Hardware-backed key protection is handled by CIRISVerify's unified signer
        # 2.9.7 (#896): persist's Engine owns the runtime encryption key
        # (auto-initialized via secrets_rotate_master_key); the on-disk file
        # bootstrap is retained for operational continuity (.ciris_keys layout
        # is documented + monitored) but the bytes are no longer plumbed into
        # SecretsService.
        master_key_path = keys_dir / "secrets_master.key"
        await self._load_or_create_master_key(master_key_path)

        # Create README if it doesn't exist. Plain-text (.txt) on purpose:
        # runtime code paths must not emit/reference .md files (D27 — keeps
        # runtime free of Markdown surfaces; CIRISAgent#807). Content is
        # informational only and reads identically as .txt.
        readme_path = keys_dir / "README.txt"
        if not readme_path.exists():
            readme_content = """# CIRIS Keys Directory

This directory contains critical cryptographic keys for the CIRIS system.

## Files

### secrets_master.key
- **Purpose**: Master encryption key for the SecretsService
- **Type**: 256-bit symmetric key
- **Usage**: Used to derive per-secret encryption keys via PBKDF2
- **Algorithm**: AES-256-GCM encryption
- **Critical**: Loss of this key means all encrypted secrets become unrecoverable

### audit_signing_private.pem
- **Purpose**: Private key for signing audit log entries
- **Type**: RSA 2048-bit private key
- **Usage**: Creates digital signatures for non-repudiation
- **Critical**: Keep this key secure - compromise allows forging audit entries

### audit_signing_public.pem
- **Purpose**: Public key for verifying audit signatures
- **Type**: RSA 2048-bit public key
- **Usage**: Verifies signatures on audit entries
- **Note**: Can be shared publicly for verification purposes

## Security Notes

1. **Permissions**: All key files should have restrictive permissions (600)
2. **Backup**: Regularly backup these keys to secure offline storage
3. **Rotation**: Consider key rotation policies for long-running deployments
4. **Access**: Only the CIRIS process should access these keys

## DO NOT
- Commit these files to version control
- Share the private keys or master key
- Store copies in insecure locations
"""
            async with aiofiles.open(readme_path, "w") as f:
                await f.write(readme_content)
            logger.info("Created .ciris_keys/README.txt")

        if self.time_service is None:
            raise RuntimeError("TimeService must be initialized before SecretsService")

        # Persist's Engine owns the secrets database + crypto (#896) — no
        # db_path / master_key / key_storage_mode plumbing.
        self.secrets_service = SecretsService(time_service=self.time_service)
        await self.secrets_service.start()
        self._services_started_count += 1
        _log_service_started(5, "SecretsService")

        # Create and register CoreToolService
        from ciris_engine.logic.services.tools import CoreToolService

        self.secrets_tool_service = CoreToolService(
            secrets_service=self.secrets_service,
            time_service=self.time_service,
            # Don't pass db_path - let persistence layer use current config
            # This allows runtime database switching (SQLite → PostgreSQL via CIRIS_DB_URL)
        )
        await self.secrets_tool_service.start()
        self._services_started_count += 1
        _log_service_started(22, "SecretsToolService")

        # LocalGraphMemoryService needs the correct db path from our config
        db_path = get_sqlite_db_full_path(self.essential_config)
        self.memory_service = LocalGraphMemoryService(
            db_path=db_path, time_service=self.time_service, secrets_service=self.secrets_service
        )
        await self.memory_service.start()
        self._services_started_count += 1
        _log_service_started(6, "MemoryService")

        # Initialize GraphConfigService now that memory service is ready
        from ciris_engine.logic.registries.base import Priority, get_global_registry
        from ciris_engine.logic.services.graph.config_service import GraphConfigService
        from ciris_engine.schemas.runtime.enums import ServiceType

        if self.time_service is None:
            raise RuntimeError("TimeService must be initialized before GraphConfigService")
        self.config_service = GraphConfigService(self.memory_service, self.time_service)
        await self.config_service.start()
        self._services_started_count += 1
        _log_service_started(7, "ConfigService")

        # Token budgets live in the config graph (none by default); the monitor
        # reads them now and follows resources.token_budget.* changes live.
        if self.resource_monitor_service is not None:
            await self.resource_monitor_service.attach_config_service(self.config_service)

        # Register config service immediately so it's available for persistence operations
        registry = get_global_registry()
        # Store essential config on the service so db_paths can find it
        # Dynamic attribute assignment for runtime access to essential_config
        self.config_service.essential_config = self.essential_config  # type: ignore[attr-defined]
        registry.register_service(
            service_type=ServiceType.CONFIG,
            provider=self.config_service,
            priority=Priority.HIGH,
            capabilities=["get_config", "set_config", "list_configs"],
            metadata={"backend": "graph", "type": "essential"},
        )
        logger.info("Config service registered early in ServiceRegistry for persistence access")

        # Create config accessor with graph service
        self.config_accessor = ConfigAccessor(self.config_service, self.essential_config)
        self._dependencies_resolved += 1  # Graph config service dependency

        # Migrate essential config to graph
        await self._migrate_config_to_graph()

    @staticmethod
    async def _load_or_create_master_key(master_key_path: Any) -> bytes:
        """Load secrets master key from disk, validating length, or generate
        a fresh one with an atomic write.

        Two failure modes this guards against:

        1. **Cancellation mid-write.** ``aiofiles.open(path, "wb")`` truncates
           the file the instant the descriptor opens; the bytes only land
           when the write+close drain. If asyncio cancels the parent task
           before close, the canonical name is left at 0 bytes — every
           subsequent boot then fails the ``len(candidate) == 32`` length
           validation below with no self-healing path.
           Fix: write to ``<path>.tmp``, fsync, then ``os.replace`` to the
           canonical name. POSIX rename is atomic — cancellation orphans
           ``.tmp`` and the canonical name either holds the previous file
           (or doesn't exist for a first write).

        2. **Corrupted file from any prior cause** — partial write from an
           older code path, manual operator intervention, FS corruption,
           etc. We treat any wrong-length file as missing, log an ERROR
           with a stable string monitoring can alert on, and rotate.
        """
        import secrets as secrets_module

        path = Path(master_key_path)

        if path.exists():
            async with aiofiles.open(path, "rb") as f:
                candidate = await f.read()
            if len(candidate) == 32:
                logger.info("Loaded existing secrets master key")
                return candidate
            # Wrong length → treat as corrupted. Stable error string for
            # monitoring: "secrets_bootstrap_corruption".
            logger.error(
                "secrets_bootstrap_corruption: existing %s is %d bytes, "
                "expected 32. Treating as corrupted and rotating master key. "
                "Any pre-existing encrypted secrets will be unrecoverable.",
                path,
                len(candidate),
            )
            # Fall through to generate-and-rotate path.

        # Generate a fresh 32-byte key and persist atomically. asyncio.shield
        # is belt-and-suspenders — even if the parent task is cancelled, the
        # write+rename completes; a torn .tmp can never become the canonical
        # name. The shield is bounded (small FS-only work) so it does not
        # extend any meaningful timeout window.
        async def _atomic_write() -> bytes:
            new_key = secrets_module.token_bytes(32)
            tmp_path = path.with_suffix(path.suffix + ".tmp")
            try:
                async with aiofiles.open(tmp_path, "wb") as f:
                    await f.write(new_key)
                    await f.flush()
                    # fsync the underlying fd so the bytes are durable on disk
                    # before we promote the .tmp to the canonical name.
                    fd = f.fileno()
                    await asyncio.get_running_loop().run_in_executor(None, os.fsync, fd)
                os.chmod(tmp_path, 0o600)
                # POSIX atomic rename. Either the canonical name holds the
                # previous file (or doesn't exist), or it holds the fully-
                # written new file. There is no torn intermediate state.
                os.replace(tmp_path, path)
            except BaseException:
                # Best-effort cleanup of any orphaned .tmp; never raise from
                # the cleanup path (the original exception is what matters).
                try:
                    if tmp_path.exists():
                        os.unlink(tmp_path)
                except Exception:
                    pass
                raise
            logger.info("Generated and saved new secrets master key (atomic)")
            return new_key

        return await asyncio.shield(_atomic_write())

    async def verify_memory_service(self) -> bool:
        """Verify memory service is operational."""
        if not self.memory_service:
            logger.error("Memory service not initialized")
            return False

        # Checked here rather than asserted inside the try below: the except
        # catches Exception, which includes AssertionError, so a missing
        # time_service was reported as "Memory service verification error" —
        # naming the wrong service. Asserts are also stripped under `python -O`,
        # so the guard would vanish entirely in an optimized run.
        if not self.time_service:
            logger.error("Time service not initialized")
            return False

        # Test basic operations
        try:
            from ciris_engine.schemas.services.graph_core import GraphNode, GraphScope, NodeType

            # Use a different node type for test - don't pollute CONFIG namespace
            now = self.time_service.now()
            test_node = GraphNode(
                id="_verification_test",
                type=NodeType.OBSERVATION,  # Use OBSERVATION type for system verification test
                attributes={
                    "created_at": now.isoformat(),  # Serialize to ISO string
                    "updated_at": now.isoformat(),  # Serialize to ISO string
                    "created_by": "system_verification",
                    "tags": ["test", "verification"],
                    "verification_type": "memory_service",  # Custom field in attributes dict
                    "verifier": "system",  # Custom field in attributes dict
                },
                scope=GraphScope.LOCAL,
            )

            # Test memorize and recall
            await self.memory_service.memorize(test_node)

            from ciris_engine.schemas.services.operations import MemoryQuery

            query = MemoryQuery(
                node_id=test_node.id, scope=test_node.scope, type=test_node.type, include_edges=False, depth=1
            )
            nodes = await self.memory_service.recall(query)

            if not nodes:
                logger.error("Memory service verification failed: no nodes recalled")
                return False

            # Clean up
            await self.memory_service.forget(test_node)

            logger.info("[OK] Memory service verified")
            return True

        except Exception as e:
            logger.error(f"Memory service verification error: {e}")
            return False

    async def initialize_security_services(self, config: Any, app_config: Any) -> None:
        """Initialize security-related services."""
        # SecretsService already initialized in initialize_memory_service

        # Initialize AuthenticationService first
        from ciris_engine.logic.services.infrastructure.authentication import AuthenticationService

        if self.time_service is None:
            raise RuntimeError("TimeService must be initialized before AuthenticationService")

        if self.config_accessor is None:
            raise RuntimeError("ConfigAccessor must be initialized before AuthenticationService")
        # Get main database path for WiseAuthority (needs access to tasks table)
        main_db_path = get_sqlite_db_full_path(self.essential_config)

        # 2.9.0: WA certificates live in the one process-wide persist engine
        # (wa_cert substrate on the main DB) — there is no separate auth DB.
        # A process hosts exactly one persist engine; handing the auth service
        # a different path trips EngineConfigMismatch on bootstrap.
        self.auth_service = AuthenticationService(
            db_path=main_db_path, time_service=self.time_service, key_dir=None  # Will use default ~/.ciris/
        )
        await self.auth_service.start()
        self._services_started_count += 1
        _log_service_started(15, "AuthenticationService")

        # Long-jump upgrade recovery (2.7.x -> 2.9.x). Pre-2.9.0 the auth
        # store wrote `wa_cert` rows into the AUDIT database; from 2.9.0 it
        # reads the persist engine (`cirislens_wa_cert` on the main DB). An
        # agent that jumped straight across boots GREEN while its owner
        # cannot log in — the certificate is still on disk, just in the
        # database the new read path no longer looks at. Import it here:
        # after the auth service is up (so the persist engine is wired and
        # the store is usable) and before adapters start minting their own
        # observers. Idempotent, insert-only, and never raises.
        self._recover_stranded_wa_certificates()

        # Process pending users from setup wizard if file exists
        await self._process_pending_users_from_setup()

        # Initialize WA authentication system with TimeService and AuthService
        # Use the main database path - WiseAuthority needs access to tasks table
        self.wa_auth_system = WiseAuthorityService(
            time_service=self.time_service, auth_service=self.auth_service, db_path=main_db_path
        )
        await self.wa_auth_system.start()
        self._services_started_count += 1
        _log_service_started(13, "WiseAuthority")

        # Log summary for first-run mode
        if self._is_first_run_mode():
            msg = f"[FIRST-RUN] ✓ {self._services_started_count}/{FIRST_RUN_SERVICES} minimal services started - ready for setup wizard"
            logger.warning(msg)
            print(msg)

    def _recover_stranded_wa_certificates(self) -> None:
        """Import legacy `wa_cert` rows stranded by a long-jump upgrade.

        Boot MUST survive this. The migration already swallows its own
        failures, but an agent that refuses to start is strictly worse than
        one whose owner has to re-run setup — so guard the import itself
        too, and say so loudly if it goes wrong.
        """
        try:
            from ciris_engine.logic.persistence.stores.wa_cert_legacy_migration import migrate_legacy_wa_certificates

            migrate_legacy_wa_certificates(self.essential_config)
        except Exception:
            logger.exception(
                "Legacy WA certificate migration could not run — pre-existing owners may be "
                "unable to log in. Boot continues."
            )

    async def verify_security_services(self) -> bool:
        """Verify security services are operational."""
        # Verify secrets service
        if not self.secrets_service:
            logger.error("Secrets service not initialized")
            return False

        # Verify WA auth system
        if not self.wa_auth_system:
            logger.error("WA authentication system not initialized")
            return False

        # Verify WA service is healthy
        if not await self.wa_auth_system.is_healthy():
            logger.error("WA auth service not healthy")
            return False

        logger.info("[OK] Security services verified")
        return True

    async def initialize_all_services(
        self,
        config: Any,
        app_config: Any,
        agent_id: str,
        startup_channel_id: Optional[str] = None,
        modules_to_load: Optional[List[str]] = None,
    ) -> None:
        """Initialize all remaining core services.

        This is called:
        - During normal startup: After first-run services (completes all 22)
        - During resume_from_first_run: Starts the remaining 12 services after wizard
        """
        # Set phase for logging - RESUME if coming from first-run, otherwise continue FULL-STARTUP
        if self._services_started_count == FIRST_RUN_SERVICES:
            _set_service_phase(f"RESUME ({RESUME_SERVICES} remaining services)")
        else:
            _set_service_phase("CORE-SERVICES")

        from ciris_engine.logic.registries.base import get_global_registry

        self.service_registry = get_global_registry()

        # Register TimeService now that we have a registry
        if self.time_service:
            self.service_registry.register_service(
                service_type=ServiceType.TIME,
                provider=self.time_service,
                priority=Priority.CRITICAL,
                capabilities=["now", "format_timestamp", "parse_timestamp"],
                metadata={"timezone": "UTC"},
            )
            self._dependencies_resolved += 1  # Service registry dependency
            logger.info("TimeService registered in ServiceRegistry")

        # Pre-load module loader to check for MOCK modules BEFORE initializing services
        if modules_to_load:
            logger.info(f"Checking modules to load: {modules_to_load}")
            from ciris_engine.logic.runtime.module_loader import ModuleLoader

            self.module_loader = ModuleLoader()

            # Check modules for MOCK status WITHOUT loading them yet
            for module_name in modules_to_load:
                assert self.module_loader is not None
                module_path = self.module_loader.modules_dir / module_name
                manifest_path = module_path / "manifest.json"
                logger.info(f"Checking for manifest at: {manifest_path}")

                if manifest_path.exists():
                    try:
                        async with aiofiles.open(manifest_path, encoding="utf-8") as f:
                            content = await f.read()
                            manifest_data = json.loads(content)

                        # Parse into typed manifest
                        manifest = ServiceManifest.model_validate(manifest_data)

                        if manifest.module.is_mock:
                            # This is a MOCK module - check what services it provides
                            for service in manifest.services:
                                if service.type == ServiceType.LLM:
                                    logger.info(
                                        f"Detected MOCK LLM module '{module_name}' will be loaded - skipping normal LLM initialization"
                                    )
                                    self._skip_llm_init = True
                                    break
                    except Exception as e:
                        logger.warning(f"Failed to pre-check module {module_name}: {e}")
        else:
            modules_to_load = []

        # Register previously initialized services in the registry
        # Register previously initialized services in the registry as per CLAUDE.md

        # Config service was already registered early in initialize_memory_service
        # to ensure it's available for persistence operations

        # Memory service was initialized in Phase 2, register it now
        if self.memory_service:
            self.service_registry.register_service(
                service_type=ServiceType.MEMORY,
                provider=self.memory_service,
                priority=Priority.HIGH,
                capabilities=[
                    "memorize",
                    "recall",
                    "forget",
                    "graph_operations",
                    "memorize_metric",
                    "memorize_log",
                    "recall_timeseries",
                    "export_identity_context",
                    "search",
                ],
                metadata={"backend": "sqlite", "graph_type": "local"},
            )
            self._dependencies_resolved += 1  # Memory service dependency
            logger.info("Memory service registered in ServiceRegistry")

        # WiseAuthority service was initialized in security phase, register it now
        if self.wa_auth_system:
            self.service_registry.register_service(
                service_type=ServiceType.WISE_AUTHORITY,
                provider=self.wa_auth_system,
                priority=Priority.HIGH,
                capabilities=[
                    "authenticate",
                    "authorize",
                    "validate",
                    "guidance",
                    "send_deferral",
                    "get_pending_deferrals",
                    "resolve_deferral",
                ],
                metadata={"type": "consolidated", "consensus": "single"},
            )
            self._dependencies_resolved += 1  # WiseAuthority service dependency
            logger.info("WiseAuthority service registered in ServiceRegistry")

        # Register AuthenticationService under WISE_AUTHORITY too. Both services
        # legitimately serve the WISE_AUTHORITY type (per the registry-typing
        # design): WiseAuthorityService exposes the deferral/guidance surface,
        # AuthenticationService exposes attestation, key management, and WA-cert
        # lookups. Consumers disambiguate via attribute presence — e.g. the
        # batch_context strict-attestation gate filters on
        # `hasattr(s, "await_attestation_ready")` to find this one. Without this
        # second registration, the gate raises CRITICAL on every thought because
        # WiseAuthorityService alone doesn't carry the attestation methods.
        if self.auth_service:
            self.service_registry.register_service(
                service_type=ServiceType.WISE_AUTHORITY,
                provider=self.auth_service,
                priority=Priority.HIGH,
                capabilities=[
                    "authenticate",
                    "verify_token",
                    "create_wa",
                    "get_wa",
                    "list_was",
                    "update_wa",
                    "await_attestation_ready",
                    "get_cached_attestation",
                    "run_attestation",
                ],
                metadata={"type": "authentication", "consensus": "single"},
            )
            logger.info("AuthenticationService registered in ServiceRegistry under WISE_AUTHORITY")

        # Create BusManager first (without telemetry service)
        assert self.service_registry is not None
        assert self.time_service is not None
        self.bus_manager = BusManager(
            self.service_registry,
            self.time_service,
            None,  # telemetry_service will be set later
            None,  # audit_service will be set later
            resource_monitor=self.resource_monitor_service,
        )
        self._dependencies_resolved += 1  # BusManager dependency

        # Initialize telemetry service using GraphTelemetryService
        # This implements the "Graph Memory as Identity Architecture" patent
        # where telemetry IS memory stored in the agent's identity graph
        from ciris_engine.logic.services.graph.telemetry_service import GraphTelemetryService

        assert self.bus_manager is not None
        assert self.time_service is not None
        try:
            # Create the concrete GraphTelemetryService instance
            telemetry_service_impl = GraphTelemetryService(
                memory_bus=self.bus_manager.memory, time_service=self.time_service  # Now we have the memory bus
            )
            # Attach service registry using protocol pattern
            # Use hasattr (protocol is not @runtime_checkable)
            if self.service_registry and hasattr(telemetry_service_impl, "attach_registry"):
                await telemetry_service_impl.attach_registry(self.service_registry)
            await telemetry_service_impl.start()
            # Assign to protocol-typed field after all setup is complete
            # Note: GraphTelemetryService structurally implements TelemetryService protocol
            self.telemetry_service = telemetry_service_impl  # type: ignore[assignment]
            self._services_started_count += 1
            _log_service_started(9, "TelemetryService")
        except Exception as e:
            self._initialization_errors += 1
            logger.error(f"Failed to initialize GraphTelemetryService: {e}")
            raise

        # Now set the telemetry service in bus manager and LLM bus
        self.bus_manager.telemetry_service = self.telemetry_service
        self.bus_manager.llm.telemetry_service = self.telemetry_service

        # Initialize LLM service(s) based on configuration
        await self._initialize_llm_services(config, modules_to_load)

        # Load any runtime LLM providers that were persisted to config (survives restarts)
        await self._load_persisted_runtime_llm_providers()

        # Secrets service no longer needs LLM service reference

        # Initialize ALL THREE REQUIRED audit services
        await self._initialize_audit_services(config, agent_id)

        # Initialize adaptive filter service
        assert self.memory_service is not None
        assert self.time_service is not None
        assert self.config_service is not None
        self.adaptive_filter_service = AdaptiveFilterService(
            memory_service=self.memory_service,
            time_service=self.time_service,
            llm_service=self.llm_service,
            config_service=self.config_service,  # Pass GraphConfigService
        )
        await self.adaptive_filter_service.start()
        self._services_started_count += 1
        _log_service_started(19, "AdaptiveFilter")

        # GraphConfigService (initialized earlier) handles all configuration including agent config
        # No separate agent configuration service needed - see GraphConfigService documentation

        # Transaction orchestrator not needed - bus-based architecture handles
        # coordination without requiring distributed transactions

        # CoreToolService removed - tools are adapter-only per user request
        # SELF_HELP moved to memory service

        # Initialize task scheduler service
        from ciris_engine.logic.services.lifecycle.scheduler import TaskSchedulerService

        # Get the correct db path from our essential config
        db_path = get_sqlite_db_full_path(self.essential_config)
        self.task_scheduler_service = TaskSchedulerService(db_path=db_path, time_service=self.time_service)
        await self.task_scheduler_service.start()
        self._services_started_count += 1
        _log_service_started(18, "TaskScheduler")

        # Initialize TSDB consolidation service BEFORE maintenance
        # This ensures we consolidate any missed windows before maintenance runs
        from ciris_engine.logic.services.graph.tsdb_consolidation import TSDBConsolidationService

        assert self.bus_manager is not None
        assert self.time_service is not None

        # Get configuration from essential config
        config = self.essential_config
        graph_config = config.graph if hasattr(config, "graph") else None

        # Get the correct db path from our essential config
        db_path = get_sqlite_db_full_path(self.essential_config)
        self.tsdb_consolidation_service = TSDBConsolidationService(
            memory_bus=self.bus_manager.memory,  # Use memory bus, not direct service
            time_service=self.time_service,  # Pass time service
            consolidation_interval_hours=6,  # Fixed for calendar alignment
            raw_retention_hours=graph_config.tsdb_raw_retention_hours if graph_config else 24,
            db_path=db_path,
        )
        await self.tsdb_consolidation_service.start()
        self._services_started_count += 1
        _log_service_started(11, "TSDBConsolidation")

        # Register TSDBConsolidationService in registry
        self.service_registry.register_service(
            service_type=ServiceType.TSDB_CONSOLIDATION,
            provider=self.tsdb_consolidation_service,
            priority=Priority.NORMAL,
            capabilities=["consolidate_data", "get_summaries"],
            metadata={"consolidation_interval": "6h", "type": "tsdb"},
        )
        logger.info("TSDBConsolidationService registered in ServiceRegistry")

        # Initialize maintenance service AFTER consolidation
        archive_dir_config = getattr(config, "data_archive_dir", "data_archive")
        # Resolve relative paths to absolute (critical for Android where CWD is read-only)
        archive_path = Path(archive_dir_config)
        if not archive_path.is_absolute():
            archive_path = get_data_dir() / archive_dir_config
        archive_dir = str(archive_path)
        archive_hours = getattr(config, "archive_older_than_hours", 24)
        assert self.time_service is not None
        assert self.config_service is not None
        assert self.bus_manager is not None
        self.maintenance_service = DatabaseMaintenanceService(
            time_service=self.time_service,
            archive_dir_path=archive_dir,
            archive_older_than_hours=archive_hours,
            config_service=self.config_service,
            bus_manager=self.bus_manager,
        )
        await self.maintenance_service.start()
        self._services_started_count += 1
        _log_service_started(16, "DatabaseMaintenance")

        # Initialize self observation service
        from ciris_engine.logic.services.governance.self_observation import SelfObservationService

        assert self.time_service is not None
        assert self.bus_manager is not None
        self.self_observation_service = SelfObservationService(
            time_service=self.time_service,
            memory_bus=self.bus_manager.memory,
            variance_threshold=0.20,  # 20% max variance from baseline
            observation_interval_hours=6,
        )
        # Attach service registry using protocol pattern
        # Use hasattr (protocol is not @runtime_checkable)
        if self.service_registry and hasattr(self.self_observation_service, "attach_registry"):
            await self.self_observation_service.attach_registry(self.service_registry)
        # Start the service for API mode (in other modes DREAM processor starts it)
        await self.self_observation_service.start()
        self._services_started_count += 1
        _log_service_started(21, "SelfObservation")

        # Initialize visibility service
        from ciris_engine.logic.services.governance.visibility import VisibilityService

        assert self.bus_manager is not None
        assert self.time_service is not None
        self.visibility_service = VisibilityService(
            bus_manager=self.bus_manager,
            time_service=self.time_service,
            db_path=get_sqlite_db_full_path(self.essential_config),
        )
        await self.visibility_service.start()
        self._services_started_count += 1
        _log_service_started(20, "VisibilityService")

        # Initialize consent service (Governance Service #5)
        from ciris_engine.logic.services.governance.consent import ConsentService

        assert self.time_service is not None
        assert self.bus_manager is not None
        self.consent_service = ConsentService(
            time_service=self.time_service,
            memory_bus=self.bus_manager.memory,  # Use memory bus for impact reporting and audit trail
            db_path=get_sqlite_db_full_path(self.essential_config),
        )
        await self.consent_service.start()
        self._services_started_count += 1
        _log_service_started(12, "ConsentService")

        # Initialize runtime control service
        from ciris_engine.logic.services.runtime.control_service import RuntimeControlService

        assert self.config_service is not None
        assert self.time_service is not None
        self.runtime_control_service = RuntimeControlService(
            runtime=None,  # Will be set by runtime after initialization
            adapter_manager=None,  # Will be created on demand
            config_manager=self.config_service,
            time_service=self.time_service,
        )
        await self.runtime_control_service.start()
        self._services_started_count += 1
        _log_service_started(17, "RuntimeControl")

        # Auto-load eligible skill adapters (if enabled)
        await self._initialize_skill_adapters()

        # Mark end of startup process
        import time

        self._startup_end_time = time.time()

    def _get_llm_service_config_value(self, config: Any, attr_name: str, default: Any) -> Any:
        """Get LLM service config value safely with fallback to default.

        Args:
            config: Configuration object
            attr_name: Attribute name to get from config.services
            default: Default value if not found

        Returns:
            Config value or default
        """
        if config and hasattr(config, "services") and config.services:
            return getattr(config.services, attr_name, default)
        return default

    @staticmethod
    def _resolve_llm_timeout(base_url: Optional[str], provider_id: Optional[str] = None) -> int:
        """The HTTP timeout for one LLM request to this provider.

        Timeouts come from the LLM budget profile,
        ciris_engine/logic/config/llm_budget.py (#1186): the provider class
        (local vs remote) picks the profile, and CIRIS_LLM_TIMEOUT overrides
        it. ``services.llm_timeout`` in essential.yaml is no longer read, so a
        desktop (which loads essential.yaml) and a phone (which does not) get
        the same timeout for the same provider.
        """
        return int(resolve_budget(provider_id, base_url).llm_http_timeout_s)

    async def _initialize_llm_services(self, config: Any, modules_to_load: Optional[List[str]] = None) -> None:
        """Initialize LLM service(s) based on configuration.

        CRITICAL: Only mock OR real LLM services are active, never both.
        This prevents attack vectors where mock responses could be confused with real ones.
        """
        # Skip if mock LLM module is being loaded
        if self._skip_llm_init:
            logger.info(" MOCK LLM module detected - skipping real LLM service initialization")
            return

        # Check if CIRIS services are disabled by user preference
        ciris_services_disabled = os.environ.get("CIRIS_SERVICES_DISABLED", "").lower() in ("true", "1", "yes")
        if ciris_services_disabled:
            logger.info(" CIRIS services disabled by user preference (CIRIS_SERVICES_DISABLED=true)")
            # Continue to load persisted runtime providers (local servers, BYOK keys)
            # but skip the hardcoded CIRIS proxy providers

        # Validate config
        if not hasattr(config, "services"):
            raise ValueError("Configuration missing LLM service settings")

        # Detect provider and get appropriate API key
        from ciris_engine.logic.services.runtime.llm_service import (
            LLMProvider,
            OpenAIConfig,
            _detect_provider_from_env,
            _get_api_key_for_provider,
        )
        from ciris_engine.logic.services.runtime.llm_service.service import _is_placeholder_api_key

        provider = _detect_provider_from_env()
        api_key = _get_api_key_for_provider(provider)

        # Fall back to CIRIS_OPENAI_API_KEY / OPENAI_API_KEY for backward compatibility
        if not api_key:
            api_key = os.environ.get("CIRIS_OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY") or ""

        if not api_key:
            # No primary API key - persisted runtime providers will be loaded after this returns
            logger.info(f"No API key found for {provider.value} - will use persisted runtime providers if available")
            return

        # Initialize real LLM service
        logger.info(f"Initializing LLM service with provider={provider.value}")

        # Get config values using helper to reduce complexity
        # Base URL only applies to OpenAI-compatible providers
        base_url = None
        base_urls = None  # Multi-endpoint support for CIRIS proxy
        is_ciris_proxy_url_checked = False
        if provider in (LLMProvider.OPENAI, LLMProvider.OPENAI_COMPATIBLE):
            base_url = os.environ.get("OPENAI_API_BASE") or self._get_llm_service_config_value(
                config, "llm_endpoint", None
            )
            # Check if this is a CIRIS proxy URL - if so, use multi-endpoint failover
            if base_url:
                from ciris_engine.config.ciris_services import get_all_proxy_endpoints, is_ciris_proxy_url

                is_ciris_proxy_url_checked = is_ciris_proxy_url(base_url)
                if is_ciris_proxy_url_checked:
                    # Skip CIRIS proxy if user has disabled CIRIS services
                    if ciris_services_disabled:
                        logger.info(" Skipping CIRIS proxy (CIRIS_SERVICES_DISABLED=true)")
                        # Load any persisted runtime providers (user's BYOK providers)
                        await self._load_persisted_runtime_llm_providers()
                        # Get the first LLM service from registry to satisfy validation
                        if self.service_registry:
                            llm_providers = self.service_registry._services.get(ServiceType.LLM, [])
                            if llm_providers:
                                self.llm_service = llm_providers[0].instance
                                logger.info(f"[OK] Using persisted LLM provider: {llm_providers[0].name}")
                            else:
                                logger.warning("[WARN] No LLM providers available after disabling CIRIS services")
                        return

                    # Get all CIRIS proxy endpoints for multi-region failover
                    endpoints = get_all_proxy_endpoints()
                    if len(endpoints) > 1:
                        # Build list of URLs in priority order, preserving /v1 suffix if present
                        suffix = "/v1" if base_url.rstrip("/").endswith("/v1") else ""
                        base_urls = [ep.url.rstrip("/") + suffix for ep in endpoints]
                        logger.info(
                            f"[MULTI_ENDPOINT] CIRIS proxy detected, using {len(base_urls)} endpoints: "
                            f"{[ep.region for ep in endpoints]}"
                        )

        # A CIRIS-PROXY URL MEANS THE CREDENTIAL IS THE OAUTH ID TOKEN.
        #
        # The proxy has no provider enum of its own — it rides OPENAI_COMPATIBLE
        # — so the key came from OPENAI_API_KEY, which is where the setup wizard
        # stashed the ID token once, at setup. That value is an hour-lived JWT.
        # Every restart therefore rebuilt the primary service around the
        # setup-time token no matter how many times the refresh handshake had
        # replaced it since, and the first interaction after a restart 401'd
        # until another whole handshake completed. The handshake variables are
        # the live copy; read them here.
        if base_url and is_ciris_proxy_url_checked and not ciris_services_disabled:
            from ciris_engine.logic.utils.token_handshake import read_proxy_token

            proxy_token, proxy_var = read_proxy_token(current=api_key)
            if proxy_token and proxy_token != api_key:
                logger.info(
                    "[TOKEN_HANDSHAKE] proxy startup credential taken from %s, not the setup-time key",
                    proxy_var,
                )
                api_key = proxy_token

        # Needed by BOTH the model default below and the service name further
        # down; computed once, here, so the two cannot disagree about it.
        effective_url = base_url or ""
        declared_provider_id, _ = primary_provider_declaration()
        is_local_provider = _is_loopback_or_lan(effective_url, declared_provider_id)

        # Get model name — a default model is only meaningful WITHIN a vendor.
        #
        # CIRISAgent#1062. OPENAI_COMPATIBLE used to default to "gpt-4o-mini",
        # and the trailing .get(provider, "gpt-4o-mini") did the same for any
        # provider not in this map. But OPENAI_COMPATIBLE means "speaks the
        # OpenAI protocol", NOT "serves OpenAI models" — it is how we reach
        # Groq, Together, DeepInfra, OpenRouter and every local server. So a
        # user who picked Groq and left the model blank booted a Groq endpoint
        # asking for gpt-4o-mini. Observed live on 2.9.24:
        #
        #     'ciris_primary' started with model: gpt-4o-mini   <- base_url = api.groq.com
        #     EthicalPDMAEvaluator initialized with model: gpt-4o-mini
        #
        # Every request then failed at the provider, surfaced as an
        # InstructorRetryException XML dump that never named the cause. His API
        # key was fine. He was told to check his key.
        #
        # A model name from the wrong vendor is not a degraded default — it is a
        # guaranteed failure wearing the costume of a working config. Where we
        # do not know the vendor's catalogue we must not invent an entry in it.
        default_models = {
            LLMProvider.OPENAI: "gpt-4o-mini",
            LLMProvider.ANTHROPIC: "claude-sonnet-4-20250514",
            LLMProvider.GOOGLE: "gemini-2.0-flash",
        }
        model_name = (
            os.environ.get("CIRIS_LLM_MODEL_NAME")  # CIRIS_ prefix preferred
            or os.environ.get("OPENAI_MODEL_NAME")  # OpenAI SDK convention
            or os.environ.get("OPENAI_MODEL")
            or os.environ.get("LLM_MODEL")
            or self._get_llm_service_config_value(config, "llm_model", default_models.get(provider, ""))
        )

        # LOUDLY LOG AND REFUSE, rather than boot a provider that cannot work.
        #
        # Same doctrine 2.9.24 applied to adapters: a thing that cannot function
        # is named and skipped, never started in a broken state and left for the
        # user to discover one failed request at a time. The API adapter stays
        # up regardless, so the console and the LLM settings screen are both
        # reachable to fix this.
        # NO MODEL RESOLVED — SAY SO LOUDLY, BUT STILL BOOT.
        #
        # An earlier attempt REFUSED the provider here. That broke local
        # inference twice, because locality is not knowable at this point: it is
        # derived from base_url, which is empty whenever the operator configured
        # the endpoint by any route other than OPENAI_API_BASE. Gating a refusal
        # on a signal that is routinely absent fails closed on exactly the users
        # who did nothing wrong.
        #
        # The fault this exists for — silently substituting ANOTHER VENDOR'S
        # model — is already fixed above: no cross-vendor default is invented.
        # What remains is to be loud, and to let the call fail legibly (#1066)
        # rather than refusing to start and taking the console down with it.
        # 2.9.24's rule holds: always keep one door open.
        if not model_name:
            logger.warning(
                "NO MODEL CONFIGURED for provider '%s' at %s. Starting anyway, but requests will "
                "fail at the provider until a model is chosen — set one in Settings -> LLM, or "
                "CIRIS_LLM_MODEL_NAME. (A local server may ignore this and serve what it has loaded.)",
                provider.value,
                effective_url or "<default url>",
            )

        # Timeouts come from the LLM budget profile, ciris_engine/logic/config/llm_budget.py (#1186).
        llm_timeout = self._resolve_llm_timeout(base_url, declared_provider_id)

        # Provider-specific instructor mode defaults
        default_instructor_modes = {
            LLMProvider.OPENAI: "JSON",
            LLMProvider.OPENAI_COMPATIBLE: "JSON",
            LLMProvider.ANTHROPIC: "ANTHROPIC_TOOLS",
            LLMProvider.GOOGLE: "GENAI_TOOLS",
        }
        instructor_mode = os.environ.get("INSTRUCTOR_MODE") or default_instructor_modes.get(provider, "JSON")

        llm_config = OpenAIConfig(
            base_url=base_url,
            base_urls=base_urls,  # Multi-endpoint for CIRIS proxy failover
            model_name=model_name,
            api_key=api_key,
            instructor_mode=instructor_mode,
            timeout_seconds=llm_timeout,
            # Remediation attempts for fixable 400s only; transport errors are never retried here (#1186).
            max_retries=self._get_llm_service_config_value(config, "llm_max_retries", 2),
            provider=provider,
        )

        # NAME THE SERVICE AFTER WHAT IT IS (CIRISAgent#1063).
        #
        # This used to decide the name on a TOPOLOGY axis — is this endpoint on
        # my LAN? — and then label the answer with a BILLING one:
        #
        #     service_name = "local_primary" if is_local_provider else "ciris_primary"
        #
        # Groq is not on anyone's LAN, so Groq was called `ciris_primary`. So
        # were OpenAI, Anthropic, Together, DeepInfra and OpenRouter. The name
        # then reached the UI ("CIRIS Primary configured" over a Groq config),
        # the error text ("LLM service 'ciris_primary' temporarily unavailable"
        # for a Groq failure), and the delete path in llm_providers.py, which
        # branches on `"ciris" in name.lower()` and cleared the wrong env vars.
        #
        # It cost a user a day and it misled the maintainer triaging it: the UI
        # said CIRIS, so he was told he had selected CIRIS services. He had
        # selected Groq.
        #
        # `is_ciris_proxy_url` is the SAME predicate the rest of the system uses
        # to decide whether it is talking to the proxy, so the name cannot drift
        # from the truth.
        from ciris_engine.config.ciris_services import is_ciris_proxy_url

        if is_ciris_proxy_url(effective_url):
            service_name = "ciris_primary"
        elif is_local_provider:
            service_name = "local_primary"
        else:
            # e.g. groq_primary, openai_primary, together_primary.
            service_name = f"{provider.value}_primary"

        # Optional: register the same OpenAI-compatible endpoint N times so the
        # LLM bus can load-balance across independently-gated replicas. Each
        # replica gets its own in-flight semaphore and circuit breaker — useful
        # for tuning: halve CIRIS_LLM_MAX_CONCURRENT and double CIRIS_LLM_REPLICAS
        # to test bus distribution under the same aggregate load.
        try:
            replica_count = max(1, int(os.environ.get("CIRIS_LLM_REPLICAS", "1")))
        except (TypeError, ValueError):
            replica_count = 1

        # A PLACEHOLDER KEY IS "NO USABLE KEY" — NOT A FATAL ERROR.
        #
        # 2.9.16 added `_is_placeholder_api_key` so the agent would stop dialling
        # a key it can see is fake (`sk-test` and friends can only return 401).
        # That part was right. Raising from `OpenAICompatibleClient.__init__` was
        # not: nothing on this path catches it, so it surfaced as
        #
        #     ✗ Core Services failed: The openai API key is a placeholder ...
        #     RuntimeError: Initialization sequence failed
        #
        # and the whole agent refused to boot. Strictly worse than the bug it
        # replaced — before, the agent ran and only the LLM call failed.
        #
        # The correct shape is twelve lines up: a missing key logs and RETURNS,
        # leaving the agent healthy-but-degraded and letting persisted runtime
        # providers load. `no_llm_provider` is a supported state with its own
        # health warning and UI affordance. A placeholder is functionally a
        # missing key, so it takes the same branch.
        if _is_placeholder_api_key(api_key, base_url):
            logger.warning(
                "⚠️  %s API key is a placeholder, not a credential (length %d) — NOT registering "
                "this provider; it could only return 401. The agent will start without an LLM "
                "(health reports `no_llm_provider`). Set a real key, or point base_url at a local "
                "runtime that does not need one.",
                provider.value,
                len(api_key.strip()),
            )
            return

        # Create and start primary service
        openai_service = OpenAICompatibleClient(
            config=llm_config,
            telemetry_service=self.telemetry_service,
            time_service=self.time_service,
            service_name=service_name,
        )
        await openai_service.start()

        # Register primary
        if self.service_registry:
            self.service_registry.register_service(
                service_type=ServiceType.LLM,
                provider=openai_service,
                priority=Priority.HIGH,
                capabilities=[LLMCapabilities.CALL_LLM_STRUCTURED],
                metadata={"provider": provider.value, "model": llm_config.model_name, "is_local": is_local_provider},
            )

        # Register additional replicas (same config, distinct service_name)
        self._llm_replica_services: List[Any] = []
        for i in range(2, replica_count + 1):
            replica_name = f"{service_name}_{i}"
            replica_service = OpenAICompatibleClient(
                config=llm_config,
                telemetry_service=self.telemetry_service,
                time_service=self.time_service,
                service_name=replica_name,
            )
            await replica_service.start()
            if self.service_registry:
                self.service_registry.register_service(
                    service_type=ServiceType.LLM,
                    provider=replica_service,
                    priority=Priority.HIGH,
                    capabilities=[LLMCapabilities.CALL_LLM_STRUCTURED],
                    metadata={
                        "provider": provider.value,
                        "model": llm_config.model_name,
                        "is_local": is_local_provider,
                        "replica_of": service_name,
                    },
                )
            self._llm_replica_services.append(replica_service)
            logger.info(f"[LLM-REPLICA] Registered {replica_name} (replica #{i} of {service_name})")

        if replica_count > 1:
            logger.info(
                f"[LLM-REPLICA] {replica_count} replicas registered at HIGH priority — "
                f"bus will load-balance across them (each with own semaphore/circuit-breaker)"
            )

        # Store reference
        self.llm_service = openai_service
        self._services_started_count += 1
        _log_service_started(14, "LLMService")

        # Register token refresh signal handler for ciris.ai authentication
        # This connects the LLM service to ResourceMonitor's signal bus
        if self.resource_monitor_service and hasattr(self.resource_monitor_service, "signal_bus"):
            self.resource_monitor_service.signal_bus.register("token_refreshed", openai_service.handle_token_refreshed)
            logger.info("Registered LLM service token refresh handler with ResourceMonitor")

        # Auto-register CIRIS proxy fallback if primary is a local/non-CIRIS URL
        # This ensures cloud fallback is always available when using local inference
        from ciris_engine.config.ciris_services import get_proxy_url, is_ciris_proxy_url

        primary_is_local = base_url and not is_ciris_proxy_url(base_url)
        if primary_is_local and not ciris_services_disabled:
            from ciris_engine.logic.utils.token_handshake import read_proxy_token

            id_token, _tok_var = read_proxy_token()
            if id_token:
                logger.info(" Primary LLM is local - registering CIRIS proxy as fallback")
                await self._initialize_ciris_proxy_fallback(config, id_token)

        # Optional: Initialize secondary LLM service
        # Supports both API key auth and CIRIS proxy with JWT auth (Google ID token)
        second_api_key = os.environ.get("CIRIS_OPENAI_API_KEY_2", "")
        second_base_url = os.environ.get("CIRIS_OPENAI_API_BASE_2", "")
        from ciris_engine.logic.utils.token_handshake import read_proxy_token

        google_id_token, _tok_var = read_proxy_token()

        # Check if secondary LLM is CIRIS proxy (requires JWT auth, not API key)
        is_ciris_proxy_secondary = "ciris.ai" in second_base_url

        if is_ciris_proxy_secondary and google_id_token:
            # Skip secondary CIRIS proxy if user has disabled CIRIS services
            if ciris_services_disabled:
                logger.info(" Skipping secondary CIRIS proxy (CIRIS_SERVICES_DISABLED=true)")
            else:
                # CIRIS proxy with JWT auth - always use fresh billing token
                # (CIRIS_OPENAI_API_KEY_2 may contain a stale JWT from initial setup)
                logger.info("Secondary LLM using CIRIS proxy with JWT auth")
                await self._initialize_secondary_llm(config, google_id_token)
        elif second_api_key:
            # Standard API key auth (non-proxy)
            await self._initialize_secondary_llm(config, second_api_key)

    async def _initialize_secondary_llm(self, config: Any, api_key: str) -> None:
        """Initialize optional secondary LLM service."""
        logger.info("Initializing secondary LLM service")

        from ciris_engine.logic.services.runtime.llm_service import OpenAIConfig

        # Get configuration from environment using helper
        base_url = os.environ.get(
            "CIRIS_OPENAI_API_BASE_2",
            self._get_llm_service_config_value(config, "llm_endpoint", "http://localhost:11434/v1"),
        )
        model_name = os.environ.get(
            "CIRIS_OPENAI_MODEL_NAME_2",
            self._get_llm_service_config_value(config, "llm_model", "llama3.2"),
        )

        # Timeouts come from the LLM budget profile, ciris_engine/logic/config/llm_budget.py (#1186).
        llm_timeout = self._resolve_llm_timeout(base_url)

        # Create config
        llm_config = OpenAIConfig(
            base_url=base_url,
            model_name=model_name,
            api_key=api_key,
            instructor_mode=os.environ.get("INSTRUCTOR_MODE", "JSON"),
            timeout_seconds=llm_timeout,
            # Remediation attempts for fixable 400s only; transport errors are never retried here (#1186).
            max_retries=self._get_llm_service_config_value(config, "llm_max_retries", 2),
        )

        # Same rule as the primary: a placeholder is "no usable key", and this
        # call site has no try/except either, so raising here would take the
        # whole boot down over an OPTIONAL fallback provider.
        from ciris_engine.logic.services.runtime.llm_service.service import _is_placeholder_api_key

        if _is_placeholder_api_key(api_key, base_url):
            logger.warning(
                "⚠️  secondary LLM API key is a placeholder (length %d) — skipping the secondary "
                "provider; the primary is unaffected.",
                len(api_key.strip()),
            )
            return

        # Create and start service
        service = OpenAICompatibleClient(
            config=llm_config,
            telemetry_service=self.telemetry_service,
            time_service=self.time_service,
            service_name="ciris_secondary",
        )
        await service.start()

        # Register with lower priority
        if self.service_registry:
            self.service_registry.register_service(
                service_type=ServiceType.LLM,
                provider=service,
                priority=Priority.NORMAL,
                capabilities=[LLMCapabilities.CALL_LLM_STRUCTURED],
                metadata={"provider": "openai_secondary", "model": model_name, "base_url": base_url},
            )

        # Only register token refresh handler for CIRIS proxy secondaries
        # Non-proxy secondaries use CIRIS_OPENAI_API_KEY_2 which isn't refreshed by Android
        is_ciris_proxy = any(domain in base_url for domain in ("ciris.ai", "ciris-services"))
        if is_ciris_proxy and self.resource_monitor_service and hasattr(self.resource_monitor_service, "signal_bus"):
            self.resource_monitor_service.signal_bus.register("token_refreshed", service.handle_token_refreshed)
            logger.info("Registered secondary LLM service token refresh handler (CIRIS proxy)")

        logger.info(f"Secondary LLM service initialized: {model_name}")

    async def _initialize_ciris_proxy_fallback(self, config: Any, id_token: str) -> None:
        """Initialize CIRIS proxy as fallback when primary is local/non-CIRIS.

        This ensures users with local inference still have cloud fallback available.
        The CIRIS proxy uses JWT auth (Google/Apple ID token) not API key.
        """
        from ciris_engine.config.ciris_services import get_all_proxy_endpoints
        from ciris_engine.logic.services.runtime.llm_service import OpenAIConfig

        logger.info("Initializing CIRIS proxy fallback for local primary")

        # Get all CIRIS proxy endpoints for multi-region failover
        endpoints = get_all_proxy_endpoints()
        if not endpoints:
            logger.warning("No CIRIS proxy endpoints available for fallback")
            return

        # Build URLs with /v1 suffix
        base_urls = [ep.url.rstrip("/") + "/v1" for ep in endpoints]
        base_url = base_urls[0]

        # Use CIRIS-recommended model for fallback
        model_name = os.environ.get("CIRIS_PROXY_MODEL", "claude-sonnet-4-20250514")

        # Timeouts come from the LLM budget profile, ciris_engine/logic/config/llm_budget.py (#1186).
        llm_timeout = self._resolve_llm_timeout(base_url)

        llm_config = OpenAIConfig(
            base_url=base_url,
            base_urls=base_urls if len(base_urls) > 1 else None,
            model_name=model_name,
            api_key=id_token,  # JWT token for CIRIS proxy auth
            instructor_mode="JSON",
            timeout_seconds=llm_timeout,
            max_retries=self._get_llm_service_config_value(config, "llm_max_retries", 2),
        )

        service = OpenAICompatibleClient(
            config=llm_config,
            telemetry_service=self.telemetry_service,
            time_service=self.time_service,
            service_name="ciris_proxy_fallback",
        )
        await service.start()

        # Register with NORMAL priority (below CRITICAL local, above LOW)
        if self.service_registry:
            self.service_registry.register_service(
                service_type=ServiceType.LLM,
                provider=service,
                priority=Priority.NORMAL,
                capabilities=[LLMCapabilities.CALL_LLM_STRUCTURED],
                metadata={"provider": "ciris_proxy", "model": model_name, "base_url": base_url},
            )

        # Register token refresh handler
        if self.resource_monitor_service and hasattr(self.resource_monitor_service, "signal_bus"):
            self.resource_monitor_service.signal_bus.register("token_refreshed", service.handle_token_refreshed)

        logger.info(f"[OK] CIRIS proxy fallback initialized: {model_name} ({len(base_urls)} endpoints)")

    async def _load_persisted_runtime_llm_providers(self) -> None:
        """Load runtime LLM providers that were persisted to config.

        This enables providers added via the API to survive restarts.
        """
        from ciris_engine.logic.persistence.llm_providers import list_providers
        from ciris_engine.logic.services.runtime.llm_service.service import runtime_provider_config
        from ciris_engine.schemas.services.capabilities import LLMCapabilities

        if not self.config_service or not self.service_registry:
            logger.debug("Cannot load persisted LLM providers - services not available")
            return

        try:
            providers = await list_providers(self.config_service)
            logger.info(f"[LLM_LOAD] list_providers returned {len(providers) if providers else 0} providers")
            if not providers:
                logger.info("No persisted runtime LLM providers to load")
                return

            logger.info(f"Loading {len(providers)} persisted runtime LLM provider(s): {list(providers.keys())}")

            # Map priority strings to internal Priority enum
            priority_map = {
                "critical": Priority.CRITICAL,
                "high": Priority.HIGH,
                "normal": Priority.NORMAL,
                "low": Priority.LOW,
                "fallback": Priority.FALLBACK,
            }

            for provider_name, config in providers.items():
                try:
                    # Check if already registered (avoid duplicates)
                    existing = self.service_registry.get_provider_by_name(provider_name, ServiceType.LLM)
                    if existing:
                        logger.debug(f"Provider '{provider_name}' already registered, skipping")
                        continue

                    # Timeout from the LLM budget profile for this provider (#1186).
                    llm_config = runtime_provider_config(
                        config.provider_id, config.base_url, config.model, config.api_key
                    )

                    # Create and start service
                    service = OpenAICompatibleClient(
                        config=llm_config,
                        telemetry_service=self.telemetry_service,
                        time_service=self.time_service,
                        service_name=provider_name,
                    )
                    await service.start()

                    # Register with appropriate priority
                    priority = priority_map.get(config.priority.lower(), Priority.FALLBACK)
                    self.service_registry.register_service(
                        service_type=ServiceType.LLM,
                        provider=service,
                        priority=priority,
                        capabilities=[LLMCapabilities.CALL_LLM_STRUCTURED],
                        metadata={
                            "provider": config.provider_id,
                            "model": config.model,
                            "base_url": config.base_url,
                            "added_at_runtime": True,
                            "restored_from_persistence": True,
                        },
                    )

                    logger.info(f"Restored runtime LLM provider '{provider_name}' with priority {config.priority}")

                except Exception as e:
                    logger.warning(f"Failed to restore LLM provider '{provider_name}': {e}")

        except Exception as e:
            logger.warning(f"Failed to load persisted runtime LLM providers: {e}")

    async def _process_pending_users_from_setup(self) -> None:
        """Process pending user creation from setup wizard.

        Checks for ~/.ciris/.ciris_pending_users.json file and creates users if found.
        This file is created by the setup wizard during first-run configuration.
        """
        import json
        from pathlib import Path

        # Check for pending users file in ~/.ciris directory
        pending_users_file = Path.home() / ".ciris" / ".ciris_pending_users.json"

        if not pending_users_file.exists():
            logger.debug("No pending users file found - skipping user creation")
            return

        try:
            logger.info("=" * 80)
            logger.info("Processing pending users from setup wizard")
            logger.info("=" * 80)

            # Read pending users data asynchronously
            async with aiofiles.open(pending_users_file, "r") as f:
                content = await f.read()
                users_data = json.loads(content)

            logger.info(f"Loaded pending users file created at: {users_data.get('created_at')}")

            # Process new user if specified
            if "new_user" in users_data:
                from ciris_engine.schemas.services.authority_core import WARole

                new_user = users_data["new_user"]
                username = new_user["username"]
                password = new_user["password"]
                role_str = new_user.get("role", "OBSERVER")

                # Map role string to WARole enum
                role_map = {
                    "ADMIN": WARole.AUTHORITY,
                    "AUTHORITY": WARole.AUTHORITY,
                    "OBSERVER": WARole.OBSERVER,
                    "USER": WARole.OBSERVER,
                }
                wa_role = role_map.get(role_str.upper(), WARole.OBSERVER)

                logger.info(f"Creating new user: {username} with role: {wa_role}")

                # Create WA certificate for the user
                wa_cert = await self.auth_service.create_wa(
                    name=username,
                    email=f"{username}@local",  # Placeholder email for local users
                    # AUTHORITY needs jurisdiction in the SCOPE grammar, not just the
                    # role: routes/wa.py checks resolve_deferral:<pattern> before letting
                    # a domain-tagged deferral be resolved (F1). Minting without it made
                    # every setup-created authority a 403 on exactly those deferrals.
                    # `:any` is the status quo ante — role-only breadth — written down so
                    # it can be NARROWED to e.g. resolve_deferral:medical_* deliberately.
                    scopes=(
                        ["read:any", "write:any", "resolve_deferral:any"]
                        if wa_role == WARole.AUTHORITY
                        else ["read:any"]
                    ),
                    role=wa_role,
                )

                # Hash password and update the WA
                password_hash = self.auth_service.hash_password(password)
                await self.auth_service.update_wa(wa_id=wa_cert.wa_id, password_hash=password_hash)

                logger.info(f"[OK] Successfully created user: {username} (WA: {wa_cert.wa_id})")

            # Process system admin password update if specified
            if "system_admin" in users_data:
                admin_data = users_data["system_admin"]
                admin_username = admin_data["username"]
                new_password = admin_data["password"]

                logger.info(f"Updating system admin password for: {admin_username}")

                # Find the admin WA by username
                all_was = await self.auth_service.list_was(active_only=True)
                admin_wa = next((wa for wa in all_was if wa.name == admin_username), None)

                if admin_wa:
                    # Hash new password and update
                    password_hash = self.auth_service.hash_password(new_password)
                    await self.auth_service.update_wa(wa_id=admin_wa.wa_id, password_hash=password_hash)
                    logger.info(f"[OK] Successfully updated admin password for {admin_username}")
                else:
                    logger.warning(f"[WARN] Admin user '{admin_username}' not found")

            # Delete the pending users file after processing
            pending_users_file.unlink()
            logger.info("Deleted pending users file after successful processing")
            logger.info("=" * 80)

        except Exception as e:
            logger.error(f"Error processing pending users file: {e}", exc_info=True)
            # Don't delete the file if processing failed - allow retry on next startup
            raise

    async def _initialize_audit_services(self, config: Any, agent_id: str) -> None:
        """Initialize the consolidated audit service with three storage backends.

        The single GraphAuditService writes to three places:
        1. SQLite hash chain database (cryptographic integrity)
        2. Graph memory via MemoryBus (primary storage, searchable)
        3. File export (optional, for compliance)
        """
        # Initialize the consolidated GraphAuditService
        logger.info("Initializing consolidated GraphAuditService...")

        # The GraphAuditService combines all audit functionality:
        # - Graph-based storage (primary)
        # - Optional file export for compliance
        # - Cryptographic hash chain for integrity
        # - Time-series capabilities built-in
        # Use config accessor for audit configuration
        assert self.config_accessor is not None
        audit_db_path = await self.config_accessor.get_path("database.audit_db", Path("data/ciris_audit.db"))
        retention_days = await self.config_accessor.get_int("security.audit_retention_days", 90)

        from ciris_engine.logic.services.graph.audit_service import GraphAuditService

        # Use platform-aware path for audit log export (critical for Android)
        audit_export_path = get_data_dir() / "audit_logs.jsonl"
        graph_audit = GraphAuditService(
            memory_bus=None,  # Will be set via service registry
            time_service=self.time_service,
            export_path=str(audit_export_path),  # Platform-aware audit log path
            export_format="jsonl",
            enable_hash_chain=True,
            db_path=str(audit_db_path),
            retention_days=retention_days,
        )
        # Runtime will be set later when available
        # Attach service registry using protocol pattern
        # Use hasattr (protocol is not @runtime_checkable)
        if self.service_registry and hasattr(graph_audit, "attach_registry"):
            await graph_audit.attach_registry(self.service_registry)
        await graph_audit.start()
        self._services_started_count += 1
        self.audit_service = graph_audit
        _log_service_started(8, "AuditService")

        # Update BusManager with the initialized audit service
        if self.bus_manager is not None:
            self.bus_manager.audit_service = self.audit_service
            logger.info(f"Updated BusManager with audit_service: {self.audit_service}")

        # Inject graph audit service into incident capture handlers
        from ciris_engine.logic.utils.incident_capture_handler import inject_graph_audit_service_to_handlers

        updated_handlers = inject_graph_audit_service_to_handlers(self.audit_service)
        logger.info(f"Injected graph audit service into {updated_handlers} incident capture handler(s)")

        # Refusals the constitutional halt makes outside the act gate are audited here.
        from ciris_engine.logic.utils.halt_latch import bind_refusal_audit

        bind_refusal_audit(self.audit_service)

        # Audit sink manager removed - GraphAuditService handles its own lifecycle
        logger.info("GraphAuditService handles its own retention and cleanup")

        # Initialize incident management service (processes audit events as incidents)
        from ciris_engine.logic.services.graph.incident_service import IncidentManagementService

        assert self.bus_manager is not None
        self.incident_management_service = IncidentManagementService(
            memory_bus=self.bus_manager.memory, time_service=self.time_service
        )
        await self.incident_management_service.start()
        self._services_started_count += 1
        _log_service_started(10, "IncidentManagement")

    def _is_auto_discovery_enabled(self) -> bool:
        """Check if auto-discovery is enabled by template and config."""
        from ciris_engine.logic.persistence.models.identity import retrieve_agent_identity

        identity = retrieve_agent_identity()

        if not identity or not hasattr(identity.core_profile, "auto_load_adapters"):
            logger.info("[SKILL-ADAPTERS] Auto-discovery not enabled by current agent template")
            return False
        if not identity.core_profile.auto_load_adapters:
            logger.info("[SKILL-ADAPTERS] Auto-discovery not enabled by current agent template")
            return False
        if not self.essential_config.adapters.auto_discovery:
            logger.info("[SKILL-ADAPTERS] Auto-discovery disabled by config")
            return False
        return True

    async def _start_and_register_adapter(self, adapter_name: str, service: Any) -> None:
        """Start an adapter service and register it with the service registry."""
        if hasattr(service, "start"):
            start_result = service.start()
            if hasattr(start_result, "__await__"):
                await start_result

        if self.service_registry is None:
            return

        # First check if the adapter declares explicit service registrations
        if hasattr(service, "get_services_to_register"):
            registrations = service.get_services_to_register()
            for reg in registrations:
                self.service_registry.register_service(
                    service_type=reg.service_type,
                    provider=reg.provider,
                    priority=reg.priority if hasattr(reg, "priority") else Priority.NORMAL,
                    capabilities=reg.capabilities if hasattr(reg, "capabilities") else [],
                    metadata={"adapter": adapter_name, "auto_loaded": True},
                )
                logger.info(f"[SKILL-ADAPTERS] Registered {reg.service_type.value} from adapter: {adapter_name}")
            return

        if hasattr(service, "get_all_tool_info"):
            self.service_registry.register_service(
                service_type=ServiceType.TOOL,
                provider=service,
                priority=Priority.NORMAL,
                capabilities=["execute_tool", "get_all_tool_info"],
                metadata={"adapter": adapter_name, "auto_loaded": True},
            )
            logger.info(f"[SKILL-ADAPTERS] Registered tool adapter: {adapter_name}")
        elif hasattr(service, "send_deferral") or hasattr(service, "handle_deferral"):
            self.service_registry.register_service(
                service_type=ServiceType.WISE_AUTHORITY,
                provider=service,
                priority=Priority.NORMAL,
                capabilities=["send_deferral", "accord_metrics"],
                metadata={"adapter": adapter_name, "auto_loaded": True},
            )
            logger.info(f"[SKILL-ADAPTERS] Registered wisdom adapter: {adapter_name}")

    async def _initialize_skill_adapters(self) -> None:
        """Auto-load eligible skill adapters based on config."""
        if not self._is_auto_discovery_enabled():
            return

        logger.info("[SKILL-ADAPTERS] Starting auto-discovery...")

        from ciris_engine.logic.config.env_utils import get_env_var
        from ciris_engine.logic.services.tool import AdapterDiscoveryService
        from ciris_engine.logic.services.tool.eligibility_checker import ToolEligibilityChecker

        eligibility_checker = ToolEligibilityChecker(config_service=self.config_service)
        service_deps = {
            "bus_manager": self.bus_manager,
            "memory_service": self.memory_service,
            "time_service": self.time_service,
            "filter_service": self.adaptive_filter_service,
            "secrets_service": self.secrets_service,
            "agent_id": self._get_runtime_agent_id(),
            "agent_occurrence_id": self.essential_config.agent_occurrence_id,
        }

        env_adapter = get_env_var("CIRIS_ADAPTER")
        explicitly_enabled = {a.strip() for a in env_adapter.split(",")} if env_adapter else set()
        adapters_config = self.essential_config.adapters
        effective_disabled = [a for a in adapters_config.disabled_adapters if a not in explicitly_enabled]

        if explicitly_enabled:
            overridden = set(adapters_config.disabled_adapters) & explicitly_enabled
            if overridden:
                logger.info(f"[SKILL-ADAPTERS] Explicitly enabled adapters override disabled: {overridden}")

        discovery = AdapterDiscoveryService(eligibility_checker=eligibility_checker)
        eligible = await discovery.load_eligible_adapters(
            disabled_adapters=effective_disabled,
            service_dependencies=service_deps,
        )

        if not eligible:
            logger.info("[SKILL-ADAPTERS] No eligible adapters found")
            return

        for adapter_name, service in eligible.items():
            # ciris_verify is always loaded at bootstrap — skip to avoid double-load
            if adapter_name == "ciris_verify":
                continue
            try:
                await self._start_and_register_adapter(adapter_name, service)
            except Exception as e:
                logger.warning(f"[SKILL-ADAPTERS] Failed to register {adapter_name}: {e}")

        logger.info(f"[SKILL-ADAPTERS] Auto-loaded {len(eligible)} eligible adapters")

    def verify_core_services(self) -> bool:
        """Verify all core services are operational."""
        try:
            # Check service registry
            if not self.service_registry:
                logger.error("Service registry not initialized")
                return False

            # Check critical services (LLM service is optional during first-run or when disabled)
            from typing import Any, List

            from ciris_engine.logic.persistence.llm_providers import get_ciris_services_disabled
            from ciris_engine.logic.setup.first_run import is_first_run

            # Use named dict for better error messages
            critical_services: dict[str, Any] = {
                "telemetry_service": self.telemetry_service,
                "memory_service": self.memory_service,
                "secrets_service": self.secrets_service,
                "adaptive_filter_service": self.adaptive_filter_service,
            }

            # LLM service is optional when:
            # 1. First-run mode (setup wizard will configure it)
            # 2. CIRIS services disabled with no other provider (user can add via settings)
            ciris_disabled = get_ciris_services_disabled()
            if is_first_run():
                if not self.llm_service:
                    logger.info("LLM service not initialized (first-run mode - will be initialized after setup)")
            elif ciris_disabled and not self.llm_service:
                logger.warning(
                    "[WARN] No LLM provider configured - CIRIS services disabled and no local provider set up"
                )
                logger.warning("[WARN] Agent will start but cannot process requests until an LLM provider is added")
            elif not ciris_disabled:
                # Only require LLM service when CIRIS services are enabled
                critical_services["llm_service"] = self.llm_service

            for name, service in critical_services.items():
                if not service:
                    logger.error(f"Critical service '{name}' not initialized (is None)")
                    return False

            # Verify audit service
            if not self.audit_service:
                logger.error("Audit service not initialized")
                return False

            logger.info("[OK] All core services verified")
            return True
        except Exception as e:
            logger.error(f"Core services verification failed: {e}")
            return False

    def _find_service_manifest(self, service_name: str, discovered_services: List[Any]) -> Any:
        """Find matching service manifest by normalized name.

        Args:
            service_name: Name to search for
            discovered_services: List of discovered service manifests

        Returns:
            Matching manifest or None
        """
        search_name_normalized = service_name.lower().replace("_adapter", "")
        for svc in discovered_services:
            svc_name_normalized = svc.module.name.lower().replace("_adapter", "")
            if svc_name_normalized == search_name_normalized:
                return svc
        return None

    def _register_tool_service(self, service_instance: Any, manifest: Any, service_def: Any) -> None:
        """Register a TOOL service with ServiceRegistry."""
        if not self.service_registry:
            return

        logger.info(f"Registering {manifest.module.name} as TOOL service")
        from ciris_engine.logic.registries.base import Priority

        priority_map = {
            "CRITICAL": Priority.CRITICAL,
            "HIGH": Priority.HIGH,
            "NORMAL": Priority.NORMAL,
            "LOW": Priority.LOW,
        }

        priority_value = (
            service_def.priority.value if hasattr(service_def.priority, "value") else service_def.priority.name
        )
        priority = priority_map.get(priority_value, Priority.NORMAL)

        self.service_registry.register_service(
            service_type=ServiceType.TOOL,
            provider=service_instance,
            priority=priority,
            capabilities=service_def.capabilities,
        )

    def _register_communication_service(self, service_instance: Any, manifest: Any, service_def: Any) -> None:
        """Register a COMMUNICATION service with ServiceRegistry."""
        if not self.service_registry:
            return

        logger.info(f"Registering {manifest.module.name} as COMMUNICATION service")
        from ciris_engine.logic.registries.base import Priority

        priority_map = {
            "CRITICAL": Priority.CRITICAL,
            "HIGH": Priority.HIGH,
            "NORMAL": Priority.NORMAL,
            "LOW": Priority.LOW,
        }

        priority_value = (
            service_def.priority.value if hasattr(service_def.priority, "value") else service_def.priority.name
        )
        priority = priority_map.get(priority_value, Priority.NORMAL)

        self.service_registry.register_service(
            service_type=ServiceType.COMMUNICATION,
            provider=service_instance,
            priority=priority,
            capabilities=service_def.capabilities,
        )

    def _register_llm_service(self, service_instance: Any, manifest: Any, service_def: Any) -> None:
        """Register an LLM service with ServiceRegistry."""
        if not self.service_registry:
            return

        logger.info(f"Registering {manifest.module.name} as LLM service")
        from ciris_engine.logic.registries.base import Priority

        priority_map = {
            "CRITICAL": Priority.CRITICAL,
            "HIGH": Priority.HIGH,
            "NORMAL": Priority.NORMAL,
            "LOW": Priority.LOW,
        }
        priority_value = (
            service_def.priority.value if hasattr(service_def.priority, "value") else service_def.priority.name
        )
        priority = priority_map.get(priority_value, Priority.NORMAL)

        self.service_registry.register_service(
            service_type=ServiceType.LLM,
            provider=service_instance,
            priority=priority,
            capabilities=service_def.capabilities,
        )

    def _get_runtime_agent_id(self) -> Optional[str]:
        """Get agent_id from persistence storage.

        Returns:
            The agent_id if found in persistence, None otherwise.
        """
        try:
            from ciris_engine.logic.persistence.models import retrieve_agent_identity

            agent_identity = retrieve_agent_identity()
            if agent_identity:
                logger.debug(f"Got agent_id from persistence: {agent_identity.agent_id}")
                return agent_identity.agent_id
        except Exception as e:
            logger.debug(f"Could not retrieve agent_id from persistence: {e}")
        return None

    def _register_adapter(self, service_instance: Any, manifest: Any, service_def: Any) -> None:
        """Register a adapter with the appropriate bus/registry based on type."""
        if service_def.type == ServiceType.TOOL:
            self._register_tool_service(service_instance, manifest, service_def)
        elif service_def.type == ServiceType.COMMUNICATION:
            self._register_communication_service(service_instance, manifest, service_def)
        elif service_def.type == ServiceType.LLM:
            self._register_llm_service(service_instance, manifest, service_def)

    async def _load_adapter(self, service_name: str) -> None:
        """Load a adapter and register its services with appropriate buses.

        Args:
            service_name: Name of the adapter to load (e.g. "reddit_adapter")
        """
        from ciris_engine.logic.services.tool import AdapterDiscoveryService
        from ciris_engine.logic.services.tool.eligibility_checker import ToolEligibilityChecker

        logger.info(f"Loading adapter: {service_name}")

        # Create eligibility checker with config service
        eligibility_checker = ToolEligibilityChecker(config_service=self.config_service)

        # Use discovery service to scan all adapter paths (built-in, user, workspace)
        discovery_service = AdapterDiscoveryService(eligibility_checker=eligibility_checker)
        discovered_services = discovery_service.discover_adapters()

        manifest = self._find_service_manifest(service_name, discovered_services)
        if not manifest:
            raise ValueError(f"Adapter '{service_name}' not found")

        logger.info(f"Found manifest for adapter '{manifest.module.name}'")

        # Load each service defined in the manifest
        for service_def in manifest.services:
            try:
                # Load the specific service class for this service definition
                service_class = discovery_service.load_service_class(manifest, service_def.class_path)
                if not service_class:
                    logger.error(f"Failed to load service class for {manifest.module.name}")
                    continue

                # Instantiate the service (services usually need minimal initialization)
                # Most adapters are self-contained and load config from env
                # Some services (like observers) may need runtime dependencies
                try:
                    # Try to inject runtime dependencies if the service accepts them
                    # Cast to Any for duck-typed optional runtime dependency injection
                    from typing import Any, cast

                    # Get agent_id from persistence (identity is stored in graph)
                    runtime_agent_id = self._get_runtime_agent_id()

                    service_instance = cast(Any, service_class)(
                        bus_manager=self.bus_manager,
                        memory_service=self.memory_service,
                        agent_id=runtime_agent_id,  # Pass agent_id from persistence identity
                        filter_service=self.adaptive_filter_service,
                        secrets_service=self.secrets_service,
                        time_service=self.time_service,
                        agent_occurrence_id=self.essential_config.agent_occurrence_id,
                    )
                except TypeError:
                    # Service doesn't accept runtime dependencies, instantiate without them
                    service_instance = service_class()

                # Start the service before registration to initialize resources (HTTP clients, credentials, etc.)
                if hasattr(service_instance, "start"):
                    start_result = service_instance.start()
                    # Handle both async and sync start methods
                    if hasattr(start_result, "__await__"):
                        await start_result
                    logger.info(f"Started adapter {manifest.module.name}")

                # Register with appropriate bus based on service type
                self._register_adapter(service_instance, manifest, service_def)

                logger.info(f"Successfully loaded and registered adapter: {manifest.module.name}")
                self.loaded_modules.append(f"modular:{service_name}")

            except Exception as e:
                logger.error(
                    f"Failed to load service {service_def.class_path} from {manifest.module.name}: {e}", exc_info=True
                )
                raise

    async def load_modules(self, modules: List[str], disable_core_on_mock: bool = True) -> None:
        """Load external modules with MOCK safety checks.

        Args:
            modules: List of module names to load (e.g. ["mockllm", "custom_tool", "modular:reddit_adapter"])
            disable_core_on_mock: If True, MOCK modules disable core services
        """
        if not self.module_loader:
            from ciris_engine.logic.runtime.module_loader import ModuleLoader

            self.module_loader = ModuleLoader()

        for module_name in modules:
            try:
                # Check if this is a adapter
                if module_name.startswith("modular:"):
                    service_name = module_name[8:]  # Remove "modular:" prefix
                    await self._load_adapter(service_name)
                    continue

                # Load module with safety checks
                if self.module_loader.load_module(module_name, disable_core_on_mock):
                    # Initialize services from module
                    result = await self.module_loader.initialize_module_services(module_name, self.service_registry)

                    if result.success:
                        self.loaded_modules.append(module_name)
                        logger.info(f"Module {module_name} loaded with {len(result.services_loaded)} services")

                        # Store first LLM service for compatibility
                        # Need to get actual service instance from registry
                        for service_meta in result.services_loaded:
                            if service_meta.service_type == ServiceType.LLM:
                                # Get the actual service from registry
                                if self.service_registry:
                                    providers = self.service_registry.get_services_by_type(ServiceType.LLM)
                                    if providers:
                                        self.llm_service = providers[0]  # First provider
                                        break
                    else:
                        logger.error(f"Failed to initialize services from {module_name}: {result.errors}")
                        for warning in result.warnings:
                            logger.warning(warning)
                else:
                    logger.error(f"Failed to load module: {module_name}")

            except Exception as e:
                logger.error(f"Error loading module {module_name}: {e}")
                raise

        # Display MOCK warnings if any
        if self.module_loader is not None:
            warnings = self.module_loader.get_mock_warnings()
            for warning in warnings:
                logger.warning(warning)

    def register_core_services(self) -> None:
        """Register core services in the service registry."""
        if not self.service_registry:
            return

        # Infrastructure services are single-instance - NO ServiceRegistry needed
        # Direct references only per "No Exceptions" principle

        # Memory service already registered above with full capabilities in initialize_all_services()
        # Don't re-register as it would overwrite the full capability list

        # Audit service is single-instance - NO ServiceRegistry needed

        # Telemetry service is single-instance - NO ServiceRegistry needed

        # Register LLM service(s) - handled by _initialize_llm_services

        # Secrets service is single-instance - NO ServiceRegistry needed

        # Adaptive filter service is single-instance - NO ServiceRegistry needed

        # Register WA service - can have multiple wisdom sources
        if self.wa_auth_system:
            self.service_registry.register_service(
                service_type=ServiceType.WISE_AUTHORITY,
                provider=self.wa_auth_system,
                priority=Priority.CRITICAL,
                capabilities=[
                    "authenticate",
                    "verify_token",
                    "provision_certificate",
                    "handle_deferral",
                    "provide_guidance",
                    "oauth_flow",
                    "send_deferral",
                    "get_pending_deferrals",
                    "resolve_deferral",
                ],
                metadata={"service_name": "WiseAuthorityService"},
            )

        # Config service is single-instance - NO ServiceRegistry needed
        # But it's used by RuntimeControlService so needs to be accessible

        # Transaction orchestrator is single-instance - NO ServiceRegistry needed

        # Register SecretsToolService for core secrets tools
        if self.secrets_tool_service:
            self.service_registry.register_service(
                service_type=ServiceType.TOOL,
                provider=self.secrets_tool_service,
                priority=Priority.HIGH,
                capabilities=[
                    "execute_tool",
                    "get_available_tools",
                    "get_tool_result",
                    "validate_parameters",
                    "get_tool_info",
                    "get_all_tool_info",
                ],
                metadata={"service_name": "SecretsToolService", "provider": "core"},
            )
            logger.info("SecretsToolService registered in ServiceRegistry")

        # Register ConsentService as a tool service (v1.4.6)
        if self.consent_service:
            self.service_registry.register_service(
                service_type=ServiceType.TOOL,
                provider=self.consent_service,
                priority=Priority.HIGH,
                capabilities=[
                    "execute_tool",
                    "get_available_tools",
                    "upgrade_relationship",
                    "degrade_relationship",
                ],
                metadata={"service_name": "ConsentService", "provider": "core"},
            )
            logger.info("ConsentService registered in ServiceRegistry as TOOL service")

        # Task scheduler is single-instance - NO ServiceRegistry needed

        # Incident management is single-instance - NO ServiceRegistry needed

    async def _migrate_config_to_graph(self) -> None:
        """Migrate essential config to graph for runtime management."""
        if not self.config_service:
            logger.warning("Cannot migrate config - GraphConfigService not available")
            return

        logger.info("Migrating essential configuration to graph...")

        # Migrate each config section
        config_dict = self.essential_config.model_dump()

        for section_name, section_data in config_dict.items():
            if isinstance(section_data, dict):
                # Migrate each key in the section
                for key, value in section_data.items():
                    full_key = f"{section_name}.{key}"
                    await self.config_service.set_config(
                        key=full_key,
                        value=value,  # Pass raw value, set_config will wrap it
                        updated_by="system_bootstrap",
                    )
                    logger.debug(f"Migrated config: {full_key}")
            else:
                # Top-level config value
                await self.config_service.set_config(
                    key=section_name,
                    value=section_data,  # Pass raw value, set_config will wrap it
                    updated_by="system_bootstrap",
                )
                logger.debug(f"Migrated config: {section_name}")

        logger.info("Configuration migration complete")

    def get_metrics(self) -> Dict[str, float]:
        """Get initializer metrics from the v1.4.3 set.

        Returns EXACTLY these metrics:
        - initializer_services_started: Services started count
        - initializer_startup_time_ms: Total startup time
        - initializer_errors: Initialization errors
        - initializer_dependencies_resolved: Dependencies resolved
        """
        # Calculate startup time in milliseconds
        startup_time_ms = 0.0
        if self._startup_start_time is not None and self._startup_end_time is not None:
            duration_seconds = self._startup_end_time - self._startup_start_time
            startup_time_ms = duration_seconds * 1000.0

        return {
            "initializer_services_started": float(self._services_started_count),
            "initializer_startup_time_ms": startup_time_ms,
            "initializer_errors": float(self._initialization_errors),
            "initializer_dependencies_resolved": float(self._dependencies_resolved),
        }
