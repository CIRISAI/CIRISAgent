"""
Identity formatter for agent identity context in system snapshots.

Converts raw identity graph node data into human-readable text format,
including shutdown/continuity history.
"""

from typing import Any, Callable, Dict, List, Optional, Tuple

from ciris_engine.logic.utils.jsondict_helpers import get_dict, get_list, get_str
from ciris_engine.schemas.types import JSONDict

from ._localized import label_localizer


def format_core_identity_block(
    agent_id: str,
    description: str,
    role: str,
    language: Optional[str] = None,
) -> str:
    """The "=== CORE IDENTITY ===" block — one routed source (#974 step 3).

    Before #974 this doctrine existed as THREE inline copies (two branches of
    ``BaseDSDMA.evaluate_thought`` and
    ``ActionSelectionPDMAEvaluator._validate_and_build_identity_block``). It
    now resolves through ``get_string`` (key: ``prompts.identity_block``) so
    the research-override ``string`` namespace intercepts it and non-English
    bundles can translate it. Bundles without the key fall back to the
    base-locale template — exactly the English bytes the inline literals
    produced for every locale.
    """
    from ciris_engine.logic.utils.localization import get_preferred_language, get_string

    lang = language or get_preferred_language()
    return get_string(
        lang,
        "prompts.identity_block",
        agent_id=agent_id,
        description=description,
        role=role,
    )


def _format_core_identity(agent_identity: JSONDict, localizer: Callable[..., str]) -> List[str]:
    """Extract and format core identity fields."""
    lines = []
    agent_id = get_str(agent_identity, "agent_id", "Unknown")
    description = get_str(agent_identity, "description", "")
    role = get_str(agent_identity, "role_description", "")

    lines.append(f"{localizer('prompts.formatters.identity_agent_id', 'Agent ID')}: {agent_id}")
    if description:
        lines.append(f"{localizer('prompts.formatters.identity_purpose', 'Purpose')}: {description.strip()}")
    if role:
        lines.append(f"{localizer('prompts.formatters.identity_role', 'Role')}: {role.strip()}")

    trust_level = agent_identity.get("trust_level")
    if trust_level is not None:
        lines.append(f"{localizer('prompts.formatters.identity_trust_level', 'Trust Level')}: {trust_level}")

    return lines


def _format_domain_knowledge(agent_identity: JSONDict, localizer: Callable[..., str]) -> List[str]:
    """Extract and format domain-specific knowledge."""
    lines = []
    domain_knowledge = agent_identity.get("domain_specific_knowledge")
    if domain_knowledge and isinstance(domain_knowledge, dict):
        dk_role = domain_knowledge.get("role")
        if dk_role:
            lines.append(f"{localizer('prompts.formatters.identity_domain_role', 'Domain Role')}: {dk_role}")
    return lines


def _format_permitted_actions(agent_identity: JSONDict, localizer: Callable[..., str]) -> List[str]:
    """Extract and format permitted actions summary."""
    lines = []
    permitted_actions = agent_identity.get("permitted_actions", [])
    if permitted_actions and isinstance(permitted_actions, list):
        label = localizer("prompts.formatters.identity_permitted_actions", "Permitted Actions")
        lines.append(f"{label}: {', '.join(permitted_actions[:10])}")
    return lines


def _is_continuity_event(tags: List[str]) -> bool:
    """Check if tags indicate a continuity awareness event."""
    return "consciousness_preservation" in tags or "continuity_awareness" in tags


def _extract_startup_timestamps(agent_identity: JSONDict) -> List[str]:
    """Extract startup event timestamps from agent identity."""
    timestamps = []
    for key, value in agent_identity.items():
        if not key.startswith("startup_"):
            continue
        if not isinstance(value, dict):
            continue

        tags = value.get("tags", [])
        if "startup" in tags and _is_continuity_event(tags):
            timestamp_str = key.replace("startup_", "")
            timestamps.append(timestamp_str)

    return timestamps


def _extract_shutdown_timestamps(agent_identity: JSONDict) -> List[str]:
    """Extract shutdown event timestamps from agent identity."""
    timestamps = []
    for key, value in agent_identity.items():
        if not key.startswith("shutdown_"):
            continue
        if not isinstance(value, dict):
            continue

        tags = value.get("tags", [])
        if "shutdown" in tags and _is_continuity_event(tags):
            timestamp_str = key.replace("shutdown_", "")
            timestamps.append(timestamp_str)

    return timestamps


def _extract_event_timestamps(agent_identity: JSONDict) -> Tuple[Optional[str], List[str]]:
    """
    Extract startup and shutdown timestamps.

    Returns
    -------
    tuple
        (first_event_timestamp, shutdown_timestamps)
    """
    startup_timestamps = _extract_startup_timestamps(agent_identity)
    shutdown_timestamps = _extract_shutdown_timestamps(agent_identity)

    all_timestamps = startup_timestamps + shutdown_timestamps
    first_event_timestamp = min(all_timestamps) if all_timestamps else None

    return first_event_timestamp, shutdown_timestamps


def _clean_timestamp(timestamp: str) -> str:
    """Clean timestamp string for display."""
    try:
        clean_ts = timestamp.split(".")[0] if "." in timestamp else timestamp
        clean_ts = clean_ts.replace("+00:00", " UTC")
        return clean_ts
    except Exception:
        return timestamp


def _format_shutdown_history(shutdown_timestamps: List[str], localizer: Callable[..., str]) -> List[str]:
    """Format shutdown history into readable lines."""
    lines: List[str] = []
    if not shutdown_timestamps:
        return lines

    # Sort by timestamp (most recent first)
    sorted_shutdowns = sorted(shutdown_timestamps, reverse=True)
    recent_shutdowns = sorted_shutdowns[:5]

    label = localizer("prompts.formatters.identity_recent_shutdowns", "Recent Shutdowns")
    lines.append(f"{label} ({len(shutdown_timestamps)} total):")
    for ts in recent_shutdowns:
        clean_ts = _clean_timestamp(ts)
        lines.append(f"  - {clean_ts}")

    if len(shutdown_timestamps) > 5:
        lines.append(f"  ... and {len(shutdown_timestamps) - 5} more")

    return lines


def _format_continuity_history(
    first_event_timestamp: Optional[str],
    shutdown_timestamps: List[str],
    localizer: Callable[..., str],
) -> List[str]:
    """Format continuity history section."""
    lines: List[str] = []
    if not first_event_timestamp and not shutdown_timestamps:
        return lines

    lines.append("")
    lines.append(f"=== {localizer('prompts.formatters.identity_continuity_history', 'Continuity History')} ===")

    if first_event_timestamp:
        clean_ts = _clean_timestamp(first_event_timestamp)
        lines.append(f"{localizer('prompts.formatters.identity_first_start', 'First Start')}: {clean_ts}")

    lines.extend(_format_shutdown_history(shutdown_timestamps, localizer))

    return lines


def _find_channel_assignment(agent_identity: JSONDict) -> Optional[str]:
    """Find channel assignment message in agent identity."""
    for key, value in agent_identity.items():
        if isinstance(value, str) and "assigned channel" in value.lower():
            return value
    return None


def format_agent_identity(agent_identity: Optional[JSONDict], language: Optional[str] = None) -> str:
    """
    Format agent identity information into readable text.

    Handles both old terminology (consciousness_preservation) and new terminology
    (continuity_awareness) for backward compatibility with existing shutdown nodes.

    Parameters
    ----------
    agent_identity : dict or None
        Agent identity data from graph node, typically containing:
        - agent_id: Agent identifier
        - description: Agent description/purpose
        - role_description: Agent role
        - trust_level: Trust level (0-1)
        - domain_specific_knowledge: Domain knowledge dict
        - permitted_actions: List of allowed actions
        - And potentially many shutdown node references
    language : str, optional
        Locale for the field labels; defaults to ``CIRIS_PREFERRED_LANGUAGE``.

    Returns
    -------
    str
        Formatted identity context ready for system prompt, or empty string if no identity.

    Notes
    -----
    - Extracts core identity fields (agent_id, description, role)
    - Identifies shutdown nodes by tags (supports both old and new terminology)
    - Formats shutdown history as clean timestamp list
    - Omits raw graph node data to keep prompts concise
    - Preserves channel assignment if present
    """
    if not agent_identity or not isinstance(agent_identity, dict):
        return ""

    localizer = label_localizer(language)
    lines = []

    # Core identity information
    lines.extend(_format_core_identity(agent_identity, localizer))

    # Domain-specific knowledge
    lines.extend(_format_domain_knowledge(agent_identity, localizer))

    # Permitted actions summary
    lines.extend(_format_permitted_actions(agent_identity, localizer))

    # Extract and format continuity history
    first_event_timestamp, shutdown_timestamps = _extract_event_timestamps(agent_identity)
    lines.extend(_format_continuity_history(first_event_timestamp, shutdown_timestamps, localizer))

    # Channel assignment (if present)
    channel_assignment = _find_channel_assignment(agent_identity)
    if channel_assignment:
        lines.append("")
        lines.append(channel_assignment)

    return "\n".join(lines)
