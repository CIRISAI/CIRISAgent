"""Infrastructure services schemas."""
