class FollowUpCreationError(Exception):
    """Raised when a follow-up thought cannot be created."""
