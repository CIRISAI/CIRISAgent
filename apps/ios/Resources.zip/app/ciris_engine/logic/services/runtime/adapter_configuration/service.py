"""
AdapterConfigurationService - Manages interactive configuration workflows for adapters.

This service orchestrates multi-step configuration workflows including:
- Discovery of local services (mDNS, API scanning)
- OAuth authentication flows with PKCE
- Interactive step-by-step configuration
- Configuration validation and application
"""

import asyncio
import base64
import hashlib
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

from ciris_engine.protocols.adapters.configurable import ConfigurableAdapterProtocol
from ciris_engine.schemas.runtime.manifest import ConfigurationStep, InteractiveConfiguration

from .session import AdapterConfigSession, SessionStatus

logger = logging.getLogger(__name__)


class StepResult:
    """Result from executing a configuration step.

    Attributes:
        step_id: ID of the step that was executed
        success: Whether step execution succeeded
        data: Data returned by the step (options, URLs, etc.)
        next_step_index: Index of next step to execute (None if staying on current)
        error: Error message if execution failed
        awaiting_callback: Whether step is waiting for external callback (OAuth)
    """

    def __init__(
        self,
        step_id: str,
        success: bool,
        data: Optional[Dict[str, Any]] = None,
        next_step_index: Optional[int] = None,
        error: Optional[str] = None,
        awaiting_callback: bool = False,
    ):
        """Initialize step result.

        Args:
            step_id: ID of the executed step
            success: Whether execution succeeded
            data: Optional data returned by step
            next_step_index: Optional index of next step
            error: Optional error message
            awaiting_callback: Whether waiting for callback
        """
        self.step_id = step_id
        self.success = success
        self.data = data or {}
        self.next_step_index = next_step_index
        self.error = error
        self.awaiting_callback = awaiting_callback


class AdapterConfigurationService:
    """Manages interactive configuration workflows for adapters.

    This service provides the runtime infrastructure for executing multi-step
    configuration workflows defined by adapters. It handles session management,
    step execution, OAuth flows, and configuration persistence.

    Example:
        >>> service = AdapterConfigurationService()
        >>> service.register_adapter_config(
        ...     adapter_type="homeassistant",
        ...     interactive_config=ha_config,
        ...     adapter_instance=ha_adapter
        ... )
        >>> session = await service.start_session("homeassistant", "user_123")
        >>> result = await service.execute_step(
        ...     session.session_id,
        ...     {"discovery_type": "mdns"}
        ... )
    """

    SESSION_TIMEOUT_MINUTES = 30

    def __init__(self) -> None:
        """Initialize the configuration service."""
        self._sessions: Dict[str, AdapterConfigSession] = {}
        self._adapter_manifests: Dict[str, InteractiveConfiguration] = {}
        self._adapter_instances: Dict[str, ConfigurableAdapterProtocol] = {}

    def register_adapter_config(
        self,
        adapter_type: str,
        interactive_config: InteractiveConfiguration,
        adapter_instance: ConfigurableAdapterProtocol,
    ) -> None:
        """Register an adapter's interactive configuration capability.

        Args:
            adapter_type: Type identifier for the adapter
            interactive_config: Configuration workflow definition
            adapter_instance: Adapter instance implementing ConfigurableAdapterProtocol
        """
        self._adapter_manifests[adapter_type] = interactive_config
        self._adapter_instances[adapter_type] = adapter_instance
        logger.info(f"Registered interactive config for adapter: {adapter_type}")

    def get_configurable_adapters(self) -> List[str]:
        """Get list of adapters that support interactive configuration.

        Returns:
            List of adapter type identifiers
        """
        return list(self._adapter_manifests.keys())

    async def start_session(
        self,
        adapter_type: str,
        user_id: str,
        start_step_id: Optional[str] = None,
        existing_config: Optional[Dict[str, Any]] = None,
    ) -> AdapterConfigSession:
        """Start a new configuration session for an adapter.

        Args:
            adapter_type: Type of adapter to configure
            user_id: ID of user performing configuration
            start_step_id: Optional step ID to start at (for re-auth flows)
            existing_config: Optional existing config to pre-populate session data
                             (used for re-auth to preserve base_url etc.)

        Returns:
            New configuration session

        Raises:
            ValueError: If adapter doesn't support interactive configuration
            ValueError: If start_step_id is invalid
        """
        if adapter_type not in self._adapter_manifests:
            raise ValueError(f"Adapter '{adapter_type}' does not support interactive configuration")

        session = AdapterConfigSession(
            session_id=str(uuid.uuid4()),
            adapter_type=adapter_type,
            user_id=user_id,
        )

        # If start_step_id is specified, find and set the step index
        if start_step_id:
            config = self._adapter_manifests[adapter_type]
            step_index = None
            for i, step in enumerate(config.steps):
                if step.step_id == start_step_id:
                    step_index = i
                    break
            if step_index is None:
                raise ValueError(f"Requested step not found in adapter '{adapter_type}'")
            session.current_step_index = step_index
            # Log index only to avoid logging user-controlled step ID
            logger.info(f"Starting session at step index {step_index}")

        # Pre-populate collected_config with existing config for re-auth flows
        # This allows OAuth step to use previously configured base_url
        if existing_config:
            session.collected_config.update(existing_config)
            # Log count only to avoid exposing user-controlled key names
            logger.info(f"Pre-populated session with {len(existing_config)} existing config keys")

        self._sessions[session.session_id] = session
        logger.info(f"Started config session {session.session_id} for {adapter_type}")
        return session

    def get_session(self, session_id: str) -> Optional[AdapterConfigSession]:
        """Get a configuration session by ID.

        Args:
            session_id: Session identifier

        Returns:
            Session if found, None otherwise. Expired sessions are marked as EXPIRED.
        """
        session = self._sessions.get(session_id)
        if session:
            # Check for expiration
            if self._is_session_expired(session):
                session.status = SessionStatus.EXPIRED
        return session

    async def execute_step(
        self,
        session_id: str,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Execute the current configuration step.

        Args:
            session_id: Session identifier
            step_data: Data for step execution (user input, selections, etc.)

        Returns:
            Result of step execution
        """
        session = self.get_session(session_id)
        if not session:
            return StepResult(step_id="", success=False, error="Session not found")

        if session.status == SessionStatus.EXPIRED:
            return StepResult(step_id="", success=False, error="Session expired")

        config = self._adapter_manifests[session.adapter_type]
        if session.current_step_index >= len(config.steps):
            return StepResult(step_id="", success=False, error="No more steps")

        step = config.steps[session.current_step_index]
        adapter = self._adapter_instances[session.adapter_type]

        try:
            result = await self._execute_step_type(session, step, adapter, step_data)
            session.update()
            return result
        except Exception as e:
            logger.error(f"Step execution failed: {e}")
            return StepResult(step_id=step.step_id, success=False, error=str(e))

    async def _execute_discovery_step(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Optional[Dict[str, Any]] = None,
    ) -> StepResult:
        """Execute a discovery step.

        If step_data contains 'selected_url' or 'manual_url', stores the URL
        and advances to the next step. Otherwise, runs discovery and returns
        discovered items for user selection.
        """
        step_data = step_data or {}

        # Check if user has selected an item or entered a manual URL
        selected_url = step_data.get("selected_url") or step_data.get("manual_url")
        if selected_url:
            logger.info(f"[DISCOVERY STEP] User selected URL: {selected_url}")
            session.collected_config["base_url"] = selected_url
            session.current_step_index += 1
            logger.info(f"[DISCOVERY STEP] Stored base_url, advancing to step {session.current_step_index}")
            return StepResult(step_id=step.step_id, success=True, next_step_index=session.current_step_index)

        # Run discovery
        items = await adapter.discover(step.discovery_method or "default")
        session.step_results[step.step_id] = items
        logger.info(f"[DISCOVERY STEP] Returning {len(items)} discovered items to client")
        for item in items:
            logger.info(
                f"[DISCOVERY STEP]   → {item.get('label', 'unknown')} - {item.get('metadata', {}).get('url', 'no url')}"
            )

        # Don't auto-advance - wait for user to select an item
        return StepResult(step_id=step.step_id, success=True, data={"discovered_items": items}, next_step_index=None)

    async def _handle_oauth_callback(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Handle OAuth callback with authorization code."""
        logger.info("[OAUTH STEP] Processing OAuth callback with code")
        tokens = await adapter.handle_oauth_callback(
            code=step_data["code"],
            state=step_data.get("state", ""),
            base_url=session.collected_config.get("base_url", ""),
            callback_base_url=session.collected_config.get("callback_base_url"),
            redirect_uri=session.collected_config.get("redirect_uri"),
            platform=session.collected_config.get("platform"),
        )
        session.collected_config["oauth_tokens"] = tokens
        session.status = SessionStatus.ACTIVE
        session.current_step_index += 1
        logger.info(f"[OAUTH STEP] Callback processed, advancing to step {session.current_step_index}")
        return StepResult(step_id=step.step_id, success=True, next_step_index=session.current_step_index)

    def _store_oauth_step_data(self, session: AdapterConfigSession, step_data: Dict[str, Any]) -> None:
        """Store OAuth-related data from step_data into session."""
        if "base_url" in step_data and step_data["base_url"]:
            session.collected_config["base_url"] = step_data["base_url"]
            logger.info("[OAUTH STEP] Stored base_url from step_data")

        if step_data.get("callback_base_url"):
            session.collected_config["callback_base_url"] = step_data["callback_base_url"]
            logger.info("[OAUTH STEP] Using local callback base URL")

        if step_data.get("redirect_uri"):
            session.collected_config["redirect_uri"] = step_data["redirect_uri"]
            session.collected_config["platform"] = step_data.get("platform")
            logger.info("[OAUTH STEP] Using custom redirect URI")

    async def _generate_oauth_url(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Generate OAuth authorization URL."""
        base_url = session.collected_config.get("base_url", "")
        logger.info("[OAUTH STEP] Generating OAuth URL")

        if not base_url:
            logger.error("[OAUTH STEP] ERROR: No base_url in collected_config!")
            return StepResult(
                step_id=step.step_id,
                success=False,
                error="No base_url configured. Please select a Home Assistant instance first.",
            )

        session.pkce_verifier = secrets.token_urlsafe(32)
        code_challenge = self._generate_pkce_challenge(session.pkce_verifier)

        try:
            oauth_url = await adapter.get_oauth_url(
                base_url=base_url,
                state=session.session_id,
                callback_base_url=step_data.get("callback_base_url"),
                redirect_uri=step_data.get("redirect_uri"),
                platform=step_data.get("platform"),
            )
            logger.info("[OAUTH STEP] Generated OAuth URL successfully")
        except Exception as e:
            logger.error(f"[OAUTH STEP] Failed to generate OAuth URL: {e}")
            return StepResult(step_id=step.step_id, success=False, error=f"Failed to get OAuth URL: {str(e)}")

        session.status = SessionStatus.AWAITING_OAUTH
        return StepResult(
            step_id=step.step_id,
            success=True,
            data={"oauth_url": oauth_url, "code_challenge": code_challenge},
            awaiting_callback=True,
        )

    async def _execute_oauth_step(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Execute an OAuth step."""
        logger.info(f"[OAUTH STEP] Executing OAuth step for session {session.session_id}")
        logger.debug(f"[OAUTH STEP] step_data keys: {list(step_data.keys())}")

        self._store_oauth_step_data(session, step_data)

        if "code" in step_data:
            return await self._handle_oauth_callback(session, step, adapter, step_data)
        return await self._generate_oauth_url(session, step, adapter, step_data)

    async def _execute_select_step(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Execute a select step."""
        logger.info(
            f"[SELECT STEP] Processing step {step.step_id}, step_data keys: {list(step_data.keys()) if step_data else 'None'}"
        )
        logger.debug(f"[SELECT STEP] step_data keys: {list(step_data.keys()) if step_data else 'None'}")

        selection = step_data.get("selection") or step_data.get("selected")

        # "skip" means user chose to skip an optional step with no selection
        if selection == "skip":
            selection = ""

        if selection is not None and (selection or getattr(step, "optional", False)):
            # Advance: has selection, OR optional step with empty/skip selection
            session.collected_config[step.step_id] = selection if selection else ""
            session.current_step_index += 1
            logger.info(
                f"[SELECT STEP] Stored selection for {step.step_id} (value='{selection}'), advancing to step {session.current_step_index}"
            )
            return StepResult(step_id=step.step_id, success=True, next_step_index=session.current_step_index)

        # No selection key in step_data at all — fetch options for display
        logger.info(f"[SELECT STEP] No selection provided, fetching options for {step.step_id}")
        options = await adapter.get_config_options(step.step_id, session.collected_config)
        logger.info(f"[SELECT STEP] Got {len(options) if options else 0} options for {step.step_id}")
        return StepResult(step_id=step.step_id, success=True, data={"options": options})

    def _execute_input_step(
        self, session: AdapterConfigSession, step: ConfigurationStep, step_data: Dict[str, Any]
    ) -> StepResult:
        """Execute an input step.

        Advances to next step if:
        - step_data is not None (i.e., user submitted the form, even if empty)
        - All required fields have values

        If step_data is None, we return awaiting_input=True.
        If step_data is {} (empty dict from optional fields), we still advance.
        """
        # step_data being None means no submission yet; {} means form submitted with no values
        if step_data is None:
            return StepResult(step_id=step.step_id, success=True, data={"awaiting_input": True})

        # Check if all required fields have values
        required_fields: list[str] = []
        if step.fields:
            for f in step.fields:
                if f.required:
                    field_key = f.name or f.field_id
                    if field_key:
                        required_fields.append(field_key)

        missing_required = [field for field in required_fields if not step_data.get(field)]

        if missing_required:
            logger.warning(f"[INPUT STEP] Missing required fields: {missing_required}")
            return StepResult(
                step_id=step.step_id, success=False, error=f"Missing required fields: {', '.join(missing_required)}"
            )

        # All validations passed - store data and advance
        if step_data:
            session.collected_config.update(step_data)
        session.current_step_index += 1
        logger.info(f"[INPUT STEP] Step completed, advancing to step {session.current_step_index}")
        return StepResult(step_id=step.step_id, success=True, next_step_index=session.current_step_index)

    def _execute_confirm_step(self, session: AdapterConfigSession, step: ConfigurationStep) -> StepResult:
        """Execute a confirm step."""
        session.current_step_index += 1
        return StepResult(
            step_id=step.step_id,
            success=True,
            data={"config_summary": session.collected_config},
            next_step_index=session.current_step_index,
        )

    async def _execute_device_auth_step(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Execute a device authorization (RFC 8628) step.

        Device auth flow:
        1. First call: Initiate device auth, return user_code and verification_uri
        2. Subsequent calls with poll=true: Poll for completion
        3. On completion: Store tokens/keys and advance
        """
        logger.info(f"[DEVICE_AUTH STEP] Executing for session {session.session_id}")
        logger.debug(f"[DEVICE_AUTH STEP] step_data keys: {list(step_data.keys()) if step_data else 'None'}")

        # Store portal URL if provided
        if "portal_url" in step_data:
            session.collected_config["portal_url"] = step_data["portal_url"]

        # Check if we're polling for completion
        if step_data.get("poll") and session.collected_config.get("device_code"):
            logger.info("[DEVICE_AUTH STEP] Polling for device auth completion")
            # Call adapter's poll method (uses handle_oauth_callback for compatibility)
            try:
                result = await adapter.handle_oauth_callback(
                    code=session.collected_config["device_code"],
                    state=session.session_id,
                    base_url=session.collected_config.get("portal_url", ""),
                )
                if result.get("status") == "complete":
                    session.collected_config["device_auth_result"] = result
                    session.status = SessionStatus.ACTIVE
                    session.current_step_index += 1
                    logger.info("[DEVICE_AUTH STEP] Authorization complete!")
                    return StepResult(
                        step_id=step.step_id,
                        success=True,
                        data={"status": "complete", "result": result},
                        next_step_index=session.current_step_index,
                    )
                elif result.get("status") == "pending":
                    return StepResult(
                        step_id=step.step_id,
                        success=True,
                        data={"status": "pending"},
                        awaiting_callback=True,
                    )
                else:
                    return StepResult(
                        step_id=step.step_id,
                        success=False,
                        error=result.get("error", "Device authorization failed"),
                    )
            except Exception as e:
                logger.error(f"[DEVICE_AUTH STEP] Poll error: {e}")
                return StepResult(step_id=step.step_id, success=False, error=str(e))

        # Initial request: Initiate device auth
        portal_url = session.collected_config.get("portal_url", "")
        if not portal_url:
            return StepResult(
                step_id=step.step_id,
                success=False,
                error="No portal_url provided. Please select a CIRISNode first.",
            )

        try:
            # Use get_oauth_url to initiate device auth (returns verification URL with user code)
            auth_data = await adapter.get_oauth_url(
                base_url=portal_url,
                state=session.session_id,
            )

            # If adapter returns a dict (device auth data) vs string (OAuth URL)
            if isinstance(auth_data, dict):
                session.collected_config["device_code"] = auth_data.get("device_code")
                session.collected_config["user_code"] = auth_data.get("user_code")
                session.status = SessionStatus.AWAITING_OAUTH  # Reuse status
                return StepResult(
                    step_id=step.step_id,
                    success=True,
                    data={
                        "verification_uri": auth_data.get("verification_uri_complete"),
                        "user_code": auth_data.get("user_code"),
                        "expires_in": auth_data.get("expires_in", 900),
                        "interval": auth_data.get("interval", 5),
                    },
                    awaiting_callback=True,
                )
            else:
                # String URL returned - treat as verification URI
                session.status = SessionStatus.AWAITING_OAUTH
                return StepResult(
                    step_id=step.step_id,
                    success=True,
                    data={"verification_uri": auth_data},
                    awaiting_callback=True,
                )

        except Exception as e:
            logger.error(f"[DEVICE_AUTH STEP] Initiation error: {e}")
            return StepResult(step_id=step.step_id, success=False, error=str(e))

    async def _execute_step_type(
        self,
        session: AdapterConfigSession,
        step: ConfigurationStep,
        adapter: ConfigurableAdapterProtocol,
        step_data: Dict[str, Any],
    ) -> StepResult:
        """Execute step based on its type."""
        if step.step_type == "discovery":
            return await self._execute_discovery_step(session, step, adapter, step_data)
        elif step.step_type == "oauth":
            return await self._execute_oauth_step(session, step, adapter, step_data)
        elif step.step_type == "device_auth":
            return await self._execute_device_auth_step(session, step, adapter, step_data)
        elif step.step_type == "select":
            return await self._execute_select_step(session, step, adapter, step_data)
        elif step.step_type == "input":
            return self._execute_input_step(session, step, step_data)
        elif step.step_type == "confirm":
            return self._execute_confirm_step(session, step)

        return StepResult(step_id=step.step_id, success=False, error=f"Unknown step type: {step.step_type}")

    async def complete_session(self, session_id: str) -> bool:
        """Complete the configuration and apply it to the adapter.

        Args:
            session_id: Session identifier

        Returns:
            True if configuration was applied successfully, False otherwise
        """
        session = self.get_session(session_id)
        if not session:
            return False

        adapter = self._adapter_instances.get(session.adapter_type)
        if not adapter:
            return False

        # Validate configuration
        is_valid, error = await adapter.validate_config(session.collected_config)
        if not is_valid:
            logger.error(f"Config validation failed: {error}")
            session.status = SessionStatus.FAILED
            return False

        # Apply configuration
        success = await adapter.apply_config(session.collected_config)
        if success:
            session.status = SessionStatus.COMPLETED
            # Sanitize session_id before logging (user-controlled data)
            import hashlib

            session_hash = hashlib.sha256(session_id.encode()).hexdigest()[:8]
            logger.info(f"Configuration applied for session [id_hash:{session_hash}]")
        else:
            session.status = SessionStatus.FAILED

        return success

    def _is_session_expired(self, session: AdapterConfigSession) -> bool:
        """Check if a session has expired.

        Args:
            session: Session to check

        Returns:
            True if session has exceeded timeout
        """
        timeout = timedelta(minutes=self.SESSION_TIMEOUT_MINUTES)
        return datetime.now(timezone.utc) - session.updated_at > timeout

    def _generate_pkce_challenge(self, verifier: str) -> str:
        """Generate PKCE code challenge from verifier.

        Args:
            verifier: PKCE code verifier

        Returns:
            Base64 URL-encoded SHA256 hash of verifier
        """
        digest = hashlib.sha256(verifier.encode()).digest()
        return base64.urlsafe_b64encode(digest).decode().rstrip("=")

    def cleanup_expired_sessions(self) -> int:
        """Remove expired sessions from memory.

        Returns:
            Count of sessions that were removed
        """
        expired = [sid for sid, session in self._sessions.items() if self._is_session_expired(session)]
        for sid in expired:
            del self._sessions[sid]
        return len(expired)

    async def load_persisted_configs(self, config_service: Any) -> Dict[str, Dict[str, Any]]:
        """Load all persisted adapter configurations from the config service.

        Args:
            config_service: GraphConfigService instance

        Returns:
            Dictionary mapping adapter_type to config data
        """
        persisted_configs: Dict[str, Dict[str, Any]] = {}

        try:
            # List all configs with the adapter_config prefix
            all_configs = await config_service.list_configs(prefix="adapter_config:")

            for key, value in all_configs.items():
                # Key format: adapter_config:{adapter_type}:{adapter_id}
                parts = key.split(":")
                if len(parts) >= 3:
                    adapter_type = parts[1]
                    adapter_id = parts[2]

                    if adapter_type not in persisted_configs:
                        persisted_configs[adapter_type] = {}

                    # Store config by adapter_id
                    if isinstance(value, dict):
                        persisted_configs[adapter_type][adapter_id] = value
                    else:
                        persisted_configs[adapter_type][adapter_id] = {"value": value}

            logger.info(f"Loaded {len(persisted_configs)} persisted adapter configs")
            return persisted_configs

        except Exception as e:
            logger.error(f"Failed to load persisted configs: {e}")
            return {}

    async def remove_persisted_config(
        self,
        adapter_type: str,
        config_service: Any,
    ) -> bool:
        """Remove persisted configuration for an adapter type.

        Args:
            adapter_type: Type of adapter to remove config for
            config_service: GraphConfigService instance

        Returns:
            True if any configs were removed, False otherwise
        """
        try:
            # List all configs with the adapter_config:{adapter_type} prefix
            prefix = f"adapter_config:{adapter_type}:"
            all_configs = await config_service.list_configs(prefix=prefix)

            if not all_configs:
                logger.info("No persisted configs found for requested adapter type")
                return False

            # Remove each config by setting to None (or use delete if available)
            removed_count = 0
            for key in all_configs.keys():
                try:
                    # Set to None to effectively delete the config
                    await config_service.set_config(key, None, updated_by="admin")
                    removed_count += 1
                    logger.debug(f"Removed persisted config: {key}")
                except Exception as e:
                    logger.warning(f"Failed to remove config {key}: {e}")

            logger.info(f"Removed {removed_count} persisted configs for adapter")
            return removed_count > 0

        except Exception as e:
            logger.error(f"Failed to remove persisted config for adapter: {e}")
            return False
