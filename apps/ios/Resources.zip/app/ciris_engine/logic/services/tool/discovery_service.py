"""Multi-path adapter discovery service.

Extends the base AdapterLoader to scan multiple directories:
1. ciris_adapters/         - Built-in adapters
2. ~/ciris/adapters/       - User-installed adapters
3. .ciris/adapters/        - Workspace-local adapters
4. CIRIS_EXTRA_ADAPTERS    - Additional paths from env var

Filters discovered adapters by tool eligibility.
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Type, cast

from ciris_engine.logic.runtime.adapter_loader import AdapterLoader
from ciris_engine.schemas.adapters.discovery import AdapterAvailabilityStatus, AdapterDiscoveryReport
from ciris_engine.schemas.adapters.tools import InstallStep, ToolInfo
from ciris_engine.schemas.runtime.manifest import ServiceDeclaration, ServiceManifest

from .eligibility_checker import EligibilityResult, ToolEligibilityChecker

logger = logging.getLogger(__name__)


@dataclass
class IneligibleAdapterInfo:
    """Information about an adapter that was discovered but is not eligible."""

    name: str
    manifest: ServiceManifest
    eligibility: EligibilityResult
    tools: List[ToolInfo] = field(default_factory=list)
    source_path: Optional[str] = None


class AdapterDiscoveryService:
    """Auto-discovers adapters from multiple paths with eligibility filtering.

    Discovery paths (in priority order):
    1. ciris_adapters/ relative to ciris_engine (works on Android)
    2. ciris_adapters/ relative to cwd (works on desktop)
    3. ~/ciris/adapters/       - User-installed adapters
    4. .ciris/adapters/        - Workspace-local adapters
    5. CIRIS_EXTRA_ADAPTERS    - Colon-separated additional paths
    """

    # Standard discovery paths
    # On Android, ciris_adapters is bundled alongside ciris_engine, so we find it
    # relative to this file's location (ciris_engine/logic/services/tool/)
    DISCOVERY_PATHS = [
        Path(__file__).parent.parent.parent.parent / "ciris_adapters",  # Relative to ciris_engine (Android)
        Path("ciris_adapters"),  # Built-in (desktop)
        Path.home() / "ciris" / "adapters",  # User
        Path(".ciris") / "adapters",  # Workspace
    ]

    def __init__(
        self,
        eligibility_checker: Optional[ToolEligibilityChecker] = None,
        extra_paths: Optional[List[Path]] = None,
    ):
        """Initialize the discovery service.

        Args:
            eligibility_checker: Checker for tool eligibility. If None, no filtering.
            extra_paths: Additional paths to scan beyond the standard ones.
        """
        self.checker = eligibility_checker or ToolEligibilityChecker()
        self.extra_paths = extra_paths or []

        # Why a given adapter's tools could not be enumerated (#945).
        # "provides no tools", "instantiation failed: <what>" and "needs live
        # collaborators" are three different answers, and collapsing all of
        # them to (None, None) is what left the first-run wizard telling an
        # operator only "unavailable" for wallet and home_assistant — the two
        # adapters whose tools an operator would most want disclosed.
        self._enumeration_failures: Dict[str, str] = {}

        # Parse CIRIS_EXTRA_ADAPTERS env var
        extra_from_env = os.environ.get("CIRIS_EXTRA_ADAPTERS", "")
        if extra_from_env:
            for path_str in extra_from_env.split(":"):
                path_str = path_str.strip()
                if path_str:
                    self.extra_paths.append(Path(path_str))

        # Create loaders for each path and track manifest->loader mapping
        self._loaders: List[AdapterLoader] = []
        self._manifest_loaders: Dict[str, AdapterLoader] = {}  # manifest_name -> loader
        for path in self._get_all_paths():
            if path.exists() and path.is_dir():
                self._loaders.append(AdapterLoader(services_dir=path))
                logger.info(f"AdapterDiscoveryService: scanning {path}")
            else:
                logger.debug(f"AdapterDiscoveryService: skipping non-existent {path}")

    def _get_all_paths(self) -> List[Path]:
        """Get all discovery paths in priority order."""
        return self.DISCOVERY_PATHS + self.extra_paths

    def discover_adapters(self) -> List[ServiceManifest]:
        """Discover all adapter manifests from all discovery paths.

        Falls back to importlib-based discovery on Android where filesystem
        paths don't exist (Chaquopy virtual filesystem).

        Returns:
            List of discovered ServiceManifest objects
        """
        all_manifests: List[ServiceManifest] = []
        seen_names: set[str] = set()

        # Try filesystem-based discovery first
        for loader in self._loaders:
            manifests = loader.discover_services()
            for manifest in manifests:
                # Skip duplicates (first occurrence wins)
                if manifest.module.name in seen_names:
                    logger.debug(f"Skipping duplicate adapter: {manifest.module.name} from {loader.services_dir}")
                    continue

                seen_names.add(manifest.module.name)
                all_manifests.append(manifest)
                # Track which loader handles this manifest
                self._manifest_loaders[manifest.module.name] = loader

        # If no loaders found adapters, try importlib-based discovery (Android/Chaquopy)
        if not all_manifests:
            importlib_manifests = self._discover_via_importlib()
            for manifest in importlib_manifests:
                if manifest.module.name not in seen_names:
                    seen_names.add(manifest.module.name)
                    all_manifests.append(manifest)

        logger.info(f"AdapterDiscoveryService: discovered {len(all_manifests)} adapters")
        return all_manifests

    def _discover_via_importlib(self) -> List[ServiceManifest]:
        """Discover adapters using importlib (for Android/Chaquopy virtual filesystem).

        Returns:
            List of discovered ServiceManifest objects
        """
        import importlib
        import importlib.resources as pkg_resources
        import json
        import pkgutil

        manifests: List[ServiceManifest] = []

        try:
            # Import the ciris_adapters package
            ciris_adapters = importlib.import_module("ciris_adapters")
        except ImportError:
            logger.debug("ciris_adapters package not found for importlib discovery")
            return manifests

        # Enumerate subpackages
        try:
            # Get the package path for iteration
            package_path = getattr(ciris_adapters, "__path__", None)
            if not package_path:
                logger.debug("ciris_adapters has no __path__, cannot enumerate")
                return manifests

            for importer, modname, ispkg in pkgutil.iter_modules(package_path):
                if not ispkg:
                    continue  # Only look at subpackages

                # Try to read manifest.json from this subpackage
                package_name = f"ciris_adapters.{modname}"
                try:
                    files = pkg_resources.files(package_name)
                    manifest_path = files.joinpath("manifest.json")
                    manifest_text = manifest_path.read_text(encoding="utf-8")
                    manifest_data = json.loads(manifest_text)

                    # Parse into ServiceManifest
                    manifest = ServiceManifest.model_validate(manifest_data)
                    manifests.append(manifest)
                    logger.debug(f"Discovered adapter via importlib: {modname}")
                except (FileNotFoundError, TypeError, AttributeError, json.JSONDecodeError) as e:
                    logger.debug(f"No valid manifest for {modname}: {e}")
                    continue
                except Exception as e:
                    logger.warning(f"Error reading manifest for {modname}: {e}")
                    continue

        except Exception as e:
            logger.warning(f"Error during importlib discovery: {e}")

        logger.info(f"AdapterDiscoveryService: discovered {len(manifests)} adapters via importlib")
        return manifests

    def load_service_class(self, manifest: ServiceManifest, class_path: str) -> Optional[Type[Any]]:
        """Load a service class from a discovered manifest.

        Args:
            manifest: The service manifest (must have been discovered first)
            class_path: Class path within the manifest

        Returns:
            The service class or None if not found
        """
        loader = self._manifest_loaders.get(manifest.module.name)
        if not loader:
            # Manifest wasn't discovered by us, try to find a loader for it
            logger.warning(
                f"Manifest '{manifest.module.name}' not in discovery cache, " "attempting to find appropriate loader"
            )
            # Try each loader to find one that can load this manifest
            for candidate_loader in self._loaders:
                try:
                    cls = candidate_loader.load_service_class(manifest, class_path)
                    if cls:
                        self._manifest_loaders[manifest.module.name] = candidate_loader
                        return cls
                except Exception:
                    continue

            # Fallback: Try importlib-based loading (for Android/Chaquopy)
            cls = self._load_class_via_importlib(manifest.module.name, class_path)
            if cls:
                logger.info(f"Loaded {class_path} via importlib for {manifest.module.name}")
                return cls

            return None

        return loader.load_service_class(manifest, class_path)

    def _load_class_via_importlib(self, _adapter_name: str, class_path: str) -> Optional[Type[Any]]:
        """Load a service class via importlib (for Android/Chaquopy).

        Args:
            _adapter_name: The adapter name (unused, kept for API compatibility)
            class_path: The class path (e.g., 'ciris_accord_metrics.services.AccordMetricsService')

        Returns:
            The service class or None if not found
        """
        import importlib

        try:
            # Parse the class path - it's relative to ciris_adapters
            # e.g., "ciris_accord_metrics.services.AccordMetricsService"
            parts = class_path.rsplit(".", 1)
            if len(parts) != 2:
                logger.debug(f"Invalid class path format: {class_path}")
                return None

            module_path, class_name = parts
            # Prepend ciris_adapters if not already there
            if not module_path.startswith("ciris_adapters."):
                full_module_path = f"ciris_adapters.{module_path}"
            else:
                full_module_path = module_path

            module = importlib.import_module(full_module_path)
            cls = getattr(module, class_name, None)
            if cls:
                logger.debug(f"Loaded {class_name} from {full_module_path} via importlib")
                return cast(Type[Any], cls)

        except ImportError as e:
            logger.debug(f"Failed to import {class_path} via importlib: {e}")
        except Exception as e:
            logger.debug(f"Error loading {class_path} via importlib: {e}")

        return None

    def get_eligible_adapters(self, disabled_adapters: Optional[List[str]] = None) -> List[ServiceManifest]:
        """Get adapters whose tools all pass eligibility checks.

        An adapter is eligible if ALL of its tools are eligible AND
        the adapter allows auto-loading (doesn't require consent/opt-in).

        Args:
            disabled_adapters: List of adapter names to exclude

        Returns:
            List of eligible ServiceManifest objects
        """
        disabled = set(disabled_adapters or [])
        eligible: List[ServiceManifest] = []

        for manifest in self.discover_adapters():
            if manifest.module.name in disabled:
                logger.info(f"Adapter '{manifest.module.name}' disabled by config")
                continue

            # Check manifest flags - skip adapters that require explicit enablement
            skip_reason = self._should_skip_for_auto_load(manifest)
            if skip_reason:
                logger.info(f"Adapter skipped for auto-load: {skip_reason}")
                continue

            eligible.append(manifest)
            logger.debug(f"Adapter '{manifest.module.name}' eligible")

        return eligible

    async def load_eligible_adapters(
        self,
        disabled_adapters: Optional[List[str]] = None,
        service_dependencies: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Load adapters whose tool requirements are satisfied.

        Discovers adapters, instantiates services, checks eligibility via
        get_all_tool_info(), and returns only those that pass.

        Args:
            disabled_adapters: Adapter names to exclude from loading
            service_dependencies: Dict of kwargs to pass when instantiating
                services (bus_manager, memory_service, etc.)

        Returns:
            Dict of adapter_name -> service_instance for eligible adapters
        """
        eligible, _ = await self.load_adapters_with_status(disabled_adapters, service_dependencies)
        return eligible

    async def _process_adapter_services(
        self,
        manifest: "ServiceManifest",
        deps: Dict[str, Any],
        eligible_services: Dict[str, Any],
        ineligible_adapters: List[IneligibleAdapterInfo],
    ) -> None:
        """Process all services in an adapter manifest."""
        adapter_name = manifest.module.name
        for service_def in manifest.services:
            try:
                service, ineligible_info = await self._instantiate_and_check_with_info(manifest, service_def, deps)
                if service:
                    eligible_services[adapter_name] = service
                    logger.info(f"[AUTO-LOAD] Eligible adapter: {adapter_name}")
                elif ineligible_info:
                    ineligible_adapters.append(ineligible_info)
                    logger.info(
                        f"[AUTO-LOAD] Adapter '{adapter_name}' not eligible: {ineligible_info.eligibility.reason}"
                    )
            except Exception as e:
                logger.debug(f"[AUTO-LOAD] Failed to check adapter '{adapter_name}': {e}")

    def _should_skip_for_auto_load(self, manifest: ServiceManifest) -> Optional[str]:
        """Check if manifest should be skipped during auto-load.

        Adapters are skipped if they have:
        - auto_load=False (require explicit enablement via setup wizard)
        - requires_consent=True (require user consent)
        - opt_in_required=True (require explicit opt-in)

        These adapters should only be loaded via the post-setup adapter loading
        path (load_post_setup_adapters_for_resume) after the user enables them.

        Returns:
            Skip reason string if should skip, None otherwise
        """
        module_name = manifest.module.name

        # Check auto_load flag (defaults to True if not specified)
        if hasattr(manifest.module, "auto_load") and not manifest.module.auto_load:
            return f"auto_load=False (requires explicit enablement): {module_name}"

        # Check requires_consent flag (defaults to False if not specified)
        if hasattr(manifest.module, "requires_consent") and manifest.module.requires_consent:
            return f"requires_consent=True (requires user consent): {module_name}"

        # Check opt_in_required flag (defaults to False if not specified)
        if hasattr(manifest.module, "opt_in_required") and manifest.module.opt_in_required:
            return f"opt_in_required=True (requires explicit opt-in): {module_name}"

        return None

    async def load_adapters_with_status(
        self,
        disabled_adapters: Optional[List[str]] = None,
        service_dependencies: Optional[Dict[str, Any]] = None,
    ) -> Tuple[Dict[str, Any], List[IneligibleAdapterInfo]]:
        """Load adapters and return both eligible services and ineligible info."""
        disabled = set(disabled_adapters or [])
        deps = service_dependencies or {}

        if self.checker and not self.checker.config_service and "config_service" in deps:
            self.checker.config_service = deps["config_service"]

        eligible_services: Dict[str, Any] = {}
        ineligible_adapters: List[IneligibleAdapterInfo] = []

        for manifest in self.discover_adapters():
            if manifest.module.name in disabled:
                logger.info(f"[AUTO-LOAD] Skipping disabled adapter: {manifest.module.name}")
                continue

            # Check manifest flags - skip adapters that require explicit enablement
            skip_reason = self._should_skip_for_auto_load(manifest)
            if skip_reason:
                logger.info(f"[AUTO-LOAD] Skipping adapter: {skip_reason}")
                continue

            await self._process_adapter_services(manifest, deps, eligible_services, ineligible_adapters)

        logger.info(
            f"[AUTO-LOAD] Loaded {len(eligible_services)} eligible, {len(ineligible_adapters)} ineligible adapters"
        )
        return eligible_services, ineligible_adapters

    async def _instantiate_and_check(
        self,
        manifest: ServiceManifest,
        service_def: ServiceDeclaration,
        deps: Dict[str, Any],
    ) -> Optional[Any]:
        """Instantiate a service and check tool eligibility.

        Returns:
            Service instance if eligible, None otherwise
        """
        service, _ = await self._instantiate_and_check_with_info(manifest, service_def, deps)
        return service

    async def _instantiate_and_check_with_info(
        self,
        manifest: ServiceManifest,
        service_def: ServiceDeclaration,
        deps: Dict[str, Any],
    ) -> Tuple[Optional[Any], Optional[IneligibleAdapterInfo]]:
        """Instantiate a service and check tool eligibility, returning ineligible info.

        Returns:
            Tuple of (service_instance or None, IneligibleAdapterInfo or None)
        """
        adapter_name = manifest.module.name
        loader = self._manifest_loaders.get(adapter_name)
        source_path = str(loader.services_dir) if loader else None

        service = self._try_instantiate_service(manifest, service_def, deps, adapter_name)
        if not service:
            # Reason was recorded by _try_instantiate_service (#945).
            return None, None

        # Check if service has get_all_tool_info (tool service)
        if not hasattr(service, "get_all_tool_info"):
            logger.debug(f"Adapter '{adapter_name}' has no get_all_tool_info, assuming eligible")
            return service, None

        # Get tool info and check eligibility
        try:
            tools = await service.get_all_tool_info()
            if not tools:
                return service, None

            combined_result = self._check_tools_eligibility(tools)
            if combined_result.eligible:
                return service, None

            ineligible_info = IneligibleAdapterInfo(
                name=adapter_name,
                manifest=manifest,
                eligibility=combined_result,
                tools=tools,
                source_path=source_path,
            )
            return None, ineligible_info

        except Exception as e:
            logger.debug(f"Error checking eligibility for {adapter_name}: {e}")
            self._record_enumeration_failure(adapter_name, f"its tool list could not be read ({type(e).__name__}: {e})")
            return None, None

    def _try_instantiate_service(
        self,
        manifest: ServiceManifest,
        service_def: ServiceDeclaration,
        deps: Dict[str, Any],
        adapter_name: str,
    ) -> Optional[Any]:
        """Try to instantiate a service with deps, falling back to no-args."""
        service_class = self.load_service_class(manifest, service_def.class_path)
        if not service_class:
            self._record_enumeration_failure(adapter_name, "its tool service class could not be imported")
            return None

        try:
            return service_class(**deps)
        except TypeError:
            try:
                return service_class()
            except Exception as e:
                logger.debug(f"Cannot instantiate {adapter_name}: {e}")
                # The reason, not just the fact (#945). A TypeError on the
                # no-args path means the constructor requires collaborators
                # this context cannot supply — which is "enumerable after
                # load", a different and much more useful thing to tell an
                # operator than "unavailable".
                if isinstance(e, TypeError):
                    reason = "its tool service needs runtime collaborators, so its tools are listed once it loads"
                else:
                    reason = f"its tool service could not be constructed ({type(e).__name__}: {e})"
                self._record_enumeration_failure(adapter_name, reason)
                return None

    def _record_enumeration_failure(self, adapter_name: str, reason: str) -> None:
        """Remember why an adapter's tools could not be listed."""
        self._enumeration_failures[adapter_name] = reason

    def enumeration_failure_reason(self, adapter_name: str) -> Optional[str]:
        """Why this adapter's tools could not be enumerated, if they could not.

        Consumed by the first-run tool disclosure so it can say *why* rather
        than only *that* — an operator deciding what to enable is owed the
        difference between "needs credentials first" and "is broken".
        """
        return self._enumeration_failures.get(adapter_name)

    def _check_tools_eligibility(self, tools: List[ToolInfo]) -> EligibilityResult:
        """Check eligibility of all tools and return combined result."""
        combined = EligibilityResult(eligible=True)
        install_hints: List[InstallStep] = []

        for tool in tools:
            result = self.checker.check_eligibility(tool)
            if result.eligible:
                continue

            combined.eligible = False
            combined.missing_binaries.extend(result.missing_binaries)
            combined.missing_env_vars.extend(result.missing_env_vars)
            combined.missing_config.extend(result.missing_config)
            if result.platform_mismatch:
                combined.platform_mismatch = True
            install_hints.extend(result.install_hints)

        if not combined.eligible:
            combined.reason = self._build_eligibility_reason(combined)
            combined.install_hints = install_hints

        return combined

    def _build_eligibility_reason(self, result: EligibilityResult) -> str:
        """Build a human-readable reason string from eligibility result."""
        reasons = []
        if result.missing_binaries:
            reasons.append(f"missing binaries: {', '.join(set(result.missing_binaries))}")
        if result.missing_env_vars:
            reasons.append(f"missing env vars: {', '.join(set(result.missing_env_vars))}")
        if result.missing_config:
            reasons.append(f"missing config: {', '.join(set(result.missing_config))}")
        if result.platform_mismatch:
            reasons.append("platform not supported")
        return "; ".join(reasons) if reasons else "unknown"

    def check_tool_eligibility(self, tool_info: ToolInfo) -> EligibilityResult:
        """Check if a single tool is eligible.

        Args:
            tool_info: Tool to check

        Returns:
            EligibilityResult with details
        """
        return self.checker.check_eligibility(tool_info)

    def filter_eligible_tools(self, tools: List[ToolInfo]) -> List[ToolInfo]:
        """Filter tools to only those that are eligible.

        Args:
            tools: List of tool infos

        Returns:
            List of eligible tools
        """
        return self.checker.filter_eligible_tools(tools)

    async def get_discovery_report(
        self,
        disabled_adapters: Optional[List[str]] = None,
        service_dependencies: Optional[Dict[str, Any]] = None,
    ) -> AdapterDiscoveryReport:
        """Get a full report of all discovered adapters with eligibility status.

        This is the main method for the GET /adapters/available endpoint.

        Args:
            disabled_adapters: Adapter names to exclude
            service_dependencies: Dependencies for service instantiation

        Returns:
            AdapterDiscoveryReport with eligible and ineligible adapters
        """
        eligible_services, ineligible_list = await self.load_adapters_with_status(
            disabled_adapters, service_dependencies
        )

        eligible_statuses: List[AdapterAvailabilityStatus] = []
        ineligible_statuses: List[AdapterAvailabilityStatus] = []

        # Build eligible adapter statuses
        for adapter_name, service in eligible_services.items():
            tools: List[ToolInfo] = []
            if hasattr(service, "get_all_tool_info"):
                try:
                    tools = await service.get_all_tool_info()
                except Exception:
                    pass

            # Get source path from loader
            loader = self._manifest_loaders.get(adapter_name)
            source_path = str(loader.services_dir) if loader else None
            is_builtin = source_path and "ciris_adapters" in source_path

            eligible_statuses.append(
                AdapterAvailabilityStatus(
                    name=adapter_name,
                    eligible=True,
                    tools=tools,
                    source_path=source_path,
                    is_builtin=is_builtin,
                )
            )

        # Build ineligible adapter statuses
        for info in ineligible_list:
            is_builtin = info.source_path and "ciris_adapters" in info.source_path if info.source_path else False
            has_hints = len(info.eligibility.install_hints) > 0

            ineligible_statuses.append(
                AdapterAvailabilityStatus(
                    name=info.name,
                    eligible=False,
                    eligibility_reason=info.eligibility.reason,
                    missing_binaries=list(set(info.eligibility.missing_binaries)),
                    missing_env_vars=list(set(info.eligibility.missing_env_vars)),
                    missing_config=list(set(info.eligibility.missing_config)),
                    platform_supported=not info.eligibility.platform_mismatch,
                    can_install=has_hints,
                    install_hints=info.eligibility.install_hints,
                    tools=info.tools,
                    source_path=info.source_path,
                    is_builtin=is_builtin,
                )
            )

        total = len(eligible_statuses) + len(ineligible_statuses)
        installable = sum(1 for s in ineligible_statuses if s.can_install)

        return AdapterDiscoveryReport(
            eligible=eligible_statuses,
            ineligible=ineligible_statuses,
            total_discovered=total,
            total_eligible=len(eligible_statuses),
            total_installable=installable,
        )

    async def get_adapter_eligibility(
        self,
        adapter_name: str,
        service_dependencies: Optional[Dict[str, Any]] = None,
    ) -> Optional[AdapterAvailabilityStatus]:
        """Get eligibility status for a specific adapter.

        Args:
            adapter_name: Name of the adapter to check
            service_dependencies: Dependencies for service instantiation

        Returns:
            AdapterAvailabilityStatus or None if adapter not found
        """
        deps = service_dependencies or {}
        manifest = self._find_manifest_by_name(adapter_name)
        if not manifest:
            return None

        source_path, is_builtin = self._get_adapter_source_info(adapter_name)

        for service_def in manifest.services:
            service, ineligible_info = await self._instantiate_and_check_with_info(manifest, service_def, deps)

            if service:
                return await self._build_eligible_status(adapter_name, service, source_path, is_builtin)

            if ineligible_info:
                return self._build_ineligible_status(adapter_name, ineligible_info, source_path, is_builtin)

        return None

    def _find_manifest_by_name(self, adapter_name: str) -> Optional[ServiceManifest]:
        """Find a manifest by adapter name."""
        for manifest in self.discover_adapters():
            if manifest.module.name == adapter_name:
                return manifest
        return None

    def _get_adapter_source_info(self, adapter_name: str) -> Tuple[Optional[str], bool]:
        """Get source path and builtin flag for an adapter."""
        loader = self._manifest_loaders.get(adapter_name)
        source_path = str(loader.services_dir) if loader else None
        is_builtin = bool(source_path and "ciris_adapters" in source_path)
        return source_path, is_builtin

    async def _build_eligible_status(
        self, adapter_name: str, service: Any, source_path: Optional[str], is_builtin: bool
    ) -> AdapterAvailabilityStatus:
        """Build AdapterAvailabilityStatus for an eligible adapter."""
        tools = await self._get_service_tools(service)
        return AdapterAvailabilityStatus(
            name=adapter_name,
            eligible=True,
            tools=tools,
            source_path=source_path,
            is_builtin=is_builtin,
        )

    def _build_ineligible_status(
        self, adapter_name: str, info: IneligibleAdapterInfo, source_path: Optional[str], is_builtin: bool
    ) -> AdapterAvailabilityStatus:
        """Build AdapterAvailabilityStatus for an ineligible adapter."""
        has_hints = len(info.eligibility.install_hints) > 0
        return AdapterAvailabilityStatus(
            name=adapter_name,
            eligible=False,
            eligibility_reason=info.eligibility.reason,
            missing_binaries=list(set(info.eligibility.missing_binaries)),
            missing_env_vars=list(set(info.eligibility.missing_env_vars)),
            missing_config=list(set(info.eligibility.missing_config)),
            platform_supported=not info.eligibility.platform_mismatch,
            can_install=has_hints,
            install_hints=info.eligibility.install_hints,
            tools=info.tools,
            source_path=source_path,
            is_builtin=is_builtin,
        )

    async def _get_service_tools(self, service: Any) -> List[ToolInfo]:
        """Get tools from a service if available."""
        if not hasattr(service, "get_all_tool_info"):
            return []
        try:
            tools: List[ToolInfo] = await service.get_all_tool_info()
            return tools
        except Exception:
            return []
