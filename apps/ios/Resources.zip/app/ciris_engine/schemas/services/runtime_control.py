"""
Runtime control service schemas for type-safe operations.

This module provides Pydantic models for the runtime control service,
ensuring full type safety and validation.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

from pydantic import BaseModel, ConfigDict, Field

from ciris_engine.schemas.audit.hash_chain import AuditEntryResult
from ciris_engine.schemas.conscience.core import EpistemicData
from ciris_engine.schemas.conscience.results import ConscienceResult
from ciris_engine.schemas.dma.core import DMAContext
from ciris_engine.schemas.dma.results import (
    ActionSelectionDMAResult,
    CSDMAResult,
    DSDMAResult,
    EthicalDMAResult,
    IDMAResult,
)
from ciris_engine.schemas.handlers.schemas import HandlerResult
from ciris_engine.schemas.processors.states import AgentState
from ciris_engine.schemas.runtime.system_context import SystemSnapshot
from ciris_engine.schemas.types import ConfigMapping, ConfigValue, JSONDict, SerializedModel

# Type aliases for configuration values
ConfigItem = Tuple[str, ConfigValue]


class ConfigDictMixin:
    """Mixin providing standard config dict access methods.

    Classes using this mixin must have a 'configs: ConfigMapping' field.
    DRY pattern to avoid code duplication across classes with config fields.
    """

    configs: ConfigMapping  # Type hint for IDEs

    def get(self, key: str, default: Optional[ConfigValue] = None) -> Optional[ConfigValue]:
        """Get a configuration value with optional default."""
        return self.configs.get(key, default)

    def set(self, key: str, value: ConfigValue) -> None:
        """Set a configuration value."""
        self.configs[key] = value

    def update(self, values: ConfigMapping) -> None:
        """Update multiple configuration values."""
        self.configs.update(values)

    def keys(self) -> List[str]:
        """Get all configuration keys."""
        return list(self.configs.keys())


# Field description constants (DRY principle - avoid duplication)
DESC_THOUGHT_ID = "Thought being processed"
DESC_TIMESTAMP = "Event timestamp"
DESC_PARENT_TASK = "Parent task if any"
DESC_CONSCIENCE_PASSED = "Whether conscience checks passed"
DESC_CONSCIENCE_OVERRIDE_REASON = "Reason if conscience overrode action"
DESC_AUDIT_SEQUENCE = "Sequence number in audit hash chain"
DESC_AUDIT_HASH = "Hash of audit entry (tamper-evident)"
DESC_AUDIT_SIGNATURE = "Cryptographic signature of audit entry"
DESC_THRESHOLD_USED = "Threshold used"
DESC_ACTION_PARAMETERS = "Action parameters (content for SPEAK, etc.)"
DESC_ENTROPY_REASON = "Entropy check result message"
DESC_COHERENCE_REASON = "Coherence check result message"

# Description constants for propagated coherence/entropy fields
DESC_COHERENCE_PASSED_PROPAGATED = "Whether coherence check passed (None for exempt actions)"
DESC_COHERENCE_SCORE_PROPAGATED = "Coherence score 0-1 (None for exempt actions)"
DESC_ENTROPY_PASSED_PROPAGATED = "Whether entropy check passed (None for exempt actions)"
DESC_ENTROPY_SCORE_PROPAGATED = "Entropy score 0-1 (None for exempt actions)"


class PropagatedCoherenceEntropyMixin(BaseModel):
    """Mixin for coherence/entropy data propagated from FINALIZE_ACTION to ACTION_COMPLETE.

    Non-exempt actions: SPEAK, TOOL, PONDER, MEMORIZE
    Exempt actions: RECALL, TASK_COMPLETE, OBSERVE, DEFER, REJECT (these skip ethical faculties)

    This mixin provides DRY fields for classes that need propagated conscience check results.
    """

    model_config = ConfigDict(extra="ignore")

    coherence_passed: Optional[bool] = Field(None, description=DESC_COHERENCE_PASSED_PROPAGATED)
    coherence_score: Optional[float] = Field(None, description=DESC_COHERENCE_SCORE_PROPAGATED)
    coherence_threshold: Optional[float] = Field(None, description="Coherence threshold used")
    coherence_reason: Optional[str] = Field(None, description=DESC_COHERENCE_REASON)
    entropy_passed: Optional[bool] = Field(None, description=DESC_ENTROPY_PASSED_PROPAGATED)
    entropy_score: Optional[float] = Field(None, description=DESC_ENTROPY_SCORE_PROPAGATED)
    entropy_threshold: Optional[float] = Field(None, description="Entropy threshold used")
    entropy_reason: Optional[str] = Field(None, description=DESC_ENTROPY_REASON)


class StepPoint(str, Enum):
    """Points where single-stepping can pause in the H3ERE pipeline.

    **This enum is the source of truth for the observable step points.** Every
    member below has a live ``@streaming_step`` decorator site in production, so
    the set is what the pipeline actually emits rather than what a document says
    it emits. Anything citing this — an evidence-registry row, a Constitution
    claim, a client that renders the pipeline — should point at the enum rather
    than restate a count, because a hardcoded number is exactly what rotted here:
    the comment here used to restate a total that had already drifted from the
    members below, and the inline stage labels skip values, so anyone counting
    them reached a different answer again — none of which failed, because
    nothing asserted it.

    Locked by ``tests/ciris_engine/schemas/services/test_step_point_evidence.py``.
    """

    # Setup, core, optional recursive re-entry, and completion. The trailing
    # numbers are historical pipeline stage labels: deliberately non-contiguous,
    # not an ordering, and not a total. Count the members, never these.
    START_ROUND = "start_round"  # 0) Setup: Tasks → Thoughts → Round Queue → Ready for context
    GATHER_CONTEXT = "gather_context"  # 1) Build context for DMA processing
    PERFORM_DMAS = "perform_dmas"  # 2) Execute multi-perspective DMAs
    PERFORM_ASPDMA = "perform_aspdma"  # 3) LLM-powered action selection
    CONSCIENCE_EXECUTION = "conscience_execution"  # 4) Ethical safety validation
    RECURSIVE_ASPDMA = "recursive_aspdma"  # 3B) Optional: Re-run action selection if conscience failed
    RECURSIVE_CONSCIENCE = "recursive_conscience"  # 4B) Optional: Re-validate if recursive action failed
    FINALIZE_ACTION = "finalize_action"  # 5) Final action determination
    PERFORM_ACTION = "perform_action"  # 6) Dispatch action to handler
    ACTION_COMPLETE = "action_complete"  # 9) Action execution completed
    ROUND_COMPLETE = "round_complete"  # 10) Processing round completed


class ReasoningEvent(str, Enum):
    """Reasoning stream events - 9 result events.

    Pipeline events (always emitted):
    - THOUGHT_START: Thought begins processing
    - SNAPSHOT_AND_CONTEXT: System snapshot + gathered context
    - DMA_RESULTS: 3 DMA results (CSDMA, DSDMA, PDMA)
    - IDMA_RESULT: Intuition DMA fragility check
    - ASPDMA_RESULT: Selected action + rationale
    - CONSCIENCE_RESULT: Conscience evaluation + final action
    - ACTION_RESULT: Action execution outcome + audit trail

    Sub-pipeline events:
    - LLM_CALL: Per-provider-call observation. Emitted by LLMBus._execute_llm_call
      after every individual LLM invocation (success or failure). Multiple LLM_CALL
      events fire under each pipeline event (one per call the DMA / ASPDMA /
      conscience handler issues). This is the level needed to debug tail latency
      and per-call failure modes that thought-level aggregates hide.
      See FSD/TRACE_EVENT_LOG_PERSISTENCE.md §5.2.

    Optional events (emitted when applicable):
    - TSASPDMA_RESULT: Tool-Specific ASPDMA (emitted when TOOL action selected)
    """

    THOUGHT_START = "thought_start"  # 0) Thought begins processing - metadata and content
    SNAPSHOT_AND_CONTEXT = "snapshot_and_context"  # 1) System snapshot + gathered context
    DMA_RESULTS = "dma_results"  # 2) 3 DMA results (CSDMA, DSDMA, PDMA)
    IDMA_RESULT = "idma_result"  # 3) Intuition DMA fragility check (always emitted)
    ASPDMA_RESULT = "aspdma_result"  # 4) Selected action + rationale
    TSASPDMA_RESULT = "tsaspdma_result"  # 4.5a) DEPRECATED: Tool-Specific ASPDMA legacy event
                                         # Kept emitting alongside VERB_SECOND_PASS_RESULT during the
                                         # transition window per FSD/TRACE_EVENT_LOG_PERSISTENCE.md §10
                                         # phase 0 gate. Remove after lens stops reading it.
    VERB_SECOND_PASS_RESULT = "verb_second_pass_result"  # 4.5) Generic verb-specific second pass
                                         # (FSD/TRACE_EVENT_LOG_PERSISTENCE.md §4). Replaces per-verb
                                         # event types — single event with `verb` discriminator and
                                         # verb-specific data so future verbs (MEMORIZE, OBSERVE, ...)
                                         # adding a second pass don't multiply the schema. Currently
                                         # fires for TOOL (replaces TSASPDMA_RESULT) and DEFER
                                         # (closes the existing no-event asymmetry on DSASPDMA).
    CONSCIENCE_RESULT = "conscience_result"  # 5) Conscience evaluation + final action
    ACTION_RESULT = "action_result"  # 6) Action execution outcome + audit trail
    LLM_CALL = "llm_call"  # *) Per-provider-call observation (every LLM invocation, success+failure)


class StepDuration(str, Enum):
    """How long to wait before building the round queue."""

    IMMEDIATE = "immediate"  # 10 seconds
    SHORT = "short"  # 20 seconds
    NORMAL = "normal"  # 30 seconds
    LONG = "long"  # 60 seconds


# Map durations to seconds
STEP_DURATION_SECONDS = {
    StepDuration.IMMEDIATE: 10.0,
    StepDuration.SHORT: 20.0,
    StepDuration.NORMAL: 30.0,
    StepDuration.LONG: 60.0,
}


class CircuitBreakerState(str, Enum):
    """States of a circuit breaker."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreakerStatus(BaseModel):
    """Status information for a circuit breaker."""

    model_config = ConfigDict(defer_build=True)

    state: CircuitBreakerState = Field(..., description="Current state of the circuit breaker")
    failure_count: int = Field(0, description="Number of consecutive failures")
    last_failure_time: Optional[datetime] = Field(None, description="Time of last failure")
    last_success_time: Optional[datetime] = Field(None, description="Time of last success")
    half_open_retry_time: Optional[datetime] = Field(None, description="When to retry in half-open state")
    trip_threshold: int = Field(5, description="Number of failures before tripping")
    reset_timeout_seconds: float = Field(60.0, description="Seconds before attempting reset")
    service_name: str = Field(..., description="Name of the service this breaker protects")


class TraceContext(BaseModel):
    """OTLP-compatible trace context for step correlation."""

    model_config = ConfigDict(defer_build=True)

    trace_id: str = Field(..., description="Unique trace identifier")
    span_id: str = Field(..., description="Unique span identifier")
    parent_span_id: Optional[str] = Field(None, description="Parent span identifier")
    span_name: str = Field(..., description="Human-readable span name")
    operation_name: str = Field(..., description="Operation name for tracing")
    start_time_ns: int = Field(..., description="Start time in nanoseconds")
    end_time_ns: int = Field(..., description="End time in nanoseconds")
    duration_ns: int = Field(..., description="Duration in nanoseconds")
    span_kind: str = Field("internal", description="Span kind (internal, server, client, etc.)")


class SpanAttribute(BaseModel):
    """OTLP-compatible span attribute."""

    model_config = ConfigDict(defer_build=True)

    key: str = Field(..., description="Attribute key")
    value: JSONDict = Field(
        ..., description="Attribute value in OTLP format"
    )  # OTLP standard requires JSON-compatible dict


class ConfigValueMap(ConfigDictMixin, BaseModel):
    """Typed map for configuration values."""

    model_config = ConfigDict(defer_build=True)

    configs: ConfigMapping = Field(default_factory=dict, description="Configuration key-value pairs with typed values")

    def items(self) -> List[ConfigItem]:
        """Get all key-value pairs."""
        return list(self.configs.items())

    def values(self) -> List[ConfigValue]:
        """Get all configuration values."""
        return list(self.configs.values())


class TaskSelectionCriteria(ConfigDictMixin, BaseModel):
    """Criteria used for task selection in processing rounds."""

    model_config = ConfigDict(defer_build=True)

    max_priority: Optional[int] = Field(None, description="Maximum priority threshold")
    min_priority: Optional[int] = Field(None, description="Minimum priority threshold")
    max_age_hours: Optional[float] = Field(None, description="Maximum age in hours")
    channel_filter: Optional[str] = Field(None, description="Channel ID filter")
    task_type_filter: Optional[str] = Field(None, description="Task type filter")
    exclude_failed: bool = Field(True, description="Whether to exclude previously failed tasks")
    max_retry_count: int = Field(3, description="Maximum retry count for tasks")
    user_id_filter: Optional[str] = Field(None, description="User ID filter")
    batch_size: int = Field(10, description="Maximum number of tasks to select")
    configs: ConfigMapping = Field(
        default_factory=dict, description="Additional configuration key-value pairs with typed values"
    )

    def items(self) -> List[ConfigItem]:
        """Get all key-value pairs."""
        return list(self.configs.items())


class ServiceProviderUpdate(BaseModel):
    """Details of a service provider update."""

    model_config = ConfigDict(defer_build=True)

    service_type: str = Field(..., description="Type of service")
    old_priority: str = Field(..., description="Previous priority")
    new_priority: str = Field(..., description="New priority")
    old_priority_group: int = Field(..., description="Previous priority group")
    new_priority_group: int = Field(..., description="New priority group")
    old_strategy: str = Field(..., description="Previous selection strategy")
    new_strategy: str = Field(..., description="New selection strategy")


class ServicePriorityUpdateResponse(BaseModel):
    """Response from service priority update operation."""

    model_config = ConfigDict(defer_build=True)

    success: bool = Field(..., description="Whether the update succeeded")
    message: Optional[str] = Field(None, description="Success or error message")
    provider_name: str = Field(..., description="Name of the service provider")
    changes: Optional[ServiceProviderUpdate] = Field(None, description="Details of changes made")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    error: Optional[str] = Field(None, description="Error message if operation failed")


class CircuitBreakerResetResponse(BaseModel):
    """Response from circuit breaker reset operation."""

    model_config = ConfigDict(defer_build=True)

    success: bool = Field(..., description="Whether the reset succeeded")
    message: str = Field(..., description="Operation result message")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    service_type: Optional[str] = Field(None, description="Service type if specified")
    reset_count: Optional[int] = Field(None, description="Number of breakers reset")
    error: Optional[str] = Field(None, description="Error message if operation failed")


class ServiceProviderInfo(BaseModel):
    """Information about a registered service provider."""

    model_config = ConfigDict(defer_build=True)

    name: str = Field(..., description="Provider name")
    priority: str = Field(..., description="Priority level name")
    priority_group: int = Field(..., description="Priority group number")
    strategy: str = Field(..., description="Selection strategy")
    capabilities: Optional[ConfigMapping] = Field(None, description="Provider capabilities")
    metadata: Optional[ConfigMapping] = Field(None, description="Provider metadata")
    circuit_breaker_state: Optional[str] = Field(None, description="Circuit breaker state if available")


class ServiceRegistryInfoResponse(BaseModel):
    """Enhanced service registry information response."""

    model_config = ConfigDict(defer_build=True)

    total_services: int = Field(0, description="Total registered services")
    services_by_type: Dict[str, int] = Field(default_factory=dict, description="Count by service type")
    handlers: Dict[str, Dict[str, List[ServiceProviderInfo]]] = Field(
        default_factory=dict, description="Handlers and their services with details"
    )
    global_services: Optional[Dict[str, List[ServiceProviderInfo]]] = Field(
        None, description="Global services not tied to specific handlers"
    )
    healthy_services: int = Field(0, description="Number of healthy services")
    circuit_breaker_states: Dict[str, str] = Field(
        default_factory=dict, description="Circuit breaker states by service"
    )
    error: Optional[str] = Field(None, description="Error message if query failed")


class WAPublicKeyMap(BaseModel):
    """Map of Wise Authority IDs to their public keys."""

    model_config = ConfigDict(defer_build=True)

    keys: Dict[str, str] = Field(
        default_factory=dict, description="Mapping of WA ID to Ed25519 public key (PEM format)"
    )

    def add_key(self, wa_id: str, public_key_pem: str) -> None:
        """Add a WA public key."""
        self.keys[wa_id] = public_key_pem

    def get_key(self, wa_id: str) -> Optional[str]:
        """Get a WA public key by ID."""
        return self.keys.get(wa_id)

    def has_key(self, wa_id: str) -> bool:
        """Check if a WA ID has a registered key."""
        return wa_id in self.keys

    def clear(self) -> None:
        """Clear all keys."""
        self.keys.clear()

    def count(self) -> int:
        """Get the number of registered keys."""
        return len(self.keys)


class ConfigBackupData(BaseModel):
    """Data structure for configuration backups."""

    model_config = ConfigDict(defer_build=True)

    configs: ConfigMapping = Field(..., description="Backed up configuration values")
    backup_timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), description="When the backup was created"
    )
    backup_version: str = Field(..., description="Version of the configuration")
    backup_by: str = Field("RuntimeControlService", description="Who created the backup")

    def to_config_value(self) -> SerializedModel:
        """Convert to a format suitable for storage as a config value."""
        return {
            "configs": self.configs,
            "backup_timestamp": self.backup_timestamp.isoformat(),
            "backup_version": self.backup_version,
            "backup_by": self.backup_by,
        }

    @classmethod
    def from_config_value(cls, data: SerializedModel) -> "ConfigBackupData":
        """Create from a stored config value."""
        return cls(
            configs=data.get("configs", {}),
            backup_timestamp=datetime.fromisoformat(data["backup_timestamp"]),
            backup_version=data["backup_version"],
            backup_by=data.get("backup_by", "RuntimeControlService"),
        )


class QueueItemStatusReport(BaseModel):
    """
    Status report for a queue item.
    Used for runtime control service to report queue status.

    Note: This is distinct from ProcessingQueueItem in logic/processors/support/processing_queue.py
    which is the actual queue item used for thought processing.
    """

    model_config = ConfigDict(defer_build=True)

    item_id: str = Field(..., description="Unique identifier for the queue item")
    item_type: str = Field(..., description="Type of item (e.g., thought, task, message)")
    priority: int = Field(0, description="Processing priority (higher = more urgent)")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: Optional[datetime] = Field(None, description="When processing started")
    status: str = Field("pending", description="Item status: pending, processing, completed, failed")
    source: Optional[str] = Field(None, description="Source of the queue item")
    metadata: Dict[str, str | int | float | bool] = Field(default_factory=dict, description="Additional item metadata")


class QueuedThought(BaseModel):
    """A thought queued for processing in the next round."""

    model_config = ConfigDict(defer_build=True)

    thought_id: str = Field(..., description="Unique thought ID")
    thought_type: str = Field(..., description="Type of thought")
    source_task_id: str = Field(..., description="Source task ID")
    task_description: str = Field(..., description="Task description")
    created_at: datetime = Field(..., description="When thought was created")
    priority: int = Field(0, description="Processing priority")
    status: str = Field(..., description="Current status")


class QueuedTask(BaseModel):
    """A task that may generate thoughts."""

    model_config = ConfigDict(defer_build=True)

    task_id: str = Field(..., description="Unique task ID")
    description: str = Field(..., description="Task description")
    status: str = Field(..., description="Task status")
    channel_id: str = Field(..., description="Source channel")
    created_at: datetime = Field(..., description="When task was created")
    thoughts_generated: int = Field(0, description="Number of thoughts generated")


class ThoughtInPipeline(BaseModel):
    """Tracks a thought's position in the processing pipeline."""

    model_config = ConfigDict(defer_build=True)

    thought_id: str = Field(..., description="Unique thought ID")
    task_id: str = Field(..., description="Source task ID")
    thought_type: str = Field(..., description="Type of thought")
    current_step: StepPoint = Field(..., description="Current step point in pipeline")
    last_completed_step: Optional[StepPoint] = Field(None, description="Last completed step point")
    entered_step_at: datetime = Field(..., description="When thought entered current step")
    processing_time_ms: float = Field(0.0, description="Total processing time so far")

    # Data accumulated at each step - using existing schemas
    context_built: Optional[DMAContext] = Field(None, description="Context built for DMAs")
    ethical_dma: Optional[EthicalDMAResult] = Field(None, description="Ethical DMA result")
    common_sense_dma: Optional[CSDMAResult] = Field(None, description="Common sense DMA result")
    domain_dma: Optional[DSDMAResult] = Field(None, description="Domain DMA result")
    aspdma_result: Optional[ActionSelectionDMAResult] = Field(None, description="ASPDMA result")
    conscience_results: Optional[List[ConscienceResult]] = Field(None, description="Conscience evaluations")
    selected_action: Optional[str] = Field(None, description="Final selected action")
    handler_result: Optional[HandlerResult] = Field(None, description="Handler execution result")
    bus_operations: Optional[List[str]] = Field(None, description="Bus operations performed")

    # Tracking recursion
    is_recursive: bool = Field(False, description="Whether in recursive ASPDMA")
    recursion_count: int = Field(0, description="Number of ASPDMA recursions")


def _create_empty_pipeline_steps() -> Dict[str, List["ThoughtInPipeline"]]:
    """Create empty pipeline step dictionary with proper typing."""
    return {step.value: [] for step in StepPoint}


class PipelineState(BaseModel):
    """Complete state of the processing pipeline."""

    model_config = ConfigDict(defer_build=True)

    is_paused: bool = Field(False, description="Whether pipeline is paused")
    current_round: int = Field(0, description="Current processing round")

    # Thoughts at each step point
    thoughts_by_step: Dict[str, List[ThoughtInPipeline]] = Field(
        default_factory=_create_empty_pipeline_steps,
        description="Thoughts grouped by their current step point",
    )

    # Queues
    task_queue: List[QueuedTask] = Field(default_factory=list, description="Tasks waiting to generate thoughts")
    thought_queue: List[QueuedThought] = Field(default_factory=list, description="Thoughts waiting to enter pipeline")

    # Metrics
    total_thoughts_processed: int = Field(0, description="Total thoughts processed")
    total_thoughts_in_flight: int = Field(0, description="Thoughts currently in pipeline")

    def get_thoughts_at_step(self, step: StepPoint) -> List[ThoughtInPipeline]:
        """Get all thoughts at a specific step point."""
        return self.thoughts_by_step.get(step.value, [])

    def move_thought(self, thought_id: str, from_step: StepPoint, to_step: StepPoint) -> bool:
        """Move a thought from one step to another."""
        from_list = self.thoughts_by_step.get(from_step.value, [])
        thought = next((t for t in from_list if t.thought_id == thought_id), None)
        if thought:
            from_list.remove(thought)
            thought.current_step = to_step
            thought.entered_step_at = datetime.now(timezone.utc)
            self.thoughts_by_step.setdefault(to_step.value, []).append(thought)
            return True
        return False

    def get_next_step(self, current_step: StepPoint) -> Optional[StepPoint]:
        """Get the next step in the pipeline."""
        steps = list(StepPoint)
        try:
            current_idx = steps.index(current_step)
            if current_idx < len(steps) - 1:
                return steps[current_idx + 1]
        except ValueError:
            pass
        return None


class ThoughtProcessingResult(BaseModel):
    """Result from processing a thought through the full pipeline."""

    model_config = ConfigDict(defer_build=True)

    thought_id: str = Field(..., description="Unique thought ID")
    task_id: str = Field(..., description="Source task ID")
    thought_type: str = Field(..., description="Type of thought")

    # Handler execution result
    handler_type: str = Field(..., description="Handler that processed the action")
    handler_success: bool = Field(..., description="Whether handler succeeded")
    handler_message: Optional[str] = Field(None, description="Handler result message")
    handler_error: Optional[str] = Field(None, description="Handler error if failed")

    # Bus operations performed
    bus_operations: List[str] = Field(
        default_factory=list, description="Bus operations performed (e.g., 'memory_stored', 'message_sent')"
    )

    # Timing
    total_processing_time_ms: float = Field(..., description="Total processing time")
    dma_time_ms: Optional[float] = Field(None, description="DMA processing time")
    conscience_time_ms: Optional[float] = Field(None, description="Conscience processing time")
    handler_time_ms: Optional[float] = Field(None, description="Handler execution time")

    # Final status
    final_status: str = Field(..., description="Final thought status")

    # Tasks selected for processing
    tasks_to_process: List[QueuedTask] = Field(
        default_factory=list, description="Tasks selected for thought generation"
    )

    # Tasks deferred or skipped
    tasks_deferred: List[Dict[str, str]] = Field(default_factory=list, description="Tasks deferred with reasons")

    # Selection criteria used
    selection_criteria: TaskSelectionCriteria = Field(
        default_factory=TaskSelectionCriteria,
        description="Criteria used to select tasks (priority, age, channel, etc.)",
    )

    # Metrics
    total_pending_tasks: int = Field(0)
    total_active_tasks: int = Field(0)
    tasks_selected_count: int = Field(0)
    processing_time_ms: float = Field(0.0)

    error: Optional[str] = Field(None)


class StepResultStartRound(BaseModel):
    """Result from START_ROUND step - moves thoughts from PENDING to PROCESSING."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.START_ROUND)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    # Round start specific data
    thoughts_processed: int = Field(..., description="Number of thoughts processed in this step")
    round_started: bool = Field(..., description="Whether round was successfully started")

    error: Optional[str] = Field(None)


class StepResultGatherContext(BaseModel):
    """Result from GATHER_CONTEXT step - builds context for DMA processing."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.GATHER_CONTEXT)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    # Additional context-specific fields
    context_size: Optional[int] = Field(None, description="Number of context items gathered")
    summary: Optional[str] = Field(None, description="Summary of context gathering process")
    thought_content: Optional[str] = Field(None, description="Content of the thought")
    thought_type: str = Field(default="standard", description="Type of thought being processed")

    error: Optional[str] = Field(None)


class StepResultPerformDMAs(BaseModel):
    """Result from PERFORM_DMAS step - parallel execution of base DMAs."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.PERFORM_DMAS)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    context: str = Field(..., description="Thought context from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


# Using the existing ConscienceResult schema instead of creating ConscienceEvaluation


class StepResultPerformASPDMA(BaseModel):
    """Result from PERFORM_ASPDMA step - action selection DMA execution."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.PERFORM_ASPDMA)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    dma_results: Optional[str] = Field(None, description="DMA results from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


class StepResultConscienceExecution(BaseModel):
    """Result from CONSCIENCE_EXECUTION step - parallel conscience checks."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.CONSCIENCE_EXECUTION)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    selected_action: str = Field(..., description="Selected action from SUT")
    action_result: Optional[str] = Field(None, description="Action result from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


class StepResultRecursiveASPDMA(BaseModel):
    """Result from RECURSIVE_ASPDMA step - retry after conscience failure."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.RECURSIVE_ASPDMA)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    retry_reason: str = Field(..., description="Retry reason from SUT")
    original_action: str = Field(..., description="Original action from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


class StepResultRecursiveConscience(BaseModel):
    """Result from RECURSIVE_CONSCIENCE step - recheck after recursive ASPDMA."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.RECURSIVE_CONSCIENCE)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    retry_action: str = Field(..., description="Retry action from SUT")
    retry_result: Optional[str] = Field(None, description="Retry result from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


class StepResultFinalizeAction(BaseModel):
    """Result from FINALIZE_ACTION step - final action determined."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.FINALIZE_ACTION)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: str = Field(..., description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    selected_action: str = Field(..., description="Selected action from SUT")
    conscience_passed: bool = Field(..., description=DESC_CONSCIENCE_PASSED)
    conscience_override_reason: Optional[str] = Field(None, description=DESC_CONSCIENCE_OVERRIDE_REASON)
    epistemic_data: EpistemicData = Field(..., description="Rich conscience evaluation data")
    processing_time_ms: float = Field(..., description="Processing time from SUT")

    error: Optional[str] = Field(None)


class StepResultPerformAction(BaseModel):
    """Result from PERFORM_ACTION step - action dispatch begins."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.PERFORM_ACTION)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: Optional[str] = Field(None, description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    selected_action: str = Field(..., description="Selected action from SUT")
    action_parameters: Optional[str] = Field(None, description="Action parameters from SUT")
    dispatch_context: str = Field(..., description="Dispatch context from SUT")

    error: Optional[str] = Field(None)


class StepResultActionComplete(BaseModel):
    """Result from ACTION_COMPLETE step - action execution completed with audit trail."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.ACTION_COMPLETE)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: Optional[str] = Field(None, description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    action_executed: str = Field(..., description="Action executed from SUT")
    dispatch_success: bool = Field(..., description="Dispatch success from SUT")
    execution_time_ms: float = Field(..., description="Execution time from SUT")
    handler_completed: bool = Field(..., description="Handler completed from SUT")
    follow_up_processing_pending: bool = Field(..., description="Follow-up processing pending from SUT")
    audit_entry_id: Optional[str] = Field(None, description="ID of audit entry for this action")
    audit_sequence_number: Optional[int] = Field(None, description=DESC_AUDIT_SEQUENCE)
    audit_entry_hash: Optional[str] = Field(None, description=DESC_AUDIT_HASH)
    audit_signature: Optional[str] = Field(None, description=DESC_AUDIT_SIGNATURE)


class StepResultRoundComplete(BaseModel):
    """Result from ROUND_COMPLETE step - processing round completed."""

    model_config = ConfigDict(defer_build=True)

    step_point: StepPoint = Field(StepPoint.ROUND_COMPLETE)
    success: bool = Field(..., description="Whether step succeeded")

    # EXACT data from SUT step_data dict
    timestamp: Optional[str] = Field(None, description="Timestamp from SUT")
    thought_id: str = Field(..., description="Thought ID from SUT")
    task_id: Optional[str] = Field(None, description="Task ID from SUT")
    processing_time_ms: float = Field(..., description="Processing time from SUT")
    round_status: str = Field(..., description="Round completion status from SUT")
    thoughts_processed: int = Field(..., description="Number of thoughts processed from SUT")

    error: Optional[str] = Field(None)


# Union type for all step results
StepResultUnion = (
    StepResultGatherContext
    | StepResultPerformDMAs
    | StepResultPerformASPDMA
    | StepResultConscienceExecution
    | StepResultRecursiveASPDMA
    | StepResultRecursiveConscience
    | StepResultFinalizeAction
    | StepResultPerformAction
    | StepResultActionComplete
)


# Step Data Schemas for type-safe step processing


class BaseStepData(BaseModel):
    """Base step data with common fields for all steps."""

    model_config = ConfigDict(defer_build=True)

    timestamp: str = Field(..., description="ISO timestamp when step started")
    thought_id: str = Field(..., description="Unique thought identifier")
    task_id: Optional[str] = Field(None, description="Source task identifier")
    processing_time_ms: float = Field(..., description="Step processing time in milliseconds")
    success: bool = Field(True, description="Whether step completed successfully")
    error: Optional[str] = Field(None, description="Error message if step failed")


class StartRoundStepData(BaseStepData):
    """Step data for START_ROUND step."""

    thoughts_processed: int = Field(..., description="Number of thoughts to process in round")
    round_started: bool = Field(True, description="Round initiation flag")


class GatherContextStepData(BaseStepData):
    """Step data for GATHER_CONTEXT step."""

    context: str = Field(..., description="Built context data for DMA processing")


class PerformDMAsStepData(BaseStepData):
    """Step data for PERFORM_DMAS step."""

    dma_results: str = Field(..., description="Results from DMA processing")
    context: str = Field(..., description="Initial context for DMA processing")


class PerformASPDMAStepData(BaseStepData):
    """Step data for PERFORM_ASPDMA step."""

    selected_action: str = Field(..., description="Action selected by ASPDMA")
    action_rationale: str = Field(..., description="Rationale for action selection")
    dma_results: Optional[str] = Field(None, description="DMA results string summary from previous PERFORM_DMAS step")
    dma_results_obj: Optional[Any] = Field(None, description="Concrete InitialDMAResults object from PERFORM_DMAS step")


class ConscienceExecutionStepData(BaseStepData):
    """Step data for CONSCIENCE_EXECUTION step."""

    selected_action: str = Field(..., description="Final action after conscience check")
    action_rationale: str = Field(..., description="Rationale for the final action (REQUIRED)")
    conscience_passed: bool = Field(..., description="Whether conscience validation passed")
    action_result: str = Field(..., description="Complete action result")
    override_reason: Optional[str] = Field(None, description="Reason for conscience override if failed")
    conscience_result: ConscienceResult = Field(..., description="Complete conscience evaluation result")
    aspdma_prompt: Optional[str] = Field(None, description="User prompt passed to ASPDMA for debugging")


class RecursiveASPDMAStepData(BaseStepData):
    """Step data for RECURSIVE_ASPDMA step."""

    retry_reason: str = Field(..., description="Reason for recursive ASPDMA execution")
    original_action: str = Field(..., description="Original action that was retried")


class RecursiveConscienceStepData(BaseStepData):
    """Step data for RECURSIVE_CONSCIENCE step."""

    retry_action: str = Field(..., description="Action being retried through conscience")
    retry_result: str = Field(..., description="Result of recursive conscience check")


class FinalizeActionStepData(BaseStepData):
    """Step data for FINALIZE_ACTION step with all 6 conscience results.

    Captures results from:
    - Bypass Guardrails (ALL actions): UpdatedStatus, ThoughtDepth
    - Ethical Faculties (non-exempt): Entropy, Coherence, OptimizationVeto, EpistemicHumility
    """

    selected_action: str = Field(..., description="Final selected action")
    conscience_passed: bool = Field(..., description="Whether conscience checks passed")
    conscience_override_reason: Optional[str] = Field(None, description="Reason if conscience overrode action")
    epistemic_data: EpistemicData = Field(..., description="Rich conscience evaluation data from all checks")

    # Exempt actions flag (RECALL, TASK_COMPLETE, OBSERVE, DEFER, REJECT skip ethical faculties)
    ethical_faculties_skipped: Optional[bool] = Field(
        None, description="Whether ethical faculties were skipped due to exempt action type"
    )

    # === BYPASS GUARDRAIL 1: Updated Status Conscience ===
    updated_status_detected: Optional[bool] = Field(
        None, description="Whether UpdatedStatusConscience detected new information during task processing"
    )
    updated_status_content: Optional[str] = Field(None, description="Content of new observation if detected")

    # === BYPASS GUARDRAIL 2: Thought Depth Conscience ===
    thought_depth_triggered: Optional[bool] = Field(
        None, description="Whether ThoughtDepthGuardrail forced DEFER due to max depth"
    )
    thought_depth_current: Optional[int] = Field(None, description="Current thought depth when evaluated")
    thought_depth_max: Optional[int] = Field(None, description="Maximum allowed thought depth")

    # === ETHICAL FACULTY 1: Entropy Conscience ===
    entropy_passed: Optional[bool] = Field(None, description="Whether entropy check passed")
    entropy_score: Optional[float] = Field(None, description="Entropy score (0=ordered, 1=chaotic)")
    entropy_threshold: Optional[float] = Field(None, description=DESC_THRESHOLD_USED)
    entropy_reason: Optional[str] = Field(None, description=DESC_ENTROPY_REASON)

    # === ETHICAL FACULTY 2: Coherence Conscience ===
    coherence_passed: Optional[bool] = Field(None, description="Whether coherence check passed")
    coherence_score: Optional[float] = Field(None, description="Coherence score (0=incoherent, 1=coherent)")
    coherence_threshold: Optional[float] = Field(None, description=DESC_THRESHOLD_USED)
    coherence_reason: Optional[str] = Field(None, description=DESC_COHERENCE_REASON)

    # === ETHICAL FACULTY 3: Optimization Veto Conscience ===
    optimization_veto_passed: Optional[bool] = Field(None, description="Whether optimization veto passed")
    optimization_veto_decision: Optional[str] = Field(None, description="Decision: proceed, abort, defer")
    optimization_veto_justification: Optional[str] = Field(None, description="Justification for decision")
    optimization_veto_entropy_ratio: Optional[float] = Field(None, description="Estimated entropy reduction ratio")
    optimization_veto_affected_values: Optional[List[str]] = Field(None, description="Values affected")

    # === ETHICAL FACULTY 4: Epistemic Humility Conscience ===
    epistemic_humility_passed: Optional[bool] = Field(None, description="Whether epistemic humility passed")
    epistemic_humility_certainty: Optional[float] = Field(None, description="Epistemic certainty level")
    epistemic_humility_uncertainties: Optional[List[str]] = Field(None, description="Identified uncertainties")
    epistemic_humility_justification: Optional[str] = Field(None, description="Reflective justification")
    epistemic_humility_recommendation: Optional[str] = Field(None, description="Recommendation: proceed, ponder, defer")

    # === CONSCIENCE PROMPTS (for localization validation) ===
    entropy_prompt: Optional[str] = Field(None, description="User prompt used for entropy evaluation")
    coherence_prompt: Optional[str] = Field(None, description="User prompt used for coherence evaluation")
    optimization_veto_prompt: Optional[str] = Field(None, description="User prompt used for optimization veto")
    epistemic_humility_prompt: Optional[str] = Field(None, description="User prompt used for epistemic humility")


class PerformActionStepData(BaseStepData):
    """Step data for PERFORM_ACTION step."""

    selected_action: str = Field(..., description="Action being performed")
    action_parameters: str = Field("None", description="Parameters for action execution")
    dispatch_context: str = Field("{}", description="Context for action dispatch")


class ActionCompleteStepData(BaseStepData, PropagatedCoherenceEntropyMixin):
    """Step data for ACTION_COMPLETE step with audit trail and resource usage information.

    Inherits coherence/entropy fields from PropagatedCoherenceEntropyMixin.
    """

    action_executed: str = Field(..., description="Action that was executed")
    action_parameters: Dict[str, Any] = Field(default_factory=dict, description=DESC_ACTION_PARAMETERS)
    dispatch_success: bool = Field(..., description="Whether action dispatch succeeded")
    handler_completed: bool = Field(..., description="Whether action handler completed")
    follow_up_processing_pending: bool = Field(False, description="Whether follow-up processing needed")
    follow_up_thought_id: Optional[str] = Field(None, description="ID of follow-up thought if created")
    execution_time_ms: float = Field(0.0, description="Action execution time")
    audit_entry_id: str = Field(..., description="ID of audit entry created for this action (REQUIRED)")
    audit_sequence_number: int = Field(..., description="Sequence number in audit hash chain (REQUIRED)")
    audit_entry_hash: str = Field(..., description="Hash of audit entry - tamper-evident (REQUIRED)")
    audit_signature: str = Field(..., description="Cryptographic signature of audit entry (REQUIRED)")

    # Resource usage (queried from telemetry by thought_id)
    tokens_total: int = Field(0, description="Total tokens used (query telemetry by thought_id)")
    tokens_input: int = Field(0, description="Input tokens (query telemetry by thought_id)")
    tokens_output: int = Field(0, description="Output tokens (query telemetry by thought_id)")
    cost_cents: float = Field(0.0, description="Cost in USD cents (query telemetry by thought_id)")
    carbon_grams: float = Field(0.0, description="CO2 emissions in grams (query telemetry by thought_id)")
    energy_mwh: float = Field(0.0, description="Energy in milliwatt-hours (query telemetry by thought_id)")
    llm_calls: int = Field(0, description="Number of LLM calls (query telemetry by thought_id)")
    models_used: List[str] = Field(default_factory=list, description="Models used (query telemetry by thought_id)")
    api_bases_used: List[str] = Field(
        default_factory=list, description="API base URLs used (query telemetry by thought_id)"
    )
    # Coherence/entropy fields inherited from PropagatedCoherenceEntropyMixin


class ActionResponse(BaseModel):
    """Typed response from action dispatch."""

    model_config = ConfigDict(defer_build=True)

    success: bool = Field(..., description="Whether action dispatch succeeded")
    handler: str = Field(..., description="Handler that executed the action")
    action_type: str = Field(..., description="Type of action executed")
    follow_up_thought_id: Optional[str] = Field(None, description="ID of follow-up thought if created")
    execution_time_ms: float = Field(0.0, description="Action execution time in milliseconds")
    # Action parameters (captures content for SPEAK, tool params, etc.)
    action_parameters: Dict[str, Any] = Field(default_factory=dict, description=DESC_ACTION_PARAMETERS)

    # Audit trail data (REQUIRED) from AuditEntryResult
    audit_data: AuditEntryResult = Field(..., description="Audit entry with hash chain data (REQUIRED)")


class RoundCompleteStepData(BaseStepData):
    """Step data for ROUND_COMPLETE step."""

    round_status: str = Field("completed", description="Status of completed round")
    thoughts_processed: int = Field(..., description="Number of thoughts processed in round")


# Union type for all step data
StepDataUnion = (
    StartRoundStepData
    | GatherContextStepData
    | PerformDMAsStepData
    | PerformASPDMAStepData
    | ConscienceExecutionStepData
    | RecursiveASPDMAStepData
    | RecursiveConscienceStepData
    | FinalizeActionStepData
    | PerformActionStepData
    | ActionCompleteStepData
    | RoundCompleteStepData
)


class StepResultData(BaseModel):
    """Complete step result data structure for streaming."""

    model_config = ConfigDict(defer_build=True)

    step_point: str = Field(..., description="Step point name")
    success: bool = Field(True, description="Whether step succeeded")
    processing_time_ms: float = Field(0.0, description="Step processing time")
    thought_id: str = Field("", description="Thought identifier")
    task_id: str = Field("", description="Task identifier")
    step_data: StepDataUnion = Field(..., description="Typed step data")
    trace_context: TraceContext = Field(..., description="OTLP trace context")
    span_attributes: List[SpanAttribute] = Field(..., description="OTLP span attributes")
    otlp_compatible: bool = Field(True, description="OTLP compatibility flag")


class StepExecutionResult(BaseModel):
    """Result from executing a single step for a paused thought."""

    model_config = ConfigDict(defer_build=True)

    success: bool = Field(..., description="Whether step execution succeeded")
    thought_id: str = Field(..., description="Thought identifier")
    message: Optional[str] = Field(None, description="Success message")
    error: Optional[str] = Field(None, description="Error message if failed")


class AllStepsExecutionResult(BaseModel):
    """Result from executing steps for all paused thoughts."""

    model_config = ConfigDict(defer_build=True)

    success: bool = Field(..., description="Whether execution succeeded")
    thoughts_advanced: int = Field(0, description="Number of thoughts advanced")
    message: Optional[str] = Field(None, description="Result message")
    error: Optional[str] = Field(None, description="Error message if failed")


# ============================================================================
# Simplified Reasoning Stream Event Results (6 clear events, no UI metadata)
# ============================================================================


class ThoughtStartEvent(BaseModel):
    """Event 0: Thought begins processing - thought and task metadata (START_ROUND step)."""

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.THOUGHT_START)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: str = Field(..., description="Source task identifier")
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # Thought metadata
    thought_type: str = Field(..., description="Type of thought (standard, pondering, etc)")
    thought_content: str = Field(..., description="Thought content/reasoning")
    thought_status: str = Field(..., description="Current thought status")
    round_number: int = Field(..., description="Processing round")
    thought_depth: int = Field(0, description="Pondering depth if applicable")
    parent_thought_id: Optional[str] = Field(None, description="Parent thought if pondering")

    # Task metadata (context for the thought)
    task_description: str = Field(..., description="What needs to be done")
    task_priority: int = Field(..., description="Priority 0-10")
    channel_id: str = Field(..., description="Channel where task originated")
    updated_info_available: bool = Field(False, description="Whether task has updated information")


class SnapshotAndContextResult(BaseModel):
    """Event 1: System snapshot (GATHER_CONTEXT step).

    The system_snapshot field contains all context data in structured form.
    The redundant context string field has been removed to eliminate duplication.
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.SNAPSHOT_AND_CONTEXT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # System snapshot - contains all context data
    system_snapshot: SystemSnapshot = Field(..., description="Current system state with all context data")


class DMAResultsEvent(BaseModel):
    """Event 2: Results from all 4 DMA perspectives (PERFORM_DMAS step)."""

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.DMA_RESULTS)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # 3 DMA results - strongly typed (IDMA is streamed separately as IDMA_RESULT event)
    csdma: CSDMAResult = Field(..., description="Common Sense DMA result")
    dsdma: DSDMAResult = Field(..., description="Domain Specific DMA result")
    pdma: EthicalDMAResult = Field(..., description="Ethical Perspective DMA result (PDMA)")
    # Note: IDMA moved to separate IDMAResultEvent (v1.9.3) for independent streaming

    # User prompts passed to each DMA (for debugging/transparency)
    csdma_prompt: Optional[str] = Field(None, description="User prompt passed to CSDMA")
    dsdma_prompt: Optional[str] = Field(None, description="User prompt passed to DSDMA")
    pdma_prompt: Optional[str] = Field(None, description="User prompt passed to PDMA")
    # Note: idma_prompt is in IDMAResultEvent

    # System prompts passed to each DMA (for debugging format instructions)
    csdma_system_prompt: Optional[str] = Field(None, description="System prompt passed to CSDMA")
    dsdma_system_prompt: Optional[str] = Field(None, description="System prompt passed to DSDMA")
    pdma_system_prompt: Optional[str] = Field(None, description="System prompt passed to PDMA")


class IDMAResultEvent(BaseModel):
    """Event 3: Intuition DMA fragility check (always emitted after DMA_RESULTS).

    IDMA evaluates epistemic diversity using CCA (Coherent Collective Action) principles.
    Emitted separately from DMA_RESULTS to allow fine-grained tracing of identity/fragility checks.
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.IDMA_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # IDMA results - CCA epistemic diversity check
    k_eff: float = Field(..., description="Effective independent source count (need >= 2 for healthy reasoning)")
    effective_source_count: Optional[float] = Field(None, description="Plain-language alias for k_eff")
    k_raw: Optional[int] = Field(None, description="Nominal raw source count k before correlation adjustment")
    raw_source_count: Optional[int] = Field(None, description="Plain-language alias for k_raw")
    correlation_risk: float = Field(..., description="Estimated correlation between sources (0-1)")
    source_overlap: Optional[float] = Field(None, description="Plain-language alias for correlation_risk")
    rho_mean: Optional[float] = Field(None, description="Average pairwise correlation ρ used to derive k_eff")
    phase: str = Field(..., description="Epistemic phase: 'chaos', 'healthy', or 'rigidity'")
    reasoning_state: Optional[str] = Field(None, description="Plain-language alias for phase")
    phase_confidence: Optional[float] = Field(None, description="Confidence that the phase classification is correct")
    fragility_flag: bool = Field(..., description="True if reasoning may be brittle")
    reasoning_is_fragile: Optional[bool] = Field(None, description="Plain-language alias for fragility_flag")
    collapse_margin: Optional[float] = Field(
        None, description="Positive distance from the fragility boundary; <= 0 indicates collapse-adjacent state"
    )
    safety_margin: Optional[float] = Field(None, description="Plain-language alias for collapse_margin")
    sources_identified: List[str] = Field(default_factory=list, description="List of distinct sources identified")
    source_ids: List[str] = Field(
        default_factory=list, description="Stable or anonymized source lineage identifiers"
    )
    source_types: List[str] = Field(
        default_factory=list,
        description="Source categories aligned positionally with source_ids (memory, tool, user, context, model_prior)",
    )
    source_independence_scores: List[float] = Field(
        default_factory=list, description="Optional per-source independence scores aligned positionally with source_ids"
    )
    source_type_counts: List[str] = Field(
        default_factory=list, description="Flat source-type counts encoded as 'type:count' strings"
    )
    correlation_factors: List[str] = Field(
        default_factory=list, description="Factors contributing to source correlation"
    )
    top_correlation_factors: List[str] = Field(
        default_factory=list, description="Most important correlation drivers ranked for intervention analysis"
    )
    pairwise_correlation_summary: List[str] = Field(
        default_factory=list, description="Flat pairwise summaries encoded as 'source_a|source_b|corr|shared_origin'"
    )
    rho_intra: Optional[float] = Field(None, description="Average within-cluster correlation when block structure exists")
    rho_inter: Optional[float] = Field(None, description="Average between-cluster correlation when block structure exists")
    module_count: Optional[int] = Field(None, description="Count of independent source modules or clusters")
    effective_module_count: Optional[float] = Field(
        None, description="Effective independent module count after block-structure adjustment"
    )
    source_clusters: List[str] = Field(
        default_factory=list, description="Flat cluster summaries encoded as 'cluster_id|source_a,source_b|rho_intra'"
    )
    common_cause_flags: List[str] = Field(
        default_factory=list, description="Shared-resource or shared-lineage indicators contributing to correlation"
    )
    intervention_recommendation: Optional[str] = Field(
        None, description="Recommendation for how to reduce correlation or recover healthy diversity"
    )
    next_best_recovery_step: Optional[str] = Field(
        None, description="Plain-language alias for intervention_recommendation"
    )
    delta_k_eff: Optional[float] = Field(None, description="Change in k_eff relative to the previous comparison window")
    delta_rho_mean: Optional[float] = Field(
        None, description="Change in average pairwise correlation relative to the previous window"
    )
    phase_persistence_steps: Optional[int] = Field(
        None, description="How many consecutive steps the current phase has persisted"
    )
    time_in_fragile_state_ms: Optional[float] = Field(
        None, description="Accumulated time spent in a fragile state for the current scope"
    )
    moving_variance: Optional[float] = Field(None, description="Rolling variance proxy for early-warning monitoring")
    rho_critical: Optional[float] = Field(None, description="Critical correlation threshold ρcrit")
    k_required: Optional[float] = Field(None, description="Required effective constraint count Kreq")
    defense_function: Optional[float] = Field(None, description="Optional defense function J estimate")
    collapse_rate: Optional[float] = Field(None, description="Optional collapse rate dJ/dt estimate")
    time_to_truth: Optional[float] = Field(None, description="Optional Ttruth estimate")
    time_to_entropy: Optional[float] = Field(None, description="Optional Tentropy estimate")
    time_to_capture: Optional[float] = Field(None, description="Optional Tcapture estimate")
    reasoning: str = Field(..., description="Analysis of information diversity and epistemic health")

    # User prompt passed to IDMA (for debugging/transparency)
    idma_prompt: Optional[str] = Field(None, description="User prompt passed to IDMA")


class ASPDMAResultEvent(BaseModel):
    """Event 3: Selected action and rationale (PERFORM_ASPDMA + RECURSIVE_ASPDMA steps)."""

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.ASPDMA_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)
    is_recursive: bool = Field(False, description="Whether this is a recursive ASPDMA after conscience override")

    # ASPDMA selection
    selected_action: str = Field(..., description="Action selected by ASPDMA")
    action_rationale: str = Field(..., description="Rationale for selection")

    # Deliberation-diversity signal — how constrained was the choice, and what
    # other legitimate paths existed. Carries k_eff signal independent of the
    # reasoning stack. Populated from ASPDMALLMResult when the LLM emitted the
    # fields; None when not emitted (older prompts / fallback models).
    selection_confidence: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Subjective confidence in chosen action (0.00-1.00)"
    )
    alternatives_considered: Optional[List[str]] = Field(
        None, description="Brief labels of alternative actions the agent considered but rejected"
    )

    # User prompt passed to ASPDMA (for debugging/transparency)
    aspdma_prompt: Optional[str] = Field(None, description="User prompt passed to ASPDMA")


class TSASPDMAResultEvent(BaseModel):
    """Event 3.5: Tool-Specific ASPDMA result (optional, when TOOL action selected).

    TSASPDMA is activated when ASPDMA selects a TOOL action. It reviews full tool
    documentation and can refine parameters, request clarification (SPEAK), or
    reconsider (PONDER).
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.TSASPDMA_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # TSASPDMA input - what ASPDMA selected
    original_tool_name: str = Field(..., description="Tool name selected by ASPDMA")
    original_parameters: JSONDict = Field(default_factory=dict, description="Original parameters from ASPDMA")
    aspdma_reasoning: str = Field(..., description="Rationale from ASPDMA for tool selection")

    # TSASPDMA output - refined decision
    final_action: str = Field(..., description="Final action: TOOL (proceed), SPEAK (clarify), or PONDER (reconsider)")
    final_tool_name: Optional[str] = Field(None, description="Tool name if action is TOOL")
    final_parameters: JSONDict = Field(default_factory=dict, description="Refined parameters if action is TOOL")
    tsaspdma_reasoning: str = Field(..., description="TSASPDMA reasoning with gotchas acknowledged")


class VerbSecondPassResultEvent(BaseModel):
    """Generic verb-specific second-pass result (FSD/TRACE_EVENT_LOG_PERSISTENCE.md §4).

    Replaces per-verb second-pass event types (TSASPDMA_RESULT, future
    DSASPDMA_RESULT, etc.) with a single event keyed by a `verb` discriminator
    and a verb-specific payload. Future verbs that gain a second-pass evaluator
    drop into this event without schema changes.

    Wire format mirrors TSASPDMAResultEvent's pattern but flattens the
    "what was selected" / "what was refined to" axis across verbs:
      - `original_action` is always the verb that triggered the second pass
        (TOOL, DEFER, future MEMORIZE, ...).
      - `final_action` is what the second pass recommended (may be the same
        verb refined, or a switch to SPEAK/PONDER).
      - `verb_specific_data` carries the verb's particular fields. For TOOL:
        original_tool_name, final_tool_name, original_parameters,
        final_parameters, gotchas_acknowledged. For DEFER: rights_basis,
        primary_need_category, secondary_need_categories, domain_hint,
        operational_reason. For future verbs: their own shape.

    During the transition window, TOOL second-passes also emit the legacy
    TSASPDMAResultEvent so existing lens consumers keep working — see
    ReasoningEvent.TSASPDMA_RESULT docstring.
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.VERB_SECOND_PASS_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # Verb discriminator — which verb's second pass produced this event.
    # Lower-case to match HandlerActionType enum value convention.
    verb: str = Field(
        ..., description="Verb whose second-pass evaluator produced this event (e.g. 'tool', 'defer')"
    )

    # First-pass input — what ASPDMA originally selected
    original_action: str = Field(..., description="Action verb selected by first-pass ASPDMA")
    original_reasoning: str = Field(..., description="Reasoning from first-pass ASPDMA")

    # Second-pass output — what the verb-specific evaluator decided
    final_action: str = Field(..., description="Final action after second pass (may be unchanged or a switch)")
    final_reasoning: str = Field(..., description="Reasoning from the verb-specific second pass")

    # Verb-specific fields — opaque at the schema level, validated per-verb at the
    # producer side. Lens reads `verb` to decide which fields are present.
    verb_specific_data: JSONDict = Field(
        default_factory=dict,
        description="Verb-specific second-pass data. Shape depends on `verb`. See class docstring.",
    )

    # User prompt passed to the verb-specific evaluator (debugging/transparency)
    second_pass_prompt: Optional[str] = Field(None, description="User prompt passed to the second-pass evaluator")

    # Tool documentation context
    tool_description: Optional[str] = Field(None, description="Tool description from documentation")
    gotchas_acknowledged: List[str] = Field(default_factory=list, description="Tool gotchas acknowledged in reasoning")

    # User prompt passed to TSASPDMA (for debugging/transparency)
    tsaspdma_prompt: Optional[str] = Field(None, description="User prompt passed to TSASPDMA")


class ConscienceResultEvent(BaseModel):
    """Event 4: Conscience evaluation and final action (CONSCIENCE_EXECUTION + RECURSIVE_CONSCIENCE + FINALIZE_ACTION steps).

    Captures results from all 6 consciences:
    - Bypass Guardrails (ALL actions): UpdatedStatus, ThoughtDepth
    - Ethical Faculties (non-exempt): Entropy, Coherence, OptimizationVeto, EpistemicHumility
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.CONSCIENCE_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)
    is_recursive: bool = Field(False, description="Whether this is a recursive conscience check after override")

    # Overall conscience evaluation
    conscience_passed: bool = Field(..., description=DESC_CONSCIENCE_PASSED)
    conscience_override_reason: Optional[str] = Field(None, description=DESC_CONSCIENCE_OVERRIDE_REASON)
    epistemic_data: EpistemicData = Field(..., description="Rich conscience evaluation data from all checks")

    # Final action
    final_action: str = Field(..., description="Final action after conscience evaluation")
    action_was_overridden: bool = Field(..., description="Whether conscience changed the action")

    # Exempt actions flag (RECALL, TASK_COMPLETE, OBSERVE, DEFER, REJECT skip ethical faculties)
    ethical_faculties_skipped: Optional[bool] = Field(
        None, description="Whether ethical faculties were skipped due to exempt action type"
    )

    # === BYPASS GUARDRAIL 1: Updated Status Conscience ===
    # Detects new information arrival, forces PONDER to incorporate updated context
    updated_status_detected: Optional[bool] = Field(
        None, description="Whether UpdatedStatusConscience detected new information"
    )
    updated_status_content: Optional[str] = Field(None, description="Content of new observation if detected")

    # === BYPASS GUARDRAIL 2: Thought Depth Conscience ===
    # Monitors reasoning depth, forces DEFER to prevent infinite loops
    thought_depth_triggered: Optional[bool] = Field(
        None, description="Whether ThoughtDepthGuardrail forced DEFER due to max depth"
    )
    thought_depth_current: Optional[int] = Field(None, description="Current thought depth when evaluated")
    thought_depth_max: Optional[int] = Field(None, description="Maximum allowed thought depth")

    # === ETHICAL FACULTY 1: Entropy Conscience ===
    # Ensures appropriate information uncertainty, prevents overconfident assertions
    entropy_passed: Optional[bool] = Field(None, description="Whether entropy check passed")
    entropy_score: Optional[float] = Field(None, ge=0.0, le=1.0, description="Entropy score (0=ordered, 1=chaotic)")
    entropy_threshold: Optional[float] = Field(None, ge=0.0, le=1.0, description=DESC_THRESHOLD_USED)
    entropy_reason: Optional[str] = Field(None, description=DESC_ENTROPY_REASON)

    # === ETHICAL FACULTY 2: Coherence Conscience ===
    # Verifies internal consistency with prior commitments
    coherence_passed: Optional[bool] = Field(None, description="Whether coherence check passed")
    coherence_score: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Coherence score (0=incoherent, 1=coherent)"
    )
    coherence_threshold: Optional[float] = Field(None, ge=0.0, le=1.0, description=DESC_THRESHOLD_USED)
    coherence_reason: Optional[str] = Field(None, description=DESC_COHERENCE_REASON)

    # === ETHICAL FACULTY 3: Optimization Veto Conscience ===
    # Preserves human values, vetoes actions that compromise them for efficiency
    optimization_veto_passed: Optional[bool] = Field(None, description="Whether optimization veto passed")
    optimization_veto_decision: Optional[str] = Field(None, description="Decision: proceed, abort, defer")
    optimization_veto_justification: Optional[str] = Field(None, description="Justification for decision")
    optimization_veto_entropy_ratio: Optional[float] = Field(None, description="Estimated entropy reduction ratio")
    optimization_veto_affected_values: Optional[List[str]] = Field(None, description="Values affected")

    # === ETHICAL FACULTY 4: Epistemic Humility Conscience ===
    # Demonstrates appropriate uncertainty, flags overconfidence
    epistemic_humility_passed: Optional[bool] = Field(None, description="Whether epistemic humility passed")
    epistemic_humility_certainty: Optional[float] = Field(None, ge=0.0, le=1.0, description="Epistemic certainty level")
    epistemic_humility_uncertainties: Optional[List[str]] = Field(None, description="Identified uncertainties")
    epistemic_humility_justification: Optional[str] = Field(None, description="Reflective justification")
    epistemic_humility_recommendation: Optional[str] = Field(None, description="Recommendation: proceed, ponder, defer")


class ActionResultEvent(PropagatedCoherenceEntropyMixin, BaseModel):
    """Event 5: Action execution outcome with audit trail and resource usage (ACTION_COMPLETE step).

    Inherits coherence/entropy fields from PropagatedCoherenceEntropyMixin.
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.ACTION_RESULT)
    thought_id: str = Field(..., description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # Action execution
    action_executed: str = Field(..., description="Action that was executed")
    action_parameters: Dict[str, Any] = Field(default_factory=dict, description=DESC_ACTION_PARAMETERS)
    execution_success: bool = Field(..., description="Whether execution succeeded")
    execution_time_ms: float = Field(..., description="Execution time in milliseconds")
    follow_up_thought_id: Optional[str] = Field(None, description="Follow-up thought created if any")
    error: Optional[str] = Field(None, description="Error message if execution failed")

    # Audit trail (tamper-evident)
    audit_entry_id: Optional[str] = Field(None, description="ID of audit entry for this action")
    audit_sequence_number: Optional[int] = Field(None, description=DESC_AUDIT_SEQUENCE)
    audit_entry_hash: Optional[str] = Field(None, description=DESC_AUDIT_HASH)
    audit_signature: Optional[str] = Field(None, description=DESC_AUDIT_SIGNATURE)

    # Resource usage (queried from telemetry by thought_id)
    tokens_total: int = Field(0, description="Total tokens used for this thought")
    tokens_input: int = Field(0, description="Input tokens used for this thought")
    tokens_output: int = Field(0, description="Output tokens used for this thought")
    cost_cents: float = Field(0.0, description="Total cost in USD cents for this thought")
    carbon_grams: float = Field(0.0, description="CO2 emissions in grams for this thought")
    energy_mwh: float = Field(0.0, description="Energy used in milliwatt-hours for this thought")
    llm_calls: int = Field(0, description="Number of LLM calls for this thought")
    models_used: List[str] = Field(default_factory=list, description="Unique models used for this thought")
    api_bases_used: List[str] = Field(default_factory=list, description="Unique API base URLs used for this thought")
    # Coherence/entropy fields inherited from PropagatedCoherenceEntropyMixin


class LLMCallEvent(BaseModel):
    """Per-LLM-call observation. Broadcast by LLMBus._execute_llm_call after
    every individual provider invocation (success, retry, or failure).

    Multiple LLM_CALL events fire under each pipeline event — every DMA, ASPDMA,
    conscience, and verb-second-pass step issues 1+ provider calls. This event
    records each one discretely so the trace persistence layer (FSD/
    TRACE_EVENT_LOG_PERSISTENCE.md §5.2) can preserve per-call latency, sizes,
    and status instead of the thought-level aggregates that hide tail latency
    and timeout patterns.

    Concrete need: 2026-04-30 Spanish Mental Health timeout exhibited three
    consecutive 90s EthicalPDMA timeouts. Today's lens shows only the cost
    counter; with LLM_CALL events, the per-call status='timeout' rows make
    the diagnosis trivial.
    """

    model_config = ConfigDict(defer_build=True)

    event_type: ReasoningEvent = Field(ReasoningEvent.LLM_CALL)
    thought_id: Optional[str] = Field(None, description=DESC_THOUGHT_ID)
    task_id: Optional[str] = Field(None, description=DESC_PARENT_TASK)
    timestamp: str = Field(..., description=DESC_TIMESTAMP)

    # Caller attribution — which DMA / ASPDMA / conscience handler issued the call
    handler_name: str = Field(..., description="Calling handler/DMA name (EthicalPDMA, CSDMA, ASPDMA, ...)")
    service_name: str = Field(..., description="LLM service that handled the call")

    # Provider identity
    model: Optional[str] = Field(None, description="Model identifier (e.g. 'google/gemma-4-31B-it')")
    base_url: Optional[str] = Field(None, description="Provider base URL")
    response_model: Optional[str] = Field(None, description="Pydantic response model class name")

    # Sizes — input and output, in tokens (provider-reported) and bytes (raw, sanity)
    prompt_tokens: Optional[int] = Field(None, ge=0, description="Input token count")
    completion_tokens: Optional[int] = Field(None, ge=0, description="Output token count")
    prompt_bytes: Optional[int] = Field(None, ge=0, description="Input raw byte count")
    completion_bytes: Optional[int] = Field(None, ge=0, description="Output raw byte count")
    cost_usd: Optional[float] = Field(None, ge=0.0, description="Estimated cost in USD")

    # Timing
    duration_ms: float = Field(..., ge=0.0, description="Wall-clock duration of the call in milliseconds")

    # Outcome
    status: str = Field(
        ...,
        description="Call outcome: 'ok' | 'timeout' | 'rate_limited' | 'model_not_available' | 'instructor_retry' | 'other_error'",
    )
    error_class: Optional[str] = Field(None, description="Exception class name on failure")
    attempt_count: int = Field(1, ge=1, description="Instructor attempt count (1 = first try; 2+ = re-prompted on parse failure)")
    retry_count: int = Field(0, ge=0, description="LLMBus retry count for this call (0 = first attempt at the bus level)")

    # Optional content (gated by trace level — empty at GENERIC, hash at DETAILED, full at FULL)
    prompt_hash: Optional[str] = Field(None, description="SHA-256 of prompt text (DETAILED+ trace level)")
    prompt: Optional[str] = Field(None, description="Full prompt text (FULL trace level only)")
    response_text: Optional[str] = Field(None, description="Full completion text (FULL trace level only)")

    # Parent-event linkage (TRACE_WIRE_FORMAT.md §5.10, item #5 of #712).
    # REQUIRED as of 2.7.9 — no transition window. Together with the parent
    # CompleteTrace's (agent_id_hash, trace_id, thought_id), uniquely
    # identifies the pipeline event that issued this LLM call. Persistence
    # implementations enforce presence on incoming LLM_CALL events; the
    # agent's emission is non-optional once trace_schema_version="2.7.9".
    parent_event_type: str = Field(
        ...,
        description="The pipeline event_type whose execution issued this LLM call (e.g. 'DMA_RESULTS', 'ASPDMA_RESULT', 'CONSCIENCE_RESULT'). Required as of 2.7.9.",
    )
    parent_attempt_index: int = Field(
        ...,
        ge=0,
        description="The attempt_index of the parent pipeline event under (thought_id, parent_event_type). Forms a non-forgeable parent-link with parent_event_type when included in the signed canonical bytes (§8). Required as of 2.7.9.",
    )
