"""
Incident Management Service - ITIL-aligned incident processing for self-improvement.

This service processes incidents captured from logs, detects patterns, identifies problems,
and generates insights for agent self-improvement. It's integrated with the dream cycle
for continuous learning from operational issues.
"""

import asyncio
import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional

import aiofiles

from ciris_engine.logic.services.base_graph_service import BaseGraphService
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.services.core import ServiceCapabilities, ServiceStatus
from ciris_engine.schemas.services.graph.incident import (
    IncidentInsightNode,
    IncidentNode,
    IncidentSeverity,
    IncidentStatus,
    ProblemNode,
)
from ciris_engine.schemas.services.graph_core import GraphScope, NodeType
from ciris_engine.schemas.services.operations import MemoryOpStatus

if TYPE_CHECKING:
    from ciris_engine.logic.buses import MemoryBus
    from ciris_engine.protocols.services.lifecycle.time import TimeServiceProtocol

logger = logging.getLogger(__name__)


class IncidentManagementService(BaseGraphService):
    """
    Manages incidents, problems, and insights for agent self-improvement.

    This service:
    1. Processes incidents captured from WARNING/ERROR logs
    2. Detects patterns and recurring issues
    3. Identifies root causes (problems)
    4. Generates actionable insights for self-improvement
    5. Tracks effectiveness of applied changes
    """

    def __init__(
        self, memory_bus: Optional["MemoryBus"] = None, time_service: Optional["TimeServiceProtocol"] = None
    ) -> None:
        super().__init__(memory_bus=memory_bus, time_service=time_service)
        self.service_name = "IncidentManagementService"
        self._started = False
        self._start_time: Optional[datetime] = None
        self._metrics_tracking: Dict[str, float] = {
            "created": 0.0,
            "resolved": 0.0,
            "active": 0.0,
        }

    def _get_time_service(self) -> "TimeServiceProtocol":
        """Get time service for consistent timestamps."""

        if self._time_service is None:
            raise RuntimeError("Time service not initialized")
        return self._time_service

    async def process_recent_incidents(self, hours: int = 24) -> IncidentInsightNode:
        """
        Process recent incidents to identify patterns and generate insights.
        This is called during the dream cycle for self-improvement.

        Args:
            hours: How many hours of incidents to analyze

        Returns:
            IncidentInsightNode with analysis results and recommendations
        """
        try:
            # Get time service
            time_service = self._get_time_service()
            if not time_service:
                raise RuntimeError("CRITICAL: TimeService not available")

            # Query recent incidents
            current_time = time_service.now()
            cutoff_time = current_time - timedelta(hours=hours)

            incidents = await self._get_recent_incidents(cutoff_time)

            if not incidents:
                logger.info("No incidents found in the last %d hours", hours)
                return self._create_no_incidents_insight(current_time)

            # Analyze incidents
            patterns = self._detect_patterns(incidents)
            problems = await self._identify_problems(patterns)
            recommendations = self._generate_recommendations(patterns, problems)

            # Create insight node
            insight = IncidentInsightNode(
                id=f"incident_insight_{current_time.strftime('%Y%m%d_%H%M%S')}",
                type=NodeType.CONCEPT,
                scope=GraphScope.LOCAL,
                attributes={},  # Required for TypedGraphNode
                insight_type="PERIODIC_ANALYSIS",
                summary=self._summarize_analysis(len(incidents), len(patterns), len(problems)),
                details={
                    "incident_count": len(incidents),
                    "pattern_count": len(patterns),
                    "problem_count": len(problems),
                    "severity_breakdown": self._get_severity_breakdown(incidents),
                    "component_breakdown": self._get_component_breakdown(incidents),
                    "time_distribution": self._get_time_distribution(incidents),
                },
                behavioral_adjustments=recommendations.get("behavioral", []),
                configuration_changes=recommendations.get("configuration", []),
                source_incidents=[i.id for i in incidents],
                source_problems=[p.id for p in problems],
                analysis_timestamp=current_time,
                updated_by="IncidentManagementService",
                updated_at=current_time,
            )

            # Store insight in graph
            if self._memory_bus:
                result = await self._memory_bus.memorize(node=insight.to_graph_node(), handler_name=self.service_name)

                if result.status != MemoryOpStatus.OK:
                    logger.error("Failed to store incident insight: %s", result.error)
            else:
                logger.warning("Memory bus not available, cannot store incident insight")

            # Mark analyzed incidents
            await self._mark_incidents_analyzed(incidents)

            return insight

        except Exception as e:
            logger.error("Failed to process incidents: %s", e, exc_info=True)
            raise

    def _query_persist_incidents(self, cutoff_time: datetime) -> List[IncidentNode]:
        """Sync persist incident query — runs in a worker thread.

        Paginates through cirislens_incident_records DESC by recorded_at
        until cutoff_time, materializes each row as an IncidentNode so the
        downstream pattern-detection code (_detect_patterns, _identify_problems)
        keeps working unchanged.
        """
        from ciris_engine.logic.audit import resolve_tenant_id
        from ciris_engine.logic.persistence.models.graph import get_persist_engine

        engine = get_persist_engine()
        if engine is None:
            # Signal "persist unavailable" distinctly from "persist returned
            # empty" so the caller falls through to the memory-bus / file
            # fallback path. Production agents always have engine wired
            # post-bootstrap, so this branch is test/early-startup only.
            raise RuntimeError("persist engine not wired")

        filter_json = json.dumps({"tenant_id": resolve_tenant_id()})
        # Start cursor at "now" — get the newest items first; stop when we
        # cross cutoff_time. last_id stays empty to anchor at the head.
        last_ts = "9999-12-31T23:59:59Z"
        last_id = ""
        incidents: List[IncidentNode] = []
        page_limit = 200
        max_pages = 50  # safety cap; 50 * 200 = 10000 incidents

        for _ in range(max_pages):
            cursor_json = json.dumps(
                {"version": "v1", "last_ts": last_ts, "last_id": last_id}
            )
            raw = engine.incident_list(filter_json, cursor_json, page_limit)
            try:
                parsed = json.loads(raw) if isinstance(raw, str) else raw
            except json.JSONDecodeError:
                parsed = None
            items = (parsed.get("items") if isinstance(parsed, dict) else None) or []
            if not items:
                break

            crossed_cutoff = False
            for row in items:
                if not isinstance(row, dict):
                    continue
                last_seen_str = str(row.get("last_seen_at", ""))
                try:
                    last_seen_dt = datetime.fromisoformat(last_seen_str.replace("Z", "+00:00"))
                except ValueError:
                    continue
                if last_seen_dt < cutoff_time:
                    crossed_cutoff = True
                    break
                incidents.append(self._persist_row_to_incident_node(row, last_seen_dt))
                last_ts = last_seen_str
                last_id = str(row.get("incident_id", ""))

            if crossed_cutoff or len(items) < page_limit:
                break

        logger.info(f"persist incident query returned {len(incidents)} incidents since {cutoff_time}")
        return incidents

    @staticmethod
    def _persist_row_to_incident_node(row: Dict[str, Any], detected_at: datetime) -> IncidentNode:
        """Convert a persist cirislens_incident_records row to an IncidentNode.

        The pattern-detection code downstream operates on IncidentNode
        objects (severity, source_component, description, etc.). The
        forensic fields persist returns map cleanly to IncidentNode's
        existing schema.
        """
        sev_str = str(row.get("severity", "warning")).lower()
        severity_map = {
            "critical": IncidentSeverity.CRITICAL,
            "error": IncidentSeverity.HIGH,
            "warning": IncidentSeverity.MEDIUM,
            "info": IncidentSeverity.LOW,
        }
        severity = severity_map.get(sev_str, IncidentSeverity.MEDIUM)
        return IncidentNode(
            id=str(row.get("incident_id", "")),
            type=NodeType.AUDIT_ENTRY,
            scope=GraphScope.LOCAL,
            attributes={},
            incident_type=str(row.get("category", "log_warning")).upper(),
            severity=severity,
            status=IncidentStatus.OPEN,
            description=str(row.get("description", row.get("title", ""))),
            source_component=str(row.get("source_component", "unknown")),
            detected_at=detected_at,
            correlation_id=None,  # encoded in correlation_keys; not separately surfaced
            task_id=None,
            thought_id=None,
            handler_name=row.get("handler_name") or None,
            filename=str(row.get("filename", "")) or None,
            line_number=int(row.get("line_number", 0)) if row.get("line_number") is not None else None,
            function_name=row.get("function_name") or None,
            exception_type=row.get("exception_type") or None,
            stack_trace=row.get("stack_trace") or None,
            impact="TBD",
            urgency="MEDIUM" if severity == IncidentSeverity.MEDIUM else "HIGH",
            updated_by="incident_service",
            updated_at=detected_at,
        )

    async def _get_recent_incidents(self, cutoff_time: datetime) -> List[IncidentNode]:
        """Get recent incidents from persist's cirislens_incident_records.

        D1-full cutover (CIRISAgent#763): incidents no longer live as graph
        nodes — they're in persist's incident substrate (CIRISPersist#56,
        v1.5.5). Memory-bus search is kept as a back-compat path for tests
        that mock the memory_service; production agents go through persist.
        File-based fallback below still works as a last-resort forensic
        path when persist hasn't seen any incidents (e.g. fresh boot).

        Resolution priority:
          1. persist returns >0 incidents → use those (production happy path)
          2. persist raises (engine not wired) → fall through to memory bus
          3. persist returns 0 incidents → also check memory bus, because
             tests routinely mock memory_service.search to return incidents
             while leaving persist empty (the engine may be wired by an
             earlier test's initialize_database side effect)
        """
        try:
            persist_incidents = await asyncio.to_thread(self._query_persist_incidents, cutoff_time)
            if persist_incidents:
                return persist_incidents
            # Persist returned empty — fall through to memory-bus + file
            # paths below in case a test mock has results.
        except Exception as e:
            logger.warning(f"persist incident query failed, falling back to legacy path: {e}")

        if not self._memory_bus:
            logger.error("Memory bus not available")
            return []

        try:
            # Back-compat: tests still mock memory_service.search to return
            # IncidentNode-shaped GraphNode objects. Keep this branch so
            # mocked test fixtures don't have to set up a persist engine.
            memory_services = (
                self._memory_bus.service_registry.get_services_by_type("memory")
                if hasattr(self._memory_bus, "service_registry")
                else []
            )
            memory_service = memory_services[0] if memory_services else None

            if memory_service and hasattr(memory_service, "search"):
                nodes = await memory_service.search(NodeType.AUDIT_ENTRY, cutoff_time)
                incidents = []
                for node in nodes:
                    try:
                        incident = IncidentNode.from_graph_node(node)
                        incidents.append(incident)
                    except Exception as e:
                        logger.warning(f"Failed to parse incident node: {e}")
                        continue
                return incidents

            # Fall through to file-based fallback (preserved as the
            # absolute-last-resort forensic surface).
            raise RuntimeError("memory_service.search unavailable")

        except Exception as e:
            logger.warning(f"Failed to get incidents from memory service: {e}")

            # Fallback to reading from file if memory service fails
            from pathlib import Path

            log_dir = Path("/app/logs")
            incidents_file = log_dir / "incidents_latest.log"

            if not incidents_file.exists():
                logger.warning("No incidents log file found")
                return []

            incidents = []
            try:
                # Parse the incidents log file
                async with aiofiles.open(incidents_file, "r") as f:
                    async for line in f:
                        line = line.strip()
                        if not line or line.startswith("==="):
                            continue

                        # Parse log line: "2025-07-09 15:24:43.200 - WARNING  - component - file.py:line - message"
                        parts = line.split(" - ", 4)
                        if len(parts) >= 5:
                            timestamp_str = parts[0]
                            level = parts[1].strip()
                            component = parts[2].strip()
                            location = parts[3].strip()
                            message = parts[4].strip()

                            # Parse timestamp
                            from datetime import datetime

                            timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S.%f")

                            # Skip if before cutoff
                            if timestamp.replace(tzinfo=cutoff_time.tzinfo) < cutoff_time:
                                continue

                            # Create incident node
                            incident = IncidentNode(
                                id=f"incident_{timestamp.strftime('%Y%m%d_%H%M%S')}_{hash(message) % 10000}",
                                type=NodeType.AUDIT_ENTRY,
                                scope=GraphScope.LOCAL,
                                attributes={},
                                incident_type=level,
                                severity=IncidentSeverity.HIGH if level == "ERROR" else IncidentSeverity.MEDIUM,
                                status=IncidentStatus.OPEN,
                                description=message,
                                source_component=component,
                                detected_at=timestamp,
                                filename=location,  # Use location as filename
                                line_number=0,  # Line number not available from log parsing
                                impact="TBD",
                                urgency="MEDIUM",
                                updated_by="incident_service",
                                updated_at=timestamp,
                            )
                            # Track incident creation
                            self._increment_metric("created")
                        incidents.append(incident)

            except Exception as e:
                logger.error(f"Failed to parse incidents log: {e}")

            logger.info(f"Found {len(incidents)} incidents since {cutoff_time}")
            return incidents

    def _detect_patterns(self, incidents: List[IncidentNode]) -> Dict[str, List[IncidentNode]]:
        """Detect patterns in incidents."""
        patterns = defaultdict(list)

        # Group by error message similarity
        error_groups = self._group_by_similarity(incidents)
        for group_key, group_incidents in error_groups.items():
            if len(group_incidents) >= 3:  # At least 3 occurrences
                patterns[f"recurring_error_{group_key}"] = group_incidents

        # Group by component
        component_groups = defaultdict(list)
        for incident in incidents:
            if hasattr(incident, "source_component") and incident.source_component:
                component_groups[incident.source_component].append(incident)
            else:
                component_groups["unknown"].append(incident)

        for component, comp_incidents in component_groups.items():
            if len(comp_incidents) >= 5:  # Component with many incidents
                patterns[f"component_issues_{component}"] = comp_incidents

        # Detect time-based clusters (error spikes)
        time_clusters = self._detect_time_clusters(incidents)
        for idx, cluster in enumerate(time_clusters):
            if len(cluster) >= 5:  # At least 5 incidents in cluster
                patterns[f"error_spike_{idx}"] = cluster

        return dict(patterns)

    async def _identify_problems(self, patterns: Dict[str, List[IncidentNode]]) -> List[ProblemNode]:
        """Identify root cause problems from patterns."""
        problems: List[ProblemNode] = []

        # Get current time for timestamps
        if not self._time_service:
            raise RuntimeError("CRITICAL: TimeService not available for incident problem identification")
        current_time = self._time_service.now()

        for pattern_key, pattern_incidents in patterns.items():
            # Skip if too few incidents
            if len(pattern_incidents) < 3:
                continue

            # Analyze root causes
            root_causes = self._analyze_root_causes(pattern_incidents)

            # Create problem node
            problem = ProblemNode(
                id=f"problem_{pattern_key}_{len(problems)}",
                type=NodeType.CONCEPT,
                scope=GraphScope.IDENTITY,
                attributes={},  # Required for TypedGraphNode
                problem_statement=self._create_problem_statement(pattern_key, pattern_incidents),
                affected_incidents=[i.id for i in pattern_incidents],
                status="UNDER_INVESTIGATION",
                potential_root_causes=root_causes,
                recommended_actions=self._suggest_fixes(pattern_key, root_causes),
                incident_count=len(pattern_incidents),
                first_occurrence=min(i.detected_at for i in pattern_incidents),
                last_occurrence=max(i.detected_at for i in pattern_incidents),
                updated_by="IncidentManagementService",
                updated_at=current_time,
            )

            # Store problem in graph
            if self._memory_bus:
                result = await self._memory_bus.memorize(node=problem.to_graph_node(), handler_name=self.service_name)

                if result.status == MemoryOpStatus.OK:
                    problems.append(problem)

                    # Link incidents to problem
                    for incident in pattern_incidents:
                        incident.problem_id = problem.id
                        incident.status = IncidentStatus.RECURRING
                        await self._update_incident(incident)
            else:
                logger.warning("Memory bus not available, cannot store problem node")
                problems.append(problem)  # Still add to problems list for return value

        return problems

    def _generate_recommendations(
        self, patterns: Dict[str, List[IncidentNode]], problems: List[ProblemNode]
    ) -> Dict[str, List[str]]:
        """Generate actionable recommendations."""
        recommendations: Dict[str, List[str]] = {"behavioral": [], "configuration": []}

        # Analyze patterns for recommendations
        for pattern_key, incidents in patterns.items():
            if "timeout" in pattern_key.lower():
                recommendations["configuration"].append("Consider increasing timeout values for affected operations")
                recommendations["behavioral"].append(
                    "Add retry logic with exponential backoff for timeout-prone operations"
                )

            elif "memory" in pattern_key.lower():
                recommendations["configuration"].append("Increase memory limits or implement memory usage monitoring")
                recommendations["behavioral"].append("Implement periodic memory cleanup in long-running operations")

            elif "component_issues" in pattern_key:
                component = pattern_key.split("_")[-1]
                recommendations["behavioral"].append(f"Add additional error handling and logging to {component}")
                recommendations["configuration"].append(f"Consider circuit breaker pattern for {component}")

        # Analyze problems for deeper recommendations
        for problem in problems:
            if "configuration" in " ".join(problem.potential_root_causes).lower():
                recommendations["configuration"].append("Review and validate all configuration settings")

            if "resource" in " ".join(problem.potential_root_causes).lower():
                recommendations["behavioral"].append("Implement resource usage monitoring and alerts")

        # De-duplicate recommendations
        recommendations["behavioral"] = list(set(recommendations["behavioral"]))
        recommendations["configuration"] = list(set(recommendations["configuration"]))

        return recommendations

    # Helper methods

    def _group_by_similarity(self, incidents: List[IncidentNode]) -> Dict[str, List[IncidentNode]]:
        """Group incidents by error message similarity."""
        groups = defaultdict(list)

        for incident in incidents:
            # Simple grouping by first few words of description
            key = "_".join(incident.description.split()[:3]).lower()
            groups[key].append(incident)

        return dict(groups)

    def _detect_time_clusters(self, incidents: List[IncidentNode]) -> List[List[IncidentNode]]:
        """Detect time-based clusters of incidents."""
        # Sort by time
        sorted_incidents = sorted(incidents, key=lambda i: i.detected_at)

        clusters: List[List[IncidentNode]] = []
        current_cluster: List[IncidentNode] = []
        cluster_threshold = timedelta(minutes=5)  # Incidents within 5 minutes

        for incident in sorted_incidents:
            if not current_cluster:
                current_cluster.append(incident)
            else:
                time_diff = incident.detected_at - current_cluster[-1].detected_at
                if time_diff <= cluster_threshold:
                    current_cluster.append(incident)
                else:
                    if len(current_cluster) >= 3:
                        clusters.append(current_cluster)
                    current_cluster = [incident]

        if len(current_cluster) >= 3:
            clusters.append(current_cluster)

        return clusters

    def _analyze_root_causes(self, incidents: List[IncidentNode]) -> List[str]:
        """Analyze potential root causes."""
        root_causes: List[str] = []

        # Check for common patterns
        descriptions = [i.description.lower() for i in incidents]

        if any("timeout" in d for d in descriptions):
            root_causes.append("Timeout configuration may be too aggressive")

        if any("connection" in d for d in descriptions):
            root_causes.append("Network connectivity or service availability issues")

        if any("memory" in d or "resource" in d for d in descriptions):
            root_causes.append("Resource constraints or memory leaks")

        if any("permission" in d or "auth" in d for d in descriptions):
            root_causes.append("Authentication or authorization configuration issues")

        # Check for specific components
        components = set(i.source_component for i in incidents)
        if len(components) == 1:
            root_causes.append(f"Issue isolated to {list(components)[0]} component")

        return root_causes

    def _create_problem_statement(self, pattern_key: str, incidents: List[IncidentNode]) -> str:
        """Create a human-readable problem statement."""
        if "recurring_error" in pattern_key:
            return f"Recurring error: {incidents[0].description} (occurred {len(incidents)} times)"
        elif "component_issues" in pattern_key:
            component = pattern_key.split("_")[-1]
            return f"Multiple issues in {component} component ({len(incidents)} incidents)"
        elif "error_spike" in pattern_key:
            return f"Error spike detected with {len(incidents)} incidents in short time period"
        else:
            return f"Pattern detected: {pattern_key} affecting {len(incidents)} incidents"

    def _suggest_fixes(self, pattern_key: str, root_causes: List[str]) -> List[str]:
        """Suggest specific fixes for the problem."""
        fixes = []

        # Pattern-based fixes
        if "timeout" in pattern_key.lower():
            fixes.append("Increase timeout values in configuration")
            fixes.append("Implement retry logic with exponential backof")

        # Root cause based fixes
        for cause in root_causes:
            if "memory" in cause.lower():
                fixes.append("Implement memory profiling to identify leaks")
                fixes.append("Add memory usage limits and monitoring")
            elif "network" in cause.lower():
                fixes.append("Add connection pooling and retry logic")
                fixes.append("Implement circuit breaker for external services")

        return fixes

    def _summarize_analysis(self, incident_count: int, pattern_count: int, problem_count: int) -> str:
        """Create a summary of the analysis."""
        if incident_count == 0:
            return "No incidents detected in the analysis period"
        elif problem_count == 0:
            return f"Analyzed {incident_count} incidents, no recurring problems identified"
        else:
            return (
                f"Analyzed {incident_count} incidents, found {pattern_count} patterns "
                f"and identified {problem_count} problems requiring attention"
            )

    def _get_severity_breakdown(self, incidents: List[IncidentNode]) -> Dict[str, int]:
        """Get breakdown by severity."""
        breakdown: defaultdict[str, int] = defaultdict(int)
        for incident in incidents:
            breakdown[incident.severity.value] += 1
        return dict(breakdown)

    def _get_component_breakdown(self, incidents: List[IncidentNode]) -> Dict[str, int]:
        """Get breakdown by component."""
        breakdown: defaultdict[str, int] = defaultdict(int)
        for incident in incidents:
            breakdown[incident.source_component] += 1
        return dict(breakdown)

    def _get_time_distribution(self, incidents: List[IncidentNode]) -> Dict[str, int]:
        """Get distribution over time (hourly buckets)."""
        distribution: defaultdict[str, int] = defaultdict(int)
        for incident in incidents:
            hour_key = incident.detected_at.strftime("%Y-%m-%d %H:00")
            distribution[hour_key] += 1
        return dict(distribution)

    def _create_no_incidents_insight(self, current_time: datetime) -> IncidentInsightNode:
        """Create insight when no incidents found."""
        return IncidentInsightNode(
            id=f"incident_insight_{current_time.strftime('%Y%m%d_%H%M%S')}",
            type=NodeType.CONCEPT,
            scope=GraphScope.LOCAL,
            attributes={},  # Required for TypedGraphNode
            insight_type="NO_INCIDENTS",
            summary="No incidents detected - system operating normally",
            details={"incident_count": 0, "pattern_count": 0, "problem_count": 0},
            behavioral_adjustments=[],
            configuration_changes=[],
            source_incidents=[],
            source_problems=[],
            analysis_timestamp=current_time,
            updated_by="IncidentManagementService",
            updated_at=current_time,
        )

    async def get_incident_count(self, hours: int = 1) -> int:
        """Get count of incidents in the specified time window.

        Args:
            hours: Number of hours to look back

        Returns:
            Count of incidents
        """
        try:
            time_service = self._get_time_service()
            current_time = time_service.now()
            cutoff_time = current_time - timedelta(hours=hours)
            incidents = await self._get_recent_incidents(cutoff_time)
            return len(incidents)
        except Exception as e:
            logger.warning(f"Failed to get incident count: {e}")
            return 0

    async def query_incidents(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        severity: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[IncidentNode]:
        """Query incidents with optional filtering.

        Args:
            start_time: Filter incidents after this time
            end_time: Filter incidents before this time
            severity: Filter by severity (CRITICAL, HIGH, MEDIUM, LOW)
            status: Filter by status (OPEN, INVESTIGATING, RESOLVED, CLOSED, RECURRING)

        Returns:
            List of matching IncidentNode objects
        """
        try:
            time_service = self._get_time_service()

            # Use start_time or default to 24 hours ago
            if not start_time:
                start_time = time_service.now() - timedelta(hours=24)

            # Get all incidents since start_time
            incidents = await self._get_recent_incidents(start_time)

            # Apply filters
            filtered_incidents = []
            for incident in incidents:
                # Filter by end_time
                if end_time and incident.detected_at > end_time:
                    continue

                # Filter by severity (case-insensitive)
                if severity and incident.severity.value.upper() != severity.upper():
                    continue

                # Filter by status (case-insensitive)
                if status and incident.status.value.upper() != status.upper():
                    continue

                filtered_incidents.append(incident)

            return filtered_incidents

        except Exception as e:
            logger.warning(f"Failed to query incidents: {e}")
            return []

    async def get_insights(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        limit: int = 10,
    ) -> List[IncidentInsightNode]:
        """Get incident insights with optional filtering.

        Args:
            start_time: Filter insights after this time
            end_time: Filter insights before this time
            limit: Maximum number of insights to return

        Returns:
            List of IncidentInsightNode objects
        """
        if not self._memory_bus:
            logger.warning("Memory bus not available")
            return []

        try:
            from ciris_engine.schemas.services.graph.memory import MemorySearchFilter

            time_service = self._get_time_service()

            # Use start_time or default to 7 days ago (insights are less frequent)
            if not start_time:
                start_time = time_service.now() - timedelta(days=7)

            # Create search filter for insight nodes
            search_filter = MemorySearchFilter(
                node_type=NodeType.CONCEPT.value,
                created_after=start_time,
                limit=limit * 2,  # Get extra for filtering
            )

            # Query for concept nodes (insights are stored as concepts)
            nodes = await self._memory_bus.search(
                query="incident insight",
                filters=search_filter,
                handler_name="incident_service",
            )

            # Convert to IncidentInsightNode and filter
            insights = []
            for node in nodes:
                try:
                    # Check if this is actually an insight node
                    attrs = node.attributes if isinstance(node.attributes, dict) else node.attributes.model_dump()
                    if "insight_type" not in attrs:
                        continue

                    insight = IncidentInsightNode.from_graph_node(node)

                    # Filter by end_time
                    if end_time and insight.analysis_timestamp > end_time:
                        continue

                    insights.append(insight)

                    # Stop if we've reached the limit
                    if len(insights) >= limit:
                        break

                except Exception as e:
                    logger.warning(f"Failed to parse insight node: {e}")
                    continue

            return insights

        except Exception as e:
            logger.warning(f"Failed to get insights: {e}")
            return []

    async def _mark_incidents_analyzed(self, incidents: List[IncidentNode]) -> None:
        """Mark incidents as analyzed."""
        for incident in incidents:
            incident.status = IncidentStatus.INVESTIGATING
            await self._update_incident(incident)
            # Track incident resolution when analyzed
            if incident.status == IncidentStatus.INVESTIGATING:
                self._increment_metric("resolved")

    async def _update_incident(self, incident: IncidentNode) -> None:
        """Update an incident in the graph."""
        if self._memory_bus:
            result = await self._memory_bus.memorize(node=incident.to_graph_node(), handler_name=self.service_name)

            if result.status != MemoryOpStatus.OK:
                logger.error("Failed to update incident %s: %s", incident.id, result.error)
        else:
            logger.warning("Memory bus not available, cannot update incident %s", incident.id)

    # Service protocol methods

    def get_node_type(self) -> str:
        """Get the type of nodes this service manages."""
        return "INCIDENT"

    def _get_actions(self) -> List[str]:
        """Get list of actions this service can handle."""
        # Graph services typically don't handle actions through buses
        return []

    # start() and stop() removed - use inherited methods from BaseGraphService/BaseService

    def get_capabilities(self) -> ServiceCapabilities:
        """Get service capabilities."""
        return ServiceCapabilities(
            service_name="IncidentManagementService",
            actions=["process_recent_incidents", "detect_patterns", "identify_problems", "generate_insights"],
            version="1.0.0",
            dependencies=["MemoryService", "TimeService"],
            metadata=None,
        )

    def get_status(self) -> ServiceStatus:
        """Get service status."""
        current_time = self._time_service.now() if self._time_service else datetime.now()
        uptime_seconds = (current_time - self._start_time).total_seconds() if self._start_time else 0.0

        return ServiceStatus(
            service_name="IncidentManagementService",
            service_type="graph_service",
            is_healthy=self._started and self._memory_bus is not None,
            uptime_seconds=uptime_seconds,
            metrics={"service_available": bool(self._memory_bus)},
            last_error=None,
            last_health_check=current_time,
        )

    async def is_healthy(self) -> bool:
        """Check if service is healthy."""
        return self._started and self._memory_bus is not None

    def get_service_type(self) -> ServiceType:
        """Get the service type."""
        return ServiceType.AUDIT

    async def get_metrics(self) -> Dict[str, float]:
        """Get incident management service metrics - v1.4.3 set."""
        # Initialize tracking if not present
        if not hasattr(self, "_metrics_tracking"):
            self._metrics_tracking = {
                "created": 0.0,
                "resolved": 0.0,
                "active": 0.0,
            }

        # Calculate uptime
        uptime_seconds = 0.0
        if self._start_time:
            current_time = self._time_service.now() if self._time_service else datetime.now()
            uptime_seconds = (current_time - self._start_time).total_seconds()

        # Get active incident count safely
        active_count = 0.0
        try:
            # Get recent unresolved incidents as active count
            incidents_24h = await self.get_incident_count(hours=24)
            # For simplicity, treat last 24h incidents as active if not resolved
            active_count = float(incidents_24h) - self._track_metric("resolved", 0.0)
            if active_count < 0:
                active_count = 0.0
        except Exception as e:
            logger.warning(f"Failed to get active incident count: {e}")
            active_count = 0.0

        # Return exactly the 4 required v1.4.3 metrics
        return {
            "incidents_created": self._track_metric("created", 0),
            "incidents_resolved": self._track_metric("resolved", 0),
            "incidents_active": float(active_count),
            "incident_uptime_seconds": uptime_seconds,
        }

    def _track_metric(self, metric_name: str, default: float = 0.0) -> float:
        """Track a metric with real values from service state."""
        if not hasattr(self, "_metrics_tracking"):
            self._metrics_tracking = {
                "created": 0.0,
                "resolved": 0.0,
                "active": 0.0,
            }
        return float(self._metrics_tracking.get(metric_name, default))

    def _increment_metric(self, metric_name: str, amount: float = 1.0) -> None:
        """Increment a tracked metric."""
        if not hasattr(self, "_metrics_tracking"):
            self._metrics_tracking = {
                "created": 0.0,
                "resolved": 0.0,
                "active": 0.0,
            }
        self._metrics_tracking[metric_name] = self._metrics_tracking.get(metric_name, 0.0) + amount

    # get_telemetry() removed - use get_metrics() from BaseService instead
