"""
CIRIS Engine Logic - Implementation Layer

This is where all the actual implementation code lives.
Everything here implements protocols and uses schemas.

Directory structure mirrors protocols/ and schemas/ exactly for navigational determinism.
"""
