"""
Adapter configuration workflow endpoints.

Provides interactive configuration workflow for adapters including OAuth callbacks.

These endpoints support both post-setup (admin auth required) and first-run setup
(no auth required) modes via the require_setup_or_admin / require_setup_or_observer
dependencies.
"""

import html
import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Annotated, Any, Dict, Optional

from fastapi import APIRouter, Body, Depends, Header, HTTPException, Request, Response

from ciris_engine.logic.setup.first_run import is_first_run
from ciris_engine.schemas.api.auth import ROLE_PERMISSIONS, UserRole
from ciris_engine.schemas.api.responses import SuccessResponse
from ciris_engine.schemas.runtime.enums import ServiceType

from ...dependencies.auth import AuthContext, get_auth_context, get_auth_service
from .._common import RESPONSES_ADAPTER_CONFIG, RESPONSES_ADAPTER_CONFIG_SESSION
from .helpers import get_adapter_config_service
from .schemas import (
    ConfigurationCompleteRequest,
    ConfigurationCompleteResponse,
    ConfigurationSessionResponse,
    ConfigurationStatusResponse,
    StepExecutionRequest,
    StepExecutionResponse,
)

logger = logging.getLogger(__name__)


# ============================================================================
# Setup-aware auth dependencies
# ============================================================================


def _create_setup_auth_context() -> AuthContext:
    """Create a synthetic auth context for first-run setup mode."""
    return AuthContext(
        user_id="setup_wizard",
        role=UserRole.ADMIN,
        permissions=ROLE_PERMISSIONS.get(UserRole.ADMIN, set()),
        authenticated_at=datetime.now(timezone.utc),
    )


async def require_setup_or_admin(
    request: Request,
    authorization: Optional[str] = Header(None),
) -> AuthContext:
    """Allow access during first-run setup OR require admin auth.

    During first-run setup, returns a synthetic setup auth context.
    After setup, delegates to normal admin authentication.
    """
    if is_first_run():
        return _create_setup_auth_context()

    auth_service = get_auth_service(request)
    auth = await get_auth_context(request, authorization, auth_service)
    if not auth.role.has_permission(UserRole.ADMIN):
        raise HTTPException(
            status_code=403,
            detail="Requires ADMIN role",
        )
    return auth


async def require_setup_or_observer(
    request: Request,
    authorization: Optional[str] = Header(None),
) -> AuthContext:
    """Allow access during first-run setup OR require observer auth."""
    if is_first_run():
        return _create_setup_auth_context()

    auth_service = get_auth_service(request)
    auth = await get_auth_context(request, authorization, auth_service)
    if not auth.role.has_permission(UserRole.OBSERVER):
        raise HTTPException(
            status_code=403,
            detail="Requires OBSERVER role",
        )
    return auth


def _sanitize_for_log(value: Any, max_length: int = 64) -> str:
    """Sanitize user-controlled data for safe logging.

    Prevents log injection by removing control characters and truncating.
    """
    if value is None:
        return "<none>"
    val_str = str(value)
    # Remove newlines, carriage returns, and other control chars
    sanitized = re.sub(r"[\x00-\x1f\x7f-\x9f]", "", val_str)
    # Truncate to prevent log flooding
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length] + "..."
    return sanitized


router = APIRouter()

# Error message constants
ERROR_SESSION_NOT_FOUND = "Session not found"


# ============================================================================
# Configuration Session Helpers
# ============================================================================


async def _get_runtime_control_service_for_adapter_load(request: Request) -> Any:
    """Get RuntimeControlService for adapter loading (returns None if unavailable)."""
    runtime_control_service = getattr(request.app.state, "main_runtime_control_service", None)
    if runtime_control_service:
        return runtime_control_service

    runtime_control_service = getattr(request.app.state, "runtime_control_service", None)
    if runtime_control_service:
        return runtime_control_service

    service_registry = getattr(request.app.state, "service_registry", None)
    if service_registry:
        return await service_registry.get_service(handler="api", service_type=ServiceType.RUNTIME_CONTROL)

    return None


async def _resolve_url_hostname_to_ip(url: str) -> str:
    """Resolve any hostname in a URL to its IP address via mDNS.

    Uses zeroconf-based mDNS resolution for reliable .local hostname
    resolution on all platforms including Android.

    Args:
        url: URL that may contain a hostname (e.g., http://homeassistant.local:8123)

    Returns:
        URL with hostname replaced by IP if resolvable, original URL otherwise
    """
    from ciris_engine.logic.utils.mdns_resolver import resolve_url_hostname

    return await resolve_url_hostname(url, timeout=3.0)


async def _get_existing_reauth_config(
    request: Request,
    adapter_type: str,
) -> Optional[Dict[str, Any]]:
    """Get existing adapter config for re-auth flows.

    When re-authenticating an already-configured adapter, we need to preserve
    settings like base_url from the original config so OAuth steps work.

    For Home Assistant, hostnames like homeassistant.local are resolved to IP
    addresses to ensure reliable connectivity on Android browsers.

    Args:
        request: FastAPI request object
        adapter_type: Type of adapter to get config for

    Returns:
        Existing config dict if found, None otherwise
    """
    runtime_control = await _get_runtime_control_service_for_adapter_load(request)
    if not runtime_control:
        return None

    adapter_manager = getattr(runtime_control, "adapter_manager", None)
    if not adapter_manager:
        return None

    # Find existing adapter of this type
    for aid, instance in adapter_manager.loaded_adapters.items():
        if instance.adapter_type != adapter_type:
            continue

        # Try to get config from the adapter instance's service
        if hasattr(instance.adapter, "ha_service"):
            ha_url = getattr(instance.adapter.ha_service, "ha_url", None)
            if ha_url:
                # Resolve hostname to IP via mDNS for reliable Android browser connectivity
                resolved_url = await _resolve_url_hostname_to_ip(ha_url)
                return {"base_url": resolved_url}

        # Generic fallback - use settings from config_params
        if instance.config_params and instance.config_params.settings:
            config = dict(instance.config_params.settings)
            # Resolve base_url if present via mDNS
            if "base_url" in config:
                config["base_url"] = await _resolve_url_hostname_to_ip(config["base_url"])
            return config

    return None


async def _load_adapter_after_config(request: Request, session: Any, persist: bool = False) -> str:
    """Load adapter after configuration and return status message.

    Args:
        request: FastAPI request object
        session: Configuration session with collected_config
        persist: Whether to persist the adapter config for auto-load on restart
    """
    runtime_control_service = await _get_runtime_control_service_for_adapter_load(request)
    if not runtime_control_service:
        logger.warning("[COMPLETE_CONFIG] RuntimeControlService not available, adapter not loaded")
        return " - runtime control service unavailable"

    logger.info("[COMPLETE_CONFIG] Loading adapter via RuntimeControlService.load_adapter")
    adapter_config = dict(session.collected_config)
    # Include persist flag in config so RuntimeAdapterManager handles persistence
    adapter_config["persist"] = persist
    adapter_id = f"{session.adapter_type}_{uuid.uuid4().hex[:8]}"

    # Unload any existing adapter of the same type to prevent duplicates
    # (e.g., user re-configures home_assistant — old instance must be replaced)
    adapter_manager = getattr(runtime_control_service, "adapter_manager", None)
    if adapter_manager:
        for existing_id, instance in list(adapter_manager.loaded_adapters.items()):
            if instance.adapter_type == session.adapter_type:
                logger.info(
                    f"[COMPLETE_CONFIG] Unloading existing adapter {existing_id} "
                    f"(type={session.adapter_type}) before loading new instance"
                )
                await adapter_manager.unload_adapter(existing_id)
                break

    load_result = await runtime_control_service.load_adapter(
        adapter_type=session.adapter_type,
        adapter_id=adapter_id,
        config=adapter_config,
    )

    if load_result.success:
        logger.info(f"[COMPLETE_CONFIG] Adapter loaded successfully: {adapter_id}")
        return f" - adapter '{adapter_id}' loaded and started"
    else:
        logger.error(f"[COMPLETE_CONFIG] Adapter load failed: {load_result.error}")
        return f" - adapter load failed: {load_result.error}"


# ============================================================================
# Endpoints
# ============================================================================


@router.post("/adapters/{adapter_type}/configure/start", responses=RESPONSES_ADAPTER_CONFIG)
async def start_adapter_configuration(
    adapter_type: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_setup_or_admin)],
    start_step_id: Optional[str] = None,
) -> SuccessResponse[ConfigurationSessionResponse]:
    """
    Start interactive configuration session for an adapter.

    Creates a new configuration session and returns the session ID along with
    information about the first step in the workflow.

    If `start_step_id` is provided, the session will start at that step (useful
    for re-authentication flows where you want to skip to the oauth step).
    When starting at a specific step, existing adapter config is pre-populated
    so dependent steps (like OAuth needing base_url from discovery) work correctly.

    Requires ADMIN role, or accessible during first-run setup without auth.
    """
    try:
        config_service = get_adapter_config_service(request)

        # For re-auth flows (start_step_id specified), get existing config
        existing_config: Optional[Dict[str, Any]] = None
        if start_step_id:
            existing_config = await _get_existing_reauth_config(request, adapter_type)

        # Start the session (optionally at a specific step with existing config)
        session = await config_service.start_session(
            adapter_type=adapter_type,
            user_id=auth.user_id,
            start_step_id=start_step_id,
            existing_config=existing_config,
        )

        # Get manifest to access steps
        manifest = config_service._adapter_manifests.get(adapter_type)
        if not manifest:
            raise HTTPException(status_code=404, detail=f"Adapter '{adapter_type}' not found")

        # Get current step (respects start_step_id, and skips steps whose
        # `condition` does not hold -- through the service, so this is the
        # SAME evaluator that execute_step uses, not a second one).
        current_step = config_service.current_step(session)

        response = ConfigurationSessionResponse(
            session_id=session.session_id,
            adapter_type=session.adapter_type,
            status=session.status.value,
            current_step_index=session.current_step_index,
            current_step=current_step,
            total_steps=len(manifest.steps),
            created_at=session.created_at,
        )

        return SuccessResponse(data=response)

    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error starting configuration session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/configure/{session_id}",
    responses={
        403: {"description": "Not the owner of this configuration session"},
        404: {"description": "Session not found"},
        500: {"description": "Failed to get configuration status"},
    },
)
async def get_configuration_status(
    session_id: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_setup_or_admin)],
) -> SuccessResponse[ConfigurationStatusResponse]:
    """
    Get current status of a configuration session.

    Returns complete session state including current step, collected configuration,
    and session status.

    #848: the response includes ``collected_config``, which holds OAuth tokens
    collected during the flow. This endpoint therefore requires ADMIN (not
    OBSERVER) AND ownership of the session — an OBSERVER who guessed a session_id
    could otherwise read another user's in-flight oauth_tokens. Accessible during
    first-run setup without auth (no real users exist yet).
    """
    try:
        config_service = get_adapter_config_service(request)
        session = config_service.get_session(session_id)

        if not session:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

        # #848: ownership gate. collected_config carries oauth_tokens; only the
        # creating user (or setup mode, where there are no real users) may read
        # it. ADMIN alone is insufficient — one admin must not read another
        # user's in-flight OAuth tokens.
        if auth.user_id != "setup_wizard" and session.user_id and session.user_id != auth.user_id:
            raise HTTPException(
                status_code=403, detail="Not the owner of this configuration session"
            )

        # Get manifest to access steps
        manifest = config_service._adapter_manifests.get(session.adapter_type)
        if not manifest:
            raise HTTPException(status_code=500, detail=f"Manifest for '{session.adapter_type}' not found")

        # Get current step, conditions evaluated (see start_configuration)
        current_step = config_service.current_step(session)

        response = ConfigurationStatusResponse(
            session_id=session.session_id,
            adapter_type=session.adapter_type,
            status=session.status.value,
            current_step_index=session.current_step_index,
            current_step=current_step,
            total_steps=len(manifest.steps),
            collected_config=session.collected_config,
            created_at=session.created_at,
            updated_at=session.updated_at,
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting configuration status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/adapters/configure/{session_id}/step", responses=RESPONSES_ADAPTER_CONFIG_SESSION)
async def execute_configuration_step(
    session_id: str,
    request: Request,
    body: StepExecutionRequest,
    auth: Annotated[AuthContext, Depends(require_setup_or_admin)],
) -> SuccessResponse[StepExecutionResponse]:
    """
    Execute the current configuration step.

    The body contains step-specific data such as user selections, input values,
    or OAuth callback data. The step type determines what data is expected.

    Requires ADMIN role, or accessible during first-run setup without auth.
    """
    try:
        config_service = get_adapter_config_service(request)

        # Execute the step
        result = await config_service.execute_step(session_id, body.step_data)

        response = StepExecutionResponse(
            step_id=result.step_id,
            success=result.success,
            data=result.data,
            next_step_index=result.next_step_index,
            error=result.error,
            awaiting_callback=result.awaiting_callback,
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error executing configuration step: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/configure/{session_id}/status",
    responses={
        404: {"description": "Session not found"},
        500: {"description": "Failed to get session status"},
    },
)
async def get_session_status(
    session_id: str,
    request: Request,
) -> SuccessResponse[ConfigurationSessionResponse]:
    """
    Get the current status of a configuration session.

    Useful for polling after OAuth callback to check if authentication completed.
    """
    try:
        config_service = get_adapter_config_service(request)
        session = config_service.get_session(session_id)

        if not session:
            raise HTTPException(status_code=404, detail=ERROR_SESSION_NOT_FOUND)

        # Get adapter steps from the adapter manifest (InteractiveConfiguration)
        current_step = None
        total_steps = 0
        manifest = config_service._adapter_manifests.get(session.adapter_type)
        if manifest and manifest.steps:
            steps = manifest.steps
            total_steps = len(steps)
            # Through the service, conditions evaluated (see start_configuration)
            current_step = config_service.current_step(session)

        response = ConfigurationSessionResponse(
            session_id=session.session_id,
            adapter_type=session.adapter_type,
            status=session.status.value,
            current_step_index=session.current_step_index,
            current_step=current_step,
            total_steps=total_steps,
            created_at=session.created_at,
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/configure/{session_id}/oauth/callback",
    responses={
        400: {"description": "Invalid OAuth state"},
        404: {"description": "Session not found"},
        500: {"description": "OAuth callback processing failed"},
    },
)
async def oauth_callback(
    session_id: str,
    code: str,
    state: str,
    request: Request,
) -> Response:
    """
    Handle OAuth callback from external service.

    This endpoint is called by OAuth providers after user authorization.
    It processes the authorization code and advances the configuration workflow.
    Returns HTML that redirects back to the app or shows success message.

    No authentication required (OAuth state validation provides security).
    """
    # Sanitize user-controlled data before logging to prevent log injection
    logger.info("=" * 60)
    logger.info("[OAUTH CALLBACK] *** CALLBACK RECEIVED ***")
    logger.info("[OAUTH CALLBACK] Path: %s", request.url.path)
    logger.info("[OAUTH CALLBACK] session_id: %s", _sanitize_for_log(session_id))
    logger.info("[OAUTH CALLBACK] state: %s", _sanitize_for_log(state))
    logger.info("[OAUTH CALLBACK] code length: %d", len(code))
    logger.info("=" * 60)
    try:
        config_service = get_adapter_config_service(request)

        # Verify session exists and state matches
        session = config_service.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail=ERROR_SESSION_NOT_FOUND)

        if state != session_id:
            raise HTTPException(status_code=400, detail="Invalid OAuth state")

        # Execute the OAuth callback step
        result = await config_service.execute_step(session_id, {"code": code, "state": state})

        if not result.success:
            error_html = f"""<!DOCTYPE html>
<html>
<head><title>OAuth Failed</title></head>
<body style="font-family: sans-serif; text-align: center; padding: 50px;">
    <h1 style="color: #d32f2f;">Authentication Failed</h1>
    <p>{html.escape(result.error or "OAuth callback failed")}</p>
    <p>Please close this window and try again in the app.</p>
</body>
</html>"""
            return Response(content=error_html, media_type="text/html")

        # Return HTML that tells user to go back to app
        success_html = f"""<!DOCTYPE html>
<html>
<head>
    <title>OAuth Success</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body style="font-family: sans-serif; text-align: center; padding: 50px; background: #f5f5f5;">
    <div style="background: white; padding: 40px; border-radius: 10px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
        <h1 style="color: #4caf50; margin-bottom: 20px;">Connected!</h1>
        <p style="color: #666; font-size: 18px;">Authentication successful.</p>
        <p style="color: #888; margin-top: 20px;">You can close this window and return to the CIRIS app.</p>
        <p style="color: #aaa; font-size: 12px; margin-top: 30px;">Session: {html.escape(session_id[:8])}...</p>
    </div>
</body>
</html>"""
        return Response(content=success_html, media_type="text/html")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error handling OAuth callback: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/adapters/oauth/callback",
    responses={
        400: {"description": "OAuth callback failed"},
        404: {"description": "Session not found"},
        500: {"description": "OAuth processing error"},
    },
)
async def oauth_deeplink_callback(
    code: str,
    state: str,
    request: Request,
    provider: Optional[str] = None,
    source: Optional[str] = None,
) -> SuccessResponse[Dict[str, Any]]:
    """
    Handle OAuth callback forwarded from Android deep link (ciris://oauth/callback).

    This endpoint receives OAuth callbacks that were forwarded from OAuthCallbackActivity
    on Android. The Android app uses a deep link (ciris://oauth/callback) to receive
    the OAuth redirect from the system browser, then forwards to this endpoint.

    This is a generic endpoint that works for any OAuth2 provider (Home Assistant,
    Discord, Google, Microsoft, Reddit, etc.) - the state parameter contains the
    session_id which identifies the configuration session.
    """
    # Sanitize user-controlled data before logging to prevent log injection
    logger.info("=" * 60)
    logger.info("[OAUTH DEEPLINK CALLBACK] *** FORWARDED CALLBACK RECEIVED ***")
    logger.info("[OAUTH DEEPLINK CALLBACK] state: %s", _sanitize_for_log(state))
    logger.info("[OAUTH DEEPLINK CALLBACK] provider: %s", _sanitize_for_log(provider))
    logger.info("[OAUTH DEEPLINK CALLBACK] source: %s", _sanitize_for_log(source))
    logger.info("[OAUTH DEEPLINK CALLBACK] code length: %d", len(code))
    logger.info("=" * 60)

    try:
        config_service = get_adapter_config_service(request)

        # The state parameter IS the session_id
        session_id = state

        # Handle provider-prefixed state (e.g., "ha:actual_session_id")
        if ":" in state:
            parts = state.split(":", 1)
            if len(parts) == 2 and len(parts[0]) < 20:
                # Looks like "provider:session_id"
                provider = provider or parts[0]
                session_id = parts[1]
                logger.info(
                    "[OAUTH DEEPLINK CALLBACK] Extracted provider=%s, session_id=%s",
                    _sanitize_for_log(provider),
                    _sanitize_for_log(session_id),
                )

        # Verify session exists
        session = config_service.get_session(session_id)
        if not session:
            logger.error("[OAUTH DEEPLINK CALLBACK] Session not found: %s", _sanitize_for_log(session_id))
            raise HTTPException(status_code=404, detail=ERROR_SESSION_NOT_FOUND)

        # Execute the OAuth callback step
        result = await config_service.execute_step(session_id, {"code": code, "state": state})

        if not result.success:
            logger.error(f"[OAUTH DEEPLINK CALLBACK] OAuth step failed: {result.error}")
            raise HTTPException(status_code=400, detail=result.error or "OAuth callback failed")

        logger.info(
            "[OAUTH DEEPLINK CALLBACK] Successfully processed OAuth callback for session %s",
            _sanitize_for_log(session_id),
        )

        return SuccessResponse(
            data={
                "session_id": session_id,
                "success": True,
                "message": "OAuth callback processed successfully",
                "next_step": result.next_step_index,
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[OAUTH DEEPLINK CALLBACK] Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/adapters/configure/{session_id}/complete",
    responses={
        404: {"description": "Session not found"},
        500: {"description": "Configuration completion failed"},
    },
)
async def complete_configuration(
    session_id: str,
    request: Request,
    auth: Annotated[AuthContext, Depends(require_setup_or_admin)],
    body: ConfigurationCompleteRequest = ConfigurationCompleteRequest(),
) -> SuccessResponse[ConfigurationCompleteResponse]:
    """
    Finalize and apply the configuration.

    Validates the collected configuration and applies it to the adapter.
    Once completed, the adapter should be ready to use with the new configuration.

    If `persist` is True, the configuration will be saved for automatic loading
    on startup, allowing the adapter to be automatically configured when the
    system restarts.

    Requires ADMIN role, or accessible during first-run setup without auth.
    """
    try:
        adapter_config_service = get_adapter_config_service(request)

        session = adapter_config_service.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

        success = await adapter_config_service.complete_session(session_id)
        persisted = False
        message = ""

        if success:
            message = f"Configuration applied successfully for {session.adapter_type}"
            logger.info(f"[COMPLETE_CONFIG] Config applied, attempting to start adapter for {session.adapter_type}")

            try:
                # Pass persist flag so RuntimeAdapterManager handles persistence
                message += await _load_adapter_after_config(request, session, persist=body.persist)
                persisted = body.persist  # Persistence is handled by RuntimeAdapterManager
                if persisted:
                    message += " and persisted for startup"
            except Exception as e:
                logger.error(f"Error loading adapter after config: {e}", exc_info=True)
                message += f" - adapter load error: {e}"
        else:
            message = f"Configuration validation or application failed for {session.adapter_type}"

        response = ConfigurationCompleteResponse(
            success=success,
            adapter_type=session.adapter_type,
            message=message,
            applied_config=session.collected_config if success else {},
            persisted=persisted,
        )

        return SuccessResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error completing configuration: {e}")
        raise HTTPException(status_code=500, detail=str(e))
