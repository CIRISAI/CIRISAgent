"""Consent utilities module."""
