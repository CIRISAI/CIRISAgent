"""External handlers module."""
