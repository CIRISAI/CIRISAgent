"""
Communication service for API adapter.
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from ciris_engine.logic.services.base_service import BaseService
from ciris_engine.protocols.services.governance.communication import CommunicationServiceProtocol
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.runtime.messages import FetchedMessage
from ciris_engine.schemas.types import JSONDict

if TYPE_CHECKING:
    from ciris_engine.schemas.services.core import ServiceCapabilities, ServiceStatus

logger = logging.getLogger(__name__)


class APICommunicationService(BaseService, CommunicationServiceProtocol):
    """Communication service for API responses."""

    def __init__(self, config: Optional[Any] = None) -> None:
        """Initialize API communication service."""
        # Initialize BaseService for telemetry
        super().__init__(time_service=None, service_name="APICommunicationService")

        self._response_queue: asyncio.Queue[Any] = asyncio.Queue()
        self._websocket_clients: JSONDict = {}
        self._config = config  # Store the API adapter config

        # Metrics tracking
        self._response_times: List[float] = []  # Track last N response times
        self._max_response_times = 100  # Keep last 100 response times
        self._requests_handled = 0
        self._error_count = 0
        self._start_time = None
        self._time_service = None

    def _create_speak_correlation(self, channel_id: str, content: str) -> None:
        """Create and store a speak correlation for outgoing message."""
        import uuid

        from ciris_engine.logic import persistence
        from ciris_engine.schemas.telemetry.core import (
            ServiceCorrelation,
            ServiceCorrelationStatus,
            ServiceRequestData,
            ServiceResponseData,
        )

        correlation_id = str(uuid.uuid4())
        now = datetime.now(timezone.utc)

        correlation = ServiceCorrelation(
            correlation_id=correlation_id,
            service_type="api",
            handler_name="APIAdapter",
            action_type="speak",
            request_data=ServiceRequestData(
                service_type="api",
                method_name="speak",
                channel_id=channel_id,
                parameters={"content": content, "channel_id": channel_id},
                request_timestamp=now,
            ),
            response_data=ServiceResponseData(
                success=True, result_summary="Message sent", execution_time_ms=0, response_timestamp=now
            ),
            status=ServiceCorrelationStatus.COMPLETED,
            created_at=now,
            updated_at=now,
            timestamp=now,
        )

        time_service = getattr(self, "_time_service", None)
        persistence.add_correlation(correlation, time_service)
        logger.debug(f"Created speak correlation for channel {channel_id}")

    async def _send_websocket_message(self, channel_id: str, content: str) -> bool:
        """Send message through WebSocket if channel is WebSocket type."""
        if not (channel_id and channel_id.startswith("ws:")):
            return False

        client_id = channel_id[3:]  # Remove "ws:" prefix
        if client_id not in self._websocket_clients:
            logger.warning(f"WebSocket client not found: {client_id}")
            return False

        ws = self._websocket_clients.get(client_id)
        # Type guard: ensure ws has send_json method
        if ws is None or not hasattr(ws, "send_json"):
            logger.warning(f"Invalid WebSocket client: {client_id}")
            return False

        await ws.send_json(
            {
                "type": "message",
                "data": {"content": content, "timestamp": datetime.now(timezone.utc).isoformat()},
            }
        )
        return True

    @staticmethod
    def _speaking_task_id() -> Optional[str]:
        """The task whose SPEAK is being delivered, if this call is inside one.

        SPEAK reaches `send_message` through `send_message_sync`, called
        inline by the handler, so the reasoning scope the ActionDispatcher
        sets around the handler (CIRISAgent#938) is still the current context
        here. Its task_id is the speaking task. When the scope carries only a
        thought id, the thought names its source task.
        """
        from ciris_engine.logic.infrastructure.authorization.reasoning_scope import current_reasoning_scope

        scope = current_reasoning_scope()
        if scope is None:
            return None
        if scope.task_id:
            return scope.task_id
        if not scope.thought_id:
            return None
        try:
            import os

            from ciris_engine.logic import persistence

            thought = persistence.get_thought_by_id(scope.thought_id, os.environ.get("AGENT_OCCURRENCE_ID", "default"))
            source_task_id = getattr(thought, "source_task_id", None) if thought is not None else None
            return str(source_task_id) if source_task_id else None
        except Exception as exc:  # noqa: BLE001 — correlation is best-effort
            logger.debug("[API_INTERACTION] could not resolve task for thought %s: %s", scope.thought_id, exc)
            return None

    def _claim_waiting_message_id(
        self, channel_id: str, queue: List[str], speaking_task_id: Optional[str]
    ) -> Optional[Tuple[str, Optional[str]]]:
        """Pick (and remove) the waiting request this SPEAK answers, or None.

        Returns (message_id, owning task_id) so interact() can name the task.

        A reply goes to a request its own task owns — never to whichever
        request happens to be next on the channel. FIFO matching delivered a
        timed-out task's late SPEAK to the user's NEXT question, which then
        showed the previous question's answer.

        - Speaking task known: the oldest queued message_id that task owns
          (with task-append one task can own several). None of them waiting
          means the reply is late — its request timed out and left the queue,
          or it was an async submission already answered. It reaches no live
          request; it is already in channel history via the speak correlation.
        - Speaking task unknown (a SPEAK from outside the reasoning loop):
          plain FIFO, the old behaviour. Timed-out requests have already been
          removed from the queue by interact()'s cleanup, so FIFO here only
          ever sees requests that are still waiting.
        """
        task_map = getattr(getattr(self, "_app_state", None), "message_task_map", None)
        if not isinstance(task_map, dict):
            task_map = {}

        if speaking_task_id is None:
            message_id = queue.pop(0)
            owner = task_map.pop(message_id, None)
            return message_id, owner if isinstance(owner, str) else None

        for index, candidate in enumerate(queue):
            if task_map.get(candidate) == speaking_task_id:
                del queue[index]
                task_map.pop(candidate, None)
                return candidate, speaking_task_id

        logger.info(
            "[API_INTERACTION] SPEAK from task %s on channel %s has no waiting request of its own "
            "(timed out or async); not delivering it to another request. Waiting: %s",
            speaking_task_id,
            channel_id,
            [(mid, task_map.get(mid)) for mid in queue],
        )
        return None

    async def _handle_api_interaction_response(self, channel_id: str, content: str) -> None:
        """Handle API interaction response storage if applicable.

        Fires whenever there's a pending interact() waiter for the channel,
        regardless of the channel prefix. The previous `api_` prefix check
        silently dropped responses for submissions that used a custom
        channel_id (e.g. model_eval's per-question channels like
        'model_eval_en_01'), leaving the client blocked until its HTTP
        timeout. message_channel_map is populated on every incoming message
        so its presence is the real signal that a waiter exists.
        """
        if not channel_id:
            return

        try:
            if not hasattr(self, "_app_state"):
                logger.warning("[API_INTERACTION] No _app_state attribute found")
                return

            message_channel_map = getattr(self._app_state, "message_channel_map", {})
            queue = message_channel_map.get(channel_id)
            if not queue:
                # No waiter for THIS channel. Could be benign (an
                # autonomous SPEAK on a channel nobody is waiting on)
                # or a real bug (the agent emitted on the wrong
                # channel and the interact() request will time out
                # at the server's correlation window).
                #
                # Bumped from DEBUG to INFO + include the set of
                # channels that DO have waiters: when an [INTERACT_
                # TIMEOUT] later fires, that log line tells us
                # whether this SPEAK was misrouted (waiters exist
                # elsewhere) vs. truly orphaned (no waiters at all).
                pending = {k: len(v) for k, v in message_channel_map.items() if v}
                logger.info(
                    "[API_INTERACTION] SPEAK on channel %s but no pending "
                    "interact() waiter on that channel. Active waiters: %s",
                    channel_id,
                    pending or "<none>",
                )
                return

            claimed = self._claim_waiting_message_id(channel_id, queue, self._speaking_task_id())
            if claimed is None:
                return
            message_id, owning_task_id = claimed

            logger.info(
                f"[API_INTERACTION] Processing channel_id={channel_id}, content_len={len(content)}, "
                f"content_preview={content[:100] if content else 'EMPTY'}"
            )

            from ciris_engine.logic.adapters.api.routes.agent import store_message_response

            logger.info(f"[API_INTERACTION] About to store: message_id={message_id}, content='{content}'")
            await store_message_response(message_id, content, task_id=owning_task_id)
            logger.info(f"Stored interact response for message {message_id} in channel {channel_id}")
        except Exception as e:
            # Was DEBUG — a real exception here means a queued
            # interact() request will NEVER get its response. Bump
            # to WARNING with traceback so incident-log scans pick
            # it up alongside the eventual [INTERACT_TIMEOUT].
            logger.warning(
                "[API_INTERACTION] Could not store interact response on channel %s: %s",
                channel_id,
                e,
                exc_info=True,
            )

    def _track_response_time(self, start_time: datetime) -> None:
        """Track response time metrics."""
        elapsed_ms = (datetime.now(timezone.utc) - start_time).total_seconds() * 1000
        self._response_times.append(elapsed_ms)
        if len(self._response_times) > self._max_response_times:
            self._response_times = self._response_times[-self._max_response_times :]

    async def send_system_message(
        self, channel_id: str, content: str, message_type: str = "system", author_name: str = "System"
    ) -> bool:
        """
        Send a system or error message to a channel.

        Args:
            channel_id: Target channel
            content: Message content
            message_type: Type of message (system, error)
            author_name: Name to display as author (default: System)

        Returns:
            True if message was sent successfully
        """
        import uuid

        from ciris_engine.logic import persistence
        from ciris_engine.schemas.telemetry.core import (
            ServiceCorrelation,
            ServiceCorrelationStatus,
            ServiceRequestData,
            ServiceResponseData,
        )

        start_time = datetime.now(timezone.utc)
        logger.info(
            f"[SEND_SYSTEM_MESSAGE] channel_id={channel_id}, message_type={message_type}, content_len={len(content)}"
        )

        try:
            # Create correlation for tracking with message_type in parameters
            correlation_id = str(uuid.uuid4())
            correlation = ServiceCorrelation(
                correlation_id=correlation_id,
                service_type="api",
                handler_name="APIAdapter",
                action_type="speak",
                request_data=ServiceRequestData(
                    service_type="api",
                    method_name="speak",
                    channel_id=channel_id,
                    parameters={"content": content, "channel_id": channel_id, "message_type": message_type},
                    request_timestamp=start_time,
                ),
                response_data=ServiceResponseData(
                    success=True,
                    result_summary=f"{message_type} message sent",
                    execution_time_ms=0,
                    response_timestamp=start_time,
                ),
                status=ServiceCorrelationStatus.COMPLETED,
                created_at=start_time,
                updated_at=start_time,
                timestamp=start_time,
            )

            time_service = getattr(self, "_time_service", None)
            persistence.add_correlation(correlation, time_service)
            logger.debug(f"Created {message_type} message correlation for channel {channel_id}")

            # Try WebSocket first
            if await self._send_websocket_message(channel_id, content):
                return True

            # Queue for HTTP response
            await self._response_queue.put({"channel_id": channel_id, "content": content})

            # Track successful request
            self._track_request()
            self._track_response_time(start_time)

            return True

        except Exception as e:
            logger.error(f"Failed to send {message_type} message: {e}")
            self._track_error(e)
            return False

    async def send_message(self, channel_id: str, content: str) -> bool:
        """Send message through API response or WebSocket."""
        start_time = datetime.now(timezone.utc)
        logger.info(
            f"[SEND_MESSAGE] channel_id={channel_id}, content_len={len(content)}, content_preview={content[:100] if content else 'EMPTY'}"
        )
        try:
            # Create correlation for tracking
            self._create_speak_correlation(channel_id, content)

            # Try WebSocket first
            if await self._send_websocket_message(channel_id, content):
                return True

            # Queue for HTTP response
            await self._response_queue.put({"channel_id": channel_id, "content": content})

            # Handle API interaction response if applicable
            await self._handle_api_interaction_response(channel_id, content)

            # Track successful request
            self._track_request()
            self._track_response_time(start_time)

            return True

        except Exception as e:
            logger.error(f"Failed to send message: {e}")
            self._track_error(e)
            return False

    def register_websocket(self, client_id: str, websocket: Any) -> None:
        """Register a WebSocket client."""
        self._websocket_clients[client_id] = websocket
        logger.info(f"WebSocket client registered: {client_id}")

    def unregister_websocket(self, client_id: str) -> None:
        """Unregister a WebSocket client."""
        if client_id in self._websocket_clients:
            del self._websocket_clients[client_id]
            logger.info(f"WebSocket client unregistered: {client_id}")

    def _extract_parameters(self, request_data: Any) -> JSONDict:
        """Extract parameters from request data handling both dict and Pydantic model cases."""
        if hasattr(request_data, "get"):
            params = request_data.get("parameters", {})
            return params if isinstance(params, dict) else {}
        elif hasattr(request_data, "parameters") and request_data.parameters:
            params = request_data.parameters
            return params if isinstance(params, dict) else {}
        return {}

    def _create_speak_message(self, correlation: Any) -> FetchedMessage:
        """Create a FetchedMessage from a 'speak' correlation (outgoing agent message)."""
        params = self._extract_parameters(correlation.request_data)
        content = params.get("content", "")
        message_type = params.get("message_type", "agent")

        return FetchedMessage(
            message_id=correlation.correlation_id,
            author_id="ciris",
            author_name="CIRIS",
            content=content,
            timestamp=self._format_timestamp(correlation),
            is_bot=True,
            message_type=message_type,
        )

    def _create_observe_message(self, correlation: Any) -> FetchedMessage:
        """Create a FetchedMessage from an 'observe' correlation (incoming user message)."""
        params = self._extract_parameters(correlation.request_data)

        return FetchedMessage(
            message_id=params.get("message_id", correlation.correlation_id),
            author_id=params.get("author_id", "unknown"),
            author_name=params.get("author_name", "User"),
            content=params.get("content", ""),
            timestamp=self._format_timestamp(correlation),
            is_bot=False,
            message_type="user",
        )

    def _format_timestamp(self, correlation: Any) -> Optional[str]:
        """Format correlation timestamp for FetchedMessage."""
        timestamp = correlation.timestamp or correlation.created_at
        return timestamp.isoformat() if timestamp else None

    def _process_correlation(self, correlation: Any) -> Optional[FetchedMessage]:
        """Process a single correlation into a FetchedMessage if applicable."""
        if not correlation.request_data:
            return None

        if correlation.action_type == "speak":
            return self._create_speak_message(correlation)
        elif correlation.action_type == "observe":
            return self._create_observe_message(correlation)

        return None

    async def fetch_messages(
        self,
        channel_id: str,
        *,
        limit: int = 50,
        before: Optional[datetime] = None,
    ) -> List[FetchedMessage]:
        """Retrieve messages from a channel using the correlations database."""
        from ciris_engine.logic.persistence import get_correlations_by_channel

        try:
            correlations = get_correlations_by_channel(channel_id=channel_id, limit=limit, before=before)

            messages = []
            for corr in correlations:
                message = self._process_correlation(corr)
                if message:
                    messages.append(message)

            # Sort by timestamp
            messages.sort(key=lambda m: str(m.timestamp))
            return messages

        except Exception as e:
            logger.error(f"Failed to fetch messages from correlations for channel {channel_id}: {e}")
            return []

    async def start(self) -> None:
        """Start the communication service."""
        await BaseService.start(self)
        logger.info("API communication service started")

    async def stop(self) -> None:
        """Stop the communication service."""
        # Clear any pending responses
        while not self._response_queue.empty():
            try:
                self._response_queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        await BaseService.stop(self)
        logger.info("API communication service stopped")

    def _check_dependencies(self) -> bool:
        """Check if all dependencies are satisfied."""
        return True  # No hard dependencies

    def _collect_custom_metrics(self) -> Dict[str, float]:
        """Collect API communication specific metrics."""
        avg_response_time = sum(self._response_times) / len(self._response_times) if self._response_times else 0.0
        return {
            "websocket_clients": float(len(self._websocket_clients)),
            "queue_size": float(self._response_queue.qsize()),
            "avg_response_time_ms": avg_response_time,
            "response_times_tracked": float(len(self._response_times)),
        }

    def _get_actions(self) -> List[str]:
        """Get the list of actions this service supports."""
        return ["send_message", "fetch_messages", "queue_response", "dequeue_response"]

    def get_service_type(self) -> ServiceType:
        """Get the type of this service."""
        return ServiceType.ADAPTER

    def get_home_channel_id(self) -> Optional[str]:
        """Get the home channel ID for this API adapter.

        Returns:
            The formatted channel ID (e.g., 'api_0.0.0.0_8080')
            or None if no home channel is configured.
        """
        if self._config and hasattr(self._config, "get_home_channel_id"):
            # Use the config method if available
            host = getattr(self._config, "host", "0.0.0.0")
            port = getattr(self._config, "port", 8080)
            result = self._config.get_home_channel_id(host, port)
            return str(result) if result is not None else None

        # Default fallback
        return "api_0.0.0.0_8080"

    def get_status(self) -> "ServiceStatus":
        """Get the service status."""
        from ciris_engine.schemas.services.core import ServiceStatus

        # Calculate uptime
        uptime_seconds = 0.0
        if self._start_time:
            current_time = datetime.now(timezone.utc) if not self._time_service else self._time_service.now()
            uptime_seconds = (current_time - self._start_time).total_seconds()

        # Calculate average response time
        avg_response_time = 0.0
        if self._response_times:
            avg_response_time = sum(self._response_times) / len(self._response_times)

        return ServiceStatus(
            service_name="APICommunicationService",
            service_type="communication",
            is_healthy=self._started,
            uptime_seconds=uptime_seconds,
            last_error=None,  # Could track last error message
            metrics={
                "requests_handled": float(self._requests_handled),
                "error_count": float(self._error_count),
                "avg_response_time_ms": avg_response_time,
                "queued_responses": float(self._response_queue.qsize()),
                "websocket_clients": float(
                    len(self._websocket_clients) if hasattr(self._websocket_clients, "__len__") else 0
                ),
            },
        )

    def get_capabilities(self) -> "ServiceCapabilities":
        """Get the service capabilities."""
        from ciris_engine.schemas.services.core import ServiceCapabilities

        return ServiceCapabilities(
            service_name="APICommunicationService",
            actions=[
                "send_message",
                "fetch_messages",
                "broadcast",
                "get_response",
                "register_websocket",
                "unregister_websocket",
            ],
            version="1.0.0",
            metadata=None,
        )
