"""Core processors module."""
