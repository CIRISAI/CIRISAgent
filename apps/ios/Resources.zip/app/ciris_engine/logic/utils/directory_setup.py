"""
Centralized directory setup for CIRIS.

Ensures all required directories exist with correct permissions
before the application starts. FAILS FAST with clear error messages.
"""

import os
import shutil
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Dict, Optional, Tuple

if TYPE_CHECKING:
    from ciris_engine.schemas.config.essential import EssentialConfig


class DirectorySetupError(Exception):
    """Base exception for directory setup failures."""

    pass


class PermissionError(DirectorySetupError):
    """Raised when directory permissions are incorrect and cannot be fixed."""

    pass


class DiskSpaceError(DirectorySetupError):
    """Raised when insufficient disk space is available."""

    pass


class DirectoryCreationError(DirectorySetupError):
    """Raised when a directory cannot be created."""

    pass


class OwnershipError(DirectorySetupError):
    """Raised when ownership cannot be fixed."""

    pass


def _get_file_owner_info(stat_info: os.stat_result) -> Tuple[str, str]:
    """Get owner and group names from file stat info (cross-platform).

    Args:
        stat_info: os.stat_result object

    Returns:
        Tuple of (owner, group) as strings
    """
    # pwd/grp are Unix-only, not available on Windows
    try:
        import grp
        import pwd

        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name
    except (ImportError, KeyError, OSError):
        owner = str(stat_info.st_uid)
        group = str(stat_info.st_gid)

    return owner, group


class WriteTestError(DirectorySetupError):
    """Raised when write test fails."""

    pass


class DatabaseAccessError(DirectorySetupError):
    """Raised when database cannot be accessed exclusively."""

    pass


def _is_ios_runtime() -> bool:
    """True when running on iOS — single-process by design, so lock-probe
    failures are always stale locks from a previous run rather than competing
    agents. iOS reports sys.platform=='ios' under 3.13+, or 'darwin' with an
    iphoneos multiarch under the Toga/BeeWare bridge that ships our build."""
    if sys.platform == "ios":
        return True
    if sys.platform == "darwin" and hasattr(sys, "implementation"):
        return "iphoneos" in getattr(sys.implementation, "_multiarch", "").lower()
    return False


def ensure_database_exclusive_access(db_path: str, fail_fast: bool = True) -> None:
    """Ensure only one agent process can hold the database.

    Post-2.9.0 absorption: persist's `Engine` constructor opens the
    DSN through sqlx with serialized writes. If a second process holds
    the SQLite file exclusively (WAL or otherwise), the Engine call
    raises with a clear `database is locked` message. We probe by
    constructing an Engine and immediately dropping it — no Python-side
    sqlite3 import needed.

    Args:
        db_path: Path to the SQLite database file or PostgreSQL connection string
        fail_fast: If True, exit immediately on access conflict (default True)

    Raises:
        DatabaseAccessError: If database is already in use by another agent
    """
    # Skip exclusive access check for PostgreSQL — sqlx pools handle
    # multi-process safely, and there's no notion of file-level locking.
    if db_path.startswith(("postgresql://", "postgres://")):
        # No DSN in this line: it carries the database password and goes to
        # container stdout on every boot (2.18.0 scouts).
        print("[OK] Skipping exclusive access check for PostgreSQL")
        return

    db_path_obj = Path(db_path)
    db_path_obj.parent.mkdir(parents=True, exist_ok=True)

    # Post-2.9.4: the prior implementation pre-constructed
    # `Engine(dsn, "ciris-agent-bootstrap")` as a probe, then `del`'d it.
    # That was safe in early persist 3.x but breaks persist 3.6.3+ because
    # the Engine is a process-singleton (CIRISPersist#88 `reset_engine` is
    # the only release path) — the probe pinned a bootstrap-keyed Engine
    # in-process, then the real `initialize_database` hit
    # `EngineConfigMismatch` with the agent's actual signing_key_id at
    # boot. See CIRISConformance/tests/test_030_cohabitation_init.py for
    # the canonical "one Engine per process" pattern.
    #
    # Lock detection is preserved end-to-end: persist's `Engine()` call
    # in `_bootstrap_persist_engine` opens the DSN via sqlx and raises
    # "database is locked" naturally when another process holds the file
    # — the lock-error mapping below still fires; it just runs against
    # the real Engine construction instead of a separate probe.
    try:
        if not os.access(db_path_obj.parent, os.W_OK):
            raise PermissionError(f"Database parent dir not writable: {db_path_obj.parent}")
        print("[OK] Database parent dir ready")

    except Exception as e:
        msg = str(e).lower()
        is_lock_error = "lock" in msg or "busy" in msg or "in use" in msg

        # iOS: stale lock from previous crash, not a competing agent.
        if _is_ios_runtime() and (is_lock_error or "operation not permitted" in msg):
            print("[WARN] iOS: database lock probe failed (stale lock from previous run) — proceeding")
            print(f"  Underlying: {e}")
            return

        if is_lock_error:
            error_msg = "CANNOT ACCESS THE DATABASE - ANOTHER AGENT MAY BE RUNNING"
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
            print(f"  Underlying error: {e}", file=sys.stderr)
            print("  Only one CIRIS agent can run per database file", file=sys.stderr)
            print("  Check for other running agents using: ps aux | grep ciris", file=sys.stderr)
        else:
            error_msg = f"UNEXPECTED DATABASE ERROR: {e}"
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)

        if fail_fast:
            sys.exit(1)
        raise DatabaseAccessError(error_msg)


def check_disk_space(path: Path, required_mb: int = 50) -> Tuple[bool, float]:
    """
    Check if sufficient disk space is available.

    Args:
        path: Path to check disk space for
        required_mb: Required space in megabytes (default 100MB)

    Returns:
        Tuple of (has_enough_space, available_mb)
    """
    try:
        stat = shutil.disk_usage(path if path.exists() else path.parent)
        available_mb = stat.free / (1024 * 1024)
        return available_mb >= required_mb, available_mb
    except Exception as e:
        # If we can't check disk space, assume it's insufficient
        print(f"ERROR: Cannot check disk space: {e}")
        return False, 0.0


def home_usage_mb(base_dir: Path) -> float:
    """How much CIRIS's own home occupies, in MB (0.0 when it cannot be read)."""
    total = 0
    try:
        for root, _dirs, files in os.walk(base_dir):
            for name in files:
                try:
                    total += os.lstat(os.path.join(root, name)).st_size
                except OSError:
                    continue
    except OSError:
        return 0.0
    return total / (1024 * 1024)


def _check_disk_space_or_fail(base_dir: Path, fail_fast: bool, required_mb: int = 50) -> None:
    """Check disk space and fail if insufficient.

    Prints a `[FATAL_CODE] disk_space ...` line on stdout first: the mobile
    client reads its key=value tokens to say, in the user's language, that the
    phone is out of storage and how much of it CIRIS holds. The `[FATAL_EXIT]`
    line that ends the startup screen's wait comes from the caller, which only
    sees this as an exception -- so the runtime calls with fail_fast=False.
    """
    has_space, available_mb = check_disk_space(base_dir, required_mb)
    if not has_space:
        ciris_mb = home_usage_mb(base_dir)
        print(
            f"[FATAL_CODE] disk_space free_mb={available_mb:.1f} required_mb={required_mb} ciris_mb={ciris_mb:.1f}",
            flush=True,
        )
        error_msg = (
            f"INSUFFICIENT DISK SPACE: Only {available_mb:.1f}MB available. MINIMUM {required_mb}MB REQUIRED - "
            f"EXITING (CIRIS's own data under {base_dir} uses {ciris_mb:.1f}MB)"
        )
        print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
        if fail_fast:
            sys.exit(1)
        raise DiskSpaceError(error_msg)


def _create_directory(dir_path: Path, mode: int, fail_fast: bool) -> None:
    """Create a single directory with specified permissions."""
    if not dir_path.exists():
        dir_path.mkdir(parents=True, mode=mode)
        print(f"[OK] Created directory: {dir_path} with mode {oct(mode)}")

        # Verify creation
        if not dir_path.exists():
            error_msg = f"UNABLE TO CREATE DIRECTORY {dir_path} - CHECK FILESYSTEM"
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
            if fail_fast:
                sys.exit(1)
            raise DirectoryCreationError(error_msg)


def _fix_directory_permissions(dir_path: Path, mode: int, fail_fast: bool) -> None:
    """Fix permissions on existing directory."""
    current_mode = dir_path.stat().st_mode & 0o777
    if current_mode != mode:
        try:
            dir_path.chmod(mode)
            print(f"[OK] Fixed permissions for {dir_path}: {oct(current_mode)} -> {oct(mode)}")
        except Exception as perm_error:
            error_msg = f"WRONG PERMS on {dir_path}: Has {oct(current_mode)}, needs {oct(mode)} - CANNOT FIX - EXITING"
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
            print(f"  Details: {perm_error}", file=sys.stderr)
            if fail_fast:
                sys.exit(1)
            raise PermissionError(error_msg)


def _check_directory_ownership(dir_path: Path, user_id: int, group_id: int, fail_fast: bool) -> None:
    """Check and fix directory ownership."""
    # Skip ownership check on Windows (user_id/group_id will be -1)
    if user_id == -1 or group_id == -1:
        return

    stat = dir_path.stat()
    if stat.st_uid != user_id or stat.st_gid != group_id:
        try:
            # os.chown is Unix-only
            if hasattr(os, "chown"):
                os.chown(dir_path, user_id, group_id)
                print(f"[OK] Fixed ownership for {dir_path}: {stat.st_uid}:{stat.st_gid} -> {user_id}:{group_id}")
            else:
                # Windows doesn't have chown
                return
        except Exception:
            error_msg = (
                f"WRONG OWNER on {dir_path}: Has {stat.st_uid}:{stat.st_gid}, needs {user_id}:{group_id} - CANNOT FIX"
            )
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
            print(f"  Try: sudo chown {user_id}:{group_id} {dir_path}", file=sys.stderr)
            if fail_fast:
                sys.exit(1)
            raise OwnershipError(error_msg)


def _check_directory_writability(dir_path: Path, fail_fast: bool) -> None:
    """Test if directory is writable."""
    test_file = dir_path / ".write_test"
    try:
        test_file.touch()
        test_file.unlink()
    except Exception as write_error:
        error_msg = f"CANNOT WRITE TO {dir_path} - CHECK PERMISSIONS AND FILESYSTEM"
        print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
        print(f"  Error: {write_error}", file=sys.stderr)
        if fail_fast:
            sys.exit(1)
        raise WriteTestError(error_msg)


def setup_application_directories(
    base_dir: Optional[Path] = None,
    user_id: Optional[int] = None,
    group_id: Optional[int] = None,
    fail_fast: bool = True,
    check_database_access: bool = True,
    essential_config: Optional["EssentialConfig"] = None,
) -> None:
    """
    Set up all required application directories with correct permissions.

    FAILS FAST with clear error messages if directories cannot be created
    or permissions cannot be set correctly.

    Args:
        base_dir: Base directory for the application (defaults to CIRIS home directory)
        user_id: User ID to own the directories (defaults to current user)
        group_id: Group ID to own the directories (defaults to current group)
        fail_fast: If True, exit immediately on any error (default True)
        check_database_access: If True, verify exclusive database access (default True)
        essential_config: Optional EssentialConfig for database path (avoids service registry lookup)

    Raises:
        DirectorySetupError: If any directory setup fails
    """
    if base_dir is None:
        from ciris_engine.logic.utils.path_resolution import get_ciris_home

        base_dir = get_ciris_home()

    if user_id is None:
        # getuid/getgid are Unix-only, not available on Windows
        user_id = getattr(os, "getuid", lambda: -1)()

    if group_id is None:
        # getuid/getgid are Unix-only, not available on Windows
        group_id = getattr(os, "getgid", lambda: -1)()

    # First, ensure exclusive database access (before any other checks)
    if check_database_access:
        if essential_config:
            # Use the provided config directly
            # Prefer database_url (for PostgreSQL), fallback to main_db path (for SQLite)
            if essential_config.database.database_url:
                main_db_path = essential_config.database.database_url
            else:
                main_db_path = str(Path(essential_config.database.main_db).resolve())
            ensure_database_exclusive_access(main_db_path, fail_fast)
        else:
            # Try to get config from service registry
            try:
                from ciris_engine.logic.config import get_sqlite_db_full_path

                main_db_path = get_sqlite_db_full_path()
                ensure_database_exclusive_access(main_db_path, fail_fast)
            except (ImportError, RuntimeError):
                # During early bootstrap, config may not be available yet
                # Default to checking the most likely database path
                default_db_path = str(base_dir / "data" / "ciris_engine.db")
                ensure_database_exclusive_access(default_db_path, fail_fast)

    # Check disk space
    _check_disk_space_or_fail(base_dir, fail_fast)

    # Define directories and their required permissions
    # 0o755 = rwxr-xr-x (readable by all, writable by owner)
    # 0o700 = rwx------ (only owner can read/write/execute)
    directories: Dict[str, int] = {
        "data": 0o755,  # Database files
        "data_archive": 0o755,  # Archived thoughts/tasks
        "logs": 0o755,  # Log files
        "config": 0o755,  # Configuration files
        "secrets": 0o700,  # Secrets storage - restricted!
    }

    for dir_name, mode in directories.items():
        dir_path = base_dir / dir_name

        try:
            # Create or verify directory
            _create_directory(dir_path, mode, fail_fast)

            # Check and fix permissions if directory exists
            if dir_path.exists():
                _fix_directory_permissions(dir_path, mode, fail_fast)

            # Test write access
            _check_directory_writability(dir_path, fail_fast)

            # Try to fix ownership (non-fatal if fails)
            try:
                _check_directory_ownership(dir_path, user_id, group_id, False)
            except (OwnershipError, SystemExit):  # noqa: S110
                # Not fatal if we can't change ownership as long as we can write
                print(f"  Warning: Cannot change ownership of {dir_path} (need root), but write access confirmed")

        except (DirectorySetupError, SystemExit):
            raise  # Re-raise our own exceptions and exits
        except Exception as e:
            error_msg = f"UNEXPECTED ERROR setting up {dir_path}: {e}"
            print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
            if fail_fast:
                sys.exit(1)
            raise DirectorySetupError(error_msg)

    # Check critical files that must be writable
    critical_files = [
        base_dir / "audit_logs.jsonl",  # Audit service export file
    ]

    for file_path in critical_files:
        if file_path.exists():
            # Check if we can write to it
            try:
                # Try to open in append mode (won't truncate)
                with open(file_path, "a"):
                    # Successfully opened for writing
                    pass
                print(f"[OK] Write access verified for {file_path}")
            except (PermissionError, IOError) as e:
                # Get file stats for debugging
                stat = file_path.stat()
                owner, group = _get_file_owner_info(stat)

                error_msg = f"CANNOT WRITE TO CRITICAL FILE {file_path}"
                print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
                print(f"  Owner: {owner}:{group} (uid={stat.st_uid}, gid={stat.st_gid})", file=sys.stderr)
                print(f"  Permissions: {oct(stat.st_mode & 0o777)}", file=sys.stderr)
                print(f"  Current user: uid={user_id}, gid={group_id}", file=sys.stderr)
                print(f"  FIX: sudo chown {user_id}:{group_id} {file_path}", file=sys.stderr)
                if fail_fast:
                    sys.exit(1)
                raise PermissionError(error_msg)

    print("[OK] All directories and critical files successfully configured")


def _validate_directory(dir_path: Path) -> None:
    """Validate a single directory exists and is writable."""
    if not dir_path.exists():
        error_msg = f"REQUIRED DIRECTORY MISSING: {dir_path} - EXITING"
        print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
        raise DirectoryCreationError(error_msg)

    if not dir_path.is_dir():
        error_msg = f"PATH EXISTS BUT IS NOT A DIRECTORY: {dir_path} - EXITING"
        print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
        raise DirectorySetupError(error_msg)

    # Check write access
    test_file = dir_path / ".write_test"
    try:
        test_file.touch()
        test_file.unlink()
    except Exception as e:
        error_msg = f"CANNOT WRITE TO DIRECTORY: {dir_path} - CHECK PERMISSIONS"
        print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
        print(f"  Error: {e}", file=sys.stderr)
        raise PermissionError(error_msg)


def validate_directories(base_dir: Optional[Path] = None) -> bool:
    """
    Validate that all required directories exist and are writable.

    This is a lighter-weight check suitable for production where
    directories should already exist.

    Args:
        base_dir: Base directory for the application

    Returns:
        True if all directories are valid

    Raises:
        DirectorySetupError: If validation fails
    """
    if base_dir is None:
        base_dir = Path.cwd()

    # Check disk space first
    _check_disk_space_or_fail(base_dir, False)

    required_dirs = ["data", "data_archive", "logs", "config"]

    for dir_name in required_dirs:
        dir_path = base_dir / dir_name
        _validate_directory(dir_path)

    # Check critical files if they exist
    critical_files = [
        base_dir / "audit_logs.jsonl",  # Audit service export file
    ]

    for file_path in critical_files:
        if file_path.exists():
            # Check if we can write to it
            try:
                with open(file_path, "a"):
                    # File is writable
                    pass
            except (PermissionError, IOError):
                # Get file stats for debugging
                stat = file_path.stat()

                # pwd/grp are Unix-only, not available on Windows
                try:
                    import grp
                    import pwd

                    owner = pwd.getpwuid(stat.st_uid).pw_name
                    group = grp.getgrgid(stat.st_gid).gr_name
                except (ImportError, KeyError, OSError):
                    owner = str(stat.st_uid)
                    group = str(stat.st_gid)

                # getuid/getgid are Unix-only, not available on Windows
                current_uid = getattr(os, "getuid", lambda: -1)()
                current_gid = getattr(os, "getgid", lambda: -1)()

                error_msg = f"CANNOT WRITE TO CRITICAL FILE: {file_path}"
                print(f"CRITICAL ERROR: {error_msg}", file=sys.stderr)
                print(f"  Owner: {owner}:{group} (uid={stat.st_uid}, gid={stat.st_gid})", file=sys.stderr)
                print(f"  Permissions: {oct(stat.st_mode & 0o777)}", file=sys.stderr)
                print(f"  Current user: uid={current_uid}, gid={current_gid}", file=sys.stderr)
                print(f"  FIX: sudo chown {current_uid}:{current_gid} {file_path}", file=sys.stderr)
                raise PermissionError(error_msg)

    print("[OK] All directories and critical files validated successfully")
    return True


if __name__ == "__main__":
    # Run setup when executed directly
    import argparse

    parser = argparse.ArgumentParser(description="CIRIS Directory Setup")
    parser.add_argument(
        "--validate-only", action="store_true", help="Only validate existing directories (for production)"
    )
    parser.add_argument("--no-fail-fast", action="store_true", help="Continue on errors instead of exiting")
    args = parser.parse_args()

    try:
        if args.validate_only:
            print("Validating CIRIS application directories...")
            validate_directories()
        else:
            print("Setting up CIRIS application directories...")
            setup_application_directories(fail_fast=not args.no_fail_fast)

        print("\n[OK] SUCCESS: All directories properly configured!")
    except DirectorySetupError as e:
        print(f"\n[FAIL] FAILED: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n[FAIL] UNEXPECTED ERROR: {e}", file=sys.stderr)
        sys.exit(1)
