"""
Schemas for runtime adapter management.

These replace all Dict[str, Any] usage in adapter_manager.py.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field

from ciris_engine.schemas.adapters.tools import ToolInfo

# Constants for field descriptions to avoid duplication
ADAPTER_ID_DESC = "Adapter ID"
ADAPTER_TYPE_DESC = "Adapter type"
IS_RUNNING_DESC = "Whether adapter is running"


class AdapterConfig(BaseModel):
    """Configuration for an adapter.

    This schema supports two configuration approaches:
    1. Simple adapters (CLI, API, Discord): Use `settings` dict with flat primitives
    2. Complex adapters (MCP): Use `adapter_config` dict for nested structures

    The adapter's own typed config class (e.g., MCPAdapterConfig, DiscordAdapterConfig)
    performs full validation when the adapter is loaded.
    """

    adapter_type: str = Field(..., description="Type of adapter (cli, api, discord, etc.)")
    enabled: bool = Field(True, description="Whether adapter is enabled")
    persist: bool = Field(
        False,
        description="Whether to persist this adapter config for auto-load on restart. "
        "When True, the adapter will be automatically restored after agent restart.",
    )
    settings: Dict[str, Optional[Union[str, int, float, bool, List[str]]]] = Field(
        default_factory=dict,
        description="Simple adapter settings (flat primitives only). "
        "Use adapter_config for complex nested configurations.",
    )
    adapter_config: Optional[Dict[str, Any]] = Field(
        None,
        description="Full adapter configuration for adapters requiring nested objects "
        "(e.g., MCP servers with bus_bindings). Validated by the adapter's typed config class.",
    )

    model_config = ConfigDict(defer_build=True)


class AdapterLoadRequest(BaseModel):
    """Request to load an adapter."""

    adapter_type: str = Field(..., description="Type of adapter to load")
    adapter_id: str = Field(..., description="Unique ID for the adapter instance")
    config: Optional[AdapterConfig] = Field(None, description="Configuration parameters")
    auto_start: bool = Field(True, description="Whether to auto-start the adapter")

    model_config = ConfigDict(defer_build=True)


class AdapterOperationResult(BaseModel):
    """Result of an adapter operation."""

    success: bool = Field(..., description="Whether operation succeeded")
    adapter_id: str = Field(..., description=ADAPTER_ID_DESC)
    adapter_type: Optional[str] = Field(None, description=ADAPTER_TYPE_DESC)
    message: Optional[str] = Field(None, description="Operation message")
    error: Optional[str] = Field(None, description="Error message if failed")
    details: Optional[Dict[str, Union[str, int, float, bool]]] = Field(None, description="Additional details")

    model_config = ConfigDict(defer_build=True)


class AdapterMetrics(BaseModel):
    """Metrics for an adapter."""

    messages_processed: int = Field(0, description="Total messages processed")
    errors_count: int = Field(0, description="Total errors")
    uptime_seconds: float = Field(0.0, description="Adapter uptime in seconds")
    last_error: Optional[str] = Field(None, description="Last error message")
    last_error_time: Optional[datetime] = Field(None, description="Last error timestamp")

    model_config = ConfigDict(defer_build=True)


class RuntimeAdapterStatus(BaseModel):
    """Status of a single adapter."""

    adapter_id: str = Field(..., description="Unique " + ADAPTER_ID_DESC)
    adapter_type: str = Field(..., description="Type of adapter")
    is_running: bool = Field(..., description=IS_RUNNING_DESC)
    loaded_at: Optional[datetime] = Field(None, description="When adapter was loaded")
    services_registered: List[str] = Field(default_factory=list, description="Services registered by adapter")
    config_params: Optional[AdapterConfig] = Field(None, description="Adapter configuration")
    metrics: Optional[AdapterMetrics] = Field(None, description="Adapter metrics")
    last_activity: Optional[datetime] = Field(None, description="Last activity timestamp")
    tools: Optional[List[ToolInfo]] = Field(None, description="Tools provided by adapter")
    error: Optional[str] = Field(None, description="Error message if adapter failed")

    # Re-authentication status - for OAuth adapters that need token refresh
    needs_reauth: bool = Field(False, description="Whether re-authentication is required")
    reauth_reason: Optional[str] = Field(None, description="Reason re-authentication is needed")

    # Interactive auth support - for adapters with auth steps in their wizard
    has_auth_step: bool = Field(False, description="Whether adapter has an auth step in its wizard")
    auth_step_id: Optional[str] = Field(None, description="ID of the auth step (oauth or device_auth)")

    model_config = ConfigDict(defer_build=True)


class AdapterListResponse(BaseModel):
    """Response containing list of adapters."""

    adapters: List[RuntimeAdapterStatus] = Field(..., description="List of adapter statuses")
    total_count: int = Field(..., description="Total number of adapters")
    running_count: int = Field(..., description="Number of running adapters")

    model_config = ConfigDict(defer_build=True)


class ServiceRegistrationInfo(BaseModel):
    """Information about a service registration."""

    service_type: str = Field(..., description="Type of service")
    provider_name: str = Field(..., description="Provider name")
    priority: str = Field(..., description="Registration priority")
    capabilities: List[str] = Field(..., description="Service capabilities")

    model_config = ConfigDict(defer_build=True)


# NOTE: AdapterInfo was removed from here - use ciris_engine.schemas.services.core.runtime.AdapterInfo
# which has full fields: services_registered, tools, metrics, etc.


class CommunicationAdapterInfo(BaseModel):
    """Information about a communication adapter."""

    adapter_id: str = Field(..., description=ADAPTER_ID_DESC)
    adapter_type: str = Field(..., description=ADAPTER_TYPE_DESC)
    is_running: bool = Field(..., description=IS_RUNNING_DESC)

    model_config = ConfigDict(defer_build=True)


class CommunicationAdapterStatus(BaseModel):
    """Status of all communication adapters."""

    total_communication_adapters: int = Field(..., description="Total count")
    running_communication_adapters: int = Field(..., description="Running count")
    communication_adapters: List[CommunicationAdapterInfo] = Field(..., description="List of adapters")
    safe_to_unload: bool = Field(..., description="Whether safe to unload")
    warning_message: Optional[str] = Field(None, description="Warning message")

    model_config = ConfigDict(defer_build=True)


class ModuleConfigParameter(BaseModel):
    """Configuration parameter definition for a module."""

    name: str = Field(..., description="Parameter name")
    param_type: str = Field(..., description="Parameter type (string, integer, float, boolean, array)")
    default: Optional[Union[str, int, float, bool, List[str]]] = Field(None, description="Default value")
    description: str = Field(..., description="Parameter description")
    env_var: Optional[str] = Field(None, description="Environment variable name")
    required: bool = Field(True, description="Whether parameter is required")
    sensitivity: Optional[str] = Field(None, description="Sensitivity level (e.g., 'HIGH' for secrets)")

    model_config = ConfigDict(defer_build=True)


class ModuleTypeInfo(BaseModel):
    """Information about an available module/adapter type."""

    module_id: str = Field(..., description="Unique module identifier (e.g., 'api', 'mcp_client')")
    name: str = Field(..., description="Human-readable module name")
    version: str = Field(..., description="Module version")
    description: str = Field(..., description="Module description")
    author: str = Field(..., description="Module author")
    homepage: Optional[str] = Field(None, description="Module homepage or documentation URL")
    emoji: Optional[str] = Field(None, description="Display emoji for UI (from imported skills)")
    module_source: str = Field(..., description="Source: 'core' for built-in or 'modular' for plugin")
    service_types: List[str] = Field(
        default_factory=list, description="Service types provided (e.g., TOOL, COMMUNICATION)"
    )
    capabilities: List[str] = Field(default_factory=list, description="Capabilities provided")
    configuration_schema: List[ModuleConfigParameter] = Field(
        default_factory=list, description="Configuration parameters and their types"
    )
    requires_external_deps: bool = Field(False, description="Whether module requires external packages")
    external_dependencies: Dict[str, str] = Field(
        default_factory=dict, description="External package dependencies with version constraints"
    )
    cli_dependencies: List[str] = Field(
        default_factory=list, description="Required CLI tools/binaries (e.g., 'tmux', 'mcporter')"
    )
    is_mock: bool = Field(False, description="Whether this is a mock/test module")
    safe_domain: Optional[str] = Field(None, description="Safe domain classification")
    prohibited: List[str] = Field(default_factory=list, description="Prohibited use cases")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata (supports nested structures)")
    # Platform requirements for this adapter
    platform_requirements: List[str] = Field(
        default_factory=list, description="Platform requirements (e.g., 'android_play_integrity', 'google_native_auth')"
    )
    platform_requirements_rationale: Optional[str] = Field(
        None, description="Explanation of why platform requirements exist"
    )
    platform_available: bool = Field(True, description="Whether this adapter is available on the current platform")
    internal_only: bool = Field(False, description="If True, adapter is hidden from UI and cannot be manually loaded")
    # Interactive configuration (wizard) support
    has_interactive_config: bool = Field(
        False, description="Whether this adapter has interactive configuration (wizard workflow)"
    )

    model_config = ConfigDict(defer_build=True)


class ModuleTypesResponse(BaseModel):
    """Response containing all available module types."""

    core_modules: List[ModuleTypeInfo] = Field(..., description="Built-in core adapters")
    adapters: List[ModuleTypeInfo] = Field(..., description="Dynamically loaded adapters")
    total_core: int = Field(..., description="Total number of core modules")
    total_adapters: int = Field(..., description="Total number of adapters")

    model_config = ConfigDict(defer_build=True)


class AdapterLoadFailure(BaseModel):
    """A configured adapter that did NOT load, kept for the life of the process.

    CIRISAgent#1057. Adapter load failures were logged once at boot and then
    forgotten, so a fleet ran for several releases with two adapters failing to
    import on every agent — and one agent serving with NONE of its configured
    adapters — while every health check said `healthy`. The failure was
    discoverable only by reading the adapter manager's own log line, which is
    not a monitoring strategy.

    Keeping the failures as state (rather than as a log event) is what lets
    /v1/system/health answer the question an operator actually asks: is this
    agent doing what it was configured to do?
    """

    adapter_type: str = Field(..., description="Configured adapter type that failed to load")
    adapter_id: str = Field(..., description="Configured adapter id")
    error: str = Field(..., description="Exception text, for the operator")
    error_type: str = Field(..., description="Exception class name")
    is_missing_module: bool = Field(
        False,
        description=(
            "True when the adapter could not be IMPORTED at all — a renamed or removed adapter still "
            "named in config, rather than one that exists and failed to start. In #1057 this was "
            "'ciris_covenant_metrics' (renamed to ciris_accord_metrics) and 'sync' (gone)."
        ),
    )
