"""First-run setup and configuration management."""
