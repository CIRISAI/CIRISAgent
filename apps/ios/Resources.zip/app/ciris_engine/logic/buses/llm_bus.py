"""
LLM message bus - handles all LLM service operations with redundancy and distribution
"""

import asyncio
import hashlib
import json
import logging
import os
import random
import re
import time
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Type, Union, cast

from ciris_engine.logic.utils import error_emitter, hedging
from ciris_engine.logic.utils.jsondict_helpers import get_float, get_int
from ciris_engine.schemas.types import JSONDict

if TYPE_CHECKING:
    from ciris_engine.logic.registries.base import ServiceRegistry
    from ciris_engine.protocols.services.infrastructure.resource_monitor import ResourceMonitorServiceProtocol
    from ciris_engine.schemas.services.llm import LLMMessage

from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum

from pydantic import BaseModel

from ciris_engine.logic.config.llm_budget import MIN_USEFUL_ATTEMPT_S, current_call_deadline
from ciris_engine.logic.services.runtime.llm_service.provider_limits import (
    IN_FLIGHT_RELEASE_SPREAD_S,
    IN_FLIGHT_TOTAL_WAIT_S,
    ProviderLimitFault,
    ProviderLimitFaultCode,
    in_flight_backoff_s,
    provider_limit_fault,
)
from ciris_engine.logic.registries.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitState,
    ProviderCircuitOpenError,
    breaker_call_scope,
)
from ciris_engine.protocols.services import LLMService
from ciris_engine.protocols.services.graph.telemetry import TelemetryServiceProtocol
from ciris_engine.protocols.services.lifecycle.time import TimeServiceProtocol
from ciris_engine.protocols.services.runtime.llm import MessageDict
from ciris_engine.schemas.context.prompt_provenance import PromptManifest
from ciris_engine.schemas.infrastructure.base import BusMetrics
from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.runtime.resources import ResourceUsage
from ciris_engine.schemas.services.capabilities import LLMCapabilities

from .base_bus import BaseBus, BusMessage
from .thought_resource_ledger import thought_resource_ledger

from ciris_engine.logic.buses.llm_call_context import close_raw_completion_holder, open_raw_completion_holder
logger = logging.getLogger(__name__)


@dataclass
class _ProviderPass:
    """What one pass over the providers produced (internal to call_llm_structured)."""

    result: Optional[Tuple[BaseModel, ResourceUsage]] = None
    tried_any: bool = False
    breaker_skipped: List[Tuple[str, Any]] = field(default_factory=list)
    last_error: Optional[Exception] = None


def _classify_error(exc: BaseException) -> str:
    """Map an exception to one of the LLMCallEvent.status enum values.

    Keep this list consistent with the schema docstring. Any class not matched
    here lands in 'other_error'; the exception class name is preserved in
    error_class so we don't lose fidelity for unrecognized failures.
    """
    cls = exc.__class__.__name__.lower()
    if "timeout" in cls or "deadlineexceeded" in cls:
        return "timeout"
    if "ratelimit" in cls or "429" in str(exc)[:32].lower():
        return "rate_limited"
    if "modelnotfound" in cls or "model_not_available" in str(exc)[:64].lower():
        return "model_not_available"
    if "instructorretry" in cls:
        return "instructor_retry"
    return "other_error"


def _safe_messages_to_text(messages: List[JSONDict]) -> str:
    """Serialize the prompt messages list to a flat string for byte-counting
    and content hashing. Uses JSON for round-trippability."""
    try:
        return json.dumps(messages, ensure_ascii=False, sort_keys=False)
    except (TypeError, ValueError):
        # Fall back to repr() if any nested object isn't JSON-able
        return repr(messages)


@dataclass
class LLMCallEventContext:
    """Bundle of arguments for emitting one ReasoningEvent.LLM_CALL.

    Grouping these into a context dataclass keeps the broadcast helper's
    parameter count under the 13-arg threshold (was 14 individual kwargs)
    and gives callers one symbol to construct + reuse on success / failure
    paths instead of repeating the kwarg list at each emit site.
    """

    success: bool
    handler_name: str
    service_name: str
    selected_service: Any
    api_base: Optional[str]
    response_model: Type[BaseModel]
    messages: List[JSONDict]
    result: Optional[BaseModel]
    usage: Optional[ResourceUsage]
    duration_ms: float
    thought_id: Optional[str]
    task_id: Optional[str]
    retry_count: int
    error: Optional[BaseException] = None


def _extract_api_base(selected_service: Any) -> Optional[str]:
    """The provider endpoint the selected service calls, when it exposes one."""
    config = getattr(selected_service, "openai_config", None)
    return cast(Optional[str], getattr(config, "base_url", None)) if config else None


def _extract_call_model(selected_service: Any) -> Optional[str]:
    """Get the provider model identifier from whichever attribute the
    selected_service exposes (varies between services)."""
    if hasattr(selected_service, "model_name"):
        return cast(Optional[str], getattr(selected_service, "model_name", None))
    if hasattr(selected_service, "openai_config") and selected_service.openai_config:
        return cast(Optional[str], getattr(selected_service.openai_config, "model_name", None))
    return None


def _extract_usage_metrics(
    usage: Optional[ResourceUsage],
) -> Tuple[Optional[int], Optional[int], Optional[float]]:
    """Return (prompt_tokens, completion_tokens, cost_usd) from a
    ResourceUsage record. Tolerates both modern (tokens_input) and legacy
    (prompt_tokens) field names."""
    if usage is None:
        return None, None, None
    prompt_tokens = getattr(usage, "tokens_input", None) or getattr(usage, "prompt_tokens", None)
    completion_tokens = getattr(usage, "tokens_output", None) or getattr(usage, "completion_tokens", None)
    cost_cents = getattr(usage, "cost_cents", None)
    cost_usd = float(cost_cents) / 100.0 if cost_cents is not None else None
    return prompt_tokens, completion_tokens, cost_usd


def _serialize_response(result: Optional[BaseModel]) -> Tuple[Optional[str], Optional[int]]:
    """Return (response_text, completion_bytes) from a Pydantic result.
    Failures here MUST NOT block the broadcast — fall back to (None, None)."""
    if result is None:
        return None, None
    try:
        if hasattr(result, "model_dump_json"):
            response_text = result.model_dump_json()
        else:
            response_text = json.dumps(getattr(result, "__dict__", {}), default=str)
    except Exception:
        return None, None
    return response_text, len(response_text.encode("utf-8"))


def _resolve_status_and_error_class(success: bool, error: Optional[BaseException]) -> Tuple[str, Optional[str]]:
    """Map (success, error) to (status_enum, error_class_name)."""
    if success:
        return "ok", None
    if error is None:
        return "other_error", None
    return _classify_error(error), error.__class__.__name__


def _context_manifest_for(ctx: LLMCallEventContext, max_tokens_sent: Optional[int]) -> Optional[PromptManifest]:
    """The prompt manifest bound to this call (FSD/PROMPT_CONTEXT_PROVENANCE.md §8), finished with what the bus
    sent; None outside prompt_manifest_scope. Never raises: the trace must not break the call."""
    try:
        from ciris_engine.logic.prompt_assembly.manifest_scope import (
            current_prompt_manifest,
            finalize_manifest_for_call,
        )

        manifest = current_prompt_manifest()
        if manifest is None:
            return None
        return finalize_manifest_for_call(
            manifest,
            messages=ctx.messages,
            response_model=ctx.response_model,
            selected_service=ctx.selected_service,
            max_tokens_sent=max_tokens_sent,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(f"[LLM_CALL manifest] failed: {exc!r}", exc_info=False)
        return None


async def _broadcast_llm_call_event(ctx: LLMCallEventContext) -> None:
    """Emit one ReasoningEvent.LLM_CALL per provider invocation.

    Called from BOTH the success path (in _execute_llm_call after the call
    returns) and the failure path (in _try_service's exception handler) so
    every call — successful, retried, or failed — produces exactly one
    discrete event. Best-effort: any exception in the broadcast itself is
    logged and swallowed so the LLM call path is never affected by trace-side
    issues.
    """
    try:
        from ciris_engine.logic.buses.llm_call_context import UNKNOWN_PARENT_EVENT_TYPE, get_parent_event_context
        from ciris_engine.logic.infrastructure.step_streaming import reasoning_event_stream
        from ciris_engine.schemas.services.runtime_control import ReasoningEvent
        from ciris_engine.schemas.streaming.reasoning_stream import create_reasoning_event

        model = _extract_call_model(ctx.selected_service)
        prompt_tokens, completion_tokens, cost_usd = _extract_usage_metrics(ctx.usage)

        prompt_text = _safe_messages_to_text(ctx.messages)
        prompt_bytes = len(prompt_text.encode("utf-8"))
        prompt_hash = hashlib.sha256(prompt_text.encode("utf-8")).hexdigest()

        sent = ctx.usage.sampling if ctx.usage is not None else None
        response_text, completion_bytes = _serialize_response(ctx.result)
        status, error_class = _resolve_status_and_error_class(ctx.success, ctx.error)

        # Parent-event linkage per TRACE_WIRE_FORMAT.md §5.10. Required
        # as of 2.7.9 — emit on every LLM_CALL. Sentinel surfaces uncovered
        # code paths so we can wire them as we find them.
        parent_event_type, parent_attempt_index = get_parent_event_context()
        if parent_event_type == UNKNOWN_PARENT_EVENT_TYPE:
            logger.warning(
                "[LLM_CALL parent] no streaming_step on the call stack — "
                "emitting parent_event_type=%r. Wire a parent context at "
                "the call site to fix this.",
                parent_event_type,
            )

        event = create_reasoning_event(
            event_type=ReasoningEvent.LLM_CALL,
            context_manifest=_context_manifest_for(ctx, sent.max_tokens if sent else None),
            thought_id=ctx.thought_id,
            task_id=ctx.task_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            handler_name=ctx.handler_name,
            service_name=ctx.service_name,
            model=model,
            base_url=ctx.api_base,
            response_model=ctx.response_model.__name__,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            prompt_bytes=prompt_bytes,
            completion_bytes=completion_bytes,
            cost_usd=cost_usd,
            sent_temperature=sent.temperature if sent else None,
            sent_seed=sent.seed if sent else None,
            sent_max_tokens=sent.max_tokens if sent else None,
            served_by=sent.served_by if sent else None,
            served_model=sent.served_model if sent else None,
            duration_ms=float(ctx.duration_ms),
            status=status,
            error_class=error_class,
            attempt_count=1,  # Instructor-level attempt count not surfaced through bus today; reserved
            retry_count=ctx.retry_count,
            prompt_hash=prompt_hash,
            # prompt and response_text are populated for the trace adapter to gate
            # by trace level (DETAILED+ keeps hash; FULL keeps full text). The bus
            # ships them and lets the adapter strip per-level.
            prompt=prompt_text,
            response_text=response_text,
            # Parent linkage — see comment above.
            parent_event_type=parent_event_type,
            parent_attempt_index=parent_attempt_index,
        )
        await reasoning_event_stream.broadcast_reasoning_event(event)
    except Exception as broadcast_exc:
        # Trace plumbing failure must never break the LLM call path. Log once
        # at warning level so the gap is visible in incidents.
        logger.warning(f"[LLM_CALL broadcast] failed: {broadcast_exc!r}", exc_info=False)


class DistributionStrategy(str, Enum):
    """Strategy for distributing requests among services at the same priority"""

    ROUND_ROBIN = "round_robin"
    LATENCY_BASED = "latency_based"
    RANDOM = "random"
    LEAST_LOADED = "least_loaded"


@dataclass
class ServiceMetrics:
    """Metrics for a single LLM service instance"""

    total_requests: int = 0
    failed_requests: int = 0
    total_latency_ms: float = 0.0
    last_request_time: Optional[datetime] = None
    last_failure_time: Optional[datetime] = None
    consecutive_failures: int = 0

    @property
    def average_latency_ms(self) -> float:
        """Calculate average latency"""
        if self.total_requests == 0:
            return 0.0
        return self.total_latency_ms / self.total_requests

    @property
    def failure_rate(self) -> float:
        """Calculate failure rate"""
        if self.total_requests == 0:
            return 0.0
        return self.failed_requests / self.total_requests


class LLMBusMessage(BusMessage):
    """Bus message for LLM generation"""

    messages: List[MessageDict]
    response_model: Type[BaseModel]
    max_tokens: int = 4096
    temperature: float = 0.0
    # For async responses
    future: Optional[asyncio.Future[Any]] = None


#: Hard stop on in-flight-budget retries for one call, beside the time bounds:
#: full jitter can draw near-zero waits, and a budget that never frees must not
#: become a tight loop.
_IN_FLIGHT_MAX_RETRIES = 12

#: Whose in-flight budget a call spends: (base URL, key digest) from the
#: service's ``budget_identity()``, or ("service", name) when it has none.
BudgetKey = Tuple[str, str]


class _InFlightQueueTimeout(Exception):
    """An in-flight retry could not get a concurrency slot within its deadline."""


class LLMBus(BaseBus[LLMService]):
    """
    Message bus for all LLM operations with redundancy and distribution.

    Features:
    - Multiple redundant LLM providers
    - Priority-based selection
    - Distribution strategies (round-robin, latency-based)
    - Circuit breakers per service
    - Automatic failover
    - Metrics tracking
    """

    def __init__(
        self,
        service_registry: "ServiceRegistry",
        time_service: TimeServiceProtocol,
        telemetry_service: Optional[TelemetryServiceProtocol] = None,
        distribution_strategy: DistributionStrategy = DistributionStrategy.LATENCY_BASED,
        circuit_breaker_config: Optional[JSONDict] = None,
        resource_monitor: Optional["ResourceMonitorServiceProtocol"] = None,
    ):
        super().__init__(service_type=ServiceType.LLM, service_registry=service_registry)
        # Receives each completed call's tokens (tokens_hour / tokens_day budgets).
        self.resource_monitor = resource_monitor

        self._time_service = time_service
        self._start_time = time_service.now() if time_service else None
        self.distribution_strategy = distribution_strategy
        self.circuit_breaker_config = circuit_breaker_config or {}
        self.telemetry_service = telemetry_service

        # Service metrics and circuit breakers
        self.service_metrics: dict[str, ServiceMetrics] = defaultdict(ServiceMetrics)
        self.circuit_breakers: dict[str, CircuitBreaker] = {}
        # The last error each provider actually RETURNED. A breaker skip sends
        # no request, so it has no error of its own; this is what the skip
        # reports instead of "Last error: None".
        self._last_provider_error: dict[str, Exception] = {}

        # Track services that have had full error logs to reduce log verbosity
        self._services_with_full_error_logged: set[str] = set()

        # Background tasks set to prevent garbage collection (SonarCloud fix)
        self._background_tasks: set[asyncio.Task[Any]] = set()

        # Global rate limit cooldown per provider (timestamp when provider can be used again)
        # This prevents hammering a rate-limited provider with immediate retries
        self._rate_limited_until: dict[str, float] = {}
        self._rate_limit_cooldown_seconds = 60.0  # Default cooldown when rate limit exhausted

        # Provider-wide PAUSE after an in-flight-budget refusal (#1366 item 20),
        # monotonic time per provider. OpenRouter's in-flight budget is the
        # ACCOUNT's: when one call is refused, the ~8 parallel calls of the same
        # thought would be refused too, and retrying them all on the same beat
        # refills the budget in lockstep. So the first refusal holds every NEW
        # call to that provider until its Retry-After / backoff has passed, and
        # releases them spread out (see _wait_out_provider_pause).
        # Keyed by BUDGET (base URL + key digest), not service name: replicas and
        # differently-named services on one key share one account budget.
        self._provider_paused_until: dict[BudgetKey, float] = {}
        # Consecutive in-flight refusals per budget, reset by any success on
        # it: the backoff exponent, so sustained pressure backs off for every
        # caller instead of each new call starting at attempt 0.
        self._in_flight_streak: dict[BudgetKey, int] = defaultdict(int)

        # Per-service FIFO concurrency gate. asyncio.Semaphore is fair — waiters
        # are released in the order they called acquire() — so excess callers
        # queue up rather than blasting the provider. Default 4 in-flight is
        # conservative for a single external endpoint (Groq/OpenRouter/etc) and
        # spreads load across a primary+backup pair (4+4 = 8 effective
        # parallelism while keeping any one provider's queue shallow). Lowered
        # from 8 in 2.7.4 after the production datum incident: 8-in-flight on
        # gemma-4 at ~16s/call meant queue depth grew faster than it drained
        # whenever the backup was unavailable; 4 forces spillover sooner.
        # Override with CIRIS_LLM_MAX_CONCURRENT for higher-rate-tier providers.
        try:
            self._max_in_flight_per_service = max(1, int(os.environ.get("CIRIS_LLM_MAX_CONCURRENT", "4")))
        except (TypeError, ValueError):
            self._max_in_flight_per_service = 4
        self._service_semaphores: dict[str, asyncio.Semaphore] = {}
        # Explicit pending counter, incremented at selection and decremented on
        # completion. Needed because asyncio.Semaphore._value only decreases
        # after `async with` has awaited its turn — under bursty concurrency,
        # many callers race selection before any of them have acquired, so
        # LEAST_LOADED needs this counter to see pending-but-unacquired load.
        self._in_flight: dict[str, int] = defaultdict(int)

        # Round-robin state
        self.round_robin_index: dict[int, int] = defaultdict(int)  # priority -> index

        logger.info(
            f"LLMBus initialized with {distribution_strategy} distribution strategy "
            f"(max {self._max_in_flight_per_service} in-flight per service)"
        )

    def _get_service_semaphore(self, service_name: str) -> asyncio.Semaphore:
        """Get or create the FIFO concurrency gate for a service."""
        sem = self._service_semaphores.get(service_name)
        if sem is None:
            sem = asyncio.Semaphore(self._max_in_flight_per_service)
            self._service_semaphores[service_name] = sem
        return sem

    @staticmethod
    def _is_connection_error(e: BaseException) -> bool:
        """A dropped or refused connection to the provider, anywhere in the cause chain.

        Typed, not worded: the LLM service re-raises it as the generic
        "LLM API call failed" RuntimeError, so the text says nothing. It is as
        transient as a 503, but it used to get the single general attempt, then
        the DMA did not retry it either, and the task failed with no reply
        (RATCHET Market 4, run 43453725789, ac-21: one "Connection error.").
        Includes openai's APITimeoutError, which subclasses APIConnectionError.
        """
        try:
            from openai import APIConnectionError
        except ImportError:  # pragma: no cover - openai is a hard dependency
            return False
        seen: set[int] = set()
        cur: Optional[BaseException] = e
        while cur is not None and id(cur) not in seen:
            seen.add(id(cur))
            if isinstance(cur, APIConnectionError):
                return True
            cur = cur.__cause__ or cur.__context__
        return False

    def _is_server_error(self, error_str: str, full_error: str) -> bool:
        """Detect transient upstream server errors (5xx and upstream-provider errors).

        These get the same polite-backoff treatment as 429s — wait, retry, and
        do NOT count against the circuit breaker. Covers:
          - HTTP 502 Bad Gateway (upstream dead or overloaded)
          - HTTP 503 Service Unavailable
          - HTTP 504 Gateway Timeout
          - OpenRouter "Provider returned error" (upstream relay error)
        """
        combined = f"{error_str} {full_error}".lower()
        # Match HTTP-shape patterns only — bare "503" or "service unavailable"
        # are too broad (a generic RuntimeError mentioning "service unavailable"
        # would trip backoff and retry-loop on a non-transient error).
        # Look for status codes attached to HTTP-style markers, or specific
        # provider/proxy error envelopes.
        return any(
            marker in combined
            for marker in (
                "http 502",
                "http 503",
                "http 504",
                "status 502",
                "status 503",
                "status 504",
                "code: 502",
                "code: 503",
                "code: 504",
                "code': 502",
                "code': 503",
                "code': 504",
                "error code: 502",
                "error code: 503",
                "error code: 504",
                "(502)",
                "(503)",
                "(504)",
                "provider returned error",
            )
        )

    # Class-level once-flags so misconfiguration / first-success logs fire
    # exactly once per process per (handler_filter, path) pair, regardless
    # of which bus instance ran the call. The capture path is process-
    # global state already (env vars + filesystem), so process-global once
    # tracking is the right granularity. Key shape: (filter_str, path_str).
    _capture_active_logged: set[Tuple[str, str]] = set()
    _capture_failure_logged: set[Tuple[str, str]] = set()

    def _maybe_capture_call(
        self,
        *,
        handler_name: str,
        service_name: str,
        thought_id: Optional[str],
        task_id: Optional[str],
        messages: List[JSONDict],
        response_model: Type[BaseModel],
        result: Any,
        temperature: float,
        max_tokens: int,
        model: Optional[str] = None,
        api_base: Optional[str] = None,
        raw_completion_text: Optional[str] = None,
        error: Optional[BaseException] = None,
    ) -> None:
        """Diagnostic capture for replay against the bounce harness.

        Also the safety battery's record of prompts and generations for
        training and research (the trace path keeps only a prompt hash unless
        the full level is delivered). Each row is the call as the model saw
        it: `messages` are the wire messages, unscrubbed and unaltered, and
        `prompt_hash` is the same sha256 the LLM_CALL trace event carries, so
        a row can be matched to its trace. `result` is the parsed structured
        reply and `raw_completion_text` is the completion as the provider
        returned it (the last one, when instructor re-asked; None when the
        service did not hand one over). A failed call is a row too: `status`
        is "error", with the error class and message and no reply.

        OFF unless the env var is set. Never set it where real users' traffic
        runs: rows hold the full conversation.

        Writes one JSONL row per matched call. Gated by env vars so
        production paths are zero-cost (early return on the os.environ
        lookup if the capture env var is unset).

        Env vars:
          CIRIS_LLM_CAPTURE_HANDLER  comma-separated list of handler
                                     names to match against handler_name
                                     (e.g. 'optimization_veto_conscience'
                                     or 'entropy_conscience,EthicalPDMA
                                     Evaluator'), or '*' for all. Unset =
                                     disabled. Whitespace around list
                                     items is stripped.
          CIRIS_LLM_CAPTURE_FILE     output JSONL path. Defaults to
                                     `~/.ciris/llm_capture.jsonl` (a
                                     user-private path). Explicitly do
                                     NOT default to /tmp/ — captured
                                     data contains LLM messages with
                                     potentially sensitive content, and
                                     a world-writable default invites
                                     symlink attacks and data leakage
                                     between local users.

        Reliability / observability:
          - First successful capture write per (filter, path) pair logs
            INFO so operators can confirm capture is flowing without
            tailing the file. The agent process log is the authoritative
            "capture is on" signal.
          - First failed write per (filter, path) pair logs WARNING with
            the failure reason so misconfiguration (path doesn't exist,
            wrong perms, symlink trap) is visible immediately. Subsequent
            failures stay at debug — the warning fired once and the
            operator can act.
          - Exceptions never escape — the diagnostic capture must not
            crash the real LLM call. The WARNING log replaces the silent-
            debug failure mode that previously hid all misconfigs.

        Hardening:
          - The output file is opened with O_NOFOLLOW so a pre-existing
            symlink at the path (e.g., a hostile local user pointing
            it at a sensitive file the agent uid can write) causes
            the open to fail rather than overwrite the symlink target.
          - O_CREAT with mode 0600 means new files are owner-readable
            only.
          - The parent directory is created with mode 0700 if missing
            (default path only — explicit paths are operator-managed).
        """
        import os

        match = os.environ.get("CIRIS_LLM_CAPTURE_HANDLER")
        if not match:
            return

        # Comma-separated list support: 'a,b,c' matches if handler_name
        # equals any of {a, b, c}. Single-name unchanged. '*' anywhere
        # in the list still wildcards everything.
        if match == "*":
            pass  # match all
        else:
            match_set = {part.strip() for part in match.split(",") if part.strip()}
            if "*" not in match_set and handler_name not in match_set:
                return

        default_dir = os.path.join(os.path.expanduser("~"), ".ciris")
        default_path = os.path.join(default_dir, "llm_capture.jsonl")
        out_path = os.environ.get("CIRIS_LLM_CAPTURE_FILE", default_path)
        _key = (match, out_path)

        try:
            import json

            # Ensure the parent directory exists with restrictive perms
            # when we're using the default. We do NOT mkdir for an
            # explicitly-set path — that's the operator's responsibility.
            if out_path == default_path:
                os.makedirs(default_dir, mode=0o700, exist_ok=True)

            from datetime import datetime, timezone

            from ciris_engine.constants import CIRIS_VERSION

            row = {
                "capture_schema": 2,
                "captured_at": datetime.now(timezone.utc).isoformat(),
                "agent_version": CIRIS_VERSION,
                "model": model,
                "api_base": api_base,
                "prompt_hash": hashlib.sha256(_safe_messages_to_text(messages).encode("utf-8")).hexdigest(),
                "scrubbed": False,
                "status": "ok" if error is None else "error",
                "error_class": error.__class__.__name__ if error is not None else None,
                "error": str(error)[:4000] if error is not None else None,
                "raw_completion_text": raw_completion_text,
                "handler": handler_name,
                "service": service_name,
                "thought_id": thought_id,
                "task_id": task_id,
                "response_model": response_model.__name__,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "messages": messages,
                "result": (
                    None if result is None else (result.model_dump() if hasattr(result, "model_dump") else str(result))
                ),
            }

            # O_NOFOLLOW: refuse to follow a symlink at out_path. If a
            # hostile local user pre-created out_path as a symlink to a
            # sensitive file, the open raises ELOOP rather than writing
            # the captured data into the symlink target. O_APPEND for
            # multi-call accumulation. Mode 0o600 = owner-only on the
            # newly-created file; ignored if the file already exists.
            flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_NOFOLLOW
            fd = os.open(out_path, flags, 0o600)
            try:
                with os.fdopen(fd, "a", encoding="utf-8") as f:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")
            except Exception:
                try:
                    os.close(fd)
                except OSError:
                    pass
                raise

            # First successful capture per (filter, path) — emit a
            # one-shot INFO so operators see "capture is active" in
            # the agent's own log without tailing the file.
            if _key not in LLMBus._capture_active_logged:
                LLMBus._capture_active_logged.add(_key)
                logger.info(
                    "[LLM_CAPTURE] active: filter=%r path=%r first_handler=%r",
                    match,
                    out_path,
                    handler_name,
                )
        except Exception as e:
            # Failure-safe: never raise out of capture. But promote the
            # FIRST failure per (filter, path) to WARNING so silent
            # misconfiguration (bad path, missing parent dir, symlink
            # trap) is visible. Subsequent failures stay at debug to
            # avoid log floods.
            if _key not in LLMBus._capture_failure_logged:
                LLMBus._capture_failure_logged.add(_key)
                logger.warning(
                    "[LLM_CAPTURE] write failed (filter=%r path=%r): %s — "
                    "subsequent failures will log at debug. Common causes: "
                    "parent dir missing for explicit path, symlink at path, "
                    "perms denied.",
                    match,
                    out_path,
                    e,
                )
            else:
                logger.debug(f"[LLM_CAPTURE] failed to write: {e}")

    def _normalize_messages(self, messages: Union[List[JSONDict], List["LLMMessage"]]) -> List[JSONDict]:
        """Normalize messages to dict format for LLM providers.

        Args:
            messages: List of message dictionaries or LLMMessage objects

        Returns:
            List of normalized message dictionaries
        """
        from ciris_engine.schemas.services.llm import LLMMessage

        normalized_messages: List[JSONDict] = []
        for msg in messages:
            if isinstance(msg, LLMMessage):
                # Use exclude_none=True to avoid sending name: None to providers
                # Some providers (e.g., Together AI) reject null values for optional fields
                msg_dict = msg.model_dump(exclude_none=True)
                normalized_messages.append(msg_dict)
            else:
                # Only strip the optional "name" field if it's None
                # IMPORTANT: Don't strip required fields like "content" even if None
                # (tool-call assistant messages require "content": None to be present)
                msg_copy = dict(msg)
                if "name" in msg_copy and msg_copy["name"] is None:
                    del msg_copy["name"]
                normalized_messages.append(msg_copy)
        return normalized_messages

    def _extract_full_error_from_cause_chain(self, e: Exception) -> str:
        """Extract full error message from exception cause chain."""
        full_error = str(e)
        cause = getattr(e, "__cause__", None)

        while cause:
            cause_str = str(cause)
            if "try again in" in cause_str.lower():
                return cause_str

            if hasattr(cause, "last_attempt"):
                try:
                    nested_exc = cause.last_attempt.exception()
                    if nested_exc:
                        return str(nested_exc)
                except Exception:
                    pass

            cause = getattr(cause, "__cause__", None)

        return full_error

    def _extract_retry_after_time(self, full_error: str) -> float:
        """Extract retry-after time from error message. Returns wait time in seconds."""
        wait_time = 5.0  # Default wait
        match_ms = re.search(r"try again in (\d+\.?\d*)ms", full_error, re.IGNORECASE)
        match_s = re.search(r"try again in (\d+\.?\d*)s(?![\w])", full_error, re.IGNORECASE)

        if match_ms:
            wait_time = float(match_ms.group(1)) / 1000.0 + 0.5
        elif match_s:
            wait_time = float(match_s.group(1)) + 0.5

        # Add jitter to spread out concurrent retry storms
        return wait_time + random.uniform(0, 2.0)

    def _is_rate_limit_error(self, error_str: str, full_error: str) -> bool:
        """Check if error is a rate limit error."""
        return "429" in full_error or "rate_limit" in error_str or "rate limit" in error_str

    def _is_schema_validation_error(self, error_str: str) -> bool:
        """Check if error is a schema validation error."""
        return "validation error" in error_str or "model_type" in error_str or "instructor" in error_str

    async def _handle_retry_error(
        self,
        e: Exception,
        service_name: str,
        retry_count: int,
        max_retries: int,
        rate_limit_retry_count: int,
        max_rate_limit_retries: int,
        rate_limit_start_time: Optional[float],
        max_rate_limit_total_time: float,
    ) -> Tuple[str, bool, int, Optional[float]]:
        """
        Handle retry logic for different error types.

        Returns: (action, is_rate_limit, updated_rate_limit_count, updated_start_time)
        - action: "continue" (retry), "break" (stop retrying), "continue_no_increment" (rate limit retry)
        """
        error_str = str(e).lower()
        full_error = self._extract_full_error_from_cause_chain(e)

        # Handle rate limit errors AND upstream server errors (502/503/504,
        # "Provider returned error"). Both are transient/external — polite
        # backoff, don't count against the circuit breaker, share the same
        # retry budget so concurrent waves don't escalate server hiccups into
        # a cascade of "LLM UNEXPECTED ERROR"s.
        is_rate_limit = self._is_rate_limit_error(error_str, full_error)
        is_server_error = self._is_server_error(error_str, full_error) or self._is_connection_error(e)
        if is_rate_limit or is_server_error:
            rate_limit_retry_count += 1
            if is_server_error and not is_rate_limit:
                logger.warning(
                    f"Upstream server or connection error on {service_name} "
                    f"(attempt {rate_limit_retry_count}/{max_rate_limit_retries}): "
                    f"{type(e).__name__} — applying rate-limit backoff"
                )
            should_continue, _, rate_limit_start_time = await self._handle_rate_limit_retry(
                service_name,
                full_error,
                rate_limit_retry_count,
                max_rate_limit_retries,
                rate_limit_start_time,
                max_rate_limit_total_time,
            )
            action = "continue_no_increment" if should_continue else "break"
            return action, True, rate_limit_retry_count, rate_limit_start_time

        # Handle schema validation errors
        if self._is_schema_validation_error(error_str):
            if retry_count < max_retries:
                logger.warning(f"Schema validation failed on {service_name}, retrying ({retry_count}/{max_retries})")
                return "continue", False, rate_limit_retry_count, rate_limit_start_time

        # Handle exhausted retries
        if retry_count >= max_retries:
            logger.warning(f"Exhausted {max_retries} attempt(s) on {service_name}")
            return "break", False, rate_limit_retry_count, rate_limit_start_time

        # General error - log and continue
        logger.warning(f"LLM error on {service_name} (attempt {retry_count}): {type(e).__name__}")
        return "continue", False, rate_limit_retry_count, rate_limit_start_time

    async def _handle_rate_limit_retry(
        self,
        service_name: str,
        full_error: str,
        rate_limit_retry_count: int,
        max_rate_limit_retries: int,
        rate_limit_start_time: Optional[float],
        max_rate_limit_total_time: float,
    ) -> tuple[bool, float, Optional[float]]:
        """Handle rate limit retry logic. Returns (should_continue, wait_time, updated_start_time)."""
        # Track when rate limit retries started
        if rate_limit_start_time is None:
            rate_limit_start_time = self._time_service.timestamp()

        elapsed = self._time_service.timestamp() - rate_limit_start_time
        remaining = max_rate_limit_total_time - elapsed

        # Check if we've exceeded limits
        if elapsed >= max_rate_limit_total_time:
            logger.warning(
                f"Rate limit total time ({elapsed:.1f}s) exceeded {max_rate_limit_total_time}s on {service_name}"
            )
            return False, 0, rate_limit_start_time

        if rate_limit_retry_count >= max_rate_limit_retries:
            logger.warning(f"Exhausted {max_rate_limit_retries} rate limit retries on {service_name}")
            return False, 0, rate_limit_start_time

        # Calculate wait time
        wait_time = self._extract_retry_after_time(full_error)
        if wait_time > remaining:
            wait_time = max(remaining, 0.5)

        logger.warning(
            f"Rate limited on {service_name}, waiting {wait_time:.1f}s before retry ({rate_limit_retry_count}/{max_rate_limit_retries}, {remaining:.1f}s budget)"
        )

        # Emit error to UI
        task = asyncio.create_task(error_emitter.emit_rate_limit_error(provider=service_name, wait_time=wait_time))
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)

        await asyncio.sleep(wait_time)
        return True, wait_time, rate_limit_start_time

    def _record_service_failure(
        self,
        service_name: str,
        service_last_error: Exception,
        last_was_rate_limit: bool,
        max_retries: int,
        started_at: Optional[float] = None,
    ) -> None:
        """Record service failure and log appropriately.

        `started_at` is the failed call's wall-clock start: calls to one
        provider that started together are one breaker failure, not N.
        """
        self._last_provider_error[service_name] = service_last_error
        limit = provider_limit_fault(service_last_error)
        if limit is not None and limit.retryable:
            # The account's in-flight budget stayed full for as long as this
            # call could wait. The provider answered correctly: not a breaker
            # failure, and no cooldown -- the shared pause already spaces calls.
            logger.warning(
                f"LLM service {service_name}: in-flight budget still full after waiting "
                f"(NOT counting as CB failure): {service_last_error}"
            )
            return
        if limit is not None and limit.code is ProviderLimitFaultCode.REQUEST_TOO_LARGE:
            # One request too large for the budget: a fact about that request,
            # like a context-length 400, not about the provider.
            logger.warning(
                f"LLM service {service_name}: request too large for the in-flight budget "
                f"(NOT counting as CB failure): {service_last_error}"
            )
            return
        if last_was_rate_limit:
            logger.warning(f"LLM service {service_name} exhausted rate limit retries (NOT counting as CB failure)")
            # Set global cooldown so subsequent requests don't immediately hit rate limit again
            # Use minimum 30s cooldown when retries exhausted - provider's retry_after is often too short
            # because per-minute rate limits don't reset as fast as the suggested retry time
            retry_after = self._extract_retry_after_time(str(service_last_error))
            min_exhausted_cooldown = 30.0  # Minimum cooldown when retries exhausted
            effective_cooldown = max(retry_after, min_exhausted_cooldown) if retry_after > 0 else None
            self._set_rate_limit_cooldown(service_name, effective_cooldown)
            return

        self._record_failure(service_name, started_at=started_at)

        if service_name not in self._services_with_full_error_logged:
            logger.error(
                f"LLM service {service_name} failed after {max_retries} attempt(s): {service_last_error}",
                exc_info=True,
            )
            self._services_with_full_error_logged.add(service_name)
        else:
            logger.warning(f"LLM service {service_name} failed (repeated): {service_last_error}")

    async def _try_service(
        self,
        selected_service: Any,  # LLMService but typed as Any to allow duck typing
        service_name: str,
        normalized_messages: List[JSONDict],
        response_model: Type[BaseModel],
        max_tokens: int,
        temperature: float,
        thought_id: Optional[str],
        task_id: Optional[str],
        handler_name: str,
        start_time: float,
        max_retries: int,
    ) -> Tuple[Optional[BaseModel], Optional[ResourceUsage], Optional[Exception], bool]:
        """Try a single service with retries. Returns (result, usage, last_error, was_rate_limit)."""
        from ciris_engine.logic.adapters.base_observer import BillingServiceError

        max_rate_limit_retries = 10
        max_rate_limit_total_time = 90.0  # Extended to handle multi-agent rate limit contention
        retry_count = 0
        rate_limit_retry_count = 0
        rate_limit_start_time: Optional[float] = None
        service_last_error: Optional[Exception] = None
        last_was_rate_limit = False
        in_flight_attempt = 0
        in_flight_started: Optional[float] = None
        budget_key = self._budget_key(selected_service, service_name)

        while retry_count < max_retries:
            # Capture per-attempt start so duration_ms on the LLM_CALL event
            # reflects THIS invocation only, not the cumulative time across
            # retries. Without this, the second timeout reports "first +
            # second" elapsed and tail-latency hotspot analysis breaks.
            attempt_start_time = self._time_service.timestamp()
            try:
                result, usage = await self._execute_llm_call(
                    selected_service,
                    service_name,
                    normalized_messages,
                    response_model,
                    max_tokens,
                    temperature,
                    thought_id,
                    task_id,
                    handler_name,
                    start_time,
                    attempt_start_time,
                    retry_count + in_flight_attempt,
                    budget_key=budget_key,
                    in_flight_retry=in_flight_attempt,
                )
                return result, usage, None, False

            except _InFlightQueueTimeout:
                # The retry could not reach the provider within the deadline:
                # surface the in-flight refusal it was retrying, not a timeout.
                break

            except BillingServiceError:
                logger.error(f"LLM billing error (not retrying): {service_last_error}")
                raise

            except Exception as e:
                service_last_error = e

                # Per-call failure broadcast — every failed LLM invocation
                # gets its own LLM_CALL event with status != 'ok'. This is
                # what makes the Spanish-MH-style three-consecutive-timeouts
                # diagnosis a one-query lookup instead of a log scrape.
                # Use attempt-local timing so each retry's reported duration
                # is the wall-clock of that attempt only.
                api_base = None
                if hasattr(selected_service, "openai_config") and selected_service.openai_config:
                    api_base = getattr(selected_service.openai_config, "base_url", None)
                attempt_duration_ms = (self._time_service.timestamp() - attempt_start_time) * 1000
                self._maybe_capture_call(
                    handler_name=handler_name,
                    service_name=service_name,
                    thought_id=thought_id,
                    task_id=task_id,
                    messages=normalized_messages,
                    response_model=response_model,
                    result=None,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    model=_extract_call_model(selected_service),
                    api_base=api_base,
                    error=e,
                )
                await _broadcast_llm_call_event(
                    LLMCallEventContext(
                        success=False,
                        handler_name=handler_name,
                        service_name=service_name,
                        selected_service=selected_service,
                        api_base=api_base,
                        response_model=response_model,
                        messages=normalized_messages,
                        result=None,
                        usage=None,
                        duration_ms=attempt_duration_ms,
                        thought_id=thought_id,
                        task_id=task_id,
                        retry_count=retry_count + in_flight_attempt,
                        error=e,
                    )
                )

                # A provider spending-limit refusal is decided by its
                # structure (#1366 item 20): only the in-flight budget is worth
                # waiting for; every other limit surfaces now, unretried.
                limit = provider_limit_fault(e)
                if limit is not None:
                    last_was_rate_limit = False
                    if not limit.retryable:
                        break
                    if in_flight_started is None:
                        in_flight_started = time.monotonic()
                    if not self._pause_for_in_flight_budget(
                        service_name, handler_name, limit, in_flight_attempt, in_flight_started, budget_key
                    ):
                        break
                    in_flight_attempt += 1
                    continue

                retry_count += 1

                action, last_was_rate_limit, rate_limit_retry_count, rate_limit_start_time = (
                    await self._handle_retry_error(
                        e,
                        service_name,
                        retry_count,
                        max_retries,
                        rate_limit_retry_count,
                        max_rate_limit_retries,
                        rate_limit_start_time,
                        max_rate_limit_total_time,
                    )
                )

                if action == "break":
                    break
                if action == "continue_no_increment":
                    retry_count -= 1  # Don't count rate limit as regular retry

        return None, None, service_last_error, last_was_rate_limit

    @staticmethod
    def _budget_key(selected_service: Any, service_name: str) -> BudgetKey:
        """The in-flight budget a service spends (#1366 item 20 F2).

        From the service's ``budget_identity()`` -- (base URL, truncated key
        digest), never the key -- so every replica and every service on the
        same account pauses together. A service with no identity (mocks,
        adapters) falls back to its own name.
        """
        reader = getattr(selected_service, "budget_identity", None)
        if callable(reader):
            try:
                ident = reader()
            except Exception:  # noqa: BLE001 - a broken identity must not fail the call
                ident = None
            if (
                isinstance(ident, tuple)
                and len(ident) == 2
                and all(isinstance(part, str) for part in ident)
                and any(ident)
            ):
                return (ident[0], ident[1])
        return ("service", service_name)

    def _pause_for_in_flight_budget(
        self,
        service_name: str,
        handler_name: str,
        limit: ProviderLimitFault,
        attempt: int,
        started: float,
        budget_key: Optional[BudgetKey] = None,
    ) -> bool:
        """Schedule the retry of an in-flight-budget refusal; False when it cannot be afforded.

        The wait is max(Retry-After, jittered backoff). Retry-After is honoured
        in full -- even past the 60 s per-wait cap -- or, when it does not fit,
        the refusal is surfaced now rather than resent early. Without one, the
        backoff has a floor of a few seconds, and its exponent is the larger of
        this call's attempt and the account's consecutive refusals.

        It is bounded twice: by IN_FLIGHT_TOTAL_WAIT_S across this call's
        refusals, and by the enclosing stage's deadline minus one useful attempt
        -- so waiting never turns into a DMA timeout. The wait is published as
        the budget's pause; the retry sleeps through it at the gate in
        _execute_llm_call, like every other new call on this budget.
        """
        key = budget_key or ("service", service_name)
        now = time.monotonic()
        allowed = IN_FLIGHT_TOTAL_WAIT_S - (now - started)
        deadline = current_call_deadline()
        if deadline is not None:
            allowed = min(allowed, deadline.remaining() - MIN_USEFUL_ATTEMPT_S)
        already_paused = max(0.0, self._provider_paused_until.get(key, 0.0) - now)
        if already_paused <= 0:
            # A refusal after the last pause ended is a NEW episode of pressure;
            # refusals of calls that were in flight together are one episode.
            self._in_flight_streak[key] += 1
        exponent = max(attempt, self._in_flight_streak[key] - 1)
        wait = in_flight_backoff_s(exponent, limit.retry_after_s)
        if attempt >= _IN_FLIGHT_MAX_RETRIES or max(wait, already_paused) > allowed:
            logger.warning(
                f"[LLM_IN_FLIGHT_BUDGET] {service_name} for {handler_name}: budget still full, "
                f"a {max(wait, already_paused):.1f}s wait does not fit the {max(allowed, 0.0):.1f}s left "
                f"(in-flight retry {attempt + 1}/{_IN_FLIGHT_MAX_RETRIES}, retry_after={limit.retry_after_s}) "
                f"-- surfacing"
            )
            return False
        until = max(self._provider_paused_until.get(key, 0.0), now + wait)
        self._provider_paused_until[key] = until
        hedging.pause_hedging_until(until)
        logger.warning(
            f"[LLM_IN_FLIGHT_BUDGET] {service_name} refused {handler_name} (in-flight budget full, "
            f"retry_after={limit.retry_after_s}); pausing the provider {wait:.1f}s, "
            f"in-flight retry {attempt + 1}/{_IN_FLIGHT_MAX_RETRIES}"
        )
        return True

    @staticmethod
    def _deadline_cap() -> Optional[float]:
        """Seconds a call may still wait before its last useful attempt; None without a deadline."""
        deadline = current_call_deadline()
        if deadline is None:
            return None
        return max(0.0, deadline.remaining() - MIN_USEFUL_ATTEMPT_S)

    async def _wait_out_provider_pause(self, budget_key: BudgetKey, service_name: str, handler_name: str) -> None:
        """Hold a call while its budget is paused for an in-flight-budget refusal.

        The pause is RE-READ after every sleep (F1): calls already in flight
        when the first refusal came back are refused moments later and push
        the pause further out, and a caller that read only the first value
        would wake inside the new pause. Once the pause has really ended the
        released callers are spread over up to IN_FLIGHT_RELEASE_SPREAD_S, and
        the pause is checked once more. Never waits past the enclosing
        deadline's last useful attempt: a call that cannot wait goes out and
        meets the provider's own answer.
        """
        waited = 0.0
        spread_done = False
        while True:
            pause = self._provider_paused_until.get(budget_key, 0.0) - time.monotonic()
            cap = self._deadline_cap()
            if cap is not None and cap <= 0:
                return
            if pause > 0:
                wait = pause if cap is None else min(pause, cap)
                logger.info(
                    f"[LLM_IN_FLIGHT_BUDGET] {service_name} paused, {handler_name} waits {wait:.1f}s"
                )
                await asyncio.sleep(wait)
                waited += wait
                spread_done = False
                continue
            if waited > 0 and not spread_done:
                spread = random.uniform(0.0, min(IN_FLIGHT_RELEASE_SPREAD_S, waited))
                if cap is not None:
                    spread = min(spread, cap)
                spread_done = True
                if spread > 0:
                    await asyncio.sleep(spread)
                continue
            return

    async def _acquire_slot(
        self, semaphore: asyncio.Semaphore, in_flight_retry: int, service_name: str, handler_name: str
    ) -> None:
        """Take a concurrency slot. An in-flight RETRY counts its queue time against the deadline (F4).

        A refused call gives up its slot and queues again behind every call
        that arrived during the pause. For a first attempt that queue is the
        ordinary contract of the gate; for an in-flight retry it would turn a
        budget wait into a DMA timeout, which this retry path promises never to
        do. So a retry waits for a slot only as long as its deadline leaves a
        useful attempt, and otherwise surfaces the refusal it was retrying.

        Chosen over giving retries priority: FIFO stays fair (a priority lane
        could starve first attempts under sustained pressure), and a priority
        slot still cannot bound the wait -- every slot may be held by calls that
        are themselves seconds from answering.
        """
        cap = self._deadline_cap() if in_flight_retry > 0 else None
        if cap is None:
            await semaphore.acquire()
            return
        try:
            await asyncio.wait_for(semaphore.acquire(), timeout=cap)
        except asyncio.TimeoutError:
            logger.warning(
                f"[LLM_IN_FLIGHT_BUDGET] {service_name} for {handler_name}: in-flight retry {in_flight_retry} "
                f"found no free slot within its deadline ({cap:.1f}s) -- surfacing the refusal"
            )
            raise _InFlightQueueTimeout() from None

    async def _execute_llm_call(
        self,
        selected_service: Any,
        service_name: str,
        normalized_messages: List[JSONDict],
        response_model: Type[BaseModel],
        max_tokens: int,
        temperature: float,
        thought_id: Optional[str],
        task_id: Optional[str],
        handler_name: str,
        start_time: float,
        attempt_start_time: float,
        retry_count: int,
        budget_key: Optional[BudgetKey] = None,
        in_flight_retry: int = 0,
    ) -> Tuple[BaseModel, Optional[ResourceUsage]]:
        """Execute the actual LLM call and record metrics on success.

        Acquires the per-service FIFO concurrency gate before dispatch so
        excess callers queue rather than all racing the provider at once.

        `start_time` is the request-level wall clock (used for existing
        service-level telemetry) and `attempt_start_time` is captured once
        per retry iteration in `_try_service` (used for the LLM_CALL
        event's per-attempt duration_ms — without this distinction, retries
        report cumulative time and tail-latency analysis breaks).
        """
        key = budget_key or ("service", service_name)
        semaphore = self._get_service_semaphore(service_name)
        # Wait out a budget pause BEFORE queueing for a slot, so paused callers
        # do not hold slots while they sleep (F4) ...
        await self._wait_out_provider_pause(key, service_name, handler_name)
        # Log when we actually have to wait so saturation is visible.
        if semaphore.locked():
            logger.info(
                f"[LLM-GATE] {service_name} saturated (max {self._max_in_flight_per_service} "
                f"in-flight), {handler_name} queued"
            )
        await self._acquire_slot(semaphore, in_flight_retry, service_name, handler_name)
        try:
            # ... and once more after it: a refusal may have paused the budget
            # while this call was queued.
            await self._wait_out_provider_pause(key, service_name, handler_name)
            logger.debug(
                f"Calling LLM service {service_name} for {handler_name} (attempt {retry_count + 1}"
                + (f", in-flight retry {in_flight_retry}/{_IN_FLIGHT_MAX_RETRIES}" if in_flight_retry else "")
                + ")"
            )

            raw_holder = open_raw_completion_holder() if os.environ.get("CIRIS_LLM_CAPTURE_HANDLER") else None
            result, usage = await selected_service.call_llm_structured(
                messages=normalized_messages,
                response_model=response_model,
                max_tokens=max_tokens,
                temperature=temperature,
                thought_id=thought_id,
                task_id=task_id,
            )

            # Diagnostic capture: env-gated so production paths are
            # unaffected. When CIRIS_LLM_CAPTURE_HANDLER matches the
            # handler_name (or is "*"), append a JSONL row to
            # CIRIS_LLM_CAPTURE_FILE with the exact wire-format messages and
            # the parsed structured result. Used to feed live traces into
            # the bounce harness for replay analysis.
            self._maybe_capture_call(
                handler_name=handler_name,
                service_name=service_name,
                thought_id=thought_id,
                task_id=task_id,
                messages=normalized_messages,
                response_model=response_model,
                result=result,
                temperature=temperature,
                max_tokens=max_tokens,
                model=(usage.model_used if usage is not None else None) or _extract_call_model(selected_service),
                api_base=_extract_api_base(selected_service),
                raw_completion_text=raw_holder.get("text") if raw_holder is not None else None,
            )
            if raw_holder is not None:
                close_raw_completion_holder()
        finally:
            semaphore.release()

        # The budget took a request: sustained pressure is over for now.
        self._in_flight_streak.pop(key, None)
        latency_ms = (self._time_service.timestamp() - start_time) * 1000
        self._record_success(service_name, latency_ms)
        # Extract api_base from service config if available
        api_base = None
        if hasattr(selected_service, "openai_config") and selected_service.openai_config:
            api_base = getattr(selected_service.openai_config, "base_url", None)
        await self._record_resource_telemetry(service_name, handler_name, usage, latency_ms, thought_id, api_base)
        logger.info(f"[LLM-TIMING] {handler_name} {thought_id or 'no-thought'}: {latency_ms:.0f}ms via {service_name}")

        # Per-call broadcast — every LLM invocation is a discrete observation
        # for the trace persistence layer (FSD/TRACE_EVENT_LOG_PERSISTENCE.md
        # §5.2). Aggregate cost columns hide tail-latency and per-call failure
        # patterns; LLM_CALL events restore that visibility.
        # duration_ms uses attempt_start_time so the event reflects THIS
        # invocation only — not the cumulative time across retries.
        attempt_duration_ms = (self._time_service.timestamp() - attempt_start_time) * 1000
        await _broadcast_llm_call_event(
            LLMCallEventContext(
                success=True,
                handler_name=handler_name,
                service_name=service_name,
                selected_service=selected_service,
                api_base=api_base,
                response_model=response_model,
                messages=normalized_messages,
                result=result,
                usage=usage,
                duration_ms=attempt_duration_ms,
                thought_id=thought_id,
                task_id=task_id,
                retry_count=retry_count,
            )
        )

        return result, usage

    async def call_llm_structured(
        self,
        messages: Union[List[JSONDict], List["LLMMessage"]],
        response_model: Type[BaseModel],
        max_tokens: int = 4096,
        temperature: float = 0.0,
        handler_name: str = "default",
        domain: Optional[str] = None,
        thought_id: Optional[str] = None,
        task_id: Optional[str] = None,
    ) -> Tuple[BaseModel, ResourceUsage]:
        """Generate structured output using LLM with optional domain routing."""
        normalized_messages = self._normalize_messages(messages)
        start_time = self._time_service.timestamp()
        services = await self._get_prioritized_services(handler_name, domain=domain)

        if not services:
            raise RuntimeError(f"No LLM services available for {handler_name}")

        priority_groups = self._group_by_priority(services)
        last_error: Optional[Exception] = None
        # One attempt per provider, so the bus moves to the next priority
        # quickly; the enclosing stage's per-try is the retry layer (#1186).
        max_retries_per_service = 1

        while True:
            outcome = await self._try_priority_groups(
                priority_groups,
                normalized_messages,
                response_model,
                max_tokens,
                temperature,
                thought_id,
                task_id,
                handler_name,
                start_time,
                max_retries_per_service,
            )
            if outcome.result is not None:
                return outcome.result
            if outcome.last_error is not None:
                last_error = outcome.last_error
            breaker_skipped = outcome.breaker_skipped
            if outcome.tried_any or not breaker_skipped:
                break
            # Every provider for this request was skipped on an open breaker:
            # there is no alternative to fail over to. Wait for the earliest
            # half-open probe if the caller's deadline covers it; otherwise
            # say so with the provider's real last error.
            if not await self._wait_for_breaker_probe(breaker_skipped, handler_name):
                raise self._circuit_open_error(breaker_skipped)

        # All services failed
        task = asyncio.create_task(
            error_emitter.emit_llm_failure(
                error_summary=str(last_error)[:100] if last_error else "Unknown error",
                retry_count=max_retries_per_service,
                max_retries=max_retries_per_service,
            )
        )
        self._background_tasks.add(task)
        task.add_done_callback(self._background_tasks.discard)
        # THE HIGHEST-LEVERAGE STRING IN THE LOG (CIRISAgent#1073).
        #
        # `last_error` embedded the full <failed_attempts> envelope, and FOUR
        # downstream sites re-print this message verbatim — csdma, dsdma_base,
        # dma_orchestrator and work_processor — so one un-flattened string became
        # 217 physical lines. Collapsing it here fixes all four at once.
        _last = " ".join(str(last_error).split())[:300]
        raise RuntimeError(f"All LLM services failed for {handler_name}. Last error: {_last}")

    def _service_side_breaker(self, service: Any) -> Optional[CircuitBreaker]:
        """The provider's own breaker (the LLM service keeps one), when it exposes a real one."""
        cb = getattr(service, "circuit_breaker", None)
        return cb if isinstance(cb, CircuitBreaker) else None

    def _breaker_wait_s(self, service_name: str, service: Any) -> float:
        """Seconds until both the bus's and the provider's breaker let a probe through."""
        waits = [0.0]
        bus_cb = self.circuit_breakers.get(service_name)
        if bus_cb is not None:
            waits.append(bus_cb.seconds_until_half_open())
        svc_cb = self._service_side_breaker(service)
        if svc_cb is not None:
            waits.append(svc_cb.seconds_until_half_open())
        return max(waits)

    async def _wait_for_breaker_probe(self, skipped: List[Tuple[str, Any]], handler_name: str) -> bool:
        """Wait out the shortest breaker recovery if the caller's deadline affords it.

        Returns False (no wait) when no stage set a deadline, or when the
        deadline cannot cover the wait plus a useful attempt -- the caller
        then gets the categorized ProviderCircuitOpenError.
        """
        # Never a zero-length spin: each round spends at least 0.1s of the
        # deadline, so the loop in call_llm_structured is bounded by it.
        wait_s = max(0.1, min(self._breaker_wait_s(name, svc) for name, svc in skipped))
        deadline = current_call_deadline()
        if deadline is None or not deadline.affords(wait_s + MIN_USEFUL_ATTEMPT_S):
            return False
        logger.warning(
            f"Circuit breaker OPEN for every provider of {handler_name}; no alternative provider, "
            f"waiting {wait_s:.1f}s for the recovery probe ({deadline.remaining():.1f}s left on the deadline)"
        )
        await asyncio.sleep(wait_s)
        return True

    def _circuit_open_error(self, skipped: List[Tuple[str, Any]]) -> ProviderCircuitOpenError:
        """The categorized error for "every provider skipped on an open breaker"."""
        name, service = min(skipped, key=lambda item: self._breaker_wait_s(item[0], item[1]))
        bus_cb = self.circuit_breakers.get(name)
        svc_cb = self._service_side_breaker(service)
        failures = max(cb.failure_count for cb in (bus_cb, svc_cb) if cb is not None) if (bus_cb or svc_cb) else 0
        last: Optional[BaseException] = self._last_provider_error.get(name)
        if last is None:
            svc_last = getattr(service, "last_error", None)
            last = svc_last if isinstance(svc_last, BaseException) else None
        return ProviderCircuitOpenError(name, failures, last, self._breaker_wait_s(name, service))

    async def _try_priority_groups(
        self,
        priority_groups: dict[int, List[object]],
        normalized_messages: List[JSONDict],
        response_model: Type[BaseModel],
        max_tokens: int,
        temperature: float,
        thought_id: Optional[str],
        task_id: Optional[str],
        handler_name: str,
        start_time: float,
        max_retries_per_service: int,
    ) -> "_ProviderPass":
        """One pass over the providers in priority order (failover unchanged)."""
        last_error: Optional[Exception] = None
        tried_any = False
        breaker_skipped: List[Tuple[str, Any]] = []
        for priority, service_group in sorted(priority_groups.items()):
            # Walk through every service in this priority group before falling
            # through to the next priority. With replica deployments (two
            # registrations at the same priority), skipping the rate-limited
            # one must try the sibling — previously we jumped straight to the
            # next priority and failed the whole call even though a healthy
            # sibling was available.
            remaining = list(service_group)
            tried: set[str] = set()
            while remaining:
                selected_service = await self._select_service(remaining, priority, handler_name)
                if not selected_service:
                    break

                service_name = self._get_service_name(selected_service)
                # Avoid infinite loop if _select_service returns the same one.
                if service_name in tried:
                    remaining = [s for s in remaining if self._get_service_name(s) != service_name]
                    continue
                tried.add(service_name)

                svc_cb = self._service_side_breaker(selected_service)
                if not self._check_circuit_breaker(service_name) or (svc_cb is not None and not svc_cb.is_available()):
                    # Either breaker open: the call would send no request.
                    # Skipping it here (instead of letting the provider raise
                    # CircuitBreakerError) keeps a fail-fast from being
                    # counted as one more provider failure.
                    logger.warning(f"Circuit breaker OPEN for {service_name}, skipping")
                    breaker_skipped.append((service_name, selected_service))
                    remaining = [s for s in remaining if self._get_service_name(s) != service_name]
                    continue

                # Check global rate limit cooldown
                if self._is_rate_limited(service_name):
                    logger.warning(f"Service {service_name} in rate limit cooldown, skipping")
                    remaining = [s for s in remaining if self._get_service_name(s) != service_name]
                    continue

                # Track pending+acquired in-flight so LEAST_LOADED can route
                # around saturated replicas even before their semaphore has
                # been acquired.
                self._in_flight[service_name] += 1
                tried_any = True
                try:
                    with breaker_call_scope() as call_started_at:
                        result = await self._try_service(
                            selected_service,
                            service_name,
                            normalized_messages,
                            response_model,
                            max_tokens,
                            temperature,
                            thought_id,
                            task_id,
                            handler_name,
                            start_time,
                            max_retries_per_service,
                        )
                finally:
                    self._in_flight[service_name] = max(0, self._in_flight[service_name] - 1)

                if result[0] is not None and result[1] is not None:  # Success
                    return _ProviderPass(result=(result[0], result[1]))

                # Service failed — record and try the next sibling in this
                # priority group (if any) before falling through to the next
                # priority tier.
                if result[2] is not None:
                    last_error = result[2]
                    self._record_service_failure(
                        service_name, result[2], result[3], max_retries_per_service, started_at=call_started_at
                    )
                remaining = [s for s in remaining if self._get_service_name(s) != service_name]

        return _ProviderPass(tried_any=tried_any, breaker_skipped=breaker_skipped, last_error=last_error)

    # Note: This method is not in the protocol but kept for internal use
    async def _generate_structured_sync(
        self,
        messages: List[JSONDict],
        response_model: Type[BaseModel],
        handler_name: str,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        domain: Optional[str] = None,
    ) -> Tuple[BaseModel, ResourceUsage]:
        """
        Synchronous version of generate_structured with domain routing.

        This is what the handlers will call directly.
        """
        return await self.call_llm_structured(
            messages=messages,
            response_model=response_model,
            handler_name=handler_name,
            max_tokens=max_tokens,
            temperature=temperature,
            domain=domain,
        )

    def _get_service_name(self, service: Any) -> str:
        """Get stable service name for circuit breaker tracking.

        Uses service.service_name if available (for consistent CB tracking across restarts),
        otherwise generates from class + id (fallback for services without service_name).
        """
        if hasattr(service, "service_name") and service.service_name:
            return str(service.service_name)
        return f"{type(service).__name__}_{id(service)}"

    def _check_service_capabilities(self, service: Any) -> bool:
        """Check if service has required LLM capabilities."""
        if not hasattr(service, "get_capabilities"):
            return True

        caps = service.get_capabilities()
        if hasattr(caps, "supports_operation_list"):
            return LLMCapabilities.CALL_LLM_STRUCTURED.value in caps.supports_operation_list
        elif hasattr(caps, "actions"):
            return LLMCapabilities.CALL_LLM_STRUCTURED.value in caps.actions
        return True

    def _get_service_priority_and_metadata(self, service: Any) -> Tuple[int, JSONDict]:
        """Get priority value and metadata for a service."""
        provider_info = self.service_registry.get_provider_info(service_type=ServiceType.LLM)
        priority_map = {"CRITICAL": 0, "HIGH": 1, "NORMAL": 2, "LOW": 3, "FALLBACK": 9}

        for providers in provider_info.get("services", {}).get(ServiceType.LLM, []):
            if providers["name"].endswith(str(id(service))):
                priority_value = priority_map.get(providers["priority"], 2)
                service_metadata = providers.get("metadata", {})
                return priority_value, service_metadata

        return 0, {}  # Default to highest priority, empty metadata

    def _should_include_service_for_domain(self, service_metadata: JSONDict, domain: Optional[str]) -> Tuple[bool, int]:
        """Check if service should be included based on domain and get priority adjustment.

        Returns:
            Tuple of (should_include, priority_adjustment)
        """
        if not domain:
            return True, 0

        service_domain = service_metadata.get("domain", "general")

        # Skip services that don't match domain and aren't general
        if service_domain != domain and service_domain != "general":
            logger.debug(f"Skipping service with domain {service_domain} (requested: {domain})")
            return False, 0

        # Boost priority for exact domain match
        if service_domain == domain:
            return True, -1

        return True, 0

    async def _get_prioritized_services(self, handler_name: str, domain: Optional[str] = None) -> List[Tuple[Any, int]]:
        """Get all available LLM services with their priorities, optionally filtered by domain.

        NOTE: This method does NOT filter by health/circuit breaker state. That check
        happens during service selection in call_llm_structured() to enable proper
        failover from services with open circuit breakers to lower-priority services.

        Args:
            handler_name: Handler identifier
            domain: Optional domain filter (e.g., 'medical', 'legal', 'financial')

        Returns:
            List of (service, priority) tuples
        """
        services = []
        all_llm_services = self.service_registry.get_services_by_type(ServiceType.LLM)

        for service in all_llm_services:
            # Check capabilities
            if not self._check_service_capabilities(service):
                continue

            # Get priority and metadata
            priority_value, service_metadata = self._get_service_priority_and_metadata(service)

            # Check domain filtering
            should_include, priority_adjustment = self._should_include_service_for_domain(service_metadata, domain)
            if not should_include:
                continue

            # Apply priority adjustment for domain matching
            priority_value = max(0, priority_value + priority_adjustment)
            services.append((service, priority_value))

        return services

    def _group_by_priority(self, services: List[Tuple[Any, int]]) -> dict[int, List[object]]:
        """Group services by priority"""
        groups: dict[int, List[object]] = defaultdict(list)
        for service, priority in services:
            groups[priority].append(service)
        return groups

    async def _select_service(self, services: List[object], priority: int, handler_name: str) -> Optional[object]:
        """Select a service from a priority group based on distribution strategy"""
        if not services:
            return None

        if len(services) == 1:
            return services[0]

        if self.distribution_strategy == DistributionStrategy.ROUND_ROBIN:
            # Round-robin selection
            index = self.round_robin_index[priority] % len(services)
            self.round_robin_index[priority] += 1
            return services[index]

        elif self.distribution_strategy == DistributionStrategy.LATENCY_BASED:
            # Select service with lowest average latency
            best_service = None
            best_latency = float("inf")

            for service in services:
                service_name = self._get_service_name(service)
                metrics = self.service_metrics[service_name]

                # New services get a chance
                if metrics.total_requests == 0:
                    return service

                if metrics.average_latency_ms < best_latency:
                    best_latency = metrics.average_latency_ms
                    best_service = service

            return best_service or services[0]

        elif self.distribution_strategy == DistributionStrategy.RANDOM:
            # Random selection for load distribution (not cryptographic)
            import random

            return random.choice(services)

        else:  # DistributionStrategy.LEAST_LOADED
            # Pick the service with the fewest in-flight (pending + acquired)
            # calls. Ties break on least total_requests so brand-new services
            # get early traffic. Incremented at selection time in _try_service,
            # decremented in its finally — see _in_flight counter.
            return min(
                services,
                key=lambda s: (
                    self._in_flight[self._get_service_name(s)],
                    self.service_metrics[self._get_service_name(s)].total_requests,
                ),
            )

    def _check_circuit_breaker(self, service_name: str) -> bool:
        """Check if circuit breaker allows execution"""
        if service_name not in self.circuit_breakers:
            # Create CircuitBreakerConfig from the dict config - use jsondict_helpers for type safety
            config = CircuitBreakerConfig(
                failure_threshold=get_int(self.circuit_breaker_config, "failure_threshold", 5),
                recovery_timeout=get_float(self.circuit_breaker_config, "recovery_timeout", 60.0),
                success_threshold=get_int(self.circuit_breaker_config, "half_open_max_calls", 3),
                timeout_duration=get_float(self.circuit_breaker_config, "timeout_duration", 30.0),
                # Concurrent failures of one provider (parallel DMA timeouts
                # from the same slow moment) are one breaker failure.
                failure_coalesce_window_s=get_float(self.circuit_breaker_config, "failure_coalesce_window_s", 1.0),
            )
            self.circuit_breakers[service_name] = CircuitBreaker(name=service_name, config=config)

        return self.circuit_breakers[service_name].is_available()

    def _is_rate_limited(self, service_name: str) -> bool:
        """Check if service is in rate limit cooldown."""
        cooldown_until = self._rate_limited_until.get(service_name)
        if cooldown_until is None:
            return False

        current_time = self._time_service.timestamp()
        if current_time >= cooldown_until:
            # Cooldown expired, clear it
            del self._rate_limited_until[service_name]
            logger.info(f"Rate limit cooldown expired for {service_name}")
            return False

        remaining = cooldown_until - current_time
        logger.debug(f"Service {service_name} in rate limit cooldown ({remaining:.1f}s remaining)")
        return True

    def _set_rate_limit_cooldown(self, service_name: str, retry_after: Optional[float] = None) -> None:
        """Set rate limit cooldown for a service.

        Args:
            service_name: The service to cooldown
            retry_after: Optional seconds to wait (from Retry-After header). If not provided,
                        uses default cooldown.
        """
        cooldown = retry_after if retry_after and retry_after > 0 else self._rate_limit_cooldown_seconds
        cooldown_until = self._time_service.timestamp() + cooldown
        self._rate_limited_until[service_name] = cooldown_until
        logger.warning(f"Rate limit cooldown set for {service_name}: {cooldown:.1f}s")

    def _record_success(self, service_name: str, latency_ms: float) -> None:
        """Record successful call metrics"""
        metrics = self.service_metrics[service_name]
        metrics.total_requests += 1
        metrics.total_latency_ms += latency_ms
        metrics.last_request_time = self._time_service.now()
        metrics.consecutive_failures = 0

        if service_name in self.circuit_breakers:
            self.circuit_breakers[service_name].record_success()

        # Clear rate limit cooldown on success
        if service_name in self._rate_limited_until:
            del self._rate_limited_until[service_name]
            logger.info(f"Rate limit cooldown cleared for {service_name} after successful call")

    def _record_failure(self, service_name: str, started_at: Optional[float] = None) -> None:
        """Record failed call metrics"""
        metrics = self.service_metrics[service_name]
        metrics.total_requests += 1
        metrics.failed_requests += 1
        metrics.last_failure_time = self._time_service.now()
        metrics.consecutive_failures += 1

        if service_name in self.circuit_breakers:
            cb = self.circuit_breakers[service_name]
            was_closed = cb.state == CircuitState.CLOSED
            cb.record_failure(started_at=started_at)
            # Emit error if circuit just opened
            if was_closed and cb.state == CircuitState.OPEN:
                task = asyncio.create_task(error_emitter.emit_circuit_breaker_open(service_name))
                self._background_tasks.add(task)
                task.add_done_callback(self._background_tasks.discard)

    async def _record_resource_telemetry(
        self,
        service_name: str,
        handler_name: str,
        usage: ResourceUsage,
        latency_ms: float,
        thought_id: Optional[str] = None,
        api_base: Optional[str] = None,
    ) -> None:
        """Record detailed telemetry for resource usage.

        The single point where a completed call's tokens are recorded: the
        canonical ``llm.tokens.total`` metric below, and the resource monitor's
        token budget (tokens_hour / tokens_day) -- the same number, once.
        """
        if self.resource_monitor is not None and usage.tokens_used > 0:
            try:
                await self.resource_monitor.record_tokens(usage.tokens_used)
            except Exception as e:  # never fail an LLM call over budget bookkeeping
                logger.warning(f"Failed to record tokens with the resource monitor: {e}")

        # Per-thought totals for the ACTION_COMPLETE event, kept in memory: a
        # dict update here instead of six graph scans per thought later.
        if thought_id:
            thought_resource_ledger.record(thought_id, usage, api_base)

        if not self.telemetry_service:
            return

        try:
            # Build base tags
            base_tags = {
                "service": service_name,
                "model": usage.model_used or "unknown",
                "handler": handler_name,
                "api_base": api_base or "default",
            }
            # Add thought_id if provided for per-thought resource tracking
            if thought_id:
                base_tags["thought_id"] = thought_id

            # Record token usage
            await self.telemetry_service.record_metric(
                metric_name="llm.tokens.total",
                value=float(usage.tokens_used),
                handler_name=handler_name,
                tags=base_tags,
            )

            # Record input/output tokens separately
            if usage.tokens_input > 0:
                await self.telemetry_service.record_metric(
                    metric_name="llm.tokens.input",
                    value=float(usage.tokens_input),
                    handler_name=handler_name,
                    tags=base_tags,
                )

            if usage.tokens_output > 0:
                await self.telemetry_service.record_metric(
                    metric_name="llm.tokens.output",
                    value=float(usage.tokens_output),
                    handler_name=handler_name,
                    tags=base_tags,
                )

            # Record cost
            if usage.cost_cents > 0:
                await self.telemetry_service.record_metric(
                    metric_name="llm.cost.cents",
                    value=usage.cost_cents,
                    handler_name=handler_name,
                    tags=base_tags,
                )

            # Record environmental impact
            if usage.carbon_grams > 0:
                await self.telemetry_service.record_metric(
                    metric_name="llm.environmental.carbon_grams",
                    value=usage.carbon_grams,
                    handler_name=handler_name,
                    tags=base_tags,
                )

            if usage.energy_kwh > 0:
                await self.telemetry_service.record_metric(
                    metric_name="llm.environmental.energy_kwh",
                    value=usage.energy_kwh,
                    handler_name=handler_name,
                    tags=base_tags,
                )

            # Record latency
            await self.telemetry_service.record_metric(
                metric_name="llm.latency.ms",
                value=latency_ms,
                handler_name=handler_name,
                tags=base_tags,
            )

        except Exception as e:
            logger.warning(f"Failed to record telemetry: {e}")

    def get_service_stats(self) -> JSONDict:
        """Get detailed statistics for all services"""
        stats: JSONDict = {}

        for service_name, metrics in self.service_metrics.items():
            circuit_breaker = self.circuit_breakers.get(service_name)

            stats[service_name] = {
                "total_requests": metrics.total_requests,
                "failed_requests": metrics.failed_requests,
                "failure_rate": f"{metrics.failure_rate * 100:.2f}%",
                "average_latency_ms": f"{metrics.average_latency_ms:.2f}",
                "consecutive_failures": metrics.consecutive_failures,
                "circuit_breaker_state": circuit_breaker.state.value if circuit_breaker else "none",
                "last_request": metrics.last_request_time.isoformat() if metrics.last_request_time else None,
                "last_failure": metrics.last_failure_time.isoformat() if metrics.last_failure_time else None,
            }

        return stats

    async def get_available_models(self, handler_name: str = "default") -> List[str]:
        """Get list of available LLM models"""
        service = await self.get_service(handler_name=handler_name, required_capabilities=["get_available_models"])

        if not service:
            logger.error(f"No LLM service available for {handler_name}")
            return []

        try:
            # Cast to Any to handle dynamic method access
            service_any = cast(Any, service)
            result: List[str] = await service_any.get_available_models()
            return result
        except Exception as e:
            logger.error(f"Error getting available models: {e}", exc_info=True)
            return []

    async def is_healthy(self, handler_name: str = "default") -> bool:
        """Check if LLM service is healthy"""
        service = await self.get_service(handler_name=handler_name)
        if not service:
            return False
        try:
            return await service.is_healthy()
        except Exception as e:
            logger.error(f"Failed to check health: {e}")
            return False

    async def get_capabilities(self, handler_name: str = "default") -> List[str]:
        """Get LLM service capabilities"""
        service = await self.get_service(handler_name=handler_name)
        if not service:
            return []
        try:
            capabilities = service.get_capabilities()
            return capabilities.supports_operation_list if hasattr(capabilities, "supports_operation_list") else []
        except Exception as e:
            logger.error(f"Failed to get capabilities: {e}")
            return []

    async def _process_message(self, message: BusMessage) -> None:
        """Process an LLM message from the queue"""
        if isinstance(message, LLMBusMessage):
            # For async processing, we would handle the request here
            # and set the result on the future
            # For now, LLM calls are synchronous
            logger.warning("Async LLM processing not yet implemented")
        else:
            logger.error(f"Unknown message type: {type(message)}")

    def get_stats(self) -> JSONDict:
        """Get bus statistics including service stats"""
        base_stats = super().get_stats()
        base_stats["service_stats"] = self.get_service_stats()
        base_stats["distribution_strategy"] = self.distribution_strategy.value
        return base_stats

    def _collect_metrics(self) -> dict[str, float]:
        """Collect base metrics for the LLM bus."""
        # Calculate uptime
        uptime_seconds = 0.0
        if hasattr(self, "_time_service") and self._time_service:
            if hasattr(self, "_start_time") and self._start_time:
                uptime_seconds = (self._time_service.now() - self._start_time).total_seconds()

        # Calculate aggregate metrics from service metrics
        total_requests = sum(m.total_requests for m in self.service_metrics.values())
        failed_requests = sum(m.failed_requests for m in self.service_metrics.values())
        total_latency = sum(m.total_latency_ms for m in self.service_metrics.values())
        avg_latency = total_latency / total_requests if total_requests > 0 else 0.0

        # Count circuit breakers open
        circuit_breakers_open = sum(1 for cb in self.circuit_breakers.values() if cb.state == CircuitState.OPEN)

        return {
            "llm_requests_total": float(total_requests),
            "llm_failed_requests": float(failed_requests),
            "llm_average_latency_ms": avg_latency,
            "llm_circuit_breakers_open": float(circuit_breakers_open),
            "llm_providers_available": float(len(self.service_metrics)),
            "llm_uptime_seconds": uptime_seconds,
        }

    def get_metrics(self) -> BusMetrics:
        """Get all LLM bus metrics as typed BusMetrics schema."""
        # Calculate aggregate metrics from service metrics
        total_requests = sum(m.total_requests for m in self.service_metrics.values())
        failed_requests = sum(m.failed_requests for m in self.service_metrics.values())
        total_latency = sum(m.total_latency_ms for m in self.service_metrics.values())
        avg_latency = total_latency / total_requests if total_requests > 0 else 0.0

        # Calculate uptime
        uptime_seconds = 0.0
        if hasattr(self, "_time_service") and self._time_service:
            if hasattr(self, "_start_time") and self._start_time:
                uptime_seconds = (self._time_service.now() - self._start_time).total_seconds()

        # Count circuit breakers open
        circuit_breakers_open = sum(1 for cb in self.circuit_breakers.values() if cb.state == CircuitState.OPEN)

        # Find busiest service (service with most requests)
        busiest_service = None
        max_requests = 0
        for service_name, metrics in self.service_metrics.items():
            if metrics.total_requests > max_requests:
                max_requests = metrics.total_requests
                busiest_service = service_name

        # Map to BusMetrics schema
        return BusMetrics(
            messages_sent=total_requests,  # Total LLM requests sent
            messages_received=total_requests,  # Same as sent (synchronous)
            messages_dropped=0,  # Not tracked yet
            average_latency_ms=avg_latency,
            active_subscriptions=len(self.service_metrics),  # Number of LLM services with metrics
            queue_depth=self.get_queue_size(),
            errors_last_hour=failed_requests,  # Total failed requests (not windowed yet)
            busiest_service=busiest_service,
            additional_metrics={
                "llm_requests_total": total_requests,
                "llm_failed_requests": failed_requests,
                "llm_circuit_breakers_open": circuit_breakers_open,
                "llm_providers_available": len(self.service_metrics),
                "llm_uptime_seconds": uptime_seconds,
            },
        )

    def _is_service_available_sync(self, service: object) -> bool:
        """Synchronous check if a service is available (for metrics collection)."""
        try:
            # Check if service has basic capabilities
            if not self._check_service_capabilities(service):
                return False

            # Check circuit breaker state
            service_name = self._get_service_name(service)
            if not self._check_circuit_breaker(service_name):
                return False

            # Service is considered active if it passes basic checks
            return True
        except Exception:
            return False

    def clear_circuit_breakers(self) -> None:
        """Clear all circuit breakers - useful for testing.

        WARNING: This should ONLY be used in test environments to ensure
        clean state between test runs. Using this in production could
        hide real service failures.
        """
        logger.warning("Clearing all LLM circuit breakers - this should only happen in tests!")
        self.circuit_breakers.clear()
        # Also clear service metrics to ensure clean state
        self.service_metrics.clear()
