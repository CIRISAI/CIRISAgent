import json
import logging
import uuid
from typing import Any, Optional

from ciris_engine.schemas.runtime.enums import TaskOrigin, TaskStatus, ThoughtStatus
from ciris_engine.schemas.runtime.models import (
    FinalAction,
    Task,
    TaskContext,
    TaskOutcome,
    Thought,
    ThoughtContext,
    VerifiedSender,
    WAAuthorization,
)
from ciris_engine.schemas.runtime.task_envelope import TaskEnvelope

logger = logging.getLogger(__name__)


def decode_wa_authorization(raw: Any, task_id: Any) -> Optional[WAAuthorization]:
    """Decode a guidance task's WA authorization. Anything malformed grants nothing.

    Only ``WiseAuthorityService.resolve_deferral`` writes it, and only for a
    VERIFIED approval. A row that cannot be read back is treated as not
    authorized, never as authorized.
    """
    if raw is None:
        return None
    try:
        return WAAuthorization.model_validate(raw)
    except Exception as exc:
        logger.warning("Failed to decode WA authorization for task %s; treating as not authorized: %s", task_id, exc)
        return None


def decode_verified_sender(raw: Any, owner_id: Any) -> Optional[VerifiedSender]:
    """Decode a persisted VerifiedSender; None (no verified sender) when absent or corrupt."""
    if raw is None:
        return None
    if isinstance(raw, VerifiedSender):
        return raw
    try:
        return VerifiedSender.model_validate(raw)
    except Exception as e:
        logger.warning("Dropping an undecodable verified sender on %s: %s", owner_id, e)
        return None


def decode_task_origin(raw: Any, task_id: Any) -> Optional[TaskOrigin]:
    """Decode a persisted task origin; None (origin not recorded) when absent or unknown, never an engine origin."""
    if raw is None:
        return None
    try:
        return TaskOrigin(raw)
    except ValueError:
        logger.warning("Dropping an unknown task origin %r on %s", raw, task_id)
        return None


def _decode_task_envelope(raw: Any, task_id: Any) -> Optional[TaskEnvelope]:
    """Decode a persisted task-scoped authorization envelope (CIRISAgent#938).

    Failure resolves to ``None`` — absence of an envelope is a denial to a
    future tool gate, never "unconstrained".
    """
    if raw is None:
        return None
    try:
        return TaskEnvelope.model_validate(raw)
    except Exception as exc:
        logger.warning(
            "Failed to decode task envelope for task %s; treating as no envelope (deny): %s", task_id, exc
        )
        return None


def map_row_to_task(row: Any) -> Task:
    row_dict = dict(row)
    # Get agent_occurrence_id from row (defaults to "default" for backwards compatibility)
    agent_occurrence_id = row_dict.get("agent_occurrence_id", "default")

    # Handle PostgreSQL JSONB vs SQLite TEXT for JSON columns
    # PostgreSQL JSONB returns parsed Python objects, SQLite TEXT returns JSON strings
    if row_dict.get("context_json"):
        try:
            ctx_json = row_dict["context_json"]
            ctx_data = ctx_json if isinstance(ctx_json, dict) else json.loads(ctx_json)
            if isinstance(ctx_data, dict):
                # Extract only the fields that TaskContext expects
                # This makes us resilient to schema changes
                row_dict["context"] = TaskContext(
                    channel_id=ctx_data.get("channel_id"),
                    user_id=ctx_data.get("user_id"),
                    correlation_id=ctx_data.get("correlation_id", str(uuid.uuid4())),
                    parent_task_id=ctx_data.get("parent_task_id"),
                    agent_occurrence_id=ctx_data.get("agent_occurrence_id", agent_occurrence_id),
                    # Persisted preferred_language must round-trip — see same
                    # fix in map_row_to_thought below for the production
                    # impact (every conscience falling through to env-default
                    # locale regardless of the user's actual language).
                    preferred_language=ctx_data.get("preferred_language"),
                    # Task-scoped authorization envelope (CIRISAgent#938). A
                    # decode failure resolves to None, the fail-closed
                    # direction: absence is denial, never "unconstrained".
                    envelope=_decode_task_envelope(ctx_data.get("envelope"), row_dict.get("task_id")),
                    wa_authorization=decode_wa_authorization(ctx_data.get("wa_authorization"), row_dict.get("task_id")),
                    verified_sender=decode_verified_sender(ctx_data.get("verified_sender"), row_dict.get("task_id")),
                    origin=decode_task_origin(ctx_data.get("origin"), row_dict.get("task_id")),
                )
                # Mirror onto the Task's top-level field — Task is the record
                # of truth for preferred_language. The schema field defaults
                # to None so we must explicitly set it from context_json on
                # load (no DB column for it; persistence keeps it in
                # context_json only).
                row_dict["preferred_language"] = ctx_data.get("preferred_language")
            else:
                # Provide required fields for TaskContext
                row_dict["context"] = TaskContext(
                    channel_id=None,
                    user_id=None,
                    correlation_id=str(uuid.uuid4()),
                    parent_task_id=None,
                    agent_occurrence_id=agent_occurrence_id,
                )
        except Exception as e:
            logger.warning(f"Failed to decode context_json for task {row_dict.get('task_id')}: {e}")
            row_dict["context"] = TaskContext(
                channel_id=None,
                user_id=None,
                correlation_id=str(uuid.uuid4()),
                parent_task_id=None,
                agent_occurrence_id=agent_occurrence_id,
            )
    else:
        row_dict["context"] = TaskContext(
            channel_id=None,
            user_id=None,
            correlation_id=str(uuid.uuid4()),
            parent_task_id=None,
            agent_occurrence_id=agent_occurrence_id,
        )
    if row_dict.get("outcome_json"):
        try:
            outcome_json = row_dict["outcome_json"]
            outcome_data = outcome_json if isinstance(outcome_json, dict) else json.loads(outcome_json)
            # Only set outcome if it's a non-empty dict with required fields
            if isinstance(outcome_data, dict) and outcome_data:
                row_dict["outcome"] = TaskOutcome.model_validate(outcome_data)
            else:
                row_dict["outcome"] = None
        except Exception:
            logger.warning(f"Failed to decode outcome_json for task {row_dict.get('task_id')}")
            row_dict["outcome"] = None
    else:
        row_dict["outcome"] = None

    # Handle PostgreSQL TIMESTAMP vs SQLite TEXT for datetime columns
    # PostgreSQL TIMESTAMP returns datetime objects, SQLite TEXT returns ISO strings
    from datetime import datetime, timezone

    for dt_field in ["created_at", "updated_at", "signed_at"]:
        if dt_field in row_dict and row_dict[dt_field]:
            if isinstance(row_dict[dt_field], datetime):
                # Ensure timezone-aware datetime (assume UTC if naive)
                dt = row_dict[dt_field]
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                row_dict[dt_field] = dt.isoformat()

    # Handle images_json for native multimodal vision support
    if row_dict.get("images_json"):
        try:
            from ciris_engine.schemas.runtime.models import ImageContent

            images_json = row_dict["images_json"]
            images_data = images_json if isinstance(images_json, list) else json.loads(images_json)
            if isinstance(images_data, list) and images_data:
                row_dict["images"] = [ImageContent.model_validate(img) for img in images_data]
            else:
                row_dict["images"] = []
        except Exception as e:
            logger.warning(f"Failed to decode images_json for task {row_dict.get('task_id')}: {e}")
            row_dict["images"] = []
    else:
        row_dict["images"] = []

    # Remove database-specific columns that aren't in the Task schema
    for k in ["context_json", "outcome_json", "retry_count", "images_json"]:
        if k in row_dict:
            del row_dict[k]

    try:
        row_dict["status"] = TaskStatus(row_dict["status"])
    except Exception:
        logger.warning(
            f"Invalid status value '{row_dict['status']}' for task {row_dict.get('task_id')}. Defaulting to PENDING."
        )
        row_dict["status"] = TaskStatus.PENDING
    return Task(**row_dict)


def map_row_to_thought(row: Any) -> Thought:
    row_dict = dict(row)
    # Get agent_occurrence_id from row (defaults to "default" for backwards compatibility)
    agent_occurrence_id = row_dict.get("agent_occurrence_id", "default")

    # Handle PostgreSQL JSONB vs SQLite TEXT for JSON columns
    # PostgreSQL JSONB returns parsed Python objects, SQLite TEXT returns JSON strings
    if row_dict.get("context_json"):
        try:
            ctx_json = row_dict["context_json"]
            ctx_data = ctx_json if isinstance(ctx_json, dict) else json.loads(ctx_json)
            if isinstance(ctx_data, dict) and ctx_data:  # Check if dict is not empty
                # Extract only the fields that ThoughtContext expects
                # This makes us resilient to schema changes
                # Note: task_id and correlation_id are required fields
                task_id = ctx_data.get("task_id")
                correlation_id = ctx_data.get("correlation_id")

                if task_id and correlation_id:
                    row_dict["context"] = ThoughtContext(
                        task_id=task_id,
                        channel_id=ctx_data.get("channel_id"),
                        round_number=ctx_data.get("round_number", 0),
                        depth=ctx_data.get("depth", 0),
                        parent_thought_id=ctx_data.get("parent_thought_id"),
                        correlation_id=correlation_id,
                        agent_occurrence_id=ctx_data.get("agent_occurrence_id", agent_occurrence_id),
                        # Critical: persisted preferred_language must round-trip
                        # so the localization helper finds it on the loaded
                        # thought. Dropping this here was the root cause of
                        # every conscience falling through to env-default
                        # CIRIS_PREFERRED_LANGUAGE regardless of the user's
                        # actual locale.
                        preferred_language=ctx_data.get("preferred_language"),
                        # The sender of the message this thought answers (#1366 item 5).
                        verified_sender=decode_verified_sender(
                            ctx_data.get("verified_sender"), row_dict.get("thought_id")
                        ),
                    )
                    # Mirror onto the Thought's top-level field — Task is the
                    # record of truth, Thought inherits at creation, persistence
                    # keeps it in context_json only (no DB column).
                    row_dict["preferred_language"] = ctx_data.get("preferred_language")
                else:
                    # Missing required fields, set to None
                    row_dict["context"] = None
            else:
                # For empty or invalid context, set to None instead of trying to create invalid ThoughtContext
                row_dict["context"] = None
        except Exception as e:
            logger.warning(f"Failed to decode context_json for thought {row_dict.get('thought_id')}: {e}")
            # For failed decoding, set to None instead of trying to create invalid ThoughtContext
            row_dict["context"] = None
    else:
        # No context provided, set to None
        row_dict["context"] = None
    if row_dict.get("ponder_notes_json"):
        try:
            ponder_json = row_dict["ponder_notes_json"]
            row_dict["ponder_notes"] = ponder_json if isinstance(ponder_json, list) else json.loads(ponder_json)
        except Exception:
            logger.warning(f"Failed to decode ponder_notes_json for thought {row_dict.get('thought_id')}")
            row_dict["ponder_notes"] = None
    else:
        row_dict["ponder_notes"] = None
    if row_dict.get("final_action_json"):
        try:
            action_json = row_dict["final_action_json"]
            action_data = action_json if isinstance(action_json, dict) else json.loads(action_json)
            # Only set final_action if it's a valid FinalAction dict (has required keys)
            # Error objects like {"error": "..."} should be skipped silently
            if isinstance(action_data, dict) and "action_type" in action_data:
                row_dict["final_action"] = FinalAction.model_validate(action_data)
            else:
                # Not a FinalAction format (e.g., error object) - skip silently
                row_dict["final_action"] = None
        except Exception:
            logger.warning(f"Failed to decode final_action_json for thought {row_dict.get('thought_id')}")
            row_dict["final_action"] = None
    else:
        row_dict["final_action"] = None

    # Handle PostgreSQL TIMESTAMP vs SQLite TEXT for datetime columns
    # PostgreSQL TIMESTAMP returns datetime objects, SQLite TEXT returns ISO strings
    from datetime import datetime, timezone

    for dt_field in ["created_at", "updated_at"]:
        if dt_field in row_dict and row_dict[dt_field]:
            if isinstance(row_dict[dt_field], datetime):
                # Ensure timezone-aware datetime (assume UTC if naive)
                dt = row_dict[dt_field]
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                row_dict[dt_field] = dt.isoformat()

    # Note: Images are stored at the TASK level, not THOUGHT level.
    # Thoughts inherit images from their source task when loaded via ProcessingQueueItem.from_thought()
    # which looks up the task and copies its images.
    row_dict["images"] = []

    for k in ["context_json", "ponder_notes_json", "final_action_json"]:
        if k in row_dict:
            del row_dict[k]
    try:
        row_dict["status"] = ThoughtStatus(row_dict["status"])
    except Exception:
        logger.warning(
            f"Invalid status value '{row_dict['status']}' for thought {row_dict.get('thought_id')}. Defaulting to PENDING."
        )
        row_dict["status"] = ThoughtStatus.PENDING
    return Thought(**row_dict)
