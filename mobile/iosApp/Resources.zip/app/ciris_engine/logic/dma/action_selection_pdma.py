"""Refactored Action Selection PDMA - Modular and Clean."""

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, cast

from ciris_engine.constants import DEFAULT_OPENAI_MODEL_NAME
from ciris_engine.logic.formatters import format_system_prompt_blocks, format_system_snapshot, format_user_profiles
from ciris_engine.logic.registries.base import ServiceRegistry
from ciris_engine.logic.utils.constants import ACCORD_TEXT, ACCORD_TEXT_COMPRESSED
from ciris_engine.protocols.dma.base import ActionSelectionDMAProtocol
from ciris_engine.protocols.faculties import EpistemicFaculty
from ciris_engine.schemas.actions.parameters import PonderParams
from ciris_engine.schemas.dma.faculty import ConscienceFailureContext, EnhancedDMAInputs
from ciris_engine.schemas.dma.prompts import PromptCollection
from ciris_engine.schemas.dma.results import (
    ActionSelectionDMAResult,
    ASPDMALLMResult,
    convert_llm_result_to_action_result,
)
from ciris_engine.schemas.runtime.enums import HandlerActionType
from ciris_engine.schemas.runtime.models import Thought
from ciris_engine.schemas.types import JSONDict

from .action_selection import ActionSelectionContextBuilder, ActionSelectionSpecialCases
from .action_selection.faculty_integration import FacultyIntegration
from .base_dma import BaseDMA

logger = logging.getLogger(__name__)


def _get_value(obj: Any, key: str, default: Any = None) -> Any:
    """Get a value from either a dict or object attribute."""
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


DEFAULT_TEMPLATE = """{system_header}

{decision_format}

{closing_reminder}"""


class ActionSelectionPDMAEvaluator(BaseDMA[EnhancedDMAInputs, ActionSelectionDMAResult], ActionSelectionDMAProtocol):
    """
    Modular Action Selection PDMA Evaluator.

    Takes outputs from PDMA, CSDMA, DSDMA, and IDMA (which evaluates their reasoning)
    and selects a concrete handler action using the Principled Decision-Making Algorithm.

    Features:
    - Modular component architecture
    - Faculty integration for enhanced evaluation
    - Recursive evaluation on conscience failures
    - Special case handling (wakeup tasks, forced ponder, etc.)
    """

    PROMPT_FILE = Path(__file__).parent / "prompts" / "action_selection_pdma.yml"

    def __init__(
        self,
        service_registry: ServiceRegistry,
        model_name: str = DEFAULT_OPENAI_MODEL_NAME,
        max_retries: int = 2,
        prompt_overrides: Optional[Union[Dict[str, str], PromptCollection]] = None,
        faculties: Optional[Dict[str, EpistemicFaculty]] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize ActionSelectionPDMAEvaluator."""
        super().__init__(
            service_registry=service_registry,
            model_name=model_name,
            max_retries=max_retries,
            prompt_overrides=prompt_overrides,
            faculties=faculties,
            **kwargs,
        )

        self.context_builder = ActionSelectionContextBuilder(self.prompts, service_registry, self.sink)
        self.faculty_integration = FacultyIntegration(faculties) if faculties else None

        # Store last prompts for debugging/streaming
        self.last_user_prompt: Optional[str] = None
        self.last_system_prompt: Optional[str] = None

    async def evaluate(  # type: ignore[override]  # Extends base signature with enable_recursive_evaluation
        self, input_data: EnhancedDMAInputs, enable_recursive_evaluation: bool = False
    ) -> ActionSelectionDMAResult:
        """Evaluate triaged inputs and select optimal action."""

        if not input_data:
            raise ValueError("input_data is required")

        original_thought: Thought = input_data.original_thought
        logger.debug(f"Evaluating action selection for thought ID {original_thought.thought_id}")

        # Handle special cases first
        special_result = await self._handle_special_cases(input_data)
        if special_result:
            return special_result

        # Perform main evaluation
        try:
            result = await self._perform_main_evaluation(input_data, enable_recursive_evaluation)

            # Add faculty metadata if applicable
            faculty_enhanced = getattr(input_data, "faculty_enhanced", False)
            recursive_evaluation = getattr(input_data, "recursive_evaluation", False)

            if self.faculty_integration and faculty_enhanced:
                result = self.faculty_integration.add_faculty_metadata_to_result(
                    result, faculty_enhanced=True, recursive_evaluation=recursive_evaluation
                )

            logger.info(
                f"Action selection successful for thought {original_thought.thought_id}: {result.selected_action.value}"
            )
            return result

        except Exception as e:
            logger.error(f"Action selection failed for thought {original_thought.thought_id}: {e}", exc_info=True)
            return self._create_fallback_result(str(e))

    async def recursive_evaluate_with_faculties(
        self,
        input_data: Union[JSONDict, EnhancedDMAInputs],
        conscience_failure_context: Union[JSONDict, ConscienceFailureContext],
    ) -> ActionSelectionDMAResult:
        """Perform recursive evaluation using epistemic faculties."""

        if not self.faculty_integration:
            logger.warning(
                "Recursive evaluation requested but no faculties available. Falling back to regular evaluation."
            )
            # Convert to EnhancedDMAInputs if dict
            if isinstance(input_data, dict):
                input_data = EnhancedDMAInputs(**input_data)
            return await self.evaluate(input_data, enable_recursive_evaluation=False)

        # Convert to EnhancedDMAInputs if dict
        if isinstance(input_data, dict):
            input_data = EnhancedDMAInputs(**input_data)

        original_thought: Thought = input_data.original_thought
        logger.info(f"Starting recursive evaluation with faculties for thought {original_thought.thought_id}")

        # Convert conscience context to typed model if needed
        if isinstance(conscience_failure_context, dict):
            conscience_failure_context = ConscienceFailureContext(
                failure_reason=conscience_failure_context.get("failure_reason", "Unknown"),
                retry_guidance=conscience_failure_context.get("retry_guidance", ""),
            )

        # At this point input_data is guaranteed to be EnhancedDMAInputs
        input_dict = input_data.model_dump()

        enhanced_inputs = await self.faculty_integration.enhance_evaluation_with_faculties(
            original_thought=original_thought,
            triaged_inputs=input_dict,
            conscience_failure_context=conscience_failure_context,
        )
        enhanced_inputs.recursive_evaluation = True

        return await self.evaluate(enhanced_inputs, enable_recursive_evaluation=False)

    async def _handle_special_cases(self, input_data: EnhancedDMAInputs) -> Optional[ActionSelectionDMAResult]:
        """Handle special cases that override normal evaluation."""

        # Check for forced ponder
        ponder_result = await ActionSelectionSpecialCases.handle_ponder_force(input_data)
        if ponder_result:
            return ponder_result

        # Check wakeup task SPEAK requirement
        wakeup_result = await ActionSelectionSpecialCases.handle_wakeup_task_speak_requirement(input_data)
        if wakeup_result:
            return wakeup_result

        return None

    def _build_main_user_content(self, input_data: EnhancedDMAInputs, agent_name: str) -> str:
        """Build main user content, using template override if available."""
        template_user_override = self.prompts.get("user_prompt_template") if isinstance(self.prompts, dict) else None

        if template_user_override:
            thought_content = str(input_data.original_thought.content) if input_data.original_thought else ""
            available_actions = (
                ", ".join(a.value for a in input_data.permitted_actions)
                if input_data.permitted_actions
                else "speak, task_complete"
            )
            content = template_user_override.format(
                thought_content=thought_content, available_actions=available_actions
            )
            logger.debug(f"ASPDMA using template user_prompt_template override ({len(content)} chars)")
            return content

        return self.context_builder.build_main_user_content(input_data, agent_name)

    def _build_accord_with_metadata(self, original_thought: Any) -> str:
        """Build accord text with thought type metadata."""
        accord_mode = self.get_accord_mode()
        if accord_mode == "full":
            accord_text = ACCORD_TEXT
        elif accord_mode == "compressed":
            accord_text = ACCORD_TEXT_COMPRESSED
        else:
            return ""

        if original_thought and hasattr(original_thought, "thought_type"):
            return f"THOUGHT_TYPE={original_thought.thought_type.value}\n\n{accord_text}"
        return accord_text

    async def _perform_main_evaluation(
        self, input_data: EnhancedDMAInputs, enable_recursive_evaluation: bool
    ) -> ActionSelectionDMAResult:
        """Perform the main LLM-based evaluation."""
        input_images = getattr(input_data, "images", []) or []
        logger.info(f"[VISION] _perform_main_evaluation called with {len(input_images)} images")

        agent_identity = getattr(input_data, "agent_identity", {})
        agent_name = _get_value(agent_identity, "agent_name", "CIRISAgent")
        original_thought = input_data.original_thought

        # Pre-cache tools AND task context BEFORE building prompt
        await self.context_builder.pre_cache_context(original_thought)

        # Build main user content
        main_user_content = self._build_main_user_content(input_data, agent_name)

        # Append faculty insights if available
        if input_data.faculty_evaluations and self.faculty_integration:
            faculty_insights = self.faculty_integration.build_faculty_insights_string(input_data.faculty_evaluations)
            main_user_content += faculty_insights

        # Build messages
        system_message = self._build_system_message(input_data)
        accord_with_metadata = self._build_accord_with_metadata(original_thought)

        if input_images:
            logger.info(f"[VISION] ActionSelectionPDMA building multimodal content with {len(input_images)} images")
        user_content = self.build_multimodal_content(main_user_content, input_images)

        messages: List[JSONDict] = []
        if accord_with_metadata:
            messages.append({"role": "system", "content": accord_with_metadata})
        messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": user_content})

        # Store prompts for streaming/debugging
        self.last_system_prompt = system_message
        self.last_user_prompt = main_user_content

        # Use Gemini-compatible flat schema (no Union types)
        # This enables compatibility with providers that don't support Union (Google Gemini)
        result_tuple = await self.call_llm_structured(
            messages=messages,
            response_model=ASPDMALLMResult,
            max_tokens=4096,
            temperature=0.0,
            thought_id=input_data.original_thought.thought_id,
            task_id=input_data.original_thought.source_task_id,
        )

        # Extract the LLM result and convert to typed ActionSelectionDMAResult
        llm_result = cast(ASPDMALLMResult, result_tuple[0])

        # Get channel_id from context if available
        channel_id = _get_value(input_data.processing_context, "channel_id") if input_data.processing_context else None

        # Convert flat LLM result to typed ActionSelectionDMAResult
        final_result = convert_llm_result_to_action_result(
            llm_result=llm_result,
            channel_id=channel_id,
            raw_llm_response=None,  # Set if needed for debugging
            evaluation_time_ms=None,  # Set from metrics if available
            resource_usage=None,  # Set from metrics if available
            user_prompt=self.last_user_prompt,
        )

        if final_result.selected_action == HandlerActionType.OBSERVE:
            thought_id = input_data.original_thought.thought_id
            logger.warning(f"OBSERVE ACTION: Successfully created for thought {thought_id}")
            logger.warning(f"OBSERVE PARAMS: {final_result.action_parameters}")
            logger.warning(f"OBSERVE RATIONALE: {final_result.rationale}")

        return final_result

    def _extract_system_blocks(self, processing_context: Any) -> tuple[str, str, Any]:
        """Extract system snapshot block, user profiles block, and system snapshot object."""
        system_snapshot = _get_value(processing_context, "system_snapshot")
        if not system_snapshot:
            return "", "", None

        user_profiles = _get_value(system_snapshot, "user_profiles")
        return (
            format_system_snapshot(system_snapshot),
            format_user_profiles(user_profiles),
            system_snapshot,
        )

    def _validate_and_build_identity_block(self, system_snapshot: Any) -> str:
        """Validate identity exists and build the identity block. Raises on missing identity."""
        if not system_snapshot:
            raise ValueError(
                "CRITICAL: No system_snapshot in processing_context for ActionSelectionPDMA! "
                "Identity is required for ALL DMA evaluations. This is a fatal error."
            )

        agent_identity = _get_value(system_snapshot, "agent_identity")
        if not agent_identity:
            raise ValueError(
                "CRITICAL: No agent identity found in system_snapshot for ActionSelectionPDMA! "
                "Identity is required for ALL DMA evaluations. This is a fatal error."
            )

        agent_id = _get_value(agent_identity, "agent_id")
        description = _get_value(agent_identity, "description")
        role = _get_value(agent_identity, "role")

        for field_name, field_value in [("agent_id", agent_id), ("description", description), ("role", role)]:
            if not field_value:
                raise ValueError(
                    f"CRITICAL: {field_name} is missing from identity in ActionSelectionPDMA! This is a fatal error."
                )

        return (
            "=== CORE IDENTITY - THIS IS WHO YOU ARE! ===\n"
            f"Agent: {agent_id}\n"
            f"Description: {description}\n"
            f"Role: {role}\n"
            "============================================"
        )

    def _build_conscience_guidance_block(self, processing_context: Any) -> str:
        """Build conscience guidance block for retry format enforcement."""
        if not processing_context:
            return ""

        conscience_guidance = _get_value(processing_context, "conscience_guidance")
        if not conscience_guidance:
            return ""

        retry_attempt = conscience_guidance.get("retry_attempt", 1)
        original_failure = conscience_guidance.get("original_action_failed_because", "")

        logger.warning(f"[ASPDMA] Conscience guidance detected - retry {retry_attempt}: {original_failure[:100]}")

        return f"""
=== CRITICAL FORMAT RETRY ===
RETRY ATTEMPT: {retry_attempt}
PREVIOUS FAILURE: {original_failure}

YOUR PREVIOUS RESPONSE WAS REJECTED because it did not start with a classification word.

MANDATORY FIX: Your SPEAK content MUST start with exactly ONE of these words:
ETHICAL, UNETHICAL, REASONABLE, UNREASONABLE, MATCHES, CONTRADICTS, FAIR, UNFAIR, JUST, UNJUST, VALID, INVALID, MORAL, IMMORAL

DO NOT start with: "The", "This", "Your", "I", "In", "It", "My" or any other word.

CORRECT: "REASONABLE. The expectation is..."
WRONG: "The expectation is reasonable..."
=== END FORMAT RETRY ===
"""

    def _build_system_message(self, input_data: EnhancedDMAInputs) -> str:
        """Build the system message for LLM evaluation."""
        processing_context = input_data.processing_context

        system_snapshot_block = ""
        user_profiles_block = ""
        identity_block = ""

        if processing_context:
            system_snapshot_block, user_profiles_block, system_snapshot = self._extract_system_blocks(
                processing_context
            )
            identity_block = self._validate_and_build_identity_block(system_snapshot)

        # Check for direct system_prompt override from template (e.g., HE-300 format instructions)
        # Template overrides take precedence over YAML-based prompts
        template_system_override = None
        if isinstance(self.prompts, dict):
            template_system_override = self.prompts.get("system_prompt")

        if template_system_override:
            # Use template system_prompt directly - contains critical format instructions
            system_guidance = template_system_override
            logger.debug(f"ASPDMA using template system_prompt override ({len(system_guidance)} chars)")
        else:
            # Fall back to standard prompt building from YAML
            if isinstance(self.prompts, PromptCollection):
                system_header = self.prompts.system_header or ""
                decision_format = self.prompts.decision_format or ""
                closing_reminder = self.prompts.closing_reminder or ""
            else:
                system_header = self.prompts.get("system_header", "")
                decision_format = self.prompts.get("decision_format", "")
                closing_reminder = self.prompts.get("closing_reminder", "")

            system_guidance = DEFAULT_TEMPLATE.format(
                system_header=system_header,
                decision_format=decision_format,
                closing_reminder=closing_reminder,
            )

        # Extract conscience_guidance from processing_context for retry format enforcement
        conscience_guidance_block = self._build_conscience_guidance_block(processing_context)

        return format_system_prompt_blocks(
            identity_block,
            "",
            system_snapshot_block,
            user_profiles_block,
            None,
            system_guidance + conscience_guidance_block,
        )

    def _create_fallback_result(self, error_message: str) -> ActionSelectionDMAResult:
        """Create a fallback result for error cases."""

        fallback_params = PonderParams(questions=[f"System error during action selection: {error_message}"])

        return ActionSelectionDMAResult(
            selected_action=HandlerActionType.PONDER,
            action_parameters=fallback_params,
            rationale=f"Fallback due to error: {error_message}",
        )

    def __repr__(self) -> str:
        faculty_count = len(self.faculties) if self.faculties else 0
        return f"<ActionSelectionPDMAEvaluator model='{self.model_name}' faculties={faculty_count}>"
