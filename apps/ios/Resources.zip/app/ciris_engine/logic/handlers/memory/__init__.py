"""Memory handlers module."""
