"""
Service manifest schemas for typed module loading.

Provides typed schemas in service loading and module manifests.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Literal, Optional, Union

import logging
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ciris_engine.schemas.runtime.enums import ServiceType
from ciris_engine.schemas.types import JSONDict


class ServicePriority(str, Enum):
    """Service priority levels for registration."""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    NORMAL = "NORMAL"
    LOW = "LOW"


class ServiceCapabilityDeclaration(BaseModel):
    """Declaration of a service capability."""

    name: str = Field(..., description="Capability name (e.g., 'call_llm_structured')")
    description: str = Field(..., description="Human-readable description of the capability")
    version: str = Field(default="1.0.0", description="Capability version")
    parameters: Optional[Dict[str, str]] = Field(None, description="Parameter descriptions")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ServiceDependency(BaseModel):
    """Declaration of a service dependency."""

    service_type: ServiceType = Field(..., description="Type of service required")
    required: bool = Field(True, description="Whether this dependency is required")
    minimum_version: Optional[str] = Field(None, description="Minimum service version required")
    capabilities_required: List[str] = Field(default_factory=list, description="Required capabilities")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ServiceDeclaration(BaseModel):
    """Declaration of a service in a manifest."""

    type: ServiceType = Field(..., description="Service type this implements")
    class_path: str = Field(..., description="Full class path (e.g., 'mock_llm.service.MockLLMService')", alias="class")
    priority: ServicePriority = Field(ServicePriority.NORMAL, description="Service priority level")
    capabilities: List[str] = Field(default_factory=list, description="List of capability names")

    model_config = ConfigDict(extra="forbid", populate_by_name=True, defer_build=True)


class ModuleInfo(BaseModel):
    """Module-level information."""

    name: str = Field(..., description="Module name")
    version: str = Field(..., description="Module version")
    description: str = Field(..., description="Module description")
    author: str = Field(..., description="Module author")
    is_mock: bool = Field(False, description="Whether this is a MOCK module", alias="MOCK")
    license: Optional[str] = Field(None, description="Module license")
    homepage: Optional[str] = Field(None, description="Module homepage URL")
    safe_domain: Optional[bool] = Field(None, description="Whether module operates in safe domains")
    reference: bool = Field(False, description="Whether this is a reference/example module")
    for_qa: bool = Field(False, description="Whether this module is for QA/testing")
    # Consent/opt-in fields for privacy-sensitive adapters
    auto_load: bool = Field(True, description="Whether to auto-load this module")
    opt_in_required: bool = Field(False, description="Whether explicit opt-in is required")
    requires_consent: bool = Field(False, description="Whether user consent is required for data collection")
    # UI visibility - internal adapters should not appear in Add Adapter dialog
    internal_only: bool = Field(False, description="If True, adapter is hidden from UI and cannot be manually loaded")

    model_config = ConfigDict(extra="forbid", populate_by_name=True, defer_build=True)


class LegacyDependencies(BaseModel):
    """Legacy dependency format for backward compatibility."""

    protocols: List[str] = Field(default_factory=list, description="Required protocols")
    schemas: List[str] = Field(default_factory=list, description="Required schemas")
    external: Optional[Dict[str, str]] = Field(None, description="External package dependencies")
    internal: Optional[List[str]] = Field(None, description="Internal module dependencies")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ConfigurationParameter(BaseModel):
    """Configuration parameter definition."""

    type: str = Field(..., description="Parameter type (integer, float, string, boolean, array)")
    default: Optional[Union[int, float, str, bool, List[str]]] = Field(None, description="Default value (optional)")
    description: str = Field(..., description="Parameter description")
    env: Optional[str] = Field(None, description="Environment variable name")
    sensitivity: Optional[str] = Field(None, description="Sensitivity level (e.g., 'HIGH' for secrets)")
    required: bool = Field(True, description="Whether this parameter is required")
    enum: Optional[List[str]] = Field(None, description="Allowed values for string parameters")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class AdapterOAuthConfig(BaseModel):
    """OAuth configuration for adapter authentication workflows.

    This is distinct from OAuthConfig in wise_authority, which handles full
    OAuth provider configuration. This schema is for adapter configuration
    workflows that need OAuth authentication.
    """

    provider_name: str = Field(..., description="OAuth provider name")
    authorization_path: str = Field("/auth/authorize", description="OAuth authorization endpoint path")
    token_path: str = Field("/auth/token", description="OAuth token endpoint path")
    client_id_source: Literal["static", "indieauth"] = Field(
        "indieauth", description="Source of client ID (static value or IndieAuth discovery)"
    )
    scopes: List[str] = Field(default_factory=list, description="OAuth scopes to request")
    pkce_required: bool = Field(True, description="Whether PKCE is required for this OAuth flow")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class AdapterDeviceAuthConfig(BaseModel):
    """Device authorization (RFC 8628) configuration for adapter workflows.

    Used for CIRISNode and similar adapters that use device code flow
    instead of redirect-based OAuth.
    """

    provider_name: str = Field(..., description="Device auth provider name (e.g., 'CIRISPortal')")
    device_authorize_path: str = Field("/api/device/authorize", description="Device authorization endpoint path")
    device_token_path: str = Field("/api/device/token", description="Device token polling endpoint path")
    poll_interval: int = Field(5, description="Seconds between poll attempts")
    expires_in: int = Field(900, description="Device code expiration in seconds")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ConfigurationFieldDefinition(BaseModel):
    """Definition of a field within an input step."""

    # ONE KEY FOR THE FIELD'S IDENTITY. This carried `name` AND `field_id` as
    # alternatives, both optional, so a field could have neither -- and 15 of
    # 58 fields in the tree used one spelling while 43 used the other. Two
    # spellings of one fact is how a reader ends up matching on the wrong one.
    # `name` is required; `field_id` retires (migrated by
    # tools/dev/migrate_interactive_config.py). CIRISClient#39.
    name: str = Field(..., description="Field name -- the key this field writes")
    label: Optional[str] = Field(None, description="Human-readable label for the field")

    # Field type and input
    type: Optional[str] = Field(None, description="Field data type (string, integer, number, boolean, password)")
    input_type: Optional[str] = Field(None, description="Input control type (text, password, number, select)")

    # Field metadata
    description: Optional[str] = Field(None, description="Description of the field")
    placeholder: Optional[str] = Field(None, description="Placeholder text for input")
    default: Optional[Any] = Field(None, description="Default value")
    required: bool = Field(False, description="Whether this field is required")

    # Validation
    min: Optional[Union[int, float]] = Field(None, description="Minimum value")
    max: Optional[Union[int, float]] = Field(None, description="Maximum value")

    # Conditional display
    depends_on: Optional[Dict[str, Any]] = Field(None, description="Conditional display based on other fields")
    # DECLARED BECAUSE THEY ARE USED. `options` is read by the client's
    # ConfigFieldData; `sensitive` and `readonly` are written by manifests. With
    # extra="allow" an undeclared key validates silently, and silence is how
    # `field_id`, `field_name` and `optional` drifted in. The manifest lint
    # rejects any key not declared here.
    options: Optional[List[Any]] = Field(None, description="Static choices for a select-style field")
    sensitive: bool = Field(False, description="Value is a secret: mask it, never log it")
    readonly: bool = Field(False, description="Shown but not editable")

    model_config = ConfigDict(extra="allow", defer_build=True)  # Allow additional field-specific properties

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_field_id(cls, data: Any) -> Any:
        """Read the retired spelling; never write it.

        The tree uses one spelling (`name`, enforced by the manifest lint), but
        an out-of-tree adapter authored against the pre-#1154 schema still says
        `field_id`. Rejecting it here would make `discover_services()` drop that
        adapter with one error line at boot -- a silent removal from the
        operator's point of view. Normalise on the way in and say so, so the
        adapter keeps working and its author learns the spelling changed.
        """
        if isinstance(data, dict) and "name" not in data and "field_id" in data:
            data = dict(data)
            data["name"] = data.pop("field_id")
            logging.getLogger(__name__).warning(
                "interactive_config field %r uses the retired key `field_id`; read as `name`. "
                "Run tools/dev/migrate_interactive_config.py on this manifest (CIRISClient#39).",
                data["name"],
            )
        return data


class ConfigurationStep(BaseModel):
    """A step in an adapter configuration workflow."""

    step_id: str = Field(..., description="Unique identifier for this step")
    step_type: Literal["discovery", "oauth", "device_auth", "select", "input", "confirm"] = Field(
        ..., description="Type of configuration step"
    )
    title: str = Field(..., description="Human-readable step title")
    description: str = Field(..., description="Description of what this step does")

    # Discovery step fields
    discovery_method: Optional[str] = Field(
        None, description="Discovery method name (e.g., 'mdns', 'api_scan') for discovery steps"
    )

    # OAuth step fields
    oauth_config: Optional[AdapterOAuthConfig] = Field(None, description="OAuth configuration for oauth steps")

    # Device auth step fields (RFC 8628)
    device_auth_config: Optional[AdapterDeviceAuthConfig] = Field(
        None, description="Device authorization configuration for device_auth steps"
    )

    # Select step fields
    options_method: Optional[str] = Field(
        None, description="Method name to call for retrieving options in select steps"
    )
    multiple: bool = Field(False, description="Whether multiple selections are allowed")

    # Input step fields - complex form with multiple fields
    fields: Optional[List[ConfigurationFieldDefinition]] = Field(
        None, description="List of field definitions for input steps"
    )
    dynamic_fields: bool = Field(False, description="Whether fields are dynamically generated")

    # CONTENTS ARE ALWAYS `fields`. Three keys used to name what a step
    # collects: `fields` (a list), `field_name` (one name, on select steps)
    # and `field` (declared, used by nothing). A single field is a list of
    # one, and a select step's output is a field like any other. `field` and
    # `field_name` retire; the migration rewrites `field_name: x` as
    # `fields: [{name: x}]`. CIRISClient#39.
    input_type: Optional[str] = Field(None, description="Input type (text, password, number)")
    placeholder: Optional[str] = Field(None, description="Placeholder text")

    # ONE AXIS, ONE KEY. This carried `required` AND `optional`, both
    # defaulting to False, so a step with neither was "not required and not
    # optional" -- a third state the schema permitted and no reader could act
    # on. One step in the tree carried both. `optional` retires; absent means
    # not required, and that is the only thing absence can mean. CIRISClient#39.
    required: bool = Field(False, description="Whether this step is required")
    default: Optional[Any] = Field(None, description="Default value for the field")
    validation: Optional[Dict[str, Any]] = Field(None, description="Validation rules (e.g., min, max, pattern)")

    # TWO CONCEPTS, TWO KEYS, EACH ONE SHAPE. `depends_on` is ORDERING: the
    # step ids that must complete first. `condition` is DISPLAY: a predicate
    # on a collected value. external_data_sql uses both on one step and
    # means both. What drifted was `depends_on` also admitting a dict that
    # nothing wrote -- one key, two shapes. It is a list now.
    depends_on: Optional[List[str]] = Field(
        None, description="Step ids that must complete before this one"
    )
    condition: Optional[Dict[str, Any]] = Field(
        None, description="Predicate on a collected value for showing this step (e.g., {field: 'x', equals: 'y'})"
    )

    # Confirm step fields
    action: Optional[str] = Field(None, description="Action to perform on confirm (e.g., 'test_connection')")

    model_config = ConfigDict(extra="allow", defer_build=True)  # Allow additional step-specific properties

    @model_validator(mode="before")
    @classmethod
    def _accept_legacy_optional(cls, data: Any) -> Any:
        """Read the retired `optional` spelling as the inverse of `required`; never write it.

        With `extra="allow"` an out-of-tree `optional: false` step validated
        silently while `required` kept its default (False) -- a step the author
        marked mandatory became skippable, and the wizard accepted an empty
        selection for it. `required` wins when both are present.
        """
        if isinstance(data, dict) and "optional" in data:
            data = dict(data)
            legacy = data.pop("optional")
            if "required" not in data:
                data["required"] = not bool(legacy)
            logging.getLogger(__name__).warning(
                "interactive_config step %r uses the retired key `optional`; read as required=%s. "
                "Run tools/dev/migrate_interactive_config.py on this manifest (CIRISClient#39).",
                data.get("step_id"),
                data.get("required"),
            )
        return data


class InteractiveConfiguration(BaseModel):
    """Interactive configuration definition for adapters.

    Enables adapters to define multi-step configuration workflows including
    discovery, OAuth authentication, and user input steps.
    """

    required: bool = Field(False, description="Whether interactive configuration is required")
    workflow_type: Literal["wizard", "discovery_then_config", "simple_config"] = Field(
        "wizard", description="Type of configuration workflow"
    )
    steps: List[ConfigurationStep] = Field(default_factory=list, description="Ordered list of configuration steps")
    completion_method: str = Field("apply_config", description="Method name to call when configuration is complete")

    model_config = ConfigDict(extra="allow", defer_build=True)  # Allow reference/documentation fields


class ServiceManifest(BaseModel):
    """Complete service module manifest."""

    module: ModuleInfo = Field(..., description="Module information")
    services: List[ServiceDeclaration] = Field(default_factory=list, description="Services provided")
    capabilities: List[str] = Field(default_factory=list, description="Global capabilities list")
    dependencies: Optional[LegacyDependencies] = Field(None, description="Legacy dependencies format")
    configuration: Optional[Dict[str, ConfigurationParameter]] = Field(None, description="Configuration parameters")
    exports: Optional[Dict[str, Union[str, List[str]]]] = Field(
        None, description="Exported components (string or list)"
    )
    metadata: Optional[JSONDict] = Field(None, description="Additional metadata")
    requirements: List[str] = Field(default_factory=list, description="Python package requirements")
    prohibited_sensors: Optional[List[str]] = Field(None, description="Prohibited sensor types for sensor modules")
    prohibited_capabilities: Optional[List[str]] = Field(None, description="Prohibited capabilities for this module")
    interactive_config: Optional[InteractiveConfiguration] = Field(
        None, description="Interactive configuration workflow for adapters"
    )
    platform_requirements: Optional[List[str]] = Field(
        None, description="Platform attestation requirements (e.g., 'android_play_integrity', 'google_native_auth')"
    )
    platform_requirements_rationale: Optional[str] = Field(
        None, description="Explanation of why platform requirements are needed"
    )
    cli_dependencies: List[str] = Field(
        default_factory=list, description="Required CLI tools/binaries (e.g., 'tmux', 'mcporter')"
    )

    model_config = ConfigDict(extra="forbid", defer_build=True)

    def validate_manifest(self) -> List[str]:
        """Validate manifest consistency.

        Returns:
            List of validation errors (empty if valid)
        """
        errors = []

        # Global capabilities are just a list in the current format
        # Service capabilities can reference these or define their own

        # Check for MOCK module warnings
        if self.module.is_mock:
            for service in self.services:
                if service.priority == ServicePriority.CRITICAL:
                    # MOCK modules often use CRITICAL priority to override real services
                    # This is actually allowed but worth noting
                    pass

        # Validate service types
        for service in self.services:
            try:
                # Ensure service type is valid
                _ = service.type
            except Exception as e:
                errors.append(f"Invalid service type in {service.class_path}: {e}")

        return errors


class ServiceMetadata(BaseModel):
    """Runtime metadata about a loaded service."""

    service_type: ServiceType = Field(..., description="Type of this service")
    module_name: str = Field(..., description="Module this service came from")
    class_name: str = Field(..., description="Service class name")
    version: str = Field(..., description="Service version")
    is_mock: bool = Field(False, description="Whether this is a MOCK service")
    loaded_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    capabilities: List[str] = Field(default_factory=list, description="Active capabilities")
    priority: ServicePriority = Field(ServicePriority.NORMAL, description="Service priority")
    health_status: str = Field("unknown", description="Current health status")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ModuleLoadResult(BaseModel):
    """Result of loading a module."""

    module_name: str = Field(..., description="Module that was loaded")
    success: bool = Field(..., description="Whether load succeeded")
    services_loaded: List[ServiceMetadata] = Field(default_factory=list, description="Services that were loaded")
    errors: List[str] = Field(default_factory=list, description="Any errors encountered")
    warnings: List[str] = Field(default_factory=list, description="Any warnings generated")

    model_config = ConfigDict(extra="forbid", defer_build=True)


class ServiceRegistration(BaseModel):
    """Registration information for a service in the registry."""

    service_type: ServiceType = Field(..., description="Type of service")
    provider_id: str = Field(..., description="Unique ID of the provider instance")
    priority: ServicePriority = Field(..., description="Registration priority")
    capabilities: List[str] = Field(default_factory=list, description="Service capabilities")
    metadata: ServiceMetadata = Field(..., description="Service metadata")
    registered_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = ConfigDict(extra="forbid", defer_build=True)
