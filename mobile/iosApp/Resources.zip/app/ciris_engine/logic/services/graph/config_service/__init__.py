"""Config Service Module."""

from .service import GraphConfigService

__all__ = ["GraphConfigService"]
